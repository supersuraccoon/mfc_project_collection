// MyCompressDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MyCompress.h"
#include "MyCompressDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();
	
	// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA
	
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	
	// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
//{{AFX_MSG_MAP(CAboutDlg)
// No message handlers
//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyCompressDlg dialog

CMyCompressDlg::CMyCompressDlg(CWnd* pParent /*=NULL*/)
: CDialog(CMyCompressDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMyCompressDlg)
	// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMyCompressDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyCompressDlg)
	// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMyCompressDlg, CDialog)
//{{AFX_MSG_MAP(CMyCompressDlg)
ON_WM_SYSCOMMAND()
ON_WM_PAINT()
ON_WM_QUERYDRAGICON()
ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
ON_BN_CLICKED(IDC_LZSSC, OnLzssc)
ON_BN_CLICKED(IDC_LZSSDE, OnLzssde)
//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyCompressDlg message handlers

BOOL CMyCompressDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	// Add "About..." menu item to system menu.
	
	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);
	
	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}
	
	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMyCompressDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMyCompressDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting
		
		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);
		
		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
		
		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMyCompressDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

//RLEѹ���㷨
void CMyCompressDlg::OnButton1()
{
	// TODO: Add your control notification handler code here
	BYTE* buf;//��ȡ�ļ�
	CString path;//�ļ�����
	CString ext;//��׺��
	CString compress;//ѹ�����ļ���
	int totalLength;//�ļ��ܳ���
	CFileDialog dlg(TRUE);
	dlg.m_ofn.lpstrTitle="My Dialog...";
	dlg.m_ofn.lpstrFilter="ALL Files(*.*)\0*.*";
	dlg.m_ofn.lpstrDefExt="txt";
	if (dlg.DoModal()==IDOK)
	{
		path=dlg.GetPathName();
		ext=dlg.GetFileExt();
		CFile file(path,CFile::modeRead);
		totalLength=file.GetLength();
		buf=new BYTE[totalLength];
		
		path=dlg.GetPathName();
		int find=path.ReverseFind('.');
		path=path.Left(find+1);
		compress=path+ext+"RLE";//�����µ��ļ��� ��׺ΪRLE
		CFile fileCopy(compress,CFile::modeCreate|CFile::modeWrite);
		
		int flag=48;//ѹ����ʼ�ı�־�ַ�
		
		file.Read(buf,totalLength);
		for (int i=0,j,index=0;i<totalLength;i=j)
		{
			j=i+1;
			int count=1;
			while(buf[i]==buf[j]&&count<255)//������ͬ���ַ��� ����Ϊ256
			{
				j++;
				count++;
			}
			
			if (count>4)//��С�ڵ����ĸ���ѹ�� ��Ϊ��û�н�ʡ�ռ�
			{
				fileCopy.Write(&flag,1);
				fileCopy.Write(&(count),1);
				fileCopy.Write(&buf[i],1);
			}
			else
			{
				for (int k=0,j=i;k<count;j++)
				{
					if (buf[j]=='0')//��Ϊ0����д������0
					{
						fileCopy.Write(&flag,1);
						fileCopy.Write(&flag,1);
					}
					else
						fileCopy.Write(&buf[j],1);
					k++;
				}
			}
		}
		file.Close();
		fileCopy.Close();
	}
	delete buf;
}

//RLE��ѹ�㷨
void CMyCompressDlg::OnButton2() 
{
	// TODO: Add your control notification handler code here
	BYTE* buf;
	CString path;
	CString ext;
	CString decompress;
	int totalLength;
	CFileDialog dlg(TRUE);
	dlg.m_ofn.lpstrTitle="My Dialog...";
	dlg.m_ofn.lpstrFilter="ALL Files(*.*)\0*.*";
	dlg.m_ofn.lpstrDefExt="txt";
	if (dlg.DoModal()==IDOK)
	{
		path=dlg.GetPathName();
		CFile file(path,CFile::modeRead);
		totalLength=file.GetLength();
		ext=dlg.GetFileExt();
		if (ext.Find("RLE",0)==-1)
		{
			MessageBox("�ļ���ʽ����!!!");
			return;
		}
		
		path.Delete(path.GetLength()-3,3);
		decompress=path;
		CFile fileDeCopy(decompress,CFile::modeCreate|CFile::modeWrite);
		buf=new BYTE[totalLength];
		int tag=48;
		
		file.Read(buf,totalLength);
		for (int i=0,j,index=0;i<totalLength;i=j)
		{
			j=i+1;
			if (buf[i]==48&&buf[j]==48)//�ж��Ƿ�Ϊ��־�ַ�
			{
				fileDeCopy.Write(&tag,1);
				j++;
				continue;
			}
			else
				if (buf[i]==48&&buf[j]!=48)//�ж��Ƿ�Ϊ0�ַ�
				{
					int count=buf[j];
					j++;
					for (int k=0;k<count;k++)
					{
						fileDeCopy.Write(&buf[j],1);
					}
					j++;
					continue;
				}
				
				fileDeCopy.Write(&buf[i],1);
		}
		file.Close();
		fileDeCopy.Close();
	}
	delete buf;
}

//LZSSѹ���㷨
void CMyCompressDlg::OnLzssc() 
{
	// TODO: Add your control notification handler code here
	int preLength=0;//����洢������
	int postIndex=0;//������ʵλ��
	int tag=4;//��д�������ַ�
	int pos;//���ַ���λ��
	
	char* buf;
	CString path;
	CString ext;
	CString compress;
	int totalLength;
	int back=0;//�˻صĲ���
	int go=0;//��ȡ���ַ���
	int length=0;
	int index=-1;
	
	CFileDialog dlg(TRUE);
	dlg.m_ofn.lpstrTitle="My Dialog...";
	dlg.m_ofn.lpstrFilter="ALL Files(*.*)\0*.*";
	dlg.m_ofn.lpstrDefExt="txt";
	if (dlg.DoModal()==IDOK)
	{
		path=dlg.GetPathName();
		ext=dlg.GetFileExt();
		CFile file(path,CFile::modeRead);
		totalLength=file.GetLength();
		buf=new char[totalLength];
		
		path=dlg.GetPathName();
		int find=path.ReverseFind('.');
		path=path.Left(find+1);
		compress=path+ext+"LZSSC";
		CFile fileCopy(compress,CFile::modeCreate|CFile::modeWrite);
		
		int flag=48;
		
		file.Read(buf,totalLength);
		fileCopy.Write(&buf[0],1);
		fileCopy.Write(&buf[1],1);
		fileCopy.Write(&buf[2],1);
		totalLength-=3;
		
		for (;totalLength!=0;tag+=length,totalLength-=length,pos=-1)
		{		
			preLength=tag-1;
			for (length=min(preLength,totalLength);length>2;length--)
			{
				char *sub=new char[preLength];
				strcpy(sub,&buf[tag-1]);
				pos=FindSubstr(buf,sub,tag,length);//�ַ���ƥ��
				if (pos!=-1)
				{
					break;
				}
				else
				{
					continue;
				}
			}
			
			if (pos==-1)//��ƥ���ַ�
			{
				fileCopy.Write(&buf[tag-1],length);		
			}
			else
			{//��ѹ��
				back=tag-pos-1;
				go=length;
				
				fileCopy.Write(&flag,1);
				fileCopy.Write(&back,1);
				fileCopy.Write(&go,1);
			}
		}
	}
	delete buf;
}

//LZSS��ѹ�㷨
void CMyCompressDlg::OnLzssde() 
{
	// TODO: Add your control notification handler code here
	int preLength=0;
	int postIndex=0;
	int tag=3;
	char* tmp;
	char* buf;
	CString path;
	CString ext;
	CString compress;
	int totalLength;
	int back=0;
	int go=0;
	int length=0;
	int flag=48;
	CFileDialog dlg(TRUE);
	dlg.m_ofn.lpstrTitle="My Dialog...";
	dlg.m_ofn.lpstrFilter="ALL Files(*.*)\0*.*";
	dlg.m_ofn.lpstrDefExt="txt";
	if (dlg.DoModal()==IDOK)
	{
		path=dlg.GetPathName();
		ext=dlg.GetFileExt();
		CFile file(path,CFile::modeRead);
		totalLength=file.GetLength();
		buf=new char[totalLength];
		
		path=dlg.GetPathName();
		int find=path.ReverseFind('.');
		path=path.Left(find+1);
		compress=path+ext+"LZSSC";
		CFile fileCopy(compress,CFile::modeCreate|CFile::modeWrite);
		
		file.Read(buf,totalLength);
		fileCopy.Write(&buf[0],1);
		fileCopy.Write(&buf[1],1);
		fileCopy.Write(&buf[2],1);
		totalLength-=3;
		
		for (;totalLength!=0;tag+=length,totalLength-=length)
		{		
			preLength=tag;
			length=1;
			if (buf[tag]==48)
			{
				if (buf[tag+1]!=48)
				{
					back=buf[++tag];
					go=buf[++tag];
					
					length=go;
					tmp=new char[length];
					strcpy(tmp,&buf[preLength-back]);
					
					fileCopy.Write(tmp,length);
				}
				else
				{
					fileCopy.Write(&flag,1);
					length++;
				}
			}
			
			else
				fileCopy.Write(&buf[tag],1);
		}
	}
	delete buf;
}

//�ַ���ƥ�� sΪ���ַ�����tΪ���ַ�����posΪs�Ĳ�ѯλ�ã�lenΪt�ĳ��ȣ�����ƥ��λ��
int CMyCompressDlg::FindSubstr(char s[], char t[] ,int pos, int len)
{
	int i=0,j=0,slen,tlen;      
	slen=pos;   
	tlen=len;   
	while(i<slen&&j<tlen)   
	{   
		if(s[i]==t[j])   
		{   
			i++;   
			j++;   
		}   
		else   
		{   
			i=i-j+1;   
			j=0;   
		}   
	}   
	if(j>=tlen)   
		return i-tlen;   
	return -1;
}
