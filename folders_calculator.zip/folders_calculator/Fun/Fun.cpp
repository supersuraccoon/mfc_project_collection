#include <afx.h>
#include <math.h>


int MyMax(double i,double j)
{
	if(i<j)
		return -1;
	else
		if(i==j)
			return 0;
		else
			return 1;
}


int MyMin(double i,double j)
{
	if(i>j)
		return -1;
	else
		if(i==j)
			return 0;
		else
			return 1;
}

void ResetStr(CString str,double &temp)
{
	int index=0;
	if(str.Right(2)=="KB")
		index=0;
	else 
		if(str.Right(2)=="MB")
			index=1;
		else
			if(str.Right(2)=="GB")
				index=2;
			else
				index=-1;
    temp=atof(str.Left(str.GetLength()-2));
	temp*=pow(1024,index);
	
}

