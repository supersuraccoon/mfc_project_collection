// SearchDlg.cpp : implementation file
//

#include "stdafx.h"
#include "8.h"
#include "8Dlg.h"
#include "SearchDlg.h"
#include "math.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

_declspec(dllimport) int MyMin(double i,double j);
_declspec(dllimport) int MyMax(double i,double j);
_declspec(dllimport) void ResetStr(CString str,double &temp);

int timer;
CString Path="";
CString oPath="";
bool sflag=true;
bool scompare=true;

/////////////////////////////////////////////////////////////////////////////
// CSearchDlg dialog


CSearchDlg::CSearchDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSearchDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSearchDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	path="";
	byte=0;
	in=true;
}

void CSearchDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSearchDlg)
	DDX_Control(pDX, IDC_LIST2, m_search_list);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSearchDlg, CDialog)
	//{{AFX_MSG_MAP(CSearchDlg)
	ON_BN_CLICKED(IDC_AGAIN, OnAgain)
	ON_WM_CREATE()
	ON_WM_TIMER()
	ON_NOTIFY(NM_CLICK, IDC_LIST2, OnClickList2)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST2, OnDblclkList2)
	ON_NOTIFY(LVN_COLUMNCLICK, IDC_LIST2, OnColumnclickList2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSearchDlg message handlers

BOOL CSearchDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here  
	char *szColumn[]={"·��","��С"};
	int widths[]={250,98,50};
	LV_COLUMN lvc;
	lvc.mask=LVCF_FMT|LVCF_WIDTH|LVCF_TEXT|LVCF_SUBITEM;
	lvc.fmt=LVCFMT_LEFT;
	for(int i=0;i<2;i++) 
	{//�������
		lvc.pszText=szColumn[i];
		lvc.cx=widths[i];
		lvc.iSubItem=i;
		m_search_list.InsertColumn(i,&lvc);
	}
	m_search_list.SetExtendedStyle(m_search_list.GetExtendedStyle()|LVS_EX_GRIDLINES|
		LVS_EX_FULLROWSELECT); 
	
	CFont *font=new CFont;
	//font->CreatePointFont(5,"����"); 
	font->CreateFont(16,0,0,0,FW_DONTCARE,FALSE,FALSE,0,ANSI_CHARSET,OUT_DEFAULT_PRECIS,
		CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH|FF_SWISS,"����");

    timer=SetTimer(1,1000,NULL);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSearchDlg::CountAgain(void)
{
	double none_file=0;
	double total_file=0;
    static int index=0;

	CFileFind  ff;
	BOOL  bFound; 

	if(path=="")
		return;
	bFound=ff.FindFile(path+"\\*.*"); 
	while(bFound)  
	{  
		bFound=ff.FindNextFile();  
		CString sFilePath=ff.GetFilePath();  
		
		if(ff.IsDirectory())  
		{  
			if(!ff.IsDots())  
			{
				m_search_list.InsertItem(0,sFilePath);
				ListFolder(sFilePath);
				total_file+=byte;
	
				WeightCount(byte);
				
				byte=0;
			}
		}
		else
			none_file+=ff.GetLength();
	}  
	
	total_file+=none_file;
	m_search_list.InsertItem(0,"��Ŀ¼�ļ�");

	WeightCount(none_file);
   
	in=false;

	ff.Close();
}

void CSearchDlg::SetPath(CString str)
{
	path=str;
	oPath=str;
}

void CSearchDlg::ListFolder(CString sPath)
{
	CFileFind  ff;  
	BOOL  bFound;  
	bFound=ff.FindFile(sPath+"\\*.*");  
	while(bFound)  
	{  
		bFound=ff.FindNextFile();  
		CString sFilePath=ff.GetFilePath();  
		
		if(ff.IsDirectory())  
		{  
			if(!ff.IsDots())  
				ListFolder(sFilePath); 
		}  
		else  
		{  
			CString str;
			char temp[300];
			byte+=ff.GetLength();
			_gcvt(byte,10,temp);
			str=temp;

			WeightCount(byte);
			
			m_search_list.UpdateWindow();
		}  
	}  
	ff.Close();
}

CString CSearchDlg::WeightCount(double dtemp)
{
	CString str;
	char temp[300];
	_gcvt(dtemp,10,temp);
	str=temp;
	
	if(dtemp==0)
		str+="0B";
	else
		if(0<dtemp&&dtemp<=1024*0.8)
			str+="B";
		else
			if(1024*0.8<dtemp&&dtemp<=(1024*1024*0.8))
			{
				_gcvt((int((dtemp/1024*100.0+0.05))/100.0),10,temp);
				str=temp;
				str+="KB";
			}
			else
				if((1024*1024*0.8)<dtemp&&dtemp<=(1024*1024*1024*0.8))
				{
					_gcvt((int((dtemp/(1024*1024)*100.0+0.05))/100.0),10,temp);
					str=temp;
					str+="MB";
				}
				else
				{
					_gcvt((int((dtemp/(1024*1024*1024)*100.0+0.05))/100.0),10,temp);
					str=temp;
					str+="GB";
				}	

	if(in)
		m_search_list.SetItemText(0,1,str);

	return str;
}

void CSearchDlg::OnAgain() 
{
	// TODO: Add your control notification handler code here
	if(Path=="��Ŀ¼�ļ�"||Path=="")
		MessageBox("����ȷѡ��·��!","����",MB_ICONWARNING);
	else
	{
		CSearchDlg dlg;
		dlg.SetPath(Path);
		dlg.DoModal();
	}
}

int CSearchDlg::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	
	return 0;
}

void CSearchDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	CountAgain();   
	KillTimer(1);

	CDialog::OnTimer(nIDEvent);
}

void CSearchDlg::OnClickList2(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	int row=0;
	LPNMITEMACTIVATE temp=(LPNMITEMACTIVATE)pNMHDR;  
	row=temp->iItem;
    
	Path=m_search_list.GetItemText(row,0);

	*pResult = 0;
}

void CSearchDlg::OnDblclkList2(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	CString str="";
	int row=0;
	LPNMITEMACTIVATE temp=(LPNMITEMACTIVATE)pNMHDR;  
	row=temp->iItem;
    
	str=m_search_list.GetItemText(row,0);

	if(str!=""&&str!="��Ŀ¼�ļ�")
		ShellExecute(m_hWnd, NULL, str, NULL, NULL, SW_SHOWNORMAL);
	else
		if(str=="��Ŀ¼�ļ�")
		{
			//int find=path.ReverseFind('\\');
			//CString newpath=path.Left(find+1);
			ShellExecute(m_hWnd, NULL, oPath, NULL, NULL, SW_SHOWNORMAL);
		}


	*pResult = 0;
}

static int CALLBACK ListCompare(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort)
{
    double temp1;
	double temp2;

	CListCtrl* pListCtrl=(CListCtrl*)lParamSort;   

    CString strItem1=pListCtrl->GetItemText(lParam1,1);   
    CString strItem2=pListCtrl->GetItemText(lParam2,1);  

    ResetStr(strItem1,temp1);
	ResetStr(strItem2,temp2);

	if(scompare)
		return  MyMax(temp1,temp2);  
	else
		return  MyMin(temp1,temp2);
}

void CSearchDlg::OnColumnclickList2(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
		int  i=m_search_list.GetItemCount();   
    while(i--)
		m_search_list.SetItemData(i,i);     
	
	//LPNMITEMACTIVATE temp=(LPNMITEMACTIVATE)pNMHDR; /////////??????
	if(!sflag)
	{
		SetHeaderBitmap(1,IDB_BITMAP3,NULL);
		sflag=true;
		scompare=false;
		m_search_list.SortItems(ListCompare,(DWORD)&m_search_list);
	}
	else
	{
		SetHeaderBitmap(1,IDB_BITMAP2,NULL);
		sflag=false;
		scompare=true;
		m_search_list.SortItems(ListCompare,(DWORD)&m_search_list);
	}

	
	*pResult = 0;
}

void CSearchDlg::SetHeaderBitmap(int nCol, int nBitmap, DWORD dwRemove)
{
	CHeaderCtrl*  pHeader=(CHeaderCtrl*)m_search_list.GetDlgItem(0);   
	if(pHeader==NULL)  
		return   ;   
	HD_ITEM  hdi;   
	hdi.mask=HDI_FORMAT;   
	pHeader->GetItem(nCol,&hdi);   
	hdi.mask=HDI_BITMAP|HDI_FORMAT;   
	hdi.fmt|=HDF_BITMAP;   
	hdi.hbm =(HBITMAP)::LoadImage(AfxGetInstanceHandle(),MAKEINTRESOURCE(nBitmap),
		IMAGE_BITMAP,0,0,LR_LOADMAP3DCOLORS);  
	if(dwRemove)   
		hdi.fmt&= ~dwRemove;   
	
	pHeader->SetItem(nCol,&hdi);   
}
