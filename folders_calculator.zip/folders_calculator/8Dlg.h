// 8Dlg.h : header file
//

#if !defined(AFX_8DLG_H__67E0C47A_4B93_46AA_8192_27424AF5D83B__INCLUDED_)
#define AFX_8DLG_H__67E0C47A_4B93_46AA_8192_27424AF5D83B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CMy8Dlg dialog

class CMy8Dlg : public CDialog
{
// Construction
public:
    void MakeAccumulation(void);
	int DeleteDirectory(CString szFolder);
	void AutoRun(void);
	HTREEITEM GetNode(char *pText, HTREEITEM parentNode);
	BOOL SetTransparent(HWND hWnd, COLORREF crKey, BYTE bAlpha, DWORD dwFlags);
	double total_amount; 
	double byte;
	CString sPath;

	HTREEITEM m_hRoot;
	CToolTipCtrl   m_myToolTip;	
	ULARGE_INTEGER uliUserFree,uliTotal,uliRealFree;

	void SetHeaderBitmap(int nCol, int nBitmap, DWORD dwRemove);
	void AddSubDir(HTREEITEM hParent);
	void GetDriveDir(HTREEITEM hParent);
	void GetLogicalDrives(HTREEITEM hParent);
	void ListFolder(CString sPath);
	
	CString WeightCount(double dtemp);
	CString GetFullPath(HTREEITEM hCurrent);

	CMy8Dlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CMy8Dlg)
	enum { IDD = IDD_MY8_DIALOG };
	CButton	m_topmost;
	CEdit	m_time;
	CComboBox	m_combo;
	CStatic	m_4;
	CStatic	m_3;
	CStatic	m_2;
	CStatic	m_1;
	CTreeCtrl	m_tree;
	CListCtrl	m_caller_list;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMy8Dlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CToolTipCtrl m_tooltip;
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMy8Dlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnAdd();
	afx_msg void OnSelchangedTree1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnClear();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnColumnclickList2(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDblclkList2(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnItemexpandedTree1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTest();
	afx_msg void OnClickList2(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnClose();
	afx_msg void OnDelete();
	afx_msg void OnDeleteitemTree1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnHelp();
	afx_msg void OnTimer(UINT nIDEvent);
	virtual void OnOK();
	afx_msg void OnRelate();
	afx_msg void OnDesrelate();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDropFiles(HDROP hDropInfo);
	afx_msg void OnButton2();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_8DLG_H__67E0C47A_4B93_46AA_8192_27424AF5D83B__INCLUDED_)
