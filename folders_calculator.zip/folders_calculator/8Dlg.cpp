// 8Dlg.cpp : implementation file
//
#include "stdafx.h"
#include "8.h"
#include "8Dlg.h"
#include "SearchDlg.h"
#include "HelpDlg.h"
#include <math.h>
#include <Windows.h>
#include <Winuser.h>
#include "SkinPPWTL.h"

#define WS_EX_LAYERED	0x00080000
#define LWA_ALPHA		0x00000002

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif       

_declspec(dllimport) int MyMin(double i,double j);
_declspec(dllimport) int MyMax(double i,double j);
_declspec(dllimport) void ResetStr(CString str,double &temp);
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

bool flag=true;
bool compare=true;
bool insert=true;
CString gPath="";
CString DropPath="";
int gRow;
HMODULE hUserDll;

CString m_Names;

UINT MyThreadFunction( LPVOID pParam )
{
	//SetTimer(::AfxGetApp()->GetMainWnd()->m_hWnd,1,1000,NULL);
	
	void CMy8Dlg::OnAdd();

	return 1;
}


class CAboutDlg : public CDialog
{
public:
	CAboutDlg();
	
	// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA
	
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	
	// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
//{{AFX_MSG_MAP(CAboutDlg)
// No message handlers
//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMy8Dlg dialog

CMy8Dlg::CMy8Dlg(CWnd* pParent /*=NULL*/)
: CDialog(CMy8Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMy8Dlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDI_ICON1);
	byte=0;
	total_amount=0;
    sPath="";
}

void CMy8Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMy8Dlg)
	DDX_Control(pDX, IDC_BUTTON2, m_topmost);
	DDX_Control(pDX, IDC_EDIT5, m_time);
	DDX_Control(pDX, IDC_STATIC_4, m_4);
	DDX_Control(pDX, IDC_STATIC_3, m_3);
	DDX_Control(pDX, IDC_STATIC_2, m_2);
	DDX_Control(pDX, IDC_STATIC_1, m_1);
	DDX_Control(pDX, IDC_TREE1, m_tree);
	DDX_Control(pDX, IDC_LIST2, m_caller_list);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMy8Dlg, CDialog)
//{{AFX_MSG_MAP(CMy8Dlg)
ON_WM_SYSCOMMAND()
ON_WM_PAINT()
ON_WM_QUERYDRAGICON()
ON_BN_CLICKED(IDC_ADD, OnAdd)
ON_NOTIFY(TVN_SELCHANGED, IDC_TREE1, OnSelchangedTree1)
ON_BN_CLICKED(IDC_CLEAR, OnClear)
ON_WM_ERASEBKGND()
ON_NOTIFY(LVN_COLUMNCLICK, IDC_LIST2, OnColumnclickList2)
ON_NOTIFY(NM_DBLCLK, IDC_LIST2, OnDblclkList2)
ON_NOTIFY(TVN_ITEMEXPANDED, IDC_TREE1, OnItemexpandedTree1)
ON_BN_CLICKED(IDC_TEST, OnTest)
ON_NOTIFY(NM_CLICK, IDC_LIST2, OnClickList2)
ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_DELETE, OnDelete)
	ON_NOTIFY(TVN_DELETEITEM, IDC_TREE1, OnDeleteitemTree1)
	ON_BN_CLICKED(IDC_HELP, OnHelp)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_DESRELATE, OnDesrelate)
	ON_WM_CREATE()
	ON_WM_DROPFILES()
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMy8Dlg message handlers

int nSubItem;

BOOL CMy8Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	// Add "About..." menu item to system menu.
	
	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);
	
	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}
	

	hUserDll= LoadLibrary("User32.DLL"); 
	//Change style to layered window style...
	//::SetWindowLong(m_hWnd, GWL_EXSTYLE,::GetWindowLong(m_hWnd,GWL_EXSTYLE)|WS_EX_LAYERED);
	//SetTransparent(m_hWnd, 0, 255*100/100,LWA_ALPHA );
	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, TRUE);		// Set small icon
	
	// TODO: Add extra initialization here
	//ModifyStyle(0,WS_MINIMIZEBOX);
	//SetWindowPos(&wndTopMost,0,0,0,0,SWP_NOSIZE|SWP_NOMOVE);
	
	char *szColumn[]={"·��","��С"};
	int widths[]={250,98,50};
	LV_COLUMN lvc;
	lvc.mask=LVCF_FMT|LVCF_WIDTH|LVCF_TEXT|LVCF_SUBITEM;
	lvc.fmt=LVCFMT_LEFT;
	for(int i=0;i<2;i++) 
	{//�������
		lvc.pszText=szColumn[i];
		lvc.cx=widths[i];
		lvc.iSubItem=i;
		m_caller_list.InsertColumn(i,&lvc);
	}
	m_caller_list.SetExtendedStyle(m_caller_list.GetExtendedStyle()|LVS_EX_GRIDLINES|
		LVS_EX_FULLROWSELECT); 
	
	DWORD dwStyle = GetWindowLong(m_tree.m_hWnd,GWL_STYLE);
	dwStyle |= TVS_HASBUTTONS | TVS_HASLINES | TVS_LINESATROOT;
	SetWindowLong(m_tree.m_hWnd,GWL_STYLE,dwStyle);
    m_hRoot = m_tree.InsertItem("�ҵĵ���");
	GetLogicalDrives(m_hRoot);
	GetDriveDir(m_hRoot);
	//m_tree.Expand(m_hRoot,TVE_EXPAND);
	
	CFont *font=new CFont;
	//font->CreatePointFont(5,"����"); 
	font->CreateFont(16,0,0,0,FW_DONTCARE,FALSE,FALSE,0,ANSI_CHARSET,OUT_DEFAULT_PRECIS,
		CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH|FF_SWISS,"����");
	
	m_1.SetFont(font);
	m_2.SetFont(font);
	m_3.SetFont(font);
	m_4.SetFont(font);
	
	
	m_myToolTip.Create(this);   
	m_myToolTip.Activate(TRUE);    
	m_myToolTip.AddTool(GetDlgItem(IDC_LIST2),"˫��·����ϸ�鿴�ļ���");   
	m_myToolTip.AddTool(GetDlgItem(IDC_TREE1),"ѡ���ͳ���ļ���");
	m_myToolTip.AddTool(GetDlgItem(IDC_TEST),"�ٴν���ͳ��");
	

	CString hour;
	CString minute;
	CString second;
	CString time="��ǰʱ��:"; 
	CTime t = CTime::GetCurrentTime();
	hour.Format("%d",t.GetHour());
	minute.Format("%d",t.GetMinute());
	second.Format("%d",t.GetSecond());
	
	time+=hour;
	time+="��";
	time+=minute;
	time+="��";
	time+=second;
	time+="��";
	SetDlgItemText(IDC_EDIT5,time);

	//AfxBeginThread(MyThreadFunction,0,THREAD_PRIORITY_ABOVE_NORMAL,0,NULL);
	SetTimer(0,1000,NULL);

	// CG: The following block was added by the ToolTips component.
	{
		// Create the ToolTip control.
		m_tooltip.Create(this);
		m_tooltip.Activate(TRUE);

		// TODO: Use one of the following forms to add controls:
		// m_tooltip.AddTool(GetDlgItem(IDC_<name>), <string-table-id>);
		// m_tooltip.AddTool(GetDlgItem(IDC_<name>), "<text>");
	}
	return TRUE;  // return TRUE  unless you set the focus to a control
	
}

void CMy8Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMy8Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting
		
		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);
		
		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
		
		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMy8Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMy8Dlg::OnAdd() 
{
	// TODO: Add your control notification handler code here
	//SetWindowPos(&wndTop,0,0,0,0,SWP_NOSIZE|SWP_NOMOVE);
	//AfxBeginThread(MyThreadFunction,0,THREAD_PRIORITY_ABOVE_NORMAL,0,NULL);

	double none_file=0;
	double total_file=0;
    static int index=0;
	CString str_total_space;
	CString str_free_space;
	CString str_used_space;
	CFileFind  ff;
	BOOL  bFound; 
	
	byte=0;
	total_amount=0;
	m_caller_list.DeleteAllItems();
	insert=true;
	
	
	GetDlgItem(IDC_EDIT1)->SetWindowText("");
	
	GetDlgItem(IDC_EDIT2)->SetWindowText("");
	
	GetDlgItem(IDC_EDIT3)->SetWindowText("");
	
	GetDlgItem(IDC_EDIT4)->SetWindowText("");

	if(sPath=="")
	{
		MessageBox("����ȷѡ���ļ���·��!","����",MB_ICONWARNING);
		return;
	}
	bFound=ff.FindFile(sPath+"\\*.*"); 
	while(bFound)  
	{  
		MSG msg; 
		while(PeekMessage(&msg, NULL, NULL, NULL, PM_REMOVE)) 
		{ 
			TranslateMessage(&msg); 
			DispatchMessage(&msg); 
		}
		bFound=ff.FindNextFile();  
		CString sFilePath=ff.GetFilePath();  
		
		if(ff.IsDirectory())  
		{  
			if(!ff.IsDots())  
			{
				m_caller_list.InsertItem(0,sFilePath);
				ListFolder(sFilePath);
				total_file+=byte;
				
				WeightCount(byte);
				
				byte=0;
			}
		}
		else
			none_file+=ff.GetLength();
	}  
	
	total_file+=none_file;
	m_caller_list.InsertItem(0,"��Ŀ¼�ļ�");
	
	WeightCount(none_file);
				
	
	insert=false;
	
	GetDlgItem(IDC_EDIT1)->SetWindowText(sPath.Left(3));
	
	GetDiskFreeSpaceEx(sPath.Left(3),&uliUserFree,&uliTotal,&uliRealFree);
	
	str_free_space=WeightCount((double)(LONGLONG)uliUserFree.QuadPart);
	if(str_free_space=="1.e-002GB")
		GetDlgItem(IDC_EDIT2)->SetWindowText("0.0GB");
	else
		GetDlgItem(IDC_EDIT2)->SetWindowText(str_free_space);
	
	str_total_space=WeightCount((double)(LONGLONG)uliTotal.QuadPart);
	if(str_free_space=="1.e-002GB")
		GetDlgItem(IDC_EDIT3)->SetWindowText("0.0GB");
	else
		GetDlgItem(IDC_EDIT3)->SetWindowText(str_total_space);
	
	str_used_space=WeightCount((double)(LONGLONG)uliTotal.QuadPart-
		(double)(LONGLONG)uliUserFree.QuadPart);
	GetDlgItem(IDC_EDIT4)->SetWindowText(str_used_space);
	
	ff.Close();
}


void CMy8Dlg::ListFolder(CString sPath)
{

	MSG msg; 
	while(PeekMessage(&msg, NULL, NULL, NULL, PM_REMOVE)) 
	{ 
		TranslateMessage(&msg); 
		DispatchMessage(&msg); 
	}
	CFileFind  ff;  
	BOOL  bFound;  
	bFound=ff.FindFile(sPath+"\\*.*");  
	while(bFound)  
	{  
		bFound=ff.FindNextFile();  
		CString sFilePath=ff.GetFilePath();  
		
		if(ff.IsDirectory())  
		{  
			if(!ff.IsDots())  
				ListFolder(sFilePath); 
		}  
		else  
		{  
			CString str;
			char temp[300];
			byte+=ff.GetLength();
			_gcvt(byte,10,temp);
			str=temp;
			
			WeightCount(byte);
			
			m_caller_list.UpdateWindow();
		}  
	}  
	ff.Close();
}



CString CMy8Dlg::WeightCount(double dtemp)
{
	CString str;
	char temp[300];
	_gcvt(dtemp,10,temp);
	str=temp;
	
	if(dtemp==0)
		str+="0B";
	else
		if(0<dtemp&&dtemp<=1024*0.8)
			str+="B";
		else
			if(1024*0.8<dtemp&&dtemp<=(1024*1024*0.8))
			{
				_gcvt((int((dtemp/1024*100.0+0.05))/100.0),10,temp);
				str=temp;
				str+="KB";
			}
			else
				if((1024*1024*0.8)<dtemp&&dtemp<=(1024*1024*1024*0.8))
				{
					_gcvt((int((dtemp/(1024*1024)*100.0+0.05))/100.0),10,temp);
					str=temp;
					str+="MB";
				}
				else
				{
					_gcvt((int((dtemp/(1024*1024*1024)*100.0+0.05))/100.0),10,temp);
					str=temp;
					str+="GB";
				}	
				
				if(insert)
					m_caller_list.SetItemText(0,1,str);
				
				return str;
}

void CMy8Dlg::GetLogicalDrives(HTREEITEM hParent)
{
	int szAllDriveStrings = GetLogicalDriveStrings(0,NULL);
	char *pDriveStrings = new char[szAllDriveStrings];//MSDN
	GetLogicalDriveStrings(szAllDriveStrings,pDriveStrings);//MSDN
	int szDriveString = strlen(pDriveStrings);
	while(szDriveString > 0)
	{
		m_tree.InsertItem(pDriveStrings,hParent);
		pDriveStrings += szDriveString + 1;
		szDriveString = strlen(pDriveStrings);
	}
}

void CMy8Dlg::GetDriveDir(HTREEITEM hParent)
{	
	HTREEITEM hChild = m_tree.GetChildItem(hParent);
	while(hChild)
	{
        CString strText = m_tree.GetItemText(hChild);
		if(strText.Right(1) != "\\")
			strText += _T("\\");
		strText += "*.*";
		CFileFind file;
		BOOL bContinue = file.FindFile(strText);
		while(bContinue)
		{
            bContinue = file.FindNextFile();
			if(file.IsDirectory() && !file.IsDots())
				m_tree.InsertItem(file.GetFileName(),hChild);
		}
		GetDriveDir(hChild);
		hChild = m_tree.GetNextItem(hChild,TVGN_NEXT);
	}
}

void CMy8Dlg::OnSelchangedTree1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	TVITEM item = pNMTreeView->itemNew;
	if(item.hItem == m_hRoot)
		return;
	else
		sPath= GetFullPath(item.hItem);
}

CString CMy8Dlg::GetFullPath(HTREEITEM hCurrent)
{
	CString strTemp;
	CString strReturn = "";
	while(hCurrent != m_hRoot)
	{
		strTemp = m_tree.GetItemText(hCurrent);
		if(strTemp.Right(1) != "\\")
			strTemp += "\\";
		strReturn = strTemp  + strReturn;
		hCurrent = m_tree.GetParentItem(hCurrent);
	}
	return strReturn;
}

void CMy8Dlg::OnClear() 
{
	// TODO: Add your control notification handler code here
	byte=0;
	total_amount=0;
    sPath="";
	m_caller_list.DeleteAllItems();
	insert=true;
	
	
	GetDlgItem(IDC_EDIT1)->SetWindowText("");
	
	GetDlgItem(IDC_EDIT2)->SetWindowText("");
	
	GetDlgItem(IDC_EDIT3)->SetWindowText("");
	
	GetDlgItem(IDC_EDIT4)->SetWindowText("");
	
}

BOOL CMy8Dlg::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default
	/*CRect rect;
    GetClientRect(&rect);//�õ�����Ĵ�С
    CDC dcMem;
    dcMem.CreateCompatibleDC(pDC);
    CBitmap bmpBackground;
    bmpBackground.LoadBitmap(IDB_BITMAP4);//���ر���ͼƬ
    BITMAP bitMap;
    bmpBackground.GetBitmap(&bitMap);
    CBitmap *pbmpOld=dcMem.SelectObject(&bmpBackground);
    pDC->StretchBlt(0,0,rect.Width(),rect.Height(),&dcMem,0,0,
		bitMap.bmWidth, bitMap.bmHeight,SRCCOPY);//�ú������Ի�������λͼ
	
	return true;*/
	
	return CDialog::OnEraseBkgnd(pDC);
}

static int CALLBACK ListCompare(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort)
{
    double temp1;
	double temp2;
	
	CListCtrl* pListCtrl=(CListCtrl*)lParamSort;   
	
    CString strItem1=pListCtrl->GetItemText(lParam1,1);   
    CString strItem2=pListCtrl->GetItemText(lParam2,1);  
	
    ResetStr(strItem1,temp1);
	ResetStr(strItem2,temp2);
	
	if(compare)
		return  MyMax(temp1,temp2);  
	else
		return  MyMin(temp1,temp2); 
}

void CMy8Dlg::OnColumnclickList2(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	skinppSetListHeaderSortInfo(m_hWnd,1,true);

	LPNMITEMACTIVATE temp=(LPNMITEMACTIVATE)pNMHDR;
	if(temp->iSubItem==0)
		return;
	int  i=m_caller_list.GetItemCount();   
    while(i--)
		m_caller_list.SetItemData(i,i);     
	
	//LPNMITEMACTIVATE temp=(LPNMITEMACTIVATE)pNMHDR; /////////??????
	
	if(!flag)
	{
		//SetHeaderBitmap(1,IDB_BITMAP5,NULL);
		flag=true;
		compare=false;
		m_caller_list.SortItems(ListCompare,(DWORD)&m_caller_list);
	}
	else
	{
		//SetHeaderBitmap(1,IDB_BITMAP6,NULL);
		flag=false;
		compare=true;
		m_caller_list.SortItems(ListCompare,(DWORD)&m_caller_list);
	}
	
	*pResult = 0;
}

void CMy8Dlg::SetHeaderBitmap(int nCol, int nBitmap, DWORD dwRemove)
{
	CHeaderCtrl*  pHeader=(CHeaderCtrl*)m_caller_list.GetDlgItem(0);   
	if(pHeader==NULL)  
		return   ;   
	HD_ITEM  hdi;   
	hdi.mask=HDI_FORMAT;   
	pHeader->GetItem(nCol,&hdi);   
	hdi.mask=HDI_BITMAP|HDI_FORMAT;   
	hdi.fmt|=HDF_BITMAP;   
	hdi.hbm =(HBITMAP)::LoadImage(AfxGetInstanceHandle(),MAKEINTRESOURCE(nBitmap),
		IMAGE_BITMAP,0,0,LR_LOADMAP3DCOLORS);  
	if(dwRemove)   
		hdi.fmt&= ~dwRemove;   
	
	pHeader->SetItem(nCol,&hdi);   
}

void CMy8Dlg::OnDblclkList2(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	CString path="";
	int row=0;
	LPNMITEMACTIVATE temp=(LPNMITEMACTIVATE)pNMHDR;  
	row=temp->iItem;
    
	path=m_caller_list.GetItemText(row,0);
	
	if(path!=""&&path!="��Ŀ¼�ļ�")
		ShellExecute(m_hWnd, NULL, path, NULL, NULL, SW_SHOWNORMAL);
	else
		if(path=="��Ŀ¼�ļ�")
		{
			int find=sPath.ReverseFind('\\');
			CString newpath=sPath.Left(find+1);
			ShellExecute(m_hWnd, NULL, newpath, NULL, NULL, SW_SHOWNORMAL);
		}
		
		*pResult = 0;
}

BOOL CMy8Dlg::PreTranslateMessage(MSG* pMsg) 
{
	// CG: The following block was added by the ToolTips component.
	{
		// Let the ToolTip process this message.
		m_tooltip.RelayEvent(pMsg);
	}
	// TODO: Add your specialized code here and/or call the base class
	m_myToolTip.RelayEvent(pMsg);
	
	return CDialog::PreTranslateMessage(pMsg);
}

void CMy8Dlg::OnItemexpandedTree1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	TVITEM item = pNMTreeView->itemNew;
	if(item.hItem == m_hRoot)
		return;
    HTREEITEM hChild = m_tree.GetChildItem(item.hItem);
	while(hChild)
	{
		AddSubDir(hChild);
		hChild = m_tree.GetNextItem(hChild,TVGN_NEXT);
	}
	
	*pResult = 0;
}

void CMy8Dlg::AddSubDir(HTREEITEM hParent)
{
	CString strPath = GetFullPath(hParent);
	if(strPath.Right(1) != "\\")
		strPath += "\\";
	strPath += "*.*";
	CFileFind file;
	BOOL bContinue = file.FindFile(strPath);
	while(bContinue)
	{
		bContinue = file.FindNextFile();
		if(file.IsDirectory() && !file.IsDots())
			m_tree.InsertItem(file.GetFileName(),hParent);
	}
}

void CMy8Dlg::OnTest() 
{
	// TODO: Add your control notification handler code here
	if(gPath=="��Ŀ¼�ļ�"||gPath=="")
		MessageBox("����ȷѡ��·��!","����",MB_ICONWARNING);
	else
	{
		CSearchDlg dlg;
		dlg.SetPath(gPath);
		dlg.DoModal();
	}
	
}

void CMy8Dlg::OnClickList2(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	int row=0;
	LPNMITEMACTIVATE temp=(LPNMITEMACTIVATE)pNMHDR;  
	row=temp->iItem;
	gRow=row;
    
	gPath=m_caller_list.GetItemText(row,0);
	
	*pResult = 0;
}




void CMy8Dlg::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	for(int nPercent=100; nPercent>= 0;nPercent--)
		SetTransparent(m_hWnd,0,255*nPercent/100, LWA_ALPHA);
	if ( hUserDll )	
		::FreeLibrary( hUserDll );
	//skinppRemoveSkin();
	//skinppExitSkin();
	CDialog::OnClose();
}

void CMy8Dlg::OnDelete() 
{
	// TODO: Add your control notification handler code here
	CString str="ȷ��Ҫɾ��";
	CString newpath;
	if(gPath==""||gPath=="��Ŀ¼�ļ�")
	{
		MessageBox("����ȷѡ���ļ���!");
		return;
	}
	str+=gPath;
	str+="��?";
	int find=gPath.ReverseFind('\\');
	newpath=gPath.Right(gPath.GetLength()-find-1);
	if(MessageBox(str,"����",MB_YESNO)==IDYES)
	{
		DeleteDirectory(gPath);
		m_caller_list.DeleteItem(gRow);
		
		HTREEITEM hCurrent = m_tree.GetSelectedItem();
		hCurrent = m_tree.GetChildItem(hCurrent);
		str=m_tree.GetItemText(hCurrent);
		
		while(str!=newpath)
		{
			hCurrent=m_tree.GetNextItem(hCurrent,TVGN_NEXT);
			str=m_tree.GetItemText(hCurrent);
		}
		m_tree.DeleteItem(hCurrent);
	}
}

void CMy8Dlg::OnDeleteitemTree1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	//m_tree.DeleteItem(m_tree.GetSelectedItem());

	*pResult=0;
}

BOOL CMy8Dlg::SetTransparent(HWND hWnd, COLORREF crKey, BYTE bAlpha, DWORD dwFlags)
{
	BOOL	bRet = TRUE;
	typedef BOOL (WINAPI* lpfnSetTransparent)(HWND hWnd, COLORREF crKey, BYTE bAlpha, DWORD dwFlags);
	
	// Check that "USER32.dll" library has been loaded successfully...
	if ( hUserDll )
	{
		lpfnSetTransparent pFnSetTransparent  = NULL;
		pFnSetTransparent  = (lpfnSetTransparent)GetProcAddress(hUserDll, "SetLayeredWindowAttributes");
		if (pFnSetTransparent )
			bRet = pFnSetTransparent(hWnd, crKey, bAlpha, dwFlags);

		else 
			bRet = FALSE;
	} //if( hUserDll )

	return bRet;
}

void CMy8Dlg::OnHelp() 
{
	// TODO: Add your control notification handler code here
	CHelpDlg dlg;
	dlg.DoModal();
}

void CMy8Dlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	CString hour;
	CString minute;
	CString second;
	CString time="��ǰʱ��:"; 
	CTime t = CTime::GetCurrentTime();
	hour.Format("%d",t.GetHour());
	minute.Format("%d",t.GetMinute());
	second.Format("%d",t.GetSecond());
	
	time+=hour;
	time+="��";
	time+=minute;
	time+="��";
	time+=second;
	time+="��";
	SetDlgItemText(IDC_EDIT5,time);
	UpdateWindow();

	CDialog::OnTimer(nIDEvent);
}

void CMy8Dlg::OnOK() 
{
	// TODO: Add extra validation here
	OnClose();
	CDialog::OnOK();
}

HTREEITEM CMy8Dlg::GetNode(char *pText, HTREEITEM parentNode)
{
	HTREEITEM FindNode = NULL;
	CString strText;
	strText.Format("%s", pText);
	//û�����ݷ���NULL
	FindNode = parentNode;
	
	if(m_tree.GetItemText(FindNode)==strText)
        return FindNode;
	
	if(m_tree.ItemHasChildren(FindNode))
	{
        FindNode = m_tree.GetChildItem(FindNode);
        FindNode = GetNode(pText, FindNode); 
        if(FindNode)
        {
			return FindNode; 
        }
        else
        {
			FindNode = m_tree.GetNextSiblingItem(m_tree.GetParentItem(FindNode));
        }
	}
	else
	{
        FindNode = m_tree.GetNextSiblingItem(FindNode);
		if(FindNode==NULL)
			return NULL;
	} 
	return FindNode;
}

void CMy8Dlg::OnRelate() 
{
	// TODO: Add your control notification handler code here
	HKEY   hresult;
	CString  str1,str2;   
	long  value;   
	LPCTSTR  dataset1="Folder\\shell\\�ҵ��ı�Ӧ�ó���";   
	LPCTSTR  dataset2="Folder\\shell\\�ҵ��ı�Ӧ�ó���\\command";   
  	str1="���ҵ��ı������";   
    str2="E:\\sxc\\8\\Debug\\8.exe";   
    DWORD   dwPos;   
    
	value=RegCreateKeyEx(HKEY_CLASSES_ROOT,dataset1,0,
		NULL,REG_OPTION_NON_VOLATILE,KEY_CREATE_SUB_KEY|KEY_ALL_ACCESS,
		NULL,&hresult,&dwPos);  
	
	value=RegSetValueEx(hresult,NULL,0,REG_SZ,
		(const BYTE*)(LPCTSTR)str1,str1.GetLength());   

	value=RegCreateKeyEx(HKEY_CLASSES_ROOT,dataset2,0,NULL
		,REG_OPTION_NON_VOLATILE,KEY_CREATE_SUB_KEY|KEY_ALL_ACCESS,NULL,&hresult,&dwPos);   
    
	value=RegSetValueEx(hresult,NULL,0,REG_SZ,
		(const BYTE*)(LPCTSTR)str2,str2.GetLength());   
    
	::RegCloseKey(hresult);   
}

void CMy8Dlg::OnDesrelate() 
{
	// TODO: Add your control notification handler code here
	HKEY   hKey;     
	LPCTSTR   dataset1="Folder\\shell\\�ҵ��ı�Ӧ�ó���";    
	LPCTSTR   dataset2="Folder\\shell";     
	long   ret1=::RegOpenKeyEx(HKEY_CLASSES_ROOT,dataset1,0,KEY_READ,&hKey);   
	
    
	::RegDeleteKey(hKey,LPCTSTR("command"));    
	::RegCloseKey(hKey);     
	ret1=::RegOpenKeyEx(HKEY_CLASSES_ROOT,dataset2,0,KEY_READ,&hKey);   
    
	::RegDeleteKey(hKey,LPCTSTR("�ҵ��ı�Ӧ�ó���"));   
    
	::RegCloseKey(hKey);   
}

int CMy8Dlg::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	DragAcceptFiles(TRUE);
	return 0;
}

void CMy8Dlg::OnDropFiles(HDROP hDropInfo) 
{
	// TODO: Add your message handler code here and/or call default
	TCHAR  tch[10000];   
    CFileFind  ff;
	int  iCnt=::DragQueryFile(hDropInfo,0xFFFFFFFF,NULL,0);  
	for(int i=0;i<iCnt;i++)   
	{   
		memset(tch,0,sizeof TCHAR*10000);   
		::DragQueryFile(hDropInfo,i,tch,10000);   
		DropPath=tch;
	}   
	::DragFinish(hDropInfo);   
	if(ff.FindFile(DropPath))  
	{  
		ff.FindNextFile(); 	
		if(ff.IsDirectory())
		{
			gPath=DropPath;
			AutoRun();
		}
	}
	ff.Close();
	CDialog::OnDropFiles(hDropInfo);
}


void CMy8Dlg::AutoRun()
{
	int find=1;
	find=gPath.Find('\\');
	CString temp;
	temp=gPath.Left(find);
	temp+='\\';
	HTREEITEM hitem=NULL;
	HTREEITEM   hNextItem=NULL;
	CString str;
	hitem=m_tree.GetRootItem();    //ȡ�ø��ڵ�
	m_tree.Expand(hitem,TVE_EXPAND);
	hitem=m_tree.GetNextItem(hitem,TVGN_CHILD);
	str=m_tree.GetItemText(hitem);
	
	while(str!=temp)
	{
		hNextItem=m_tree.GetNextItem(hitem,TVGN_NEXT);
		str=m_tree.GetItemText(hNextItem);
		hitem=hNextItem;
	}
	m_tree.Expand(hitem,TVE_EXPAND);
	hitem=m_tree.GetNextItem(hitem,TVGN_CHILD);
	find=0;
	gPath.Delete(0,sizeof(temp)-1);
	find=gPath.Find('\\');
	if(find!=-1)
		temp=gPath.Left(find);
	else
	temp=gPath;

	str=m_tree.GetItemText(hitem);
	for(;find!=-1;)
	{
		while(str!=temp)
		{
			hNextItem=m_tree.GetNextItem(hitem,TVGN_NEXT);
			str=m_tree.GetItemText(hNextItem);
			hitem=hNextItem;
		}
		m_tree.Expand(hitem,TVE_EXPAND);
		hitem=m_tree.GetNextItem(hitem,TVGN_CHILD);
		find=0;
		gPath.Delete(0,strlen(temp)+1);
		str=m_tree.GetItemText(hitem);
		find=gPath.Find('\\');
		if(find!=-1)
			temp=gPath.Left(find);
		else
			temp=gPath;
	}

	str=m_tree.GetItemText(hitem);

	while(str!=temp)
		{
			hNextItem=m_tree.GetNextItem(hitem,TVGN_NEXT);
			str=m_tree.GetItemText(hNextItem);
			hitem=hNextItem;
		}
	m_tree.SelectItem(hitem);
}

int CMy8Dlg::DeleteDirectory(CString szFolder)
{
	CFileFind finder;
    CString strWildcard(szFolder);
    char szTmp[255];
    int i;
    strWildcard += _T("\\*.*");
    BOOL bWorking = finder.FindFile(strWildcard);
    while (bWorking)
    {
        bWorking = finder.FindNextFile();
        if (finder.IsDots())
            continue;
        CString str;
        str=finder.GetFilePath();//.GetFileName();
        memset(szTmp,0,255);
        strcpy(szTmp,str.GetBuffer(0));
        if (finder.IsDirectory())
        {
            i = DeleteDirectory(szTmp);  //�ݹ�ɾ�����ļ���
            if( 0 != i)
            {
                finder.Close();
                return -1;
            }
            continue;
        }    
        //ɾ���ļ�
        TRY
        {
			// CFile::Remove( szTmp );
            if(remove(szTmp) == -1)
            {
                MoveFileEx(szTmp, NULL, MOVEFILE_DELAY_UNTIL_REBOOT);                
            }
        }
        CATCH( CFileException, e )
        {
            //ShowError(GetLastError());
            finder.Close();
            return -2;
        }
        END_CATCH
    }
    finder.Close();
    //ɾ���ļ��У���Ŀ¼��
    if( !RemoveDirectory( szFolder))
    {
        //ShowError(GetLastError());
        return -3 ;
    }
    return 0;

}

void CMy8Dlg::MakeAccumulation()
{

}


void CMy8Dlg::OnButton2() 
{
	// TODO: Add your control notification handler code here
	CRect rect;
	CString str;
	GetWindowRect(&rect);

	m_topmost.GetWindowText(str);

	if(str=="������ǰ��")
	{
		SetWindowPos(&wndTopMost,rect.left,
			rect.top,rect.Width(),rect.Height(),SWP_SHOWWINDOW);
		m_topmost.SetWindowText("ȡ��ǰ����ʾ");
	}
	else
	{
		SetWindowPos(&wndNoTopMost,rect.left,rect.top,
			rect.Width(),rect.Height(),SWP_SHOWWINDOW);
		
	m_topmost.SetWindowText("������ǰ��");
	}
}
