//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by 8.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MY8_DIALOG                  102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     134
#define IDI_ICON1                       136
#define IDB_BITMAP2                     139
#define IDB_BITMAP3                     140
#define IDB_BITMAP6                     140
#define IDD_DIALOG1                     141
#define IDB_BITMAP4                     143
#define IDB_BITMAP5                     151
#define IDD_HELP                        210
#define IDC_LIST2                       1001
#define IDC_ADD                         1002
#define IDC_TREE1                       1003
#define IDC_CLEAR                       1004
#define IDC_TEST                        1005
#define IDC_HELP                        1006
#define IDC_DELETE                      1007
#define IDC_EDIT1                       1008
#define IDC_EDIT2                       1009
#define IDC_EDIT3                       1010
#define IDC_EDIT4                       1011
#define IDC_STATIC_1                    1012
#define IDC_STATIC_2                    1013
#define IDC_STATIC_3                    1014
#define IDC_STATIC_4                    1015
#define IDC_DESRELATE                   1016
#define IDC_TOPMOST                     1016
#define IDC_AGAIN                       1019
#define IDC_ANIMATE1                    1029
#define IDC_EDIT5                       1030
#define IDC_BUTTON2                     1034

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        213
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1035
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
