// DictManagementDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MyDict.h"
#include "DictManagementDlg.h"
#include "AddDictDlg.h"
#include "MyExcel.h"
#include "CSpreadSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDictManagementDlg dialog


CDictManagementDlg::CDictManagementDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDictManagementDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDictManagementDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDictManagementDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDictManagementDlg)
	DDX_Control(pDX, IDC_WORDTYPE, m_wordType);
	DDX_Control(pDX, IDC_COMBO1, m_dictType);
	DDX_Control(pDX, IDC_WORDLIST, m_list);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDictManagementDlg, CDialog)
	//{{AFX_MSG_MAP(CDictManagementDlg)
	ON_CBN_CLOSEUP(IDC_COMBO1, OnCloseupCombo1)
	ON_BN_CLICKED(IDC_ADDDICT, OnAdddict)
	ON_BN_CLICKED(IDC_DELETEDICT, OnDeletedict)
	ON_BN_CLICKED(IDC_SAVEWORD, OnSaveword)
	ON_BN_CLICKED(IDC_ADDWORD, OnAddword)
	ON_BN_CLICKED(IDC_EXPORT, OnExport)
	ON_BN_CLICKED(IDC_IMPORT, OnImport)
	ON_BN_CLICKED(IDC_SAVEALL, OnSaveall)
	ON_BN_CLICKED(IDC_DELETEWORD, OnDeleteword)
	ON_NOTIFY(NM_CLICK, IDC_WORDLIST, OnClickWordlist)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_VALIDATE, OnEndLabelEditVariableCriteria)
	ON_MESSAGE(WM_SET_ITEMS, PopulateComboList)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDictManagementDlg message handlers

BOOL CDictManagementDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CMyDictApp* pApp=(CMyDictApp*)AfxGetApp();  
	DBpath=pApp->DBPath;
	
	m_MyDB = new CAccessDB(DBpath.GetBuffer(MAX_PATH),DBpath.GetBuffer(MAX_PATH),0);
	DBpath.ReleaseBuffer();
	
	if(!m_MyDB->OpenDB(DBpath.GetBuffer(MAX_PATH)))
	{
		AfxMessageBox("DB Open Error!");
		DBpath.ReleaseBuffer();
		return FALSE;
	}
	
	DBpath.ReleaseBuffer();

	m_list.InsertColumn(0, "���", LVCFMT_LEFT, 20);
	m_list.InsertColumn(1, "Ӣ�ﵥ��", LVCFMT_LEFT, 165);
	m_list.InsertColumn(2, "���Ľ���", LVCFMT_LEFT, 165);
	m_list.InsertColumn(3, "����", LVCFMT_LEFT, 60);
	
	m_list.SetReadOnlyColumns(0);//read only
		
	m_list.SetComboColumns(3,TRUE);
	m_list.EnableVScroll(); 			
	m_list.SetExtendedStyle(LVS_EX_FULLROWSELECT);

	InitDictTypeCombo();
	m_dictType.SetCurSel(0);
	preState=0;
	curState=0;
	InitTypeCombo();
	InitListView();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDictManagementDlg::OnCloseupCombo1() 
{
	// TODO: Add your control notification handler code here
	curState=m_dictType.GetCurSel();
	
	if (curState!=preState)
	{
		InitListView();
		preState=curState;
	}
}

BOOL CDictManagementDlg::InitDictTypeCombo()
{
	CString sql="SELECT * From  DictType";
	CString dictType;
	
	m_dictType.ResetContent();
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return false;
	int DictTypeNo=m_MyDB->GetDataSetRowCount(1);
	
	if(!DictTypeNo)
		DictTypeNo=0;
	
	for(int i=0;i<DictTypeNo;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,1,dictType.GetBuffer(0));
		m_dictType.AddString(dictType);
	}
	
	return true;
}

BOOL CDictManagementDlg::InitListView()
{
	CString sql;
	CString str;
	char EnWord[100];
	char CnMeaning[100];
	char WordType[100];
	int typeId;

	m_list.DeleteAllItems();
	int index=m_dictType.GetCurSel();
	if (index==-1)
	{
		index=0;
	}
	m_dictType.GetLBText(index,dictType);

	sql.Format("SELECT * FROM %s",dictType);

	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
	{
		return FALSE;
	}

	int wordNo=m_MyDB->GetDataSetRowCount(1);
	
	if(wordNo<0)
		wordNo=0;
	
	for(int i=0;i<wordNo;i++)
	{
		str.Format("%d",i+1);
		m_list.InsertItem(LVIF_TEXT|LVIF_STATE, i, 
			str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
		
		m_MyDB->GetDataSetFieldValue(i,1,EnWord);
		m_list.SetItemText(i,1,EnWord);
		m_MyDB->GetDataSetFieldValue(i,3,CnMeaning);
		m_list.SetItemText(i,2,CnMeaning);
		m_MyDB->GetDataSetFieldValue(i,2,WordType);
		typeId=atoi(WordType);
		m_wordType.GetLBText(typeId-1,WordType);
		m_list.SetItemText(i,3,WordType);
	}

	return TRUE;
}

BOOL CDictManagementDlg::InitTypeCombo()
{
	CString sql="SELECT WordType From WordType";
	CString word;
	
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
	{
		return false;
	}
	int TypeNo=m_MyDB->GetDataSetRowCount(1);
	
	if(TypeNo<0)
		TypeNo=0;
	
	for(int i=0;i<TypeNo;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,word.GetBuffer(0));
		m_wordType.AddString(word);
	}
	m_wordType.AddString("ALL");
	m_wordType.SetCurSel(m_wordType.GetCount()-1);
	
	return true;
}

void CDictManagementDlg::OnAdddict() 
{
	// TODO: Add your control notification handler code here
	CAddDictDlg dlg;
	CString sql;
	CString DictName;
	int index=m_dictType.GetCurSel();
	if (dlg.DoModal()==IDOK)
	{
		DictName=dlg.DictName;

		sql.Format("CREATE TABLE %s (ID  AUTOINCREMENT PRIMARY KEY,EnWord CHAR(100),WordType SMALLINT,CnMeaning CHAR(100))",DictName);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;

		sql.Format("INSERT INTO DictType(DictType) VALUES('%s')",DictName);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;

		MessageBox("The Dict has created successfully!!!");

		InitDictTypeCombo();
		m_dictType.SetCurSel(index);
	}
}

void CDictManagementDlg::OnDeletedict() 
{
	// TODO: Add your control notification handler code here
	CString DictName;
	CString sql;
	CString mes;
	m_dictType.GetLBText(m_dictType.GetCurSel(),DictName);

	mes.Format("Are you sure you want to delete %s?",DictName);
	if (MessageBox(mes,"Warning",MB_OKCANCEL)==IDOK)
	{
		
		sql.Format("DELETE * FROM DictType WHERE DictType='%s'",DictName);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;
	
		m_MyDB->CloseDB();
		CMyDictApp* pApp=(CMyDictApp*)AfxGetApp();  
		DBpath=pApp->DBPath;
		
		m_MyDB = new CAccessDB(DBpath.GetBuffer(MAX_PATH),DBpath.GetBuffer(MAX_PATH),0);
		DBpath.ReleaseBuffer();
		
		if(!m_MyDB->OpenDB(DBpath.GetBuffer(MAX_PATH)))
		{
			AfxMessageBox("DB Open Error!");
			DBpath.ReleaseBuffer();
			return ;
		}

		sql.Format("DROP TABLE %s",DictName);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;

		InitDictTypeCombo();
		InitListView();
	}
}

void CDictManagementDlg::OnSaveword() 
{
	// TODO: Add your control notification handler code here
	CString EnWord="";
	CString CnMeaning="";
	CString Wordtype="";
	CString sql;
	char ch[100];
	int typeID;
	int i=m_list.GetItemCount();
	
	EnWord=m_list.GetItemText(i-1,1);
	Wordtype=m_list.GetItemText(i-1,3);
	sql.Format("SELECT ID FROM WordType Where WordType='%s'",Wordtype);
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
	{
		return ;
	}
	m_MyDB->GetDataSetRowCount(1);
	m_MyDB->GetDataSetFieldValue(0,0,ch);
	typeID=atoi(ch);

	CnMeaning=m_list.GetItemText(i-1,2);
	
	if (EnWord!=""&&Wordtype!=""&&CnMeaning!="")
	{
		sql.Format("INSERT INTO %s(EnWord,Wordtype,CnMeaning) VALUES('%s',%d,'%s')",dictType,EnWord,typeID,CnMeaning);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			AfxMessageBox("DB Error");
		
		(CButton*)GetDlgItem(IDC_SAVEWORD)->EnableWindow(FALSE);
		(CButton*)GetDlgItem(IDC_ADDWORD)->EnableWindow(TRUE);
		
	}
	else
	{
		MessageBox("Word Infomation Incomplete!");
	}
}

void CDictManagementDlg::OnAddword() 
{
	// TODO: Add your control notification handler code here
	(CButton*)GetDlgItem(IDC_SAVEWORD)->EnableWindow(TRUE);
	(CButton*)GetDlgItem(IDC_ADDWORD)->EnableWindow(FALSE);
	
	int i =m_list.GetItemCount();
	
	CString str;
	str.Format("%d",i+1);
	m_list.InsertItem(LVIF_TEXT|LVIF_STATE, i+1, 
		str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);

	m_list.EnsureVisible(i,TRUE);
}

BOOL CDictManagementDlg::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(pMsg->message == WM_KEYDOWN)
    {
        switch(pMsg->wParam)
        {
        case VK_RETURN: 
            // [RETURN] key����
            m_list.GoToNextItem();
            return TRUE;
        }
    }
	
	return CDialog::PreTranslateMessage(pMsg);
}

LRESULT CDictManagementDlg::PopulateComboList(WPARAM wParam, LPARAM lParam)
{
	// Get the Combobox window pointer
	CString str;
	CComboBox* pInPlaceCombo = static_cast<CComboBox*> (GetFocus());
	
	// Get the inplace combbox top left
	CRect obWindowRect;
	
	pInPlaceCombo->GetWindowRect(&obWindowRect);
	
	CPoint obInPlaceComboTopLeft(obWindowRect.TopLeft()); 
	
	// Get the active list
	// Get the control window rect
	// If the inplace combobox top left is in the rect then
	// The control is the active control
	m_list.GetWindowRect(&obWindowRect);
	
	int iColIndex = (int )wParam;
	
	CStringList* pComboList = reinterpret_cast<CStringList*>(lParam);
	pComboList->RemoveAll(); 
	
	if (obWindowRect.PtInRect(obInPlaceComboTopLeft)) 
	{				
		if(iColIndex==3)
		{
			for (int i=0;i<m_wordType.GetCount();i++)
			{
				m_wordType.GetLBText(i,str);
				pComboList->AddTail(str);
			}		
		}			
	}
	return true;
}

LRESULT CDictManagementDlg::OnEndLabelEditVariableCriteria(WPARAM wParam, LPARAM lParam) 
{
	LV_DISPINFO* pDispInfo = (LV_DISPINFO*)lParam;
	// TODO: Add your control notification handler code here
	
	return 1;
}

void CDictManagementDlg::OnExport() 
{
	// TODO: Add your control notification handler code here
	CMyExcel excel;
	excel.ExportListToExcel(&m_list,"MyDict");
}

void CDictManagementDlg::OnImport() 
{
	// TODO: Add your control notification handler code here
	CFileDialog dlg(TRUE);
	dlg.m_ofn.lpstrTitle="Import Dict Dialog...";
	dlg.m_ofn.lpstrFilter="Excel Files(*.xls)\0*.xls";
	dlg.m_ofn.lpstrDefExt="xls";
	if (dlg.DoModal()==IDOK)
	{
		CSpreadSheet SS(dlg.GetPathName(), "MyDict");
		CStringArray Rows, Column;
		CString str;
		int count =m_list.GetItemCount();
		
		for (int i = 2; i <= SS.GetTotalRows(); i++)
		{
			// ��ȡһ��
			SS.ReadRow(Rows, i);
			CString strContents = "";
			str.Format("%d",count+1);
			m_list.InsertItem(LVIF_TEXT|LVIF_STATE, count+1, 
				str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);

			m_list.SetItemText(count,1,Rows.GetAt(0));
			m_list.SetItemText(count,2,Rows.GetAt(1));
			m_list.SetItemText(count,3,Rows.GetAt(2));	

			count++;
		}
		m_list.EnsureVisible(i,TRUE);
	}
}

void CDictManagementDlg::OnSaveall() 
{
	// TODO: Add your control notification handler code here
	CString EnWord;
	CString CnMeaning;
	CString WordType;
	int typeID;
	CString sql;

	for(int i=0;i<m_list.GetItemCount();i++)
	{
		EnWord=m_list.GetItemText(i,1);
		CnMeaning=m_list.GetItemText(i,2);
		WordType=m_list.GetItemText(i,3);
		typeID=m_wordType.FindString(-1,WordType);
		
		sql.Format("INSERT INTO %s (EnWord,WordType,CnMeaning) VALUES('%s',%d,'%s')",dictType,EnWord,typeID,CnMeaning);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			AfxMessageBox("DB Error");	
	}
}

void CDictManagementDlg::OnDeleteword() 
{
	// TODO: Add your control notification handler code here
	CString EnWord;
	CString sql;
	CString str;
	
	if (gRow==-1)
	{
		MessageBox("Please select a word!!!");
		return ;
	}
	
	if(MessageBox("The word selected is being deleted!!!","WARNING!!!",MB_OKCANCEL)==IDOK)
	{
		EnWord=m_list.GetItemText(gRow,1);
		
		sql.Format("DELETE * FROM %s WHERE EnWord='%s'",dictType,EnWord);
		
		m_list.DeleteItem(gRow);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			AfxMessageBox("DB Error");
	}
}

void CDictManagementDlg::OnClickWordlist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	LPNMITEMACTIVATE temp=(LPNMITEMACTIVATE)pNMHDR;  
	gRow=temp->iItem;
	
	*pResult = 0;
}
