#if !defined(AFX_DICTMANAGEMENTDLG_H__1219869E_AE2E_43ED_8B87_388963CDEA8B__INCLUDED_)
#define AFX_DICTMANAGEMENTDLG_H__1219869E_AE2E_43ED_8B87_388963CDEA8B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DictManagementDlg.h : header file
//

#include "ComboListCtrl.h"
#include "AccessDB.h"
/////////////////////////////////////////////////////////////////////////////
// CDictManagementDlg dialog

class CDictManagementDlg : public CDialog
{
// Construction
public:
	BOOL InitTypeCombo();
	BOOL InitListView();
	BOOL InitDictTypeCombo();
	CDictManagementDlg(CWnd* pParent = NULL);   // standard constructor
	CAccessDB * m_MyDB;
	CString DBpath;

// Dialog Data
	//{{AFX_DATA(CDictManagementDlg)
	enum { IDD = IDD_DICTMANAGEMENT };
	CComboBox	m_wordType;
	CComboBox	m_dictType;
	CComboListCtrl	m_list;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDictManagementDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDictManagementDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnCloseupCombo1();
	afx_msg void OnAdddict();
	afx_msg void OnDeletedict();
	afx_msg void OnSaveword();
	afx_msg void OnAddword();
	afx_msg void OnExport();
	afx_msg void OnImport();
	afx_msg void OnSaveall();
	afx_msg void OnDeleteword();
	afx_msg void OnClickWordlist(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	afx_msg LRESULT OnEndLabelEditVariableCriteria(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT PopulateComboList(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
private:
	CString dictType;
	int preState;
	int curState;
	int gRow;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DICTMANAGEMENTDLG_H__1219869E_AE2E_43ED_8B87_388963CDEA8B__INCLUDED_)
