// MyDictDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MyDict.h"
#include "MyDictDlg.h"

#include "SearchWordDlg.h"
#include "DictManagementDlg.h"
#include "MyTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyDictDlg dialog

CMyDictDlg::CMyDictDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMyDictDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMyDictDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMyDictDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyDictDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMyDictDlg, CDialog)
	//{{AFX_MSG_MAP(CMyDictDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_SEARCHWORD, OnSearchword)
	ON_WM_WINDOWPOSCHANGING()
	ON_BN_CLICKED(IDC_DICTMANAGEMRNT, OnDictmanagemrnt)
	ON_BN_CLICKED(IDC_TEST, OnTest)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyDictDlg message handlers

BOOL CMyDictDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	CRect rect;
	GetWindowRect(&rect);
	
	int m_xScreen;
	int m_yScreen;
	m_xScreen=GetSystemMetrics(SM_CXSCREEN);
	m_yScreen=GetSystemMetrics(SM_CYSCREEN);
	
	SetWindowPos(&wndTopMost,m_xScreen/2,m_yScreen/2,rect.Width(),rect.Height(),SWP_SHOWWINDOW);
	
	m_btn1.SubclassDlgItem(IDC_SEARCHWORD,this);
	m_btn1.SetIcon(IDI_ICON4);
	m_btn1.SetTooltipText("Ӣ����Ӣ�ֵ�");

	m_btn2.SubclassDlgItem(IDCANCEL,this);
	m_btn2.SetIcon(IDI_ICON6);
	m_btn2.SetTooltipText("�˳�");

	m_btn3.SubclassDlgItem(IDC_DICTMANAGEMRNT,this);
	m_btn3.SetIcon(IDI_ICON3);
	m_btn3.SetTooltipText("�ǵ����");

	m_btn4.SubclassDlgItem(IDC_TEST,this);
	m_btn4.SetIcon(IDI_ICON2);
	m_btn4.SetTooltipText("����");

	m_nEdgeSnapGap=15;


	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMyDictDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMyDictDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMyDictDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMyDictDlg::OnSearchword() 
{
	// TODO: Add your control notification handler code here
	CSearchWordDlg dlg;
	ShowWindow(SW_HIDE);
	dlg.DoModal();
	ShowWindow(SW_NORMAL);
}


void CMyDictDlg::OnWindowPosChanging(WINDOWPOS FAR* lpwndpos) 
{
	CDialog::OnWindowPosChanging(lpwndpos);
	
	// TODO: Add your message handler code here
	RECT rcScrn;
	SystemParametersInfo (SPI_GETWORKAREA, 0, &rcScrn, 0);
	
	// Snap X axis
	if (abs(lpwndpos->x - rcScrn.left) <= m_nEdgeSnapGap)
		lpwndpos->x = rcScrn.left;
	else if (abs(lpwndpos->x + lpwndpos->cx - rcScrn.right) <= m_nEdgeSnapGap)
		lpwndpos->x = rcScrn.right - lpwndpos->cx;
	
	// Snap Y axis
	if (abs(lpwndpos->y - rcScrn.top) <= m_nEdgeSnapGap)
		lpwndpos->y = rcScrn.top;
	else if (abs(lpwndpos->y + lpwndpos->cy - rcScrn.bottom) <= m_nEdgeSnapGap)
		lpwndpos->y = rcScrn.bottom - lpwndpos->cy;
}

void CMyDictDlg::OnDictmanagemrnt() 
{
	// TODO: Add your control notification handler code here
	CDictManagementDlg dlg;
	ShowWindow(SW_HIDE);
	dlg.DoModal();
	ShowWindow(SW_NORMAL);
}

void CMyDictDlg::OnTest() 
{
	// TODO: Add your control notification handler code here
	CMyTestDlg dlg;
	dlg.DoModal();
}
