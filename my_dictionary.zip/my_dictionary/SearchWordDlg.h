#if !defined(AFX_SEARCHWORDDLG_H__3C812E7B_8E44_4C9C_A1CA_7F0010B229F2__INCLUDED_)
#define AFX_SEARCHWORDDLG_H__3C812E7B_8E44_4C9C_A1CA_7F0010B229F2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SearchWordDlg.h : header file
//

#include "AccessDB.h"
#include "BtnST.h"
/////////////////////////////////////////////////////////////////////////////
// CSearchWordDlg dialog

class CSearchWordDlg : public CDialog
{
// Construction
public:
	BOOL EnToCn(CString str,CString &re);
	BOOL CnToEn(CString str,CString &re);
	BOOL IsChinese(CString str);
	BOOL InitWordCombo();
	BOOL InitDictTypeCombo(void);
	CSearchWordDlg(CWnd* pParent = NULL);   // standard constructor
	CAccessDB * m_MyDB;
	CString DBpath;

// Dialog Data
	//{{AFX_DATA(CSearchWordDlg)
	enum { IDD = IDD_SEARCHWORD };
	CComboBox	m_word;
	CComboBox	m_dictType;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSearchWordDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSearchWordDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSearch();
	afx_msg void OnEditchangeWord();
	afx_msg void OnAddtodict();
	afx_msg void OnModifymeaing();
	afx_msg void OnButton1();
	afx_msg void OnCloseupDicttype();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CString dictType;
	CString targetWord;
	CString EnWord;
	CString WordType;
	CString CnMeaning;
	int state;//0 as CtoE,1 as EtoC
	int typeId;//Word Type ID
	int curWordId;

	CButtonST m_btn1;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SEARCHWORDDLG_H__3C812E7B_8E44_4C9C_A1CA_7F0010B229F2__INCLUDED_)
