// AddDictDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MyDict.h"
#include "AddDictDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAddDictDlg dialog


CAddDictDlg::CAddDictDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAddDictDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAddDictDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CAddDictDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAddDictDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAddDictDlg, CDialog)
	//{{AFX_MSG_MAP(CAddDictDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAddDictDlg message handlers

BOOL CAddDictDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CMyDictApp* pApp=(CMyDictApp*)AfxGetApp();  
	DBpath=pApp->DBPath;
	
	m_MyDB = new CAccessDB(DBpath.GetBuffer(MAX_PATH),DBpath.GetBuffer(MAX_PATH),0);
	DBpath.ReleaseBuffer();
	
	if(!m_MyDB->OpenDB(DBpath.GetBuffer(MAX_PATH)))
	{
		AfxMessageBox("DB Open Error!");
		DBpath.ReleaseBuffer();
		return FALSE;
	}
	
	DBpath.ReleaseBuffer();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CAddDictDlg::OnOK() 
{
	// TODO: Add extra validation here
	GetDlgItemText(IDC_EDIT1,DictName);
	if (IsDictNameIn(DictName))
	{
		MessageBox("This dict already exsit!");
		return ;
	}
	
	CDialog::OnOK();
}

BOOL CAddDictDlg::IsDictNameIn(CString str)
{
	CString sql;
	sql.Format("SELECT * FROM DictType WHERE DictType='%s'",str);

	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return false;
	int DictTypeNo=m_MyDB->GetDataSetRowCount(1);
	
	if(DictTypeNo==1)
		return TRUE;
	else
		return FALSE;
}
