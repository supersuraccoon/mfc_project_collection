// SearchWordDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MyDict.h"
#include "SearchWordDlg.h"
#include "AddWordDlg.h"
#include "ModifyDlg.h"
#include "HelpDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSearchWordDlg dialog


CSearchWordDlg::CSearchWordDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSearchWordDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSearchWordDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CSearchWordDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSearchWordDlg)
	DDX_Control(pDX, IDC_WORD, m_word);
	DDX_Control(pDX, IDC_DICTTYPE, m_dictType);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSearchWordDlg, CDialog)
	//{{AFX_MSG_MAP(CSearchWordDlg)
	ON_BN_CLICKED(IDC_SEARCH, OnSearch)
	ON_CBN_EDITCHANGE(IDC_WORD, OnEditchangeWord)
	ON_BN_CLICKED(IDC_ADDTODICT, OnAddtodict)
	ON_BN_CLICKED(IDC_MODIFYMEAING, OnModifymeaing)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_CBN_CLOSEUP(IDC_DICTTYPE, OnCloseupDicttype)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSearchWordDlg message handlers

BOOL CSearchWordDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CMyDictApp* pApp=(CMyDictApp*)AfxGetApp();  
	DBpath=pApp->DBPath;
	
	m_MyDB = new CAccessDB(DBpath.GetBuffer(MAX_PATH),DBpath.GetBuffer(MAX_PATH),0);
	DBpath.ReleaseBuffer();
	
	if(!m_MyDB->OpenDB(DBpath.GetBuffer(MAX_PATH)))
	{
		AfxMessageBox("DB Open Error!");
		DBpath.ReleaseBuffer();
		return FALSE;
	}
	
	DBpath.ReleaseBuffer();

	m_btn1.SubclassDlgItem(IDC_BUTTON1,this);
	m_btn1.SetIcon(IDI_ICON5);
	m_btn1.SetTooltipText("����");

	InitDictTypeCombo();
	InitWordCombo();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CSearchWordDlg::InitDictTypeCombo()
{
	CString sql="SELECT * From  DictType";
	CString dictType;

	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return false;
	int DictTypeNo=m_MyDB->GetDataSetRowCount(1);
	
	if(!DictTypeNo)
		DictTypeNo=0;
	
	for(int i=0;i<DictTypeNo;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,1,dictType.GetBuffer(0));
		m_dictType.AddString(dictType);
	}
	m_dictType.SetCurSel(0);

	return true;
		
}

BOOL CSearchWordDlg::InitWordCombo()
{
	CString sql;
	CString word;

	m_word.ResetContent();
	m_dictType.GetLBText(m_dictType.GetCurSel(),dictType);
	sql.Format("SELECT EnWord From %s",dictType);

	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return false;
	int WordNo=m_MyDB->GetDataSetRowCount(1);
	
	if(!WordNo)
		WordNo=0;
	
	for(int i=0;i<WordNo;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,word.GetBuffer(0));
		m_word.AddString(word);
	}

	sql.Format("SELECT CnMeaning From %s",dictType);
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return false;
	WordNo=m_MyDB->GetDataSetRowCount(1);
	
	if(!WordNo)
		WordNo=0;
	
	for(i=0;i<WordNo;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,word.GetBuffer(0));
		m_word.AddString(word);
	}

	return true;
}

void CSearchWordDlg::OnSearch() 
{
	// TODO: Add your control notification handler code here
	CString result="����: ";

	GetDlgItemText(IDC_WORD,targetWord);
	//m_word.GetLBText(m_word.GetCurSel(),targetWord);
	if (IsChinese(targetWord))
	{
		if(CnToEn(targetWord,result))
		{	
			SetDlgItemText(IDC_DETAIL,result);
			(CButton*)GetDlgItem(IDC_MODIFYMEAING)->EnableWindow(TRUE);
		}
		else
		{
			SetDlgItemText(IDC_DETAIL,result);
			(CButton*)GetDlgItem(IDC_ADDTODICT)->EnableWindow(TRUE);
		}
	}
	else
	{
		if(EnToCn(targetWord,result))
		{	
			SetDlgItemText(IDC_DETAIL,result);
			(CButton*)GetDlgItem(IDC_MODIFYMEAING)->EnableWindow(TRUE);
		}
		else
		{
			SetDlgItemText(IDC_DETAIL,result);
			(CButton*)GetDlgItem(IDC_ADDTODICT)->EnableWindow(TRUE);
		}
	}
}

void CSearchWordDlg::OnEditchangeWord() 
{
	// TODO: Add your control notification handler code here
	(CButton*)GetDlgItem(IDC_MODIFYMEAING)->EnableWindow(FALSE);
	(CButton*)GetDlgItem(IDC_ADDTODICT)->EnableWindow(FALSE);
	m_word.ShowDropDown(TRUE);
}

BOOL CSearchWordDlg::IsChinese(CString str)
{
	BOOL  bIsChinese=FALSE;   
	state=1;
	int   i=0;   
	while(i<str.GetLength())   
	{   
		if(str[i]<0)
		{   
			state=0;
			bIsChinese=TRUE;   
			break;  
		}   	
		i++;
	}	

	return bIsChinese;
}

BOOL CSearchWordDlg::CnToEn(CString str, CString &re)
{
	CString sql;
	char enword[100];
	char wordtype[100];
	char wordId[100];

	m_dictType.GetLBText(m_dictType.GetCurSel(),dictType);

	sql.Format("SELECT * From %s WHERE CnMeaning='%s'",dictType,str);
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return false;
	int no=m_MyDB->GetDataSetRowCount(1);
	
	if(!no)
	{
		re="���鵥�ʲ�����!!!\n����Խ�������ֵ�^_^";
		return false;
	}

	else
	{
		m_MyDB->GetDataSetFieldValue(0,0,wordId);
		curWordId=atoi(wordId);
		m_MyDB->GetDataSetFieldValue(0,1,enword);
		re+=enword;
		re+="\r\n";
		re+="Word Type: ";
		m_MyDB->GetDataSetFieldValue(0,2,wordtype);
		typeId=atoi(wordtype);

		sql.Format("SELECT WordType From WordType WHERE ID=%d",typeId);
		if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
			return false;
		
		m_MyDB->GetDataSetFieldValue(0,0,wordtype);
		re+=wordtype;
		return true;
	}
}

BOOL CSearchWordDlg::EnToCn(CString str, CString &re)
{
	CString sql;
	char cnword[100];
	char wordtype[100];
	char wordId[100];
	
	m_dictType.GetLBText(m_dictType.GetCurSel(),dictType);
	
	sql.Format("SELECT * From %s WHERE EnWord='%s'",dictType,str);
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return false;
	int no=m_MyDB->GetDataSetRowCount(1);
	
	if(no<0)
	{
		re="���ʲ�����!!!";
		return false;
	}
	
	else
	{
		m_MyDB->GetDataSetFieldValue(0,0,wordId);
		curWordId=atoi(wordId);
		m_MyDB->GetDataSetFieldValue(0,3,cnword);
		re+=cnword;
		re+="\r\n";
		re+="����: ";
		m_MyDB->GetDataSetFieldValue(0,2,wordtype);
		typeId=atoi(wordtype);
		
		sql.Format("SELECT WordType From WordType WHERE ID=%d",typeId);
		if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
			return false;
		
		m_MyDB->GetDataSetFieldValue(0,0,wordtype);

		re+=wordtype;
		return true;
	}
}

void CSearchWordDlg::OnAddtodict() 
{
	// TODO: Add your control notification handler code here
	CString sql;
	CString tans;
	CAddWordDlg dlg;
	int type;
	if (dlg.DoModal()==IDOK)
	{
		if (state==1)//EntoCn
		{
			EnWord=targetWord;
			CnMeaning=dlg.trans;
			type=dlg.type;
		}
		else
			if (state==0)//CntoEn
			{
				EnWord=dlg.trans;
				CnMeaning=targetWord;
				type=dlg.type;
			}
	}
	
	sql.Format("INSERT INTO %s(EnWord,WordType,CnMeaning) VALUES('%s',%d,'%s')",dictType,EnWord,type,CnMeaning);
	if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
		return ;
	
	InitWordCombo();
}

void CSearchWordDlg::OnModifymeaing() 
{
	// TODO: Add your control notification handler code here
	CModifyDlg dlg;
	CString newMeaning;
	int newType;
	CString sql;
	CString result;
	CString cnewtype;

	dlg.type=typeId;
	if (dlg.DoModal()==IDOK)
	{
		newMeaning=dlg.newMeaning;
		newType=dlg.type;
		cnewtype=dlg.cnewtype;
	
		if (state==1)//EntoCn
		{
			sql.Format("UPDATE %s SET CnMeaning='%s',WordType=%d WHERE ID=%d",dictType,newMeaning,newType,curWordId);
			
			if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
				return ;

			result.Format("����: %s\r\n����: %s",newMeaning,cnewtype);
			SetDlgItemText(IDC_DETAIL,result);
		}
		else
			if (state==0)
			{
				sql.Format("UPDATE %s SET EnWord='%s',WordType=%d WHERE ID=%d",dictType,newMeaning,newType,curWordId);
				
				if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
					return ;

				result.Format("����: %s\r\n����: %s",newMeaning,cnewtype);
				SetDlgItemText(IDC_DETAIL,result);
			}
	}
}

void CSearchWordDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	CHelpDlg dlg;
	dlg.DoModal();
}

void CSearchWordDlg::OnCloseupDicttype() 
{
	// TODO: Add your control notification handler code here
	InitWordCombo();
}
