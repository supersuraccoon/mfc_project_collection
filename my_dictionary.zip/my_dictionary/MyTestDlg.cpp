// MyTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MyDict.h"
#include "MyTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

int countdown=10;
/////////////////////////////////////////////////////////////////////////////
// CMyTestDlg dialog


CMyTestDlg::CMyTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMyTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMyTestDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CMyTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyTestDlg)
	DDX_Control(pDX, IDC_COMBO1, m_dictType);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMyTestDlg, CDialog)
	//{{AFX_MSG_MAP(CMyTestDlg)
	ON_BN_CLICKED(ID_START, OnStart)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyTestDlg message handlers

void CMyTestDlg::OnStart() 
{
	// TODO: Add your control notification handler code here
	m_dictType.EnableWindow(FALSE);
	CString question;
	
	SetDlgItemText(IDC_CORRECT,"0");
	SetDlgItemText(IDC_ERROR,"0");

	question=RandQuestion();
	SetDlgItemText(IDC_QUESTION,question);

	SetTimer(1,1000,NULL);
}

BOOL CMyTestDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CMyDictApp* pApp=(CMyDictApp*)AfxGetApp();  
	DBpath=pApp->DBPath;
	
	m_MyDB = new CAccessDB(DBpath.GetBuffer(MAX_PATH),DBpath.GetBuffer(MAX_PATH),0);
	DBpath.ReleaseBuffer();
	
	if(!m_MyDB->OpenDB(DBpath.GetBuffer(MAX_PATH)))
	{
		AfxMessageBox("DB Open Error!");
		DBpath.ReleaseBuffer();
		return FALSE;
	}
	
	DBpath.ReleaseBuffer();

	CRect rect;
	GetWindowRect(&rect);
	
	int m_xScreen;
	int m_yScreen;
	m_xScreen=GetSystemMetrics(SM_CXSCREEN);
	m_yScreen=GetSystemMetrics(SM_CYSCREEN);
	
	SetWindowPos(&wndTopMost,m_xScreen/2,m_yScreen/2,rect.Width(),rect.Height(),SWP_SHOWWINDOW);

	InitDictTypeCombo();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CMyTestDlg::InitDictTypeCombo()
{
	CString sql="SELECT * From  DictType";
	CString dictType;
	
	m_dictType.ResetContent();
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return false;
	int DictTypeNo=m_MyDB->GetDataSetRowCount(1);
	
	if(!DictTypeNo)
		DictTypeNo=0;
	
	for(int i=0;i<DictTypeNo;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,1,dictType.GetBuffer(0));
		m_dictType.AddString(dictType);
	}
	m_dictType.SetCurSel(0);
	
	return true;
}

CString CMyTestDlg::RandQuestion()
{
	CString sql;
	CString question;
	CString dictType;
	int QNo;
	int totalNo;

	m_dictType.GetLBText(m_dictType.GetCurSel(),dictType);
	sql.Format("SELECT * From %s",dictType);
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return question;
	totalNo=m_MyDB->GetDataSetRowCount(1);

	srand((unsigned)time(NULL));
	QNo=rand()%totalNo;

	m_MyDB->GetDataSetFieldValue(QNo,3,question.GetBuffer(0));
	return question;
}

void CMyTestDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	CString time;
	CString Answer;
	CString Question;
	CString right;
	CString wrong;
	int nright;
	int nwrong;

	time.Format("%d",countdown);
	SetDlgItemText(IDC_TIME,time);	

	if (countdown==0)
	{
		CString question;
		GetDlgItemText(IDC_QUESTION,Question);
		GetDlgItemText(IDC_ANSWER,Answer);
		SetDlgItemText(IDC_ANSWER,"");
		if (CheckAnswer(Answer,Question))
		{
			GetDlgItemText(IDC_CORRECT,right);
			nright=atoi(right);
			nright++;
			right.Format("%d",nright);
			SetDlgItemText(IDC_CORRECT,right);
		}
		else
		{
			GetDlgItemText(IDC_ERROR,wrong);
			nwrong=atoi(wrong);
			nwrong++;
			wrong.Format("%d",nwrong);
			SetDlgItemText(IDC_ERROR,wrong);
		}

		question=RandQuestion();
		SetDlgItemText(IDC_QUESTION,question);
		countdown=11;
	}

	countdown--;

	CDialog::OnTimer(nIDEvent);
}

BOOL CMyTestDlg::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	CString Answer;
	CString Question;
	CString right;
	CString wrong;
	int nright;
	int nwrong;
	if(pMsg->message == WM_KEYDOWN)
    {
        switch(pMsg->wParam)
        {
        case VK_RETURN: 
			GetDlgItemText(IDC_QUESTION,Question);
            GetDlgItemText(IDC_ANSWER,Answer);
			SetDlgItemText(IDC_ANSWER,"");
			if (CheckAnswer(Answer,Question))
			{
				GetDlgItemText(IDC_CORRECT,right);
				nright=atoi(right);
				nright++;
				right.Format("%d",nright);
				SetDlgItemText(IDC_CORRECT,right);
			}
			else
			{
				GetDlgItemText(IDC_ERROR,wrong);
				nwrong=atoi(wrong);
				nwrong++;
				wrong.Format("%d",nwrong);
				SetDlgItemText(IDC_ERROR,wrong);
			}
			SetDlgItemText(IDC_QUESTION,RandQuestion());
			countdown=10;
            return TRUE;
        }
    }

	return CDialog::PreTranslateMessage(pMsg);
}

BOOL CMyTestDlg::CheckAnswer(CString ans,CString ques)
{
	CString sql;
	CString dictType;
	CString rightAnswer;
	
	if (ans=="")
	{
		return FALSE;
	}
	m_dictType.GetLBText(m_dictType.GetCurSel(),dictType);
	sql.Format("SELECT EnWord From %s WHERE CnMeaning='%s'",dictType,ques);
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return FALSE;
	m_MyDB->GetDataSetRowCount(1);
	
	m_MyDB->GetDataSetFieldValue(0,0,rightAnswer.GetBuffer(0));
	
	if (rightAnswer==ans)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

void CMyTestDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	KillTimer(1);
	
	CDialog::OnCancel();
}
