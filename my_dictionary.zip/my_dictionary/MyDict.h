// MyDict.h : main header file for the MYDICT application
//

#if !defined(AFX_MYDICT_H__2ABF22E7_AD89_4764_B112_BAE9BE07AE5D__INCLUDED_)
#define AFX_MYDICT_H__2ABF22E7_AD89_4764_B112_BAE9BE07AE5D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CMyDictApp:
// See MyDict.cpp for the implementation of this class
//

class CMyDictApp : public CWinApp
{
public:
	CString DBPath;
	CString strPath;
	CMyDictApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyDictApp)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CMyDictApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYDICT_H__2ABF22E7_AD89_4764_B112_BAE9BE07AE5D__INCLUDED_)
