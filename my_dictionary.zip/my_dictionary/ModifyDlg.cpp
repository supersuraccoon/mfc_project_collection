// ModifyDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MyDict.h"
#include "ModifyDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CModifyDlg dialog


CModifyDlg::CModifyDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CModifyDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CModifyDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CModifyDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CModifyDlg)
	DDX_Control(pDX, IDC_NEWTYPE, m_newType);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CModifyDlg, CDialog)
	//{{AFX_MSG_MAP(CModifyDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CModifyDlg message handlers

BOOL CModifyDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CMyDictApp* pApp=(CMyDictApp*)AfxGetApp();  
	DBpath=pApp->DBPath;
	
	m_MyDB = new CAccessDB(DBpath.GetBuffer(MAX_PATH),DBpath.GetBuffer(MAX_PATH),0);
	DBpath.ReleaseBuffer();
	
	if(!m_MyDB->OpenDB(DBpath.GetBuffer(MAX_PATH)))
	{
		AfxMessageBox("DB Open Error!");
		DBpath.ReleaseBuffer();
		return FALSE;
	}
	
	DBpath.ReleaseBuffer();
	
	IntiTypeCombo();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CModifyDlg::IntiTypeCombo()
{
	CString sql="SELECT WordType From WordType";
	CString word;
	
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return false;
	int TypeNo=m_MyDB->GetDataSetRowCount(1);
	
	if(TypeNo<0)
		TypeNo=0;
	
	for(int i=0;i<TypeNo;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,word.GetBuffer(0));
		m_newType.AddString(word);
	}
	m_newType.SetCurSel(type-1);
	return true;
}

void CModifyDlg::OnOK() 
{
	// TODO: Add extra validation here
	type=m_newType.GetCurSel()+1;
	GetDlgItemText(IDC_EDIT1,newMeaning);
	m_newType.GetLBText(m_newType.GetCurSel(),cnewtype);
	
	CDialog::OnOK();
}
