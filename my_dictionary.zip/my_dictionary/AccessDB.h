// MyDB.h: interface for the CAccessDB class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYDB_H__62B1A15A_D2C8_42A4_B9C7_78D3BC8B7664__INCLUDED_)
#define AFX_MYDB_H__62B1A15A_D2C8_42A4_B9C7_78D3BC8B7664__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxdao.h>
//#include <AFXSTATE.h>
#include <ODBCINST.H>
#include <AFXDB.H>

#define MAXTABLE		200
#define MAXTABLENAME	30
#define	MAXFIELD		200
#define MAXFIELDNAME	30
#define MAXDATASETNAME	20
#define MAXSQLSTRING	1000

#define DBNAME		"garment.mdb"
#define NAMETB		".\\dbname.ini"
#define NAMELB		".\\labname.ini"



#define DB_CONDITIONERROR			-1
#define DB_DATAEXIST				-2
#define DB_INSERTERROR				-3
#define DB_DATANOTEXIST				-4
#define DB_OTHERERROR				-5


#define YYYYMMDD	0
#define	YYMMDD		1
#define	YYIMMIDD	2
#define	MMIDDIYY	3


#define DESC		0
#define ASC			1

/*////////////////////////////////////////////////////////////////////

*///////////////////////////////////////////
struct AccessConnInfo
{
	char DBName[256];
	char DBPath[256];
	char UserName[20];
	char PassWord[12];

	char ServerName[20];
};

class CAccessDB:public CObject
{
public:
	int UpdateRecord(char *tbName,CStringArray &KeyName,CStringArray &KeyValues,CStringArray &fldName,CStringArray &fldValues);
	int DelRecord(char *tbName,CStringArray &KeyName,CStringArray &KeyValues,int flag=1);
	int AddRecord(char *tbName,CStringArray &fldName,CStringArray &fldValues);
	short GetFieldType(char *TableName,int FieldIndex);
	short GetFieldType(char *TableName,char *FieldName);
	BOOL IsDBOpen();
	int ConnectDB(const char * DsnName,const char *UserName,const char *Password);
	void OptimizeDB();
	char * GetFieldName(char *TableName,int FieldIndex);
	char * GetFieldName(int TableIndex,int FieldIndex);
	char * GetTableName(int TbIndex);
	int GetDataSetFieldValue(int iFieldIndex,char * OutValue);
	void MoveNext();
	BOOL IsEOF();
	void MoveFirst();
	BOOL DeleteDataSet(char * DSName);
	void GetCurrentDateSetName(char *OutValue);
	int GetDataSetFieldValue(int RowIndex,char * FieldName,char *OutValue);
	int GetDataSetFieldValue(int RowIndex,int iFieldIndex,char *OutValue);
	int GetDataSetRowCount(int ForceAll=0,BOOL DoException=FALSE);
	int GetDataSetFieldName(int nIndex,char *OutValue);
	int SetDataSet(char * DSName,char * szSql,int szOpenMode=dbOpenDynaset);
	int GetDataSetFieldCount();
	BOOL FreshTBInfo(char * TbName);
	BOOL FreshDBInfo();
	int GetValueInField(char * TbName,int nIndex,char * OutValue);
	int GetValueInField(char * TbName,char * lpszName,char *OutValue);
	int GetRowCount(char * TbName);
	int GetFieldCount(char * TbName);
	int GetTableCount();
//	int ConnectDB(char *DBPath=NULL,char *DBName=NULL);
	int ConnectDB(char * DsnName=NULL);
	int ExecSQL(unsigned char *szSql);
	BOOL CloseDB();
	int OpenDB(LPCTSTR lpszName,BOOL bExclusive = FALSE,BOOL bReadOnly = FALSE,
				LPCTSTR lpszConnect = _T(""));
//	CAccessDB(char *DBPath,char *DBName);
	CAccessDB(char *DBPath,char * DBName,int OptFlag=0);
	virtual ~CAccessDB();
	char m_DSName[MAXDATASETNAME];

private:
	char m_DBPath[200];
	char m_FieldName[MAXTABLE][MAXFIELD][MAXFIELDNAME];
	short m_FieldType[MAXTABLE][MAXFIELD];
	char m_DBName[MAXTABLENAME];
	char m_DataSetSql[MAXSQLSTRING];
	char m_TableName[MAXTABLE][MAXTABLENAME];
	int m_TableCount;
	CDaoDatabase m_DB;
	CDaoRecordset m_DataSet;
protected:
	CString Str2Variant(const COleVariant &var);
	LPCTSTR Str2Bool(BOOL bFlag);
};

char * SwitchName2Lab(char *KeyName,char *SectionName=NULL,char *FileName=NULL,char *AppName=NULL);

char * SwitchLab2Name(char *Lab,char *SectionName=NULL);

#ifdef _MYSYSTEMAPI_

char *GetCurAppExecPath(CString &strPath,char *AppName);
BOOL GetCurAppExecPath(char * szPath,char *AppName);
#endif

#endif // !defined(AFX_MYDB_H__62B1A15A_D2C8_42A4_B9C7_78D3BC8B7664__INCLUDED_)
