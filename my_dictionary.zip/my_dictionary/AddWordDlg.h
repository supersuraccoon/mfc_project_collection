#if !defined(AFX_ADDWORDDLG_H__0D6498B4_37C4_4D6D_AE85_C67B630C5436__INCLUDED_)
#define AFX_ADDWORDDLG_H__0D6498B4_37C4_4D6D_AE85_C67B630C5436__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AddWordDlg.h : header file
//

#include "AccessDB.h"
/////////////////////////////////////////////////////////////////////////////
// CAddWordDlg dialog

class CAddWordDlg : public CDialog
{
// Construction
public:
	BOOL IntiTypeCombo();
	CAddWordDlg(CWnd* pParent = NULL);   // standard constructor
	CAccessDB * m_MyDB;
	CString DBpath;
	CString trans;
	int type;

// Dialog Data
	//{{AFX_DATA(CAddWordDlg)
	enum { IDD = IDD_ADDWORD };
	CComboBox	m_type;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAddWordDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CAddWordDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADDWORDDLG_H__0D6498B4_37C4_4D6D_AE85_C67B630C5436__INCLUDED_)
