//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MyDict.rc
//
#define IDRESTART                       3
#define ID_START                        4
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MYDICT_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDD_SEARCHWORD                  129
#define IDI_ICON1                       131
#define IDD_ADDWORD                     132
#define IDD_MODIFYMEANING               133
#define IDI_ICON4                       144
#define IDI_ICON6                       146
#define IDI_ICON2                       147
#define IDI_ICON3                       148
#define IDD_DICTMANAGEMENT              149
#define IDI_ICON5                       151
#define IDD_HELPDLG                     152
#define IDD_ADDDICT                     153
#define IDD_TEST                        154
#define IDC_DICTTYPE                    1000
#define IDC_WORD                        1001
#define IDC_SEARCH                      1002
#define IDC_SEARCHWORD                  1003
#define IDC_TEST                        1004
#define IDC_DETAIL                      1005
#define IDC_DICTMANAGEMRNT              1005
#define IDC_EDIT1                       1006
#define IDC_ADDTODICT                   1007
#define IDC_TYPE                        1007
#define IDC_MODIFYMEAING                1008
#define IDC_NEWTYPE                     1008
#define IDC_WORDLIST                    1010
#define IDC_COMBO1                      1011
#define IDC_DELETEDICT                  1012
#define IDC_ADDDICT                     1013
#define IDC_ADDWORD                     1014
#define IDC_DELETEWORD                  1015
#define IDC_WORDTYPE                    1016
#define IDC_BUTTON1                     1017
#define IDC_EXPORT                      1017
#define IDC_SAVEWORD                    1018
#define IDC_IMPORT                      1019
#define IDC_QUESTION                    1020
#define IDC_SAVEALL                     1020
#define IDC_iii                         1021
#define IDC_ANSWER                      1022
#define IDC_TIME                        1023
#define IDC_CORRECT                     1024
#define IDC_ERROR                       1025
#define IDC_LEFT                        1026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        156
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
