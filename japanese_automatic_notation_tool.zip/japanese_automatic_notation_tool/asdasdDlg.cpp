// asdasdDlg.cpp : implementation file
//

#include "stdafx.h"
#include "asdasd.h"
#include "asdasdDlg.h"
#include "SxcDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

bool flg=true;
CString path;
CString title;
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();
	
	// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA
	
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	
	// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
//{{AFX_MSG_MAP(CAboutDlg)
// No message handlers
//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAsdasdDlg dialog

CAsdasdDlg::CAsdasdDlg(CWnd* pParent /*=NULL*/)
: CDialog(CAsdasdDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAsdasdDlg)
	// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CAsdasdDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAsdasdDlg)
	// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAsdasdDlg, CDialog)
//{{AFX_MSG_MAP(CAsdasdDlg)
ON_WM_SYSCOMMAND()
ON_WM_PAINT()
ON_WM_QUERYDRAGICON()
ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_BN_CLICKED(IDC_BUTTON4, OnButton4)
	ON_BN_CLICKED(IDCANCEL2, OnCancel2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAsdasdDlg message handlers

BOOL CAsdasdDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	// Add "About..." menu item to system menu.
	
	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);
	
	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}
	
	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_bExpand=FALSE;
	CRect rcDlg, rcMarker;
	GetWindowRect(rcDlg);
	m_nExpandedHeight = rcDlg.Height();
	GetDlgItem(IDC_BORDER)->GetWindowRect(rcMarker);
	m_nNormalHeight = (rcMarker.top - rcDlg.top);
	Display();
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CAsdasdDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CAsdasdDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting
		
		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);
		
		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
		
		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CAsdasdDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CAsdasdDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	CString re="\r\n";
	
	
	int ret;
	CString str;
	CStdioFile readfile(path,CFile::modeRead);
	CStdioFile writefile(title+="---ע��.txt",CFile::modeWrite|CFile::modeCreate);
	
	readfile.ReadString(str);
	
	while(ret!=FALSE)
	{
		writefile.WriteString(str);
		writefile.WriteString(re);
		str=Transfer(str);
		writefile.WriteString(str);
		writefile.WriteString(re);
		
		
		do
		{
			ret=readfile.ReadString(str);
		}
		while(str==""&&ret!=FALSE);
		
		if(ret==FALSE)
			break;
	}

	MessageBox("ע�����!!!");
}
	
	void CAsdasdDlg::Encode(CString &str)
	{
		if (str=="��"||str=="��"||str=="��")	
			str="a";
		else
			if (str=="��"||str=="��"||str=="��")	
				str="i";
			else
				if (str=="��"||str=="��"||str=="��")
					str="u";
				else
					if (str=="��"||str=="��"||str=="��")
						str="e";
					else
						if (str=="��"||str=="��"||str=="��")
							str="o";
						else
							if (str=="��"||str=="��")
								str="ka";
							else
								if (str=="��"||str=="��")
									str="ki";
								else
									if (str=="��"||str=="��")
										str="ku";
									else
										if (str=="��"||str=="��")
											str="ke";
										else
											if (str=="��"||str=="��")
												str="ko";
											else
												if (str=="��"||str=="��")
													str="sa";
												else
													if (str=="��"||str=="��")
														str="xi";
													else
														if (str=="��"||str=="��")
															str="si";
														else
															if (str=="��"||str=="��")
																str="se";
															else
																if (str=="��"||str=="��")
																	str="so";
																else
																	if (str=="��"||str=="��")
																		str="ta";
																	else
																		if (str=="��"||str=="��")
																			str="qi";
																		else
																			if (str=="��"||str=="��")
																				str="ji";
																		else
																			if (str=="��"||str=="��")
																				str="ci";
																			else
																				if (str=="��"||str=="��")
																					str="te";
																				else
																					if (str=="��"||str=="��")
																						str="to";
																					else
																						if (str=="��"||str=="��")
																							str="na";
																						else
																							if (str=="��"||str=="��")
																								str="ni";
																							else
																								if (str=="��"||str=="��")
																									str="nu";
																								else
																									if (str=="��"||str=="��")
																										str="ne";
																									else
																										if (str=="��"||str=="��")
																											str="no";
																										else
																											if (str=="��"||str=="��")
																												str="ha";
																											else
																												if (str=="��"||str=="��")
																													str="hi";
																												else
																													if (str=="��"||str=="��")
																														str="fu";
																													else
																														if (str=="��"||str=="��")
																															str="he";
																														else
																															if (str=="��"||str=="��")
																																str="ho";
																															else
																																if (str=="��"||str=="��")
																																	str="ra";
																																else
																																	if (str=="��"||str=="��")
																																		str="ri";
																																	else
																																		if (str=="��"||str=="��")
																																			str="ru";
																																		else
																																			if (str=="��"||str=="��")
																																				str="re";
																																			else
																																				if (str=="��"||str=="��")
																																					str="ro";
																																				else
																																					if (str=="��"||str=="��"||str=="��")
																																						str="wa";
																																					else
																																						if (str=="��"||str=="��")
																																							str="o";
																																						else
																																							if (str=="��"||str=="��")
																																								str="n";
																																							else
																																								if (str=="��"||str=="��"||str=="��"||str=="��")
																																									str="ya";
																																								else
																																									if (str=="��"||str=="��"||str=="��"||str=="��")
																																										str="yu";
																																									else
																																										if (str=="��"||str=="��"||str=="��"||str=="��")
																																											str="yo";
																																										else
																																											if (str=="��"||str=="��")
																																												str="ma";
																																											else
																																												if (str=="��"||str=="��")
																																													str="mi";
																																												else
																																													if (str=="��"||str=="��")
																																														str="mu";
																																													else
																																														if (str=="��"||str=="��")
																																															str="me";
																																														else
																																															if (str=="��"||str=="��")
																																																str="mo";
																																															else
																																																if (str=="��"||str=="��")
																																																	str="ga";
																																																else
																																																	if (str=="��"||str=="��")
																																																		str="gi";
																																																	else
																																																		if (str=="��"||str=="��")
																																																			str="gu";
																																																		else
																																																			if (str=="��"||str=="��")
																																																				str="ge";
																																																			else
																																																				if (str=="��"||str=="��")
																																																					str="go";
																																																				else
																																																					if (str=="��"||str=="��")
																																																						str="za";
																																																					else
																																																						if (str=="��"||str=="��")
																																																							str="ji";
																																																						else
																																																							if (str=="��"||str=="��")
																																																								str="zi";
																																																							else
																																																								if (str=="��"||str=="��")
																																																									str="ze";
																																																								else
																																																									if (str=="��"||str=="��")
																																																										str="zo";
																																																									else
																																																										if (str=="��"||str=="��")
																																																											str="ba";
																																																										else
																																																											if (str=="��"||str=="��")
																																																												str="bi";
																																																											else
																																																												if (str=="��"||str=="��")
																																																													str="bu";
																																																												else
																																																													if (str=="��"||str=="��")
																																																														str="be";
																																																													else
																																																														if (str=="��"||str=="��")
																																																															str="bo";
																																																														else
																																																															if (str=="��"||str=="��")
																																																																str="pa";
																																																															else
																																																																if (str=="��"||str=="��")
																																																																	str="pi";
																																																																else
																																																																	if (str=="��"||str=="��")
																																																																		str="pu";
																																																																	else
																																																																		if (str=="��"||str=="��")
																																																																			str="pe";
																																																																		else
																																																																			if (str=="��"||str=="��")
																																																																				str="po";
																																																																			else
																																																																				if (str=="��"||str=="��")
																																																																					str="da";
																																																																				else
																																																																					if (str=="��"||str=="��")
																																																																						str="zi";
																																																																					else
																																																																						if (str=="��"||str=="��")
																																																																							str="de";
																																																																						else
																																																																							if (str=="��"||str=="��")
																																																																								str="do";
																																																																							else
																																																																								if (str=="�`")
																																																																								str="  ";
																																																																								else
																																																																									if (str=="��"||str=="��")
																																																																								str="  ";
																																																																							else
																																																																								str="";
}

CString CAsdasdDlg::Transfer(CString str)
{
	int length=str.GetLength();
	CString ret;
	CString temp;
	for(int index=0;index<length;)
	{
		char ch[3];
		ch[2]=0;
		ch[0]=str.GetAt(index);
		if(0<=ch[0]&&ch[0]<=255)
		{
			ret+=" ";
			index++;
			continue;
		}
		if((index+1)==length)
			return ret;
		ch[1]=str.GetAt(++index);
		temp=ch;

		Encode(temp);
		if(temp=="")
		{
			ret+="  ";
			index++;
			continue;
		}

		if (temp.GetLength()==1)
		{
			temp+=" ";
		}
		ret+=temp;
		index++;
	}

	return ret;
}

void CAsdasdDlg::Display()
{
	CRect rcDlg;
	
	GetWindowRect(rcDlg);
	
	if (m_bExpand)
	{
		rcDlg.SetRect( rcDlg.left, rcDlg.top, 
			rcDlg.left + rcDlg.Width(),
			rcDlg.top + m_nExpandedHeight);
	}
	else
	{
		rcDlg.SetRect(rcDlg.left, rcDlg.top, 
			rcDlg.left + rcDlg.Width(),
			rcDlg.top + m_nNormalHeight);
	}
	
	MoveWindow(rcDlg, TRUE);
}

void CAsdasdDlg::OnButton3() 
{
	// TODO: Add your control notification handler code here
	m_bExpand = !m_bExpand;
	Display();
}

void CAsdasdDlg::OnButton2() 
{
	// TODO: Add your control notification handler code here
	CFileDialog fileDlg(TRUE);
	fileDlg.m_ofn.lpstrTitle="�ҵ��ļ��򿪶Ի���";
	fileDlg.m_ofn.lpstrFilter="Text Files(*.txt)\0*.txt\0All Files(*.*)\0*.*\0\0";

	if(IDOK==fileDlg.DoModal())
	{
		path=fileDlg.GetFileName();
		title=fileDlg.GetFileTitle();
	}
}

void CAsdasdDlg::OnButton4() 
{
	// TODO: Add your control notification handler code here
	CFileDialog fileDlg(FALSE);
	CString savePath="";
	CString savePathCopy="";
	CString text;
	fileDlg.m_ofn.lpstrTitle="�ҵ��ļ�����Ի���";
	fileDlg.m_ofn.lpstrFilter="Text Files(*.txt)\0*.txt\0All Files(*.*)\0*.*\0\0";
	
	GetDlgItemText(IDC_EDIT1,text);
	if (text=="")
	{
		MessageBox("�ı�������Ϊ��!!!");
		return;
	}

	else
	{
		if(IDOK==fileDlg.DoModal())
		{
			savePath=fileDlg.GetFileName();
		}
		
		if (savePath=="")
		{
			return;
		}
		else
		{
			savePathCopy=savePath;
			CStdioFile mywritefile(savePathCopy+="sss.txt",CFile::modeWrite|CFile::modeCreate);
			mywritefile.WriteString(text);
			mywritefile.Close();
			
			CString re="\r\n";
			
			
			int ret;
			CString str;
			CStdioFile readfile(savePathCopy,CFile::modeRead);
			CStdioFile writefile(savePath+=".txt",CFile::modeWrite|CFile::modeCreate);
			
			readfile.ReadString(str);
			str=str.Left(str.GetLength()-1);
			
			while(ret!=FALSE)
			{
				writefile.WriteString(str);
				writefile.WriteString(re);
				str=Transfer(str);
				writefile.WriteString(str);
				writefile.WriteString(re);
				
				
				do
				{
					ret=readfile.ReadString(str);
				}
				while(str==""&&ret!=FALSE);
				
				if(ret==FALSE)
					break;
				str=str.Left(str.GetLength()-2);
			}

			readfile.Close();
			writefile.Close();
			DeleteFile(savePathCopy);
		}
	MessageBox("ע�����!!!");
	}
}

void CAsdasdDlg::OnCancel2() 
{
	// TODO: Add your control notification handler code here
	CSxcDlg dlg;
	dlg.DoModal();
}
