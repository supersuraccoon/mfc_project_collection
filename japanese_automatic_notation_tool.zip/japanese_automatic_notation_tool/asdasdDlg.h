// asdasdDlg.h : header file
//

#if !defined(AFX_ASDASDDLG_H__300CCB82_3646_4544_836E_1595E4FD1099__INCLUDED_)
#define AFX_ASDASDDLG_H__300CCB82_3646_4544_836E_1595E4FD1099__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CAsdasdDlg dialog

class CAsdasdDlg : public CDialog
{
// Construction
public:
	void Display();
	CString Transfer(CString str);
	void Encode(CString &str);
	CAsdasdDlg(CWnd* pParent = NULL);	// standard constructor
	BOOL m_bExpand;
	UINT m_nExpandedHeight,m_nNormalHeight;

// Dialog Data
	//{{AFX_DATA(CAsdasdDlg)
	enum { IDD = IDD_ASDASD_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAsdasdDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CAsdasdDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButton1();
	afx_msg void OnButton3();
	afx_msg void OnButton2();
	afx_msg void OnButton4();
	afx_msg void OnCancel2();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ASDASDDLG_H__300CCB82_3646_4544_836E_1595E4FD1099__INCLUDED_)
