// MyColorDlg.cpp : implementation file
//

#include "stdafx.h"
#include "1.h"
#include "MyColorDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyColorDlg

IMPLEMENT_DYNAMIC(CMyColorDlg, CColorDialog)

CMyColorDlg::CMyColorDlg(COLORREF clrInit, DWORD dwFlags, CWnd* pParentWnd) :
	CColorDialog(clrInit, dwFlags, pParentWnd)
{
}


BEGIN_MESSAGE_MAP(CMyColorDlg, CColorDialog)
	//{{AFX_MSG_MAP(CMyColorDlg)
	ON_WM_MOVING()
	ON_WM_CREATE()
	ON_WM_SETCURSOR()
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()




void CMyColorDlg::OnMoving(UINT fwSide, LPRECT pRect) 
{
	CColorDialog::OnMoving(fwSide, pRect);
	
	// TODO: Add your message handler code here
    CRect   rect;   
    GetWindowRect(&rect);   
    CDialog::OnMoving(fwSide,   pRect);   
    pRect->bottom=rect.bottom;   
    pRect->left=rect.left;   
    pRect->right=rect.right;   
    pRect->top=rect.top;
	
}

int CMyColorDlg::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CColorDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	//ModifyStyle(WS_CAPTION,0,SWP_DRAWFRAME);

	return 0;
}

BOOL CMyColorDlg::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	// TODO: Add your message handler code here and/or call default
	::SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR5));
	return   TRUE; 
	return CColorDialog::OnSetCursor(pWnd, nHitTest, message);
}

void CMyColorDlg::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	
	CColorDialog::OnClose();
}
