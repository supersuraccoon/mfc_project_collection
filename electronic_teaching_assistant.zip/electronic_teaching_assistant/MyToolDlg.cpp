// MyToolDlg.cpp : implementation file
//

 
#include "stdafx.h"
#include "1.h"

#include "MainFrm.h"
#include "HelpDlg.h"
#include "StyleSetDlg.h"
#include "MyColorDlg.h"

//#ifndef   MY_FILENAME_H   
//#define   MY_FILENAME_H   

#include "1View.h"
#include "MyToolDlg.h"

//#endif  



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyToolDlg dialog


CMyToolDlg::CMyToolDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMyToolDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMyToolDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_nEdgeSnapGap=15;
}

CMyToolDlg::CMyToolDlg(CMy1View *m_pView,CWnd* pParent)     
:   CDialog(CMyToolDlg::IDD, pParent)   
{   
	pView=m_pView;   
}


void CMyToolDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyToolDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here

	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMyToolDlg, CDialog)
	//{{AFX_MSG_MAP(CMyToolDlg)
		ON_WM_CREATE()
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_BN_CLICKED(IDC_BUTTON7, OnButton7)
	ON_BN_CLICKED(IDC_BUTTON4, OnButton4)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	ON_BN_CLICKED(IDC_BUTTON5, OnButton5)
	ON_BN_CLICKED(IDC_BUTTON6, OnButton6)
	ON_BN_CLICKED(IDC_BUTTON8, OnButton8)
	ON_BN_CLICKED(IDC_BUTTON9, OnButton9)
	ON_BN_CLICKED(IDC_BUTTON10, OnButton10)
	ON_BN_CLICKED(IDC_BUTTON11, OnButton11)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyToolDlg message handlers

BOOL CMyToolDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	int m_xScreen;
	int m_yScreen;
	m_xScreen=GetSystemMetrics(SM_CXSCREEN);
	m_yScreen=GetSystemMetrics(SM_CYSCREEN);
	SetWindowPos(&wndTop,m_xScreen-180,m_yScreen-180,180,180,NULL); 
	// TODO: Add extra initialization here
	CRect rect;
	m_btn1.SubclassDlgItem(IDC_BUTTON2,this);
	m_btn1.SetIcon(IDI_ICON2);
	m_btn1.SetTooltipText("���ʹ���");

	m_btn2.SubclassDlgItem(IDC_BUTTON7,this);
	m_btn2.SetIcon(IDI_ICON3);
	m_btn2.SetTooltipText("��Ƥ��");

	m_btn3.SubclassDlgItem(IDC_BUTTON3,this);
	m_btn3.SetIcon(IDI_ICON5);
	m_btn3.SetTooltipText("�Ŵ�");

	m_btn4.SubclassDlgItem(IDC_BUTTON4,this);
	m_btn4.SetIcon(IDI_ICON1);
	m_btn4.SetTooltipText("�����ͼ");

	m_btn5.SubclassDlgItem(IDC_BUTTON5,this);
	m_btn5.SetIcon(IDI_ICON6);
	m_btn5.SetTooltipText("��ɫѡ����");

	m_btn6.SubclassDlgItem(IDC_BUTTON6,this);
	m_btn6.SetIcon(IDI_ICON13);
	m_btn6.SetTooltipText("����");

	m_btn7.SubclassDlgItem(IDC_BUTTON8,this);
	m_btn7.SetIcon(IDI_ICON16);
	m_btn7.SetTooltipText("�˳�");

	m_btn8.SubclassDlgItem(IDC_BUTTON9,this);
	m_btn8.SetIcon(IDI_ICON12);
	m_btn8.SetTooltipText("����");

	m_btn9.SubclassDlgItem(IDC_BUTTON11,this);
	m_btn9.SetIcon(IDI_ICON11);
	m_btn9.SetTooltipText("�����߿�");

	//this->GetWindowRect(rect);
    //this->SetWindowPos(&wndTopMost,rect.left,rect.top,rect.Width(),rect.Height(),SWP_NOMOVE);
	

	
	//::AfxBeginThread(MyControllingFunction,m_hWnd);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

//DEL void CMyToolDlg::OnWindowPosChanging(WINDOWPOS FAR* lpwndpos) 
//DEL {
//DEL 	CDialog::OnWindowPosChanging(lpwndpos);
//DEL 	
//DEL 	// TODO: Add your message handler code here
//DEL 	RECT rcScrn;
//DEL 	SystemParametersInfo (SPI_GETWORKAREA, 0, &rcScrn, 0);
//DEL 
//DEL 	// Snap X axis
//DEL 	if (abs(lpwndpos->x - rcScrn.left) <= m_nEdgeSnapGap)
//DEL 		lpwndpos->x = rcScrn.left;
//DEL 	else if (abs(lpwndpos->x + lpwndpos->cx - rcScrn.right) <= m_nEdgeSnapGap)
//DEL 	lpwndpos->x = rcScrn.right - lpwndpos->cx;
//DEL 
//DEL 	// Snap Y axis
//DEL 	if (abs(lpwndpos->y - rcScrn.top) <= m_nEdgeSnapGap)
//DEL 		lpwndpos->y = rcScrn.top;
//DEL 	else if (abs(lpwndpos->y + lpwndpos->cy - rcScrn.bottom) <= m_nEdgeSnapGap)
//DEL 		lpwndpos->y = rcScrn.bottom - lpwndpos->cy;
//DEL }

//DEL void CMyToolDlg::OnMouseMove(UINT nFlags, CPoint point) 
//DEL {
//DEL 	// TODO: Add your message handler code here and/or call default
//DEL /*	CRect rect(0,0,100,100);
//DEL 	CPoint m_point;
//DEL 	GetCursorPos(&m_point);
//DEL     
//DEL 	
//DEL 	if(!rect.PtInRect(point))
//DEL 	{
//DEL 		MessageBox("asdsad");
//DEL 		ShowWindow(SW_SHOW);
//DEL 	}
//DEL */
//DEL 
//DEL 	CDialog::OnMouseMove(nFlags, point);
//DEL }


int CMyToolDlg::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	//SetWindowPos(&CWnd::wndTopMost,0,0,0,0,SWP_NOSIZE|SWP_NOMOVE);

	return 0;
}

void CMyToolDlg::OnButton2() 
{
	// TODO: Add your control notification handler code here
	pView->SetChoice(1);
	//ShowWindow(SW_HIDE);  
}

void CMyToolDlg::OnButton7() 
{
	// TODO: Add your control notification handler code here
	pView->SetChoice(5);
	//ShowWindow(SW_HIDE); 
	
}

void CMyToolDlg::OnButton4() 
{
	// TODO: Add your control notification handler code here
	pView->SetChoice(4);
	//ShowWindow(SW_HIDE);
	
}

void CMyToolDlg::OnButton3() 
{
	// TODO: Add your control notification handler code here
	pView->SetChoice(10);
	//ShowWindow(SW_HIDE);
}

void CMyToolDlg::OnButton5() 
{
	// TODO: Add your control notification handler code here
	//pView->SetOnDrawLocker(false);
    CMyColorDlg dlg;
	dlg.m_cc.Flags |= CC_PREVENTFULLOPEN;
	dlg.DoModal();
	//if(dlg.DoModal()==IDOK)
	//{
		pView->SetColor(dlg.GetColor());
	//}
	//	pView->SetOnDrawLocker(true);
	//ShowWindow(SW_HIDE);
}

void CMyToolDlg::OnButton6() 
{
	// TODO: Add your control notification handler code here
	Sleep(500);
	pView->Refresh();
	ShowWindow(SW_HIDE);
	
}

void CMyToolDlg::OnButton8() 
{
	// TODO: Add your control notification handler code here
	::DeleteFile("D:\\bitmap0.bmp");
	::DeleteFile("D:\\bitmap1.bmp");
	::DeleteFile("D:\\Expanded0.bmp");
	//exit(0);
	::SendMessage(::AfxGetApp()->GetMainWnd()->m_hWnd,WM_CLOSE,NULL,NULL);
}

void CMyToolDlg::OnButton9() 
{
	// TODO: Add your control notification handler code here
	CHelpDlg dlg;
	dlg.DoModal();
	//ShowWindow(SW_HIDE);
	
}

void CMyToolDlg::OnButton10() 
{
	// TODO: Add your control notification handler code here
	//SetForegroundWindow();   
	//UpdateWindow();   
	//	WinExec("calc",SW_SHOWNORMAL);
	//FindWindow(NULL,"��ѧ������")->SetForegroundWindow();
	//pView->SetOnDrawLocker(false);
	//pView->SetOnDrawLocker(true);
		pView->SetChoice(12);
}

void CMyToolDlg::OnButton11() 
{
	// TODO: Add your control notification handler code here
	CStyleSetDlg dlg;
	
	dlg.DoModal();

	pView->SetPenWidth(dlg.Width);
}
