#if !defined(AFX_MYTOOLDLG_H__F36B6BC3_0DE6_4C34_85F5_8EF27E50FCD1__INCLUDED_)
#define AFX_MYTOOLDLG_H__F36B6BC3_0DE6_4C34_85F5_8EF27E50FCD1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MyToolDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMyToolDlg dialog

#include "BtnST.h"

class CMy1View; 
class CMyToolDlg : public CDialog
{
// Construction
public:
	CButtonST m_btn1;
	CButtonST m_btn2;
	CButtonST m_btn3;
	CButtonST m_btn4;
	CButtonST m_btn5;
	CButtonST m_btn6;
	CButtonST m_btn7;
	CButtonST m_btn8;
	CButtonST m_btn9;

	int m_nEdgeSnapGap;
	CMyToolDlg(CWnd* pParent = NULL);   // standard constructor
	CMyToolDlg(CMy1View *m_pView,CWnd* pParent=NULL);   
	CMy1View   *pView;  

// Dialog Data
	//{{AFX_DATA(CMyToolDlg)
	enum { IDD = IDD_DIALOG5 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyToolDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMyToolDlg)
		virtual BOOL OnInitDialog();
		afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnButton2();
	afx_msg void OnButton7();
	afx_msg void OnButton4();
	afx_msg void OnButton3();
	afx_msg void OnButton5();
	afx_msg void OnButton6();
	afx_msg void OnButton8();
	afx_msg void OnButton9();
	afx_msg void OnButton10();
	afx_msg void OnButton11();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYTOOLDLG_H__F36B6BC3_0DE6_4C34_85F5_8EF27E50FCD1__INCLUDED_)
