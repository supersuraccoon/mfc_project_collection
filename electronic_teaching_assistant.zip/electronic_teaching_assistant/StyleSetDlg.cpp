// StyleSetDlg.cpp : implementation file
//

#include "stdafx.h"
#include "1.h"
#include "StyleSetDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStyleSetDlg dialog


CStyleSetDlg::CStyleSetDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CStyleSetDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CStyleSetDlg)
	//}}AFX_DATA_INIT
	Width=3;
}


void CStyleSetDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CStyleSetDlg)
	DDX_Control(pDX, IDC_EDIT3, m_edit2);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CStyleSetDlg, CDialog)
	//{{AFX_MSG_MAP(CStyleSetDlg)
	ON_WM_SETCURSOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStyleSetDlg message handlers

BOOL CStyleSetDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	//m_combo.InsertString(0,"ʵ��");
	//m_combo.InsertString(1,"����");
	//m_combo.InsertString(2,"����");

    //m_combo.SetCurSel(0);
    //SetDlgItemText(IDC_EDIT1,"ʵ��");
	SetDlgItemText(IDC_EDIT3,"2");

	CFont *font=new CFont;

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CStyleSetDlg::OnOK() 
{
	// TODO: Add extra validation here
	Width=GetDlgItemInt(IDC_EDIT3);

	CDialog::OnOK();
}

BOOL CStyleSetDlg::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	// TODO: Add your message handler code here and/or call default
	::SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR5));
	return   TRUE; 

	return CDialog::OnSetCursor(pWnd, nHitTest, message);
}
