#if !defined(AFX_BMPSAVEDLG_H__9DBC1F89_4BDD_4870_934D_853C8CE2EB9E__INCLUDED_)
#define AFX_BMPSAVEDLG_H__9DBC1F89_4BDD_4870_934D_853C8CE2EB9E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// BmpSaveDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CBmpSaveDlg dialog

class CBmpSaveDlg : public CFileDialog
{
	DECLARE_DYNAMIC(CBmpSaveDlg)

public:
	CBmpSaveDlg(BOOL bOpenFileDialog, // TRUE for FileOpen, FALSE for FileSaveAs
		LPCTSTR lpszDefExt = NULL,
		LPCTSTR lpszFileName = NULL,
		DWORD dwFlags = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		LPCTSTR lpszFilter = NULL,
		CWnd* pParentWnd = NULL);

protected:
	//{{AFX_MSG(CBmpSaveDlg)
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BMPSAVEDLG_H__9DBC1F89_4BDD_4870_934D_853C8CE2EB9E__INCLUDED_)
