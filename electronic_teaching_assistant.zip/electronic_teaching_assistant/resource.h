//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by 1.rc
//
#define IDD_ABOUTBOX                    100
#define CG_IDR_POPUP_MY1_VIEW           102
#define IDB_SPLASH                      103
#define IDR_MAINFRAME                   128
#define IDR_MY1TYPE                     129
#define IDD_DIALOG1                     132
#define IDD_STYLESET                    132
#define IDD_DIALOG2                     133
#define IDB_BITMAP1                     134
#define IDD_DIALOG3                     137
#define IDD_DIALOG4                     138
#define IDC_CURSOR1                     141
#define IDC_CURSOR2                     143
#define IDC_CURSOR4                     145
#define IDC_CURSOR5                     146
#define IDC_CURSOR6                     148
#define IDD_DIALOG5                     151
#define IDI_ICON1                       153
#define IDI_ICON2                       154
#define IDI_ICON3                       155
#define IDI_ICON4                       156
#define IDI_ICON5                       157
#define IDI_ICON6                       158
#define IDI_ICON7                       159
#define IDC_CURSOR7                     161
#define IDI_ICON9                       165
#define IDI_ICON8                       166
#define IDI_ICON10                      167
#define IDI_ICON11                      168
#define IDI_ICON12                      169
#define IDI_ICON13                      170
#define IDI_ICON14                      171
#define IDI_ICON15                      172
#define IDI_ICON16                      173
#define IDC_EDIT3                       1004
#define IDC_COMBO1                      1009
#define IDC_BUTTON2                     1012
#define IDC_BUTTON3                     1013
#define IDC_BUTTON4                     1014
#define IDC_BUTTON5                     1015
#define IDC_BUTTON6                     1016
#define IDC_BUTTON7                     1017
#define IDC_BUTTON8                     1018
#define IDC_BUTTON9                     1019
#define IDC_BUTTON10                    1020
#define IDC_BUTTON11                    1021
#define ID_EXIT                         32772
#define IDR_REFRESH                     32773
#define ID_PRTSCR                       32774
#define ID_LINE                         32776
#define ID_ELLIPSE                      32777
#define ID_PIXEL                        32778
#define IDC_COLOR                       32779
#define IDR_STYLESET                    32780
#define IDR_RECT                        32782
#define ID_SAVE                         32784
#define ID_UNDO                         32785
#define ID_EXPAND                       32786
#define ID_TEXT                         32787

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        174
#define _APS_NEXT_COMMAND_VALUE         32788
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
