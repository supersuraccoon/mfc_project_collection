// 1View.cpp : implementation of the CMy1View class
//

#include "stdafx.h"
#include "1.h"
#include "MainFrm.h"
#include  <io.h>
#include "MyColorDlg.h"
#include "StyleSetDlg.h"
#include "HelpDlg.h"
#include "SaveDlg.h"
#include "BmpSaveDlg.h"

#include "MyToolDlg.h"
#include "1Doc.h"
#include "1View.h"




#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
/////////////////////////////////////////////////////////////////////////////

_declspec(dllimport) void SetHook(HWND hwnd);

/////////////////////////////////////////////////////////////////////////////

int index=-1;
int PenStyle=PS_SOLID;
int Width=3;
int m_xScreen;
int m_yScreen;
bool LEraserDown=false;
bool final=true;
bool lock=true;
bool onDrawLocke=true;

CString m_SavePath="d:\\";
CPoint ptEraser;
CRect g_qq_DlgRt;
CRect LTRect;
CRect RTRect;
CRect LBRect;
CRect RBRect;
CRect expandRect;
HBITMAP g_screenBmp;
HBITMAP g_expandedBmp;
HBITMAP g_ClipBmp;
HBITMAP g_reDrawBmp;
HHOOK g_hookPrint=NULL;
HBITMAP CopyScreenToBitmap(LPRECT lpRect);
HCURSOR hCursor=NULL;

CMyToolDlg* pDlg;

/////////////////////////////////////////////////////////////////////////////

int SaveBitmapToFile(HBITMAP hBitmap, LPSTR lpFileName);
void BmpToClipboard();
void PrintScreen(void);


static bool once=true;

/////////////////////////////////////////////////////////////////////////////
// CMy1View

IMPLEMENT_DYNCREATE(CMy1View, CView)

BEGIN_MESSAGE_MAP(CMy1View, CView)
ON_WM_CONTEXTMENU()
//{{AFX_MSG_MAP(CMy1View)
ON_WM_LBUTTONDOWN()
ON_WM_LBUTTONUP()
ON_WM_ERASEBKGND()
ON_WM_RBUTTONDOWN()
ON_COMMAND(ID_EXIT, OnExit)
ON_WM_MOUSEMOVE()
ON_COMMAND(IDR_REFRESH, OnRefresh)
ON_COMMAND(ID_PRTSCR, OnPrtscr)
ON_COMMAND(ID_LINE, OnLine)
ON_COMMAND(IDC_COLOR, OnColor)
ON_COMMAND(IDR_STYLESET, OnStyleset)
ON_COMMAND(IDR_RECT, OnRect)
ON_COMMAND(ID_HELP, OnHelp)
ON_COMMAND(ID_SAVE, OnSave)
ON_COMMAND(ID_UNDO, OnUndo)
	ON_WM_LBUTTONDBLCLK()
	ON_WM_SETCURSOR()
	ON_COMMAND(ID_EXPAND, OnExpand)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_SETFOCUS()
	ON_COMMAND(ID_TEXT, OnText)
	//}}AFX_MSG_MAP
// Standard printing commands
ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

LRESULT CALLBACK KeyboardProc(int code,WPARAM wParam,LPARAM lParam)
{
	static flag=true;
	if(VK_F4==wParam)
	{
		if(flag)
		{
			g_qq_DlgRt.left+=3;
			g_qq_DlgRt.top+=3;
			PrintScreen();
			BmpToClipboard();
			flag=false;
			return true;
		}
		else
		{
			flag=true;
			return true;
		}
	}
	else
		if(VK_F3==wParam)
		{
			final=true;
			return CallNextHookEx(g_hookPrint,code,wParam,lParam); 
		}
		else
			if(VK_ESCAPE==wParam)
			{
				::DeleteFile("D:\\bitmap0.bmp");
				::DeleteFile("D:\\bitmap1.bmp");
				::DeleteFile("D:\\Expanded0.bmp");
				::SendMessage(::AfxGetApp()->GetMainWnd()->m_hWnd,WM_CLOSE,NULL,NULL);
			}
	else
		return CallNextHookEx(g_hookPrint,code,wParam,lParam); 
}


/////////////////////////////////////////////////////////////////////////////
// CMy1View construction/destruction

CMy1View::CMy1View()
{
	// TODO: add construction code here
	color=RGB(255,0,0);
	m_xScreen=GetSystemMetrics(SM_CXSCREEN);
	m_yScreen=GetSystemMetrics(SM_CYSCREEN);
	preChoice=choice=0;
	flag=false;
	g_qq_DlgRt.left=0;
	g_qq_DlgRt.top=0;
	g_qq_DlgRt.right=m_xScreen;
	g_qq_DlgRt.bottom=m_yScreen;
	LTRect.SetRect(CPoint(0,0),CPoint(m_xScreen/2,m_yScreen/2));
    RTRect.SetRect(CPoint(m_xScreen/2,0),CPoint(m_xScreen,m_yScreen/2));
    LBRect.SetRect(CPoint(0,m_yScreen/2),CPoint(m_xScreen/2,m_yScreen));
    RBRect.SetRect(CPoint(m_xScreen/2,m_yScreen/2),CPoint(m_xScreen,m_yScreen));
	expandRect=NULL;
	g_hookPrint=SetWindowsHookEx(WH_KEYBOARD,KeyboardProc,NULL,GetCurrentThreadId()); 
}

CMy1View::~CMy1View()
{
}
/////////////////////////////////////////////////////////////////////////////
// CMy1View drawing

void CMy1View::OnDraw(CDC* pDC)
{
	CMy1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
	/*CRect    rect;   
	GetClientRect(&rect);   
	CBitmap   m_picture; 
	HBITMAP   hBmp=(HBITMAP)::LoadImage(AfxGetInstanceHandle(),
		"d:\\bitmap0.bmp",IMAGE_BITMAP,0,0,LR_CREATEDIBSECTION|LR_LOADFROMFILE);   
	m_picture.Attach(hBmp);   
	CDC   dc;   
	dc.CreateCompatibleDC(pDC);   
	dc.SelectObject(&m_picture);   
	BITMAP  bmp;   
	m_picture.GetBitmap(&bmp);   
	pDC->StretchBlt(0,0,rect.Width(),rect.Height(),&dc,0,0,
		bmp.bmWidth, bmp.bmHeight,SRCCOPY);
	/*if(!onDrawLocke)
	{
		if(g_reDrawBmp)
		{
			CRect    rect;   
			GetClientRect(&rect);   
			CBitmap   m_picture; 
			HBITMAP   hBmp=(HBITMAP)::LoadImage(AfxGetInstanceHandle(),
				"d:\\bitmap1.bmp",IMAGE_BITMAP,0,0,LR_CREATEDIBSECTION|LR_LOADFROMFILE);   
			m_picture.Attach(hBmp);   
			CDC   dc;   
			dc.CreateCompatibleDC(pDC);   
			dc.SelectObject(&m_picture);   
			BITMAP  bmp;   
			m_picture.GetBitmap(&bmp);   
			pDC->StretchBlt(0,0,rect.Width(),rect.Height(),&dc,0,0,
				bmp.bmWidth, bmp.bmHeight,SRCCOPY);
		}
	}*/
}

/////////////////////////////////////////////////////////////////////////////
// CMy1View printing

BOOL CMy1View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CMy1View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CMy1View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CMy1View diagnostics

#ifdef _DEBUG
void CMy1View::AssertValid() const
{
	CView::AssertValid();
}

void CMy1View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMy1Doc* CMy1View::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMy1Doc)));
	return (CMy1Doc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMy1View message handlers

void CMy1View::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CRect theRect;
	CRectTracker   tracker;  
	CRect desRect=NULL;
	//CString bmpPath;
	CClientDC dc(this);
	CDC *mdc=new CDC;  
	CDC *pDC=new CDC;
	CBitmap *bitmap=new CBitmap;
	m_ptStart=point;
	switch(choice)
	{
	case 0:
		choice=preChoice;
		break;
	case 1:
		flag=true;
		break;
	case 2:
		flag=true;
		break;
	case 3:
		break;
	case 4:
		tracker.TrackRubberBand(this,point,false);   
		tracker.m_rect.NormalizeRect();   
		dc.SelectStockObject(NULL_BRUSH);
		dc.Rectangle(&tracker.m_rect);
		g_qq_DlgRt=tracker.m_rect;	
		break;	
	case 5:
		LEraserDown=true;
		break;
	case 10:
		tracker.TrackRubberBand(this,point,false);   
		tracker.m_rect.NormalizeRect();   
		dc.SelectStockObject(NULL_BRUSH);
		dc.Rectangle(&tracker.m_rect);
		expandRect=tracker.m_rect;
		choice=11;
		break;
    case 11:
		g_expandedBmp=NULL;
		g_qq_DlgRt.left = 0;
		g_qq_DlgRt.top = 0;
		g_qq_DlgRt.right = m_xScreen;
		g_qq_DlgRt.bottom = m_yScreen;
		g_expandedBmp= CopyScreenToBitmap(&g_qq_DlgRt);
		::DeleteFile("D:\\Expanded0.bmp");
		SaveBitmapToFile(g_expandedBmp,"D:\\Expanded0.bmp");
		SetFileAttributes("D:\\Expanded0.bmp",FILE_ATTRIBUTE_HIDDEN);   

		mdc->CreateCompatibleDC(pDC);   
		if(_access("D:\\Expanded0.bmp",0)!=-1)
			bitmap->m_hObject=(HBITMAP)::LoadImage(NULL,"D:\\Expanded0.bmp"
			,IMAGE_BITMAP,0,0,LR_LOADFROMFILE);   
		else
			bitmap->m_hObject=(HBITMAP)::LoadImage(NULL,"D:\\bitmap0.bmp"
			,IMAGE_BITMAP,0,0,LR_LOADFROMFILE);   

		mdc->SelectObject(bitmap);  
		
		desRect=expandRect;
		SetShowRegion(expandRect,desRect);
		dc.StretchBlt(desRect.left,desRect.top,expandRect.Width()*2,
			expandRect.Height()*2,mdc,expandRect.left+2,expandRect.top+2
			,expandRect.Width(),expandRect.Height(),SRCCOPY);
		choice=10;
		delete mdc;
		delete pDC;
		delete bitmap;
		break;
	case 12:
		//p_Origin=point;
		//str.Empty();
		//ShowCaret();
		//SetCaretPos(point);
		break;
	default:
		delete mdc;
		delete pDC;
		delete bitmap;
		break;
	}
	
	CView::OnLButtonDown(nFlags, point);
}

void CMy1View::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CClientDC dc(this);
	CBrush bru;
	int i=1;
	bru.CreateStockObject(NULL_BRUSH);
	m_ptEnd=point;
	srand((unsigned)time(NULL));
	switch(choice)
	{
	case 1:
		flag=false;
		break;
	case 2:
		dc.SelectObject(&bru);
		dc.Ellipse(m_ptStart.x,m_ptStart.y,m_ptEnd.x,m_ptEnd.y);
		flag=false;
		break;
	case 3:
		for(;i<=50;i++)
		{
			int x=rand()%30-10;
			int y=rand()%30-10;
			dc.SetPixel(m_ptStart.x+x,m_ptStart.y+y,RGB(255,0,0));
		}
	case 4:
		break;
	case 5:
		LEraserDown=false;
		break;
	default:
		break;
	}
	
	CView::OnLButtonUp(nFlags, point);
}

BOOL CMy1View::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default
	if(final)
	{
		g_screenBmp=NULL;
		g_qq_DlgRt.left = 2;
		g_qq_DlgRt.top = 2;
		g_qq_DlgRt.right = m_xScreen-2;
		g_qq_DlgRt.bottom = m_yScreen-2;
		g_screenBmp = CopyScreenToBitmap(&g_qq_DlgRt);
		::DeleteFile("D:\\bitmap0.bmp");
		SaveBitmapToFile(g_screenBmp,"D:\\bitmap0.bmp");
		SetFileAttributes("D:\\bitmap0.bmp",FILE_ATTRIBUTE_HIDDEN);
		final=false;
	}

	CRect    rect;   
	GetClientRect(&rect);   
	CBitmap   m_picture; 
	HBITMAP   hBmp=(HBITMAP)::LoadImage(AfxGetInstanceHandle(),
		"d:\\bitmap0.bmp",IMAGE_BITMAP,0,0,LR_CREATEDIBSECTION|LR_LOADFROMFILE);   
	m_picture.Attach(hBmp);   
	CDC   dc;   
	dc.CreateCompatibleDC(pDC);   
	dc.SelectObject(&m_picture);   
	BITMAP  bmp;   
	m_picture.GetBitmap(&bmp);   
	pDC->StretchBlt(0,0,rect.Width(),rect.Height(),&dc,0,0,
		bmp.bmWidth, bmp.bmHeight,SRCCOPY);

	/*CRect    rect;   
	GetClientRect(&rect);   
	pDC=CDC::FromHandle(::GetDC(NULL));   
	CDC    memdc;   
	memdc.CreateCompatibleDC(pDC);   
	(HBITMAP)::SelectObject(memdc,g_screenBmp);
	pDC->BitBlt(0,0,rect.Width(),rect.Height(),&memdc,0,0,SRCCOPY);*/



	return   true; 

	return CView::OnEraseBkgnd(pDC);
}


void CMy1View::OnContextMenu(CWnd*, CPoint point)
{
	
	// CG: This block was added by the Pop-up Menu component
	/*{
		if (point.x == -1 && point.y == -1){
			//keystroke invocation
			CRect rect;
			GetClientRect(rect);
			ClientToScreen(rect);
			
			point = rect.TopLeft();
			point.Offset(5, 5);
		}		
		CMenu menu;
		VERIFY(menu.LoadMenu(CG_IDR_POPUP_MY1_VIEW));
		
		CMenu* pPopup = menu.GetSubMenu(0);
		ASSERT(pPopup != NULL);
		CWnd* pWndPopupOwner = this;
		
		while (pWndPopupOwner->GetStyle() & WS_CHILD)
			pWndPopupOwner = pWndPopupOwner->GetParent();
		
		pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y,
			pWndPopupOwner);
	}*/
}

void CMy1View::OnRButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	choice=0;
	g_reDrawBmp=NULL;
	g_qq_DlgRt.left = 2;
	g_qq_DlgRt.top = 2;
	g_qq_DlgRt.right = m_xScreen-2;
	g_qq_DlgRt.bottom = m_yScreen-2;
	g_reDrawBmp= CopyScreenToBitmap(&g_qq_DlgRt);
	::DeleteFile("D:\\bitmap1.bmp");
	SaveBitmapToFile(g_reDrawBmp,"D:\\bitmap1.bmp");
	SetFileAttributes("D:\\bitmap1.bmp",FILE_ATTRIBUTE_HIDDEN);
	if(!lock)
		lock=true;
	/*CMenu menu;
	menu.LoadMenu(CG_IDR_POPUP_MY1_VIEW);
	CMenu *pPopup=menu.GetSubMenu(0);
	pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y,
		this);  */
	
	CView::OnRButtonDown(nFlags, point);
}

void CMy1View::OnExit() 
{
	// TODO: Add your command handler code here
	::DeleteFile("D:\\bitmap0.bmp");
	::DeleteFile("D:\\bitmap1.bmp");
	exit(0);
}

void CMy1View::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(lock)
	{
		CRect rect;
		if(pDlg)
		{
			pDlg->GetWindowRect(&rect);
			if(!rect.PtInRect(point))
				pDlg->ShowWindow(SW_HIDE);
			else
			{
				//Sleep(1000);
				pDlg->ShowWindow(SW_SHOW);
			}
		}
	}


	CWindowDC dc(GetDesktopWindow());

	CDC *mdc=new CDC;  
	CDC *pDC=new CDC;
	CBitmap *bitmap=new CBitmap;   
	ptEraser.x=point.x-20;
	ptEraser.y=point.y-20;

	CPen pen(PenStyle,Width,color);
	dc.SelectObject(&pen);
	m_ptEnd=point;
	switch(choice)
	{
	case 1:
		if(flag)
		{
			dc.MoveTo(m_ptStart);
			dc.LineTo(m_ptEnd);
			m_ptStart=point;
		}
		lock=false;
		break;
	case 2:
		lock=false;
		break;
	case 4:
		lock=false;
		break;
	case 5:
		lock=false;
		if(LEraserDown)
		{
			mdc->CreateCompatibleDC(pDC);   
			bitmap->m_hObject=(HBITMAP)::LoadImage(NULL,"D:\\bitmap0.bmp"
				,IMAGE_BITMAP,0,0,LR_LOADFROMFILE);   
			mdc->SelectObject(bitmap);   
			dc.StretchBlt(ptEraser.x+2,ptEraser.y+2,40,40,
				mdc,ptEraser.x,ptEraser.y,40,40,SRCCOPY);
			delete mdc;
			delete pDC;
			delete bitmap;
		}
		break;
	case 10:
		lock=false;
		break;
	default:
		break;
	}
	CView::OnMouseMove(nFlags, point);
}


void CMy1View::OnRefresh() 
{
	// TODO: Add your command handler code here
	/*g_screenBmp=NULL;
	g_qq_DlgRt.left = 0;
	g_qq_DlgRt.top = 0;
	g_qq_DlgRt.right = m_xScreen;
	g_qq_DlgRt.bottom = m_yScreen;
	g_screenBmp = CopyScreenToBitmap(&g_qq_DlgRt);
	::DeleteFile("D:\\bitmap0.bmp");
	SaveBitmapToFile(g_screenBmp,"D:\\bitmap0.bmp");
	SetFileAttributes("D:\\bitmap0.bmp",FILE_ATTRIBUTE_HIDDEN);*/


	CRect    rect;   
	GetClientRect(&rect);   
	CDC    *pDC=CDC::FromHandle(::GetDC(NULL));   
	CDC    memdc;   
	memdc.CreateCompatibleDC(pDC);   
	(HBITMAP)::SelectObject(memdc,g_screenBmp);
	pDC->BitBlt(0,0,rect.Width(),rect.Height(),&memdc,0,0,SRCCOPY); 
	expandRect=NULL;
	if(choice==11)
		choice=10;
}

HBITMAP CopyScreenToBitmap(LPRECT lpRect)
{
	HDC hScrDC,hMemDC;
	HBITMAP hBitmap,hOldBitmap;
	int nX1,nX2,nY1,nY2;
	int nWidth,nHeight;
	if (IsRectEmpty(lpRect))
	{
		return FALSE;
	}
	//Ϊ��Ļ�����豸������
	hScrDC = CreateDC("DISPLAY",NULL,NULL,NULL);
	//Ϊ��Ļ�豸�������������ݵ��ڴ��豸������
	hMemDC = CreateCompatibleDC(hScrDC);
	// ���ѡ����������
	nX1 = lpRect->left;
	nY1 = lpRect->top;
	nX2 = lpRect->right;
	nY2 = lpRect->bottom;
	//ȷ��ѡ�������ǿɼ���
	if (nX1 < 0)
		nX1 = 0;
	if (nY1 < 0)
		nY1 = 0;
	if (nX2 > m_xScreen)
		nX2 = m_xScreen;
	if (nY2 > m_yScreen)
		nY2 = m_yScreen;
	nWidth = nX2 - nX1;
	nHeight = nY2 - nY1;
	// ����һ������Ļ�豸���������ݵ�λͼ
	hBitmap = CreateCompatibleBitmap(hScrDC,nWidth,nHeight);
	// ����λͼѡ���ڴ��豸��������
	hOldBitmap = (HBITMAP)SelectObject(hMemDC,hBitmap);
	// ����Ļ�豸�������������ڴ��豸��������
	BitBlt(hMemDC,0,0,nWidth,nHeight,hScrDC,nX1,nY1,SRCCOPY);
	//�õ���Ļλͼ�ľ��
	hBitmap = (HBITMAP)SelectObject(hMemDC,hOldBitmap);
	//���
	DeleteDC(hScrDC);
	DeleteDC(hMemDC);
	return hBitmap;
	
}

int SaveBitmapToFile(HBITMAP hBitmap, LPSTR lpFileName)
{
	//lpFileName Ϊλͼ�ļ���
	HDC hDC; 
	//�豸������
	int iBits; 
	//��ǰ��ʾ�ֱ�����ÿ��������ռ�ֽ���
	WORD wBitCount; 
	//λͼ��ÿ��������ռ�ֽ���
	//�����ɫ���С�� λͼ�������ֽڴ�С �� λͼ�ļ���С �� д���ļ��ֽ���
	DWORD dwPaletteSize=0,dwBmBitsSize,dwDIBSize, dwWritten;
	BITMAP Bitmap; 
	//λͼ���Խṹ
	BITMAPFILEHEADER bmfHdr; 
	//λͼ�ļ�ͷ�ṹ
	BITMAPINFOHEADER bi; 
	//λͼ��Ϣͷ�ṹ 
	LPBITMAPINFOHEADER lpbi; 
	//ָ��λͼ��Ϣͷ�ṹ
	HANDLE fh, hDib, hPal;
	HPALETTE hOldPal=NULL;
	//�����ļ��������ڴ�������ɫ����
	//����λͼ�ļ�ÿ��������ռ�ֽ���
	hDC = CreateDC("DISPLAY",NULL,NULL,NULL);
	iBits = GetDeviceCaps(hDC, BITSPIXEL) * 
		GetDeviceCaps(hDC, PLANES);
	DeleteDC(hDC);
	if (iBits <= 1)
		wBitCount = 1;
	else if (iBits <= 4)
		wBitCount = 4;
	else if (iBits <= 8)
		wBitCount = 8;
	else if (iBits <= 24)
		wBitCount = 24;
	else
		wBitCount = 32;
	//�����ɫ���С
	if (wBitCount <= 8)
		dwPaletteSize=(1<<wBitCount)*sizeof(RGBQUAD);
	//����λͼ��Ϣͷ�ṹ
	GetObject(hBitmap, sizeof(BITMAP), (LPSTR)&Bitmap);
	bi.biSize = sizeof(BITMAPINFOHEADER);
	bi.biWidth = Bitmap.bmWidth;
	bi.biHeight = Bitmap.bmHeight;
	bi.biPlanes = 1;
	bi.biBitCount = wBitCount;
	bi.biCompression = BI_RGB;
	bi.biSizeImage = 0;
	bi.biXPelsPerMeter = 0;
	bi.biYPelsPerMeter = 0;
	bi.biClrUsed = 0;
	bi.biClrImportant = 0;
	dwBmBitsSize = ((Bitmap.bmWidth*wBitCount+31)/32)*4*Bitmap.bmHeight;
	//Ϊλͼ���ݷ����ڴ�
	/*xxxxxxxx����λͼ��С�ֽ�һ��(����һ����������)xxxxxxxxxxxxxxxxxxxx 
	//ÿ��ɨ������ռ���ֽ���Ӧ��Ϊ4���������������㷨Ϊ:
	int biWidth = (Bitmap.bmWidth*wBitCount) / 32;
	if((Bitmap.bmWidth*wBitCount) % 32)
	biWidth++; //�����������ļ�1
	biWidth *= 4;//���������õ���Ϊÿ��ɨ���е��ֽ�����
	dwBmBitsSize = biWidth * Bitmap.bmHeight;//�õ���С
	xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx*/
	
	hDib = GlobalAlloc(GHND,dwBmBitsSize+dwPaletteSize+sizeof(BITMAPINFOHEADER));
	lpbi = (LPBITMAPINFOHEADER)GlobalLock(hDib);
	*lpbi = bi;
	// ������ɫ�� 
	hPal = GetStockObject(DEFAULT_PALETTE);
	if (hPal)
	{
		hDC = ::GetDC(NULL);
		hOldPal=SelectPalette(hDC,(HPALETTE)hPal,FALSE);
		RealizePalette(hDC);
	}
	// ��ȡ�õ�ɫ�����µ�����ֵ
	GetDIBits(hDC,hBitmap,0,(UINT)Bitmap.bmHeight,(LPSTR)lpbi+sizeof(BITMAPINFOHEADER)+dwPaletteSize, (BITMAPINFO *)lpbi,DIB_RGB_COLORS);
	//�ָ���ɫ�� 
	if (hOldPal)
	{
		SelectPalette(hDC, hOldPal, TRUE);
		RealizePalette(hDC);
		::ReleaseDC(NULL, hDC);
	}
	//����λͼ�ļ� 
	fh=CreateFile(lpFileName, GENERIC_WRITE,0, NULL, CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL | FILE_FLAG_SEQUENTIAL_SCAN, NULL);
	if (fh==INVALID_HANDLE_VALUE)
		return FALSE;
	// ����λͼ�ļ�ͷ
	bmfHdr.bfType = 0x4D42; // "BM"
	dwDIBSize=sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER)+dwPaletteSize+dwBmBitsSize; 
	bmfHdr.bfSize = dwDIBSize;
	bmfHdr.bfReserved1 = 0;
	bmfHdr.bfReserved2 = 0;
	bmfHdr.bfOffBits = (DWORD)sizeof(BITMAPFILEHEADER)+(DWORD)sizeof(BITMAPINFOHEADER)+dwPaletteSize;
	// д��λͼ�ļ�ͷ
	WriteFile(fh, (LPSTR)&bmfHdr, sizeof(BITMAPFILEHEADER), &dwWritten, NULL);
	// д��λͼ�ļ���������
	WriteFile(fh, (LPSTR)lpbi, sizeof(BITMAPINFOHEADER)+dwPaletteSize+dwBmBitsSize , &dwWritten, NULL); 
	//��� 
	GlobalUnlock(hDib);
	GlobalFree(hDib);
	CloseHandle(fh);
	return TRUE;
}

void CMy1View::OnPrtscr() 
{
	// TODO: Add your command handler code here
	PrintScreen();
}

void CMy1View::OnLine() 
{
	// TODO: Add your command handler code here
	preChoice=choice=1;
}


void CMy1View::OnColor() 
{
	// TODO: Add your command handler code here
		g_screenBmp=NULL;
		g_qq_DlgRt.left = 2;
		g_qq_DlgRt.top = 2;
		g_qq_DlgRt.right = m_xScreen-2;
		g_qq_DlgRt.bottom = m_yScreen-2;
		g_screenBmp = CopyScreenToBitmap(&g_qq_DlgRt);
		::DeleteFile("D:\\bitmap1.bmp");
		SaveBitmapToFile(g_screenBmp,"D:\\bitmap1.bmp");
		SetFileAttributes("D:\\bitmap1.bmp",FILE_ATTRIBUTE_HIDDEN);
		final=false;
	choice=0;
	CColorDialog  dlg;
	dlg.DoModal();
	color=dlg.GetColor();
}

void PrintScreen(void)
{
	static i=0;
	char str[200];
	char des[100];
	char type[5]=".bmp";
	HBITMAP temp_screenBmp;
	temp_screenBmp=NULL;
	temp_screenBmp= CopyScreenToBitmap(&g_qq_DlgRt);
	g_qq_DlgRt.left+=2;
	g_qq_DlgRt.top+=2;
	g_ClipBmp=temp_screenBmp;
	do
	{
		strcpy(str,m_SavePath);
		i++;
		itoa(i,des,10);
		strcat(str,des);
		strcat(str,type);
	}
	while(_access(str,0)==0);
	SaveBitmapToFile(temp_screenBmp,str);
	g_qq_DlgRt.left=0;
	g_qq_DlgRt.top=0;
	g_qq_DlgRt.right=m_xScreen;
	g_qq_DlgRt.bottom=m_yScreen;
}

void CMy1View::OnStyleset() 
{
	// TODO: Add your command handler code here
	CStyleSetDlg dlg;
	
	dlg.DoModal();
	Width=dlg.Width;
}

void CMy1View::OnRect() 
{
	// TODO: Add your command handler code here
	preChoice=choice=4;
}

void BmpToClipboard()
{
	if(OpenClipboard(AfxGetMainWnd()->m_hWnd))
	{
		EmptyClipboard();
		SetClipboardData(CF_BITMAP,g_ClipBmp);
		CloseClipboard();
	}
}

void CMy1View::OnHelp() 
{
	// TODO: Add your command handler code here
	CHelpDlg dlg;
	dlg.DoModal();
}

void CMy1View::OnSave() 
{
	//CSaveDlg dlg;
	//dlg.DoModal();
	//m_SavePath=dlg.SavePath;
	/*BROWSEINFO bInfo;
	LPITEMIDLIST pidl;
	ZeroMemory((PVOID)&bInfo, sizeof(BROWSEINFO));
	bInfo.pidlRoot = NULL;
	bInfo.hwndOwner = m_hWnd;
	bInfo.pszDisplayName = m_SavePath.GetBuffer(MAX_PATH);
	bInfo.lpszTitle = "DIR ѡ��Ի���";
	bInfo.ulFlags = BIF_RETURNFSANCESTORS|BIF_RETURNONLYFSDIRS;
	
	if ((pidl = ::SHBrowseForFolder(&bInfo)) == NULL){
		return ;
	}
	SHGetPathFromIDList(pidl,m_SavePath.GetBuffer(MAX_PATH));

	//CBmpSaveDlg dlg(FALSE,NULL,"1",OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT
	//	,"bmp(*.bmp)|*.bmp||",AfxGetMainWnd());
//	dlg.DoModal();
	//path=dlg.GetPathName();
	//name=dlg.GetFileTitle();*/
}

void CMy1View::OnUndo() 
{
	// TODO: Add your command handler code here
	preChoice=choice=5;
}


void CMy1View::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	//CWindowDC dc(GetDesktopWindow()); 
//	m_xScreen = GetSystemMetrics(SM_CXSCREEN);
	//m_yScreen = GetSystemMetrics(SM_CYSCREEN);
	//if(choice==5)
//	{
		/*CDC *mdc=new CDC;  
		CDC *pDC=new CDC;
		CBitmap *bitmap=new CBitmap;  
		mdc->CreateCompatibleDC(pDC);   
		bitmap->m_hObject=(HBITMAP)::LoadImage(NULL,"D:\\bitmap0.bmp"
			,IMAGE_BITMAP,0,0,LR_LOADFROMFILE);   
		mdc->SelectObject(bitmap);   
		dc.StretchBlt(0,0,m_xScreen,m_yScreen,
			mdc,0,0,m_xScreen,m_yScreen,SRCCOPY);
		delete mdc;
		delete pDC;
		delete bitmap;*/
		//Invalidate();
//	}
	
	CView::OnLButtonDblClk(nFlags, point);
}

BOOL CMy1View::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	// TODO: Add your message handler code here and/or call default
	if(choice==1)
	{
		::SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR2));    
		return   TRUE;     
	}
	else
		if(choice==11)
		{
			::SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR6));    
			return   TRUE;     
		}
		else
			if(choice==5)
			{
				::SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR1));    
				return   TRUE;     
			}
			else 
				if(choice==4||choice==10)
				{
					::SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR7));    
					return   TRUE; 
				}
				else
					if(choice==0)
					{
						::SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR5));    
						return   TRUE; 
					}
					
					return CView::OnSetCursor(pWnd, nHitTest, message);
}

void CMy1View::OnExpand() 
{
	// TODO: Add your command handler code here
	choice=10;
}

void CMy1View::SetShowRegion(CRect orgRect,CRect &desRect)
{
	if(orgRect.Width()*3>=m_xScreen)
	{
		desRect.left=2;
		return;
	}
	else
		if(orgRect.Height()*2>=m_yScreen)
		{
			desRect.top=2;
			return;
		}
		else
			if(LTRect.PtInRect(orgRect.CenterPoint()))
			{
				return;
			}
			else
				if(RTRect.PtInRect(orgRect.CenterPoint()))
				{
					desRect.left-=50;
					return;
				}
				else
					if(LBRect.PtInRect(orgRect.CenterPoint()))
					{
						desRect.top-=50;
						return;
					}
					else
						if(RBRect.PtInRect(orgRect.CenterPoint()))
						{
							desRect.left-=50;
							desRect.top-=50;
						}
}

//DEL void CMy1View::OnShowWindow(BOOL bShow, UINT nStatus) 
//DEL {
//DEL 	CView::OnShowWindow(bShow, nStatus);
//DEL 	
//DEL 	// TODO: Add your message handler code here
//DEL 
//DEL 	
//DEL }

//DEL void CMy1View::OnSize(UINT nType, int cx, int cy) 
//DEL {
//DEL 	CView::OnSize(nType, cx, cy);
//DEL 	
//DEL 	// TODO: Add your message handler code here
//DEL 	if(once)
//DEL 	{
//DEL 	
//DEL 	}
//DEL 	
//DEL }

//DEL void CMy1View::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized) 
//DEL {
//DEL 	CView::OnActivate(nState, pWndOther, bMinimized);
//DEL 	
//DEL 	// TODO: Add your message handler code here
//DEL 	
//DEL 	
//DEL }

//DEL void CMy1View::OnActivateApp(BOOL bActive, HTASK hTask) 
//DEL {
//DEL 	CView::OnActivateApp(bActive, hTask);
//DEL 	
//DEL 	// TODO: Add your message handler code here
//DEL 	g_screenBmp=NULL;
//DEL 	m_xScreen = GetSystemMetrics(SM_CXSCREEN);
//DEL 	m_yScreen = GetSystemMetrics(SM_CYSCREEN);
//DEL 	g_qq_DlgRt.left = 0;
//DEL 	g_qq_DlgRt.top = 0;
//DEL 	g_qq_DlgRt.right = m_xScreen;
//DEL 	g_qq_DlgRt.bottom = m_yScreen;
//DEL 	g_screenBmp = CopyScreenToBitmap(&g_qq_DlgRt);
//DEL 	::DeleteFile("D:\\bitmap0.bmp");
//DEL 	SaveBitmapToFile(g_screenBmp,"D:\\bitmap0.bmp");
//DEL 	SetFileAttributes("D:\\bitmap0.bmp",FILE_ATTRIBUTE_HIDDEN);
//DEL 	
//DEL }

//DEL BOOL CMy1View::OnCopyData(CWnd* pWnd, COPYDATASTRUCT* pCopyDataStruct) 
//DEL {
//DEL 	// TODO: Add your message handler code here and/or call default
//DEL 	
//DEL 	return CView::OnCopyData(pWnd, pCopyDataStruct);
//DEL }

int CMy1View::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	CRect rect;
	pDlg= new CMyToolDlg(this);
   
	pDlg->Create(IDD_DIALOG5,GetParent());	 
	//pDlg->GetWindowRect(rect);
	//ScreenToClient(&rect);
    //pDlg->SetWindowPos(&wndTopMost,rect.left,rect.top,rect.Width(),rect.Height(),SWP_NOMOVE);
	//pDlg->ShowWindow(SW_HIDE);
	//CClientDC dc(this);
//	TEXTMETRIC tm;
	//dc.GetTextMetrics(&tm);
	//CreateSolidCaret(tm.tmAveCharWidth/8,tm.tmHeight);
	
	//ShowCaret();

	return 0;
}

void CMy1View::SetChoice(int newVal)
{
	choice=newVal;
}

void CMy1View::SetColor(COLORREF newVal)
{
	color=newVal;
}

void CMy1View::OnDestroy() 
{
	CView::OnDestroy();
	
	// TODO: Add your message handler code here
	pDlg->Detach();
	delete pDlg;
	
}

void CMy1View::SetPenWidth(int newVal)
{	
	Width=newVal;
}

void CMy1View::SetOnDrawLocker(bool newVal)
{
	onDrawLocke=newVal;
}

//DEL void CMy1View::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized) 
//DEL {
//DEL 	CView::OnActivate(nState, pWndOther, bMinimized);
//DEL 	
//DEL 	// TODO: Add your message handler code here
//DEL 	
//DEL }

void CMy1View::OnSetFocus(CWnd* pOldWnd) 
{
	CView::OnSetFocus(pOldWnd);
	
	// TODO: Add your message handler code here
}

void CMy1View::OnText() 
{
	// TODO: Add your command handler code here
	
}

//DEL void CMy1View::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
//DEL {
//DEL 	// TODO: Add your message handler code here and/or call default
//DEL 	static int count=0;
//DEL 	CClientDC dc(this);
//DEL 	CSize cs;
//DEL 	CPoint pt;
//DEL 	CRect m_rect;
//DEL 	TEXTMETRIC tm;
//DEL 	dc.GetTextMetrics(&tm);
//DEL 	if(nChar==0x0d)
//DEL 	{
//DEL 		sstr[count]=str;
//DEL 		count++;
//DEL 		str.Empty();
//DEL 		p_Origin.y+=tm.tmHeight;
//DEL 		dc.TextOutA(p_Origin.x,p_Origin.y,str);
//DEL 		cs=dc.GetTextExtent(str);
//DEL 		pt.x=p_Origin.x+cs.cx;
//DEL 		pt.y=p_Origin.y;
//DEL 		SetCaretPos(pt);
//DEL 	}
//DEL 	else 
//DEL 		if(nChar==0x08)
//DEL 		{
//DEL 			if(str.IsEmpty())
//DEL 			{
//DEL 				str=sstr[count-1];
//DEL 				cs=dc.GetTextExtent(str);
//DEL 				str=str.Left(str.GetLength()-1);
//DEL 				p_Origin.y-=tm.tmHeight;
//DEL 				m_rect.left=0;
//DEL 				m_rect.bottom=p_Origin.y+cs.cy;
//DEL 				m_rect.right=cs.cx;
//DEL 				m_rect.top=p_Origin.y;
//DEL 				InvalidateRect(&m_rect);
//DEL 				pt.x=p_Origin.x+cs.cx;
//DEL 				pt.y=p_Origin.y;
//DEL 				SetCaretPos(pt);
//DEL 
//DEL 			}
//DEL 			else
//DEL 			{
//DEL 				cs=dc.GetTextExtent(str);
//DEL 				str=str.Left(str.GetLength()-1);
//DEL 				m_rect.left=p_Origin.x;
//DEL 				m_rect.bottom=p_Origin.y+cs.cy;
//DEL 				m_rect.right=cs.cx;
//DEL 				m_rect.top=p_Origin.y;
//DEL 				InvalidateRect(&m_rect);
//DEL 				cs=dc.GetTextExtent(str);
//DEL 				pt.x=p_Origin.x+cs.cx;
//DEL 				pt.y=p_Origin.y;
//DEL 				SetCaretPos(pt);
//DEL 
//DEL 			}
//DEL 		}
//DEL 	else
//DEL 	{
//DEL 		str+=CHAR(nChar);
//DEL 		dc.TextOutA(p_Origin.x,p_Origin.y,str);
//DEL 		cs=dc.GetTextExtent(str);
//DEL 		pt.x=p_Origin.x+cs.cx;
//DEL 		pt.y=p_Origin.y;
//DEL 		SetCaretPos(pt);
//DEL 	}
//DEL 
//DEL 	CView::OnChar(nChar, nRepCnt, nFlags);
//DEL }
void CMy1View::Refresh()
{
	CRect    rect;   
	GetClientRect(&rect);   
	CDC    *pDC=CDC::FromHandle(::GetDC(NULL));   
	CDC    memdc;   
	memdc.CreateCompatibleDC(pDC);   
	(HBITMAP)::SelectObject(memdc,g_screenBmp);
	pDC->BitBlt(2,2,rect.Width(),rect.Height(),&memdc,0,0,SRCCOPY); 
	expandRect=NULL;
}
