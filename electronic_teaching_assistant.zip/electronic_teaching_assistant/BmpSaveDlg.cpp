// BmpSaveDlg.cpp : implementation file
//

#include "stdafx.h"
#include "1.h"
#include "BmpSaveDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBmpSaveDlg

IMPLEMENT_DYNAMIC(CBmpSaveDlg, CFileDialog)

CBmpSaveDlg::CBmpSaveDlg(BOOL bOpenFileDialog, LPCTSTR lpszDefExt, LPCTSTR lpszFileName,
		DWORD dwFlags, LPCTSTR lpszFilter, CWnd* pParentWnd) :
		CFileDialog(bOpenFileDialog, lpszDefExt, lpszFileName, dwFlags, lpszFilter, pParentWnd)
{
}


BEGIN_MESSAGE_MAP(CBmpSaveDlg, CFileDialog)
	//{{AFX_MSG_MAP(CBmpSaveDlg)
	ON_WM_SETCURSOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()




BOOL CBmpSaveDlg::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	// TODO: Add your message handler code here and/or call default
	::SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR4));
	return true;

	return CFileDialog::OnSetCursor(pWnd, nHitTest, message);
}
