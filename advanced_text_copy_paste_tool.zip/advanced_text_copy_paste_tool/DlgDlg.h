// DlgDlg.h : header file
//

#if !defined(AFX_DLGDLG_H__2027E8B3_4861_471E_8C13_8942D0A738A5__INCLUDED_)
#define AFX_DLGDLG_H__2027E8B3_4861_471E_8C13_8942D0A738A5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CDlgDlg dialog

class CDlgDlg : public CDialog
{
// Construction
public:
	void toTray();
	CDlgDlg(CWnd* pParent = NULL);	// standard constructor
	int index;
	
	void GetClipboardText(void);

// Dialog Data
	//{{AFX_DATA(CDlgDlg)
	enum { IDD = IDD_DLG_DIALOG };
	CComboBox	m_com;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	afx_msg void OnContextMenu(CWnd*, CPoint point);
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CDlgDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnChangeCbChain(HWND hWndRemove, HWND hWndAfter);
	afx_msg void OnDrawClipboard();
	virtual void OnOK();
	afx_msg void OnWindowPosChanging(WINDOWPOS FAR* lpwndpos);
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	afx_msg void OnExit();
	afx_msg void OnMyhelp();
	afx_msg void OnButton3();
	afx_msg void OnButton4();
	//}}AFX_MSG
	LRESULT   OnHotKey(WPARAM   wParam,LPARAM   lParam);
	LRESULT   OnShowTask(WPARAM wParam, LPARAM lParam);
	//LRESULT   OnHelp(WPARAM wParam, LPARAM lParam);
	//LRESULT   OnPowerOff(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGDLG_H__2027E8B3_4861_471E_8C13_8942D0A738A5__INCLUDED_)
