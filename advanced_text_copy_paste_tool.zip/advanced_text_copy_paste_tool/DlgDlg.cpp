// DlgDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Dlg.h"
#include "DlgDlg.h"
#include "MyDlg.h"
#include "MyClipboard.h"
#include "resource.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define WM_SHOWTASK (WM_USER+100)
//#define WM_MYHELP (WM_USER+101)
//#define WM_POWEROFF (WM_USER+102)

NOTIFYICONDATA   nid;
bool lock=true;
bool get=true;
CString str[10];
bool   visible;
bool PowerOn=true;

CMyDlg dlg;
CString OutputStr="";
bool once=true;
HWND m_hwndNextViewer=NULL;
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgDlg dialog

CDlgDlg::CDlgDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	index=0;
	for(int i=0;i<10;i++)
		str[i]="";
	visible   =   false;
}

void CDlgDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgDlg)
	DDX_Control(pDX, IDC_COMBO2, m_com);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDlgDlg, CDialog)
	ON_WM_CONTEXTMENU()
	//{{AFX_MSG_MAP(CDlgDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_CHANGECBCHAIN()
	ON_WM_DRAWCLIPBOARD()
	ON_WM_WINDOWPOSCHANGING()
	ON_WM_ACTIVATE()
	ON_COMMAND(ID_EXIT, OnExit)
	ON_COMMAND(ID_MYHELP, OnMyhelp)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	ON_MESSAGE(WM_HOTKEY,OnHotKey)
	ON_MESSAGE(WM_SHOWTASK,OnShowTask)
	ON_BN_CLICKED(IDC_BUTTON4, OnButton4)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgDlg message handlers

BOOL CDlgDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	//ShowWindow(SW_MINIMIZE);

	//toTray();
	m_hwndNextViewer = SetClipboardViewer();
	//m_com.ShowDropDown(TRUE);
	toTray();
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CDlgDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CDlgDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CDlgDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
} 

int CDlgDlg::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	RegisterHotKey(m_hWnd,1001,0,VK_F3);
	
	return 0;
}

void CDlgDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here

	NOTIFYICONDATA nd;
	nd.cbSize = sizeof (NOTIFYICONDATA);
	nd.hWnd = m_hWnd;
	
	nd.uID = IDR_MAINFRAME;
	nd.uFlags = NIF_ICON|NIF_MESSAGE|NIF_TIP;
	nd.uCallbackMessage = WM_SHOWTASK;
	nd.hIcon = m_hIcon;
	
	Shell_NotifyIcon(NIM_DELETE, &nd);

	UnregisterHotKey( m_hWnd, 1001); 
	exit(0);
}

LRESULT CDlgDlg::OnHotKey(WPARAM wParam,LPARAM lParam) 
{
	int no=m_com.GetCount();
	if(wParam==1001&&!visible&&no)
	{
		CPoint point;
		//point=CWnd::GetCaretPos();
		::GetCursorPos(&point);
		//ClientToScreen(&point);
		SetWindowPos(&wndBottom,point.x,point.y,220,20,NULL);

		m_com.ShowDropDown(true);
		visible=true;
		ShowWindow(SW_SHOW);
		
		CWnd::SetForegroundWindow();

	}
	return true;
}

void CDlgDlg::OnChangeCbChain(HWND hWndRemove, HWND hWndAfter) 
{
	CDialog::OnChangeCbChain(hWndRemove, hWndAfter);
	if(hWndRemove == m_hwndNextViewer)
        m_hwndNextViewer = hWndAfter;
	
	// TODO: Add your message handler code here
	
}

void CDlgDlg::OnDrawClipboard() 
{
	CDialog::OnDrawClipboard();
	
	// TODO: Add your message handler code here
	if(once)
		once=false;
	else
	{
		if(get)
			GetClipboardText();
		else
			get=true;
	}
}

//DEL void CDlgDlg::SetCString(CString str)
//DEL {
//DEL 	OutputStr=str;
//DEL 	get=false;
//DEL 	CClipboard::SetText(OutputStr.GetBuffer(1));
//DEL 	get=true;
//DEL }


void CDlgDlg::GetClipboardText()
{
	char* buf;
	unsigned long nSize;
	
	if(!CClipboard::GetTextLength(&nSize))
		return;

	buf = new char[nSize + 1];

	CClipboard::GetText(buf, nSize + 1);
	buf[nSize] = 0;

	str[index%10]=buf;

	m_com.InsertString(0,str[index%10]);

	index++;

	delete[] buf;
}

LRESULT CDlgDlg::OnShowTask(WPARAM wParam, LPARAM lParam)
{
	if(wParam!=IDR_MAINFRAME) 
        return 1; 
	
	CMenu menu;
	CPoint point;
	menu.LoadMenu(CG_IDR_POPUP_DLG_DLG);
	CMenu *pMenu=menu.GetSubMenu(0);

    switch(lParam) 
    {    
        case WM_RBUTTONUP://�Ҽ�����ʱ������ݲ˵�������ֻ��һ�����رա� 
        { 
			::GetCursorPos(&point);//�õ����λ�� 
            pMenu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON,point.x,point.y,this);
			menu.DestroyMenu(); 
        } 
        break; 
        case WM_LBUTTONDBLCLK://˫������Ĵ��� 
		{ 
				
		} 
        break; 
		default:
			break;
    } 
    return 0;
}

void CDlgDlg::toTray()
{
   NOTIFYICONDATA nid; 
    nid.cbSize=(DWORD)sizeof(NOTIFYICONDATA); 
    nid.hWnd=this->m_hWnd; 
    nid.uID=IDR_MAINFRAME; 
    nid.uFlags=NIF_ICON|NIF_MESSAGE|NIF_TIP ; 
    nid.uCallbackMessage=WM_SHOWTASK;//�Զ������Ϣ���� 
    nid.hIcon=LoadIcon(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDR_MAINFRAME)); 
    strcpy(nid.szTip,"����ճ����ǿ��");    //��Ϣ��ʾ��Ϊ���ƻ��������ѡ� 
    Shell_NotifyIcon(NIM_ADD,&nid);    //������������ͼ�� 
    ShowWindow(SW_HIDE);    //���������� 

}


void CDlgDlg::OnOK() 
{
	// TODO: Add extra validation here
	CString str;
	GetDlgItemText(IDC_COMBO2,str);
	if(str!="ȡ��")
	{
		get=false;
		CClipboard::SetText(str.GetBuffer(1));
	}
	visible=false;
	//ShowWindow(SW_HIDE);
	toTray();

	//CDialog::OnOK();
}

void CDlgDlg::OnWindowPosChanging(WINDOWPOS FAR* lpwndpos) 
{
	CDialog::OnWindowPosChanging(lpwndpos);
	
	// TODO: Add your message handler code here
	if(!visible)   
		lpwndpos->flags   &=   ~SWP_SHOWWINDOW;

}

BOOL CDlgDlg::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(pMsg->message   ==   WM_KEYDOWN)
		if(pMsg->wParam==VK_ESCAPE)
			return   TRUE;   

	return CDialog::PreTranslateMessage(pMsg);
}

void CDlgDlg::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized) 
{
	CDialog::OnActivate(nState, pWndOther, bMinimized);
	
	// TODO: Add your message handler code here
	if(nState==WA_INACTIVE)
	{
		visible=false;
		toTray();
	}
	
}

void CDlgDlg::OnContextMenu(CWnd*, CPoint point)
{

	// CG: This block was added by the Pop-up Menu component
	{
		if (point.x == -1 && point.y == -1){
			//keystroke invocation
			CRect rect;
			GetClientRect(rect);
			ClientToScreen(rect);

			point = rect.TopLeft();
			point.Offset(5, 5);
		}

		CMenu menu;
		VERIFY(menu.LoadMenu(CG_IDR_POPUP_DLG_DLG));

		CMenu* pPopup = menu.GetSubMenu(0);
		ASSERT(pPopup != NULL);
		CWnd* pWndPopupOwner = this;

		while (pWndPopupOwner->GetStyle() & WS_CHILD)
			pWndPopupOwner = pWndPopupOwner->GetParent();

		pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y,
			pWndPopupOwner);
	}
}

void CDlgDlg::OnExit() 
{
	// TODO: Add your command handler code here
	SendMessage(WM_DESTROY);
}

void CDlgDlg::OnMyhelp() 
{
	// TODO: Add your command handler code here
	MessageBox("F3��ѡ��ճ������\n","����");
}

void CDlgDlg::OnButton3() 
{
	// TODO: Add your control notification handler code here
	CString str;
	GetDlgItemText(IDC_COMBO2,str);
	if(str!="ȡ��")
	{
		get=false;
		CClipboard::SetText(str.GetBuffer(1));
	}
	visible=false;
	toTray();
}


void CDlgDlg::OnButton4() 
{
	// TODO: Add your control notification handler code here
	m_com.ResetContent();
	m_com.AddString("ȡ��");
}
