#if !defined(AFX_FIRE_H__F525334F_691A_4696_8538_FC3D13036577__INCLUDED_)
#define AFX_FIRE_H__F525334F_691A_4696_8538_FC3D13036577__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Fire.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// Fire view
class Fire : public CView
{
protected:
	//Fire();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(Fire)
		
		// Attributes
public:
	
	// Operations
public:
	int SearchFireIndex(int x,int y);
	void Fireout(int x,int y, int index, HWND hwnd);
	void SetMembers(void);
	void DrawFire(CDC *pDC);
	void InitFirePosition(void);
	int GetFireLeft(void) const;
	
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(Fire)
protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL
	
	// Implementation
protected:
	//virtual ~Fire();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	
	// Generated message map functions
protected:
	//{{AFX_MSG(Fire)
	// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int fireNumber;
	BOOL fired[12];
	CBitmap fireBitmap;
	CPoint firePt[12];
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FIRE_H__F525334F_691A_4696_8538_FC3D13036577__INCLUDED_)
