// Layout.h: interface for the Layout class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LAYOUT_H__259931C7_688D_440E_9B6D_3BD572112765__INCLUDED_)
#define AFX_LAYOUT_H__259931C7_688D_440E_9B6D_3BD572112765__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define SXC 1;

class Layout  
{
public:
	void DrawBlank(CDC *pDC);
	void DrawBk(CDC *pDC);
//	Layout();
	void SetMembers(CRect);
	void ChangeState(int i,int j,int state);
	int GetLayoutState(int i,int j);
	CRect GetClientRect() const;
	CRect GetLayoutRect(int i,int j);
	void SetClientRect(CRect val);
	COLORREF crColor;
//	virtual ~Layout();
	
private:
	CRect layoutRect[20][20];
	int layoutState[20][20];
	CRect clientRect;
	CBitmap bkBitmap;
};

#endif // !defined(AFX_LAYOUT_H__259931C7_688D_440E_9B6D_3BD572112765__INCLUDED_)
