// Coin.cpp : implementation file
//

#include "stdafx.h"
#include "Game.h"
#include "Coin.h"
#include "Layout.h"
#include "Mmsystem.h"

extern Layout layout;
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCoin

IMPLEMENT_DYNCREATE(CCoin, CView)

/*CCoin::CCoin()
{
}

CCoin::~CCoin()
{
}*/


BEGIN_MESSAGE_MAP(CCoin, CView)
	//{{AFX_MSG_MAP(CCoin)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCoin drawing

void CCoin::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CCoin diagnostics

#ifdef _DEBUG
void CCoin::AssertValid() const
{
	CView::AssertValid();
}

void CCoin::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CCoin message handlers

void CCoin::DrawCoin(CDC *pDC)
{
	CDC *mdc=new CDC;
	CPoint temp;
	mdc->CreateCompatibleDC(pDC);

	for (iter=ptVector.begin();iter!=ptVector.end();++iter)
	{
		temp=*iter;
		if (layout.GetLayoutState(temp.x/20,temp.y/20)==APPLE)
		{
			mdc->SelectObject(appleBitmap);
		}
		else
			if (layout.GetLayoutState(temp.x/20,temp.y/20)==PEAR)
			{
				mdc->SelectObject(pearBitamp);
			}
			else
				if (layout.GetLayoutState(temp.x/20,temp.y/20)==ORANGE)
				{
					mdc->SelectObject(orangeBitmap);
				}
		TransparentBlt(pDC->m_hDC,temp.x,temp.y,20,20,mdc->m_hDC,0,0,20,20,RGB(255,255,255));
	}
	delete mdc;
}

void CCoin::SetMembers()
{
	appleBitmap.m_hObject=(HBITMAP)::LoadImage(NULL,"D://res//RINGO.bmp",IMAGE_BITMAP,20,20,LR_LOADFROMFILE);
	pearBitamp.m_hObject=(HBITMAP)::LoadImage(NULL,"D://res//YOUNASHI.bmp",IMAGE_BITMAP,20,20,LR_LOADFROMFILE);
	orangeBitmap.m_hObject=(HBITMAP)::LoadImage(NULL,"D://res//MIKAN.bmp",IMAGE_BITMAP,20,20,LR_LOADFROMFILE);
	ptVector.clear();
}

void CCoin::RandomCoins()
{
	int x,y;
	int type;
	srand((unsigned)time(NULL));
	for (int i=0;i<2;i++)
	{
		do 
		{
			x=rand()%20;
			y=rand()%20;
		}while (layout.GetLayoutState(x,y));
		type=rand()%10;

		if (type>=0&&type<=6)
		{
			layout.ChangeState(x,y,APPLE);
		}
		else
			if (type>6&&type<=8)
			{
				layout.ChangeState(x,y,PEAR);
			}
			else
			{
				layout.ChangeState(x,y,ORANGE);
			}
		coin[i].x=layout.GetLayoutRect(x,y).left;
		coin[i].y=layout.GetLayoutRect(x,y).top;

		ptVector.push_back(coin[i]);
	}
}

void CCoin::CoinEaten(int i, int j,int role)
{
	if (role==HERO)
	{
		sndPlaySound("D://res//GAME99.WAV",SND_ASYNC);
	}
	CPoint temp;
	for (iter=ptVector.begin();iter!=ptVector.end();++iter)
	{
		temp=*iter;
		if (temp.x==i&&temp.y==j)
		{
			ptVector.erase(iter);
			break;
		}
	}
}
