// ScoreBoard.cpp : implementation file
//

#include "stdafx.h"
#include "Game.h"
#include "ScoreBoard.h"
#include "Enemy.h"
#include "MainDailog.h"
#include "Layout.h"

extern Layout layout;
extern Enemy enemy;
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CScoreBoard

IMPLEMENT_DYNCREATE(CScoreBoard, CView)

/*CScoreBoard::CScoreBoard()
{
}

CScoreBoard::~CScoreBoard()
{
}*/

BEGIN_MESSAGE_MAP(CScoreBoard, CView)
	//{{AFX_MSG_MAP(CScoreBoard)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CScoreBoard drawing

void CScoreBoard::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CScoreBoard diagnostics

#ifdef _DEBUG
void CScoreBoard::AssertValid() const
{
	CView::AssertValid();
}

void CScoreBoard::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CScoreBoard message handlers

void CScoreBoard::SetScoreboardRect(CRect val)
{
	scoreboardRect=val;
}

CRect CScoreBoard::GetScoreboardRect()const
{
	return scoreboardRect;
}

void CScoreBoard::SetMembers()
{
	life=3;
	score=0;
	level=1;
	gameOver=FALSE;
	addlifeLevel=5000;
	CStdioFile mywritefile("D://Data.sav",CFile::modeRead);
	mywritefile.ReadString(highScoreName);
	mywritefile.ReadString(highScore);
	highScoreName.Delete(highScoreName.GetLength()-1);
	mywritefile.Close();

	heroBitmap.m_hObject=(HBITMAP)::LoadImage(NULL,"D://res//Kabi01.bmp",IMAGE_BITMAP,20,20,LR_LOADFROMFILE);
	fireBitmap.m_hObject=(HBITMAP)::LoadImage(NULL,"D://res//Sunburst.bmp",IMAGE_BITMAP,20,20,LR_LOADFROMFILE);
	appleBitmap.m_hObject=(HBITMAP)::LoadImage(NULL,"D://res//RINGO.bmp",IMAGE_BITMAP,20,20,LR_LOADFROMFILE);
	enemy1Bitmap.m_hObject=(HBITMAP)::LoadImage(NULL,"D://res//skull.bmp",IMAGE_BITMAP,20,20,LR_LOADFROMFILE);
	enemy2Bitmap.m_hObject=(HBITMAP)::LoadImage(NULL,"D://res//10.bmp",IMAGE_BITMAP,20,20,LR_LOADFROMFILE);
	pearBitmap.m_hObject=(HBITMAP)::LoadImage(NULL,"D://res//YOUNASHI.bmp",IMAGE_BITMAP,20,20,LR_LOADFROMFILE);
	orangeBitmap.m_hObject=(HBITMAP)::LoadImage(NULL,"D://res//MIKAN.bmp",IMAGE_BITMAP,20,20,LR_LOADFROMFILE);
}

void CScoreBoard::DrawScoreboard(CDC *pDC)
{
	CDC *mdc=new CDC;
	mdc->CreateCompatibleDC(pDC);
	CRect rect(402,0,500,400);
	CBrush bru(layout.crColor);
	char ch[10];

	pDC->FillRect(rect,&bru);
	pDC->SetBkColor(layout.crColor);

	mdc->SelectObject(appleBitmap);
	TransparentBlt(pDC->m_hDC,410,110,20,20,mdc->m_hDC,0,0,20,20,RGB(255,255,255));
	pDC->TextOut(430,113,"��>200 Pt");

	mdc->SelectObject(fireBitmap);
	TransparentBlt(pDC->m_hDC,410,140,20,20,mdc->m_hDC,0,0,20,20,RGB(255,255,255));
	pDC->TextOut(430,143,"��>100 Pt");

	mdc->SelectObject(pearBitmap);
	TransparentBlt(pDC->m_hDC,410,170,20,20,mdc->m_hDC,0,0,20,20,RGB(255,255,255));
	pDC->TextOut(430,173,"��>300 Pt");

	mdc->SelectObject(orangeBitmap);
	TransparentBlt(pDC->m_hDC,410,200,20,20,mdc->m_hDC,0,0,20,20,RGB(255,255,255));
	pDC->TextOut(430,203,"��>400 Pt");

	mdc->SelectObject(enemy1Bitmap);
	TransparentBlt(pDC->m_hDC,410,230,20,20,mdc->m_hDC,0,0,20,20,RGB(255,255,255));
	pDC->TextOut(430,233,"��>100 Pt");

	mdc->SelectObject(enemy2Bitmap);
	TransparentBlt(pDC->m_hDC,410,260,20,20,mdc->m_hDC,0,0,20,20,RGB(255,255,255));
	pDC->TextOut(430,263,"��>50 Pt");

	pDC->MoveTo(402,308);
	pDC->LineTo(500,308);
	pDC->MoveTo(402,309);
	pDC->LineTo(500,309);

	pDC->TextOut(410,330,"����: "+highScore);
	pDC->TextOut(410,350,"����: "+highScoreName);

	pDC->MoveTo(402,0);
	pDC->LineTo(402,600);

	itoa(life,ch,10);
	pDC->TextOut(410,8,"Life:");
	pDC->TextOut(440,8,ch);

	itoa(score,ch,10);
	pDC->TextOut(410,28,"Scores:");
	pDC->TextOut(460,28,ch);

	itoa(level,ch,10);
	pDC->TextOut(410,48,"Level:");
	pDC->TextOut(453,48,ch);

	itoa(enemy.GetEnemyNum(),ch,10);
	pDC->TextOut(410,68,"Enemy:");
	pDC->TextOut(460,68,ch);

	pDC->MoveTo(402,100);
	pDC->LineTo(502,100);
	pDC->MoveTo(402,101);
	pDC->LineTo(502,101);

	delete mdc;
	//delete scoreboardBitmap;
}



BOOL CScoreBoard::CheckGameOver()
{
	if (!life)
	{
		CString temp;
		CString str="Your score is: ";
		gameOver=TRUE;
		MessageBox("Game Over!!!");
		temp.Format("%d",score);
		str+=temp;
		
		MessageBox(str);

		if (score>atoi(highScore))
		{
			CMainDailog dlg;
			if (dlg.DoModal()==IDOK)
			{
				CStdioFile mywritefile("D://Data.sav",CFile::modeWrite|CFile::modeCreate);
				mywritefile.WriteString(dlg.name);
				mywritefile.WriteString("\r\n");
				mywritefile.WriteString(temp);
				mywritefile.Close();
			}
		}
		return true;
	}
	return false;
}

void CScoreBoard::AddLife( int val )
{
	life+=val;
}