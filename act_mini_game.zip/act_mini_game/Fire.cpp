// Fire.cpp : implementation file
//

#include "stdafx.h"
#include "Game.h"
#include "Fire.h"
#include "Layout.h"
#include "Enemy.h"
#include "ScoreBoard.h"
#include "Mmsystem.h"
#include "Coin.h"

extern CScoreBoard scoreboard;
extern Layout layout;
extern Enemy enemy;
extern CCoin coin;
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Fire

IMPLEMENT_DYNCREATE(Fire, CView)

/*Fire::Fire()
{
}

Fire::~Fire()
{
}*/


BEGIN_MESSAGE_MAP(Fire, CView)
	//{{AFX_MSG_MAP(Fire)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Fire drawing

void Fire::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// Fire diagnostics

#ifdef _DEBUG
void Fire::AssertValid() const
{
	CView::AssertValid();
}

void Fire::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// Fire message handlers

void Fire::InitFirePosition(void)
{
	int x,y;
	srand((unsigned)time(NULL));
	for (int i=0;i<12;i++)
	{
		do 
		{
			x=rand()%20;
			y=rand()%20;
		} while (layout.GetLayoutState(x,y));
		
		layout.ChangeState(x,y,FIRE);
		firePt[i].x=layout.GetLayoutRect(x,y).left;
		firePt[i].y=layout.GetLayoutRect(x,y).top;
	}
}

void Fire::DrawFire(CDC *pDC)
{
	CDC *mdc=new CDC;
	mdc->CreateCompatibleDC(pDC);
	fireBitmap.m_hObject=(HBITMAP)::LoadImage(NULL,"D://res//Sunburst.bmp",IMAGE_BITMAP,20,20,LR_LOADFROMFILE);
	mdc->SelectObject(fireBitmap);
	for (int i=0;i<12;i++)
	{
		if(!fired[i])
			TransparentBlt(pDC->m_hDC,firePt[i].x,firePt[i].y,20,20,mdc->m_hDC,0,0,20,20,RGB(255,255,255));
	}
	delete mdc;
}

void Fire::SetMembers()
{
	for (int i=0;i<12;i++)
	{
		fired[i]=FALSE;
	}
	fireNumber=12;
	fireBitmap.m_hObject=(HBITMAP)::LoadImage(NULL,"D://res//Sunburst.bmp",IMAGE_BITMAP,20,20,LR_LOADFROMFILE);
}

void Fire::Fireout(int x, int y, int index, HWND hwnd)
{
	int state=-1;
	scoreboard.SetScore(100);
	if (scoreboard.GetScore()>=scoreboard.GetlifeLevel())
	{
		scoreboard.SetlifeLevel();
		scoreboard.AddLife(1);
	}
	sndPlaySound("D://res//GAME25.WAV",SND_ASYNC);
	int xx=x;
	int yy=y;
	fireNumber--;
	CDC    *pDC=CDC::FromHandle(::GetDC(hwnd));
	CDC *mdc=new CDC;
	mdc->CreateCompatibleDC(pDC);
	mdc->SelectObject(fireBitmap);
	for (;;)
	{
		state=layout.GetLayoutState(xx/20,yy/20);
		if (layout.GetLayoutState(xx/20,yy/20)==FIREORBIT)
		{
			layout.ChangeState(xx/20,yy/20,NONE);
		}
		yy-=20;
		state=layout.GetLayoutState(xx/20,yy/20);
		if (yy<0||state==WALL)
		{
			break;
		}
		firePt[index].y=yy;
		firePt[index].x=xx;
		TransparentBlt(pDC->m_hDC,firePt[index].x,firePt[index].y,20,20,mdc->m_hDC,0,0,20,20,RGB(255,255,255));
		if (state==ENEMY1||state==ENEMY2)
		{
			if(layout.GetLayoutState(xx/20,yy/20)==ENEMY1)
				scoreboard.SetScore(100);
			else
				scoreboard.SetScore(50);
			layout.ChangeState(xx/20,yy/20,FIREORBIT);
			enemy.ChangeEatenState(enemy.SearchFireIndex(xx,yy),TRUE);
			if (scoreboard.GetScore()>=scoreboard.GetlifeLevel())
			{
				scoreboard.SetlifeLevel();
				scoreboard.AddLife(1);
			}
			enemy.SetEnemyNum(1);
			coin.RandomCoins();
			sndPlaySound("D://res//Game1.WAV",SND_ASYNC);
		}
		Sleep(2);
	}
	xx=x;
	yy=y;

	for (;;)
	{
		state=layout.GetLayoutState(xx/20,yy/20);
		if (layout.GetLayoutState(xx/20,yy/20)==FIREORBIT)
		{
			layout.ChangeState(xx/20,yy/20,NONE);
		}
		yy+=20;
		state=layout.GetLayoutState(xx/20,yy/20);
		if (yy>380||state==WALL)
		{
			break;
		}
		firePt[index].y=yy;
		firePt[index].x=xx;
		TransparentBlt(pDC->m_hDC,firePt[index].x,firePt[index].y,20,20,mdc->m_hDC,0,0,20,20,RGB(255,255,255));
		if (state==ENEMY1||state==ENEMY2)
		{
			if(layout.GetLayoutState(xx/20,yy/20)==ENEMY1)
				scoreboard.SetScore(100);
			else
				scoreboard.SetScore(50);
			layout.ChangeState(xx/20,yy/20,FIREORBIT);
			enemy.ChangeEatenState(enemy.SearchFireIndex(xx,yy),TRUE);
			if (scoreboard.GetScore()>=scoreboard.GetlifeLevel())
			{
				scoreboard.SetlifeLevel();
				scoreboard.AddLife(1);
			}
			enemy.SetEnemyNum(1);
			coin.RandomCoins();
			sndPlaySound("D://res//Game1.WAV",SND_ASYNC);
		}
		Sleep(2);
	}
	xx=x;
	yy=y;
	for (;;)
	{
		state=layout.GetLayoutState(xx/20,yy/20);
		if (layout.GetLayoutState(xx/20,yy/20)==FIREORBIT)
		{
			layout.ChangeState(xx/20,yy/20,NONE);
		}
		xx-=20;
		state=layout.GetLayoutState(xx/20,yy/20);
		if (xx<0||state==WALL)
		{
			break;
		}
		firePt[index].y=yy;
		firePt[index].x=xx;
		TransparentBlt(pDC->m_hDC,firePt[index].x,firePt[index].y,20,20,mdc->m_hDC,0,0,20,20,RGB(255,255,255));
		if (state==ENEMY1||state==ENEMY2)
		{
			if(layout.GetLayoutState(xx/20,yy/20)==ENEMY1)
				scoreboard.SetScore(100);
			else
				scoreboard.SetScore(50);
			layout.ChangeState(xx/20,yy/20,0);
			enemy.ChangeEatenState(enemy.SearchFireIndex(xx,yy),TRUE);
			if (scoreboard.GetScore()>=scoreboard.GetlifeLevel())
			{
				scoreboard.SetlifeLevel();
				scoreboard.AddLife(1);
			}
			enemy.SetEnemyNum(1);
			coin.RandomCoins();
			sndPlaySound("D://res//Game1.WAV",SND_ASYNC);
		}
		Sleep(2);
	}

	xx=x;
	yy=y;
	for (;;)
	{
		state=layout.GetLayoutState(xx/20,yy/20);
		if (layout.GetLayoutState(xx/20,yy/20)==FIREORBIT)
		{
			layout.ChangeState(xx/20,yy/20,NONE);
		}
		xx+=20;
		state=layout.GetLayoutState(xx/20,yy/20);
		if (xx>380||state==WALL)
		{
			break;
		}
		firePt[index].y=yy;
		firePt[index].x=xx;
		TransparentBlt(pDC->m_hDC,firePt[index].x,firePt[index].y,20,20,mdc->m_hDC,0,0,20,20,RGB(255,255,255));
		if (state==ENEMY1||state==ENEMY2)
		{
			if(layout.GetLayoutState(xx/20,yy/20)==ENEMY1)
				scoreboard.SetScore(100);
			else
				scoreboard.SetScore(50);
			layout.ChangeState(xx/20,yy/20,FIREORBIT);
			enemy.ChangeEatenState(enemy.SearchFireIndex(xx,yy),TRUE);
			if (scoreboard.GetScore()>=scoreboard.GetlifeLevel())
			{
				scoreboard.SetlifeLevel();
				scoreboard.AddLife(1);
			}
			enemy.SetEnemyNum(1);
			coin.RandomCoins();
			sndPlaySound("D://res//Game1.WAV",SND_ASYNC);
		}
		Sleep(2);
	}
	delete mdc;
}

int Fire::SearchFireIndex(int x, int y)
{
	for (int i=0;i<12;i++)
	{
		if (firePt[i].x==x&&firePt[i].y==y)
		{
			fired[i]=TRUE;
			return i;
		}
	}
	return -1;
}

int Fire::GetFireLeft( void ) const
{
	return fireNumber;	
}
