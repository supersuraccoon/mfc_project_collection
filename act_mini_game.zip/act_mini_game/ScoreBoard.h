#if !defined(AFX_SCOREBOARD_H__82B42E6C_7A24_4844_A1C2_A3CD1FAD7850__INCLUDED_)
#define AFX_SCOREBOARD_H__82B42E6C_7A24_4844_A1C2_A3CD1FAD7850__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ScoreBoard.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CScoreBoard view
#include "MainDailog.h"

class CScoreBoard : public CView
{
protected:
//	CScoreBoard();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CScoreBoard)

// Attributes
public:

// Operations
public:
	BOOL CheckGameOver(void);
	void SetMembers(void);
	void DrawScoreboard(CDC *pDC);
	CRect GetScoreboardRect() const;
	void SetScoreboardRect(CRect val);
	int GetLife() const { return life; }
	void SetLife(int val) { life -= val; }
	void AddLife(int val);
	int GetScore() const { return score; }
	void SetScore(int val) { score += val; }
	int GetLevel() const { return level; }
	void SetLevel(int val) { level += val; }
	BOOL GetGameOver() const { return gameOver; }
	int GetlifeLevel() const { return addlifeLevel; }
	void SetlifeLevel(void) { addlifeLevel += addlifeLevel; }

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScoreBoard)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
//	virtual ~CScoreBoard();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CScoreBoard)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CRect scoreboardRect;
	int life;
	int score;
	int level;
	BOOL gameOver;
	CMainDailog dlg;
	int addlifeLevel;
	CBitmap heroBitmap;
	CBitmap fireBitmap;
	CBitmap appleBitmap;
	CBitmap enemy1Bitmap;
	CBitmap enemy2Bitmap;
	CBitmap pearBitmap;
	CBitmap orangeBitmap;
	CString highScore;
	CString highScoreName;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCOREBOARD_H__82B42E6C_7A24_4844_A1C2_A3CD1FAD7850__INCLUDED_)
