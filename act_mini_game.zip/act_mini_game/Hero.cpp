// Hero.cpp : implementation file
//

#include "stdafx.h"
#include "Game.h"
#include "Hero.h"
#include "Layout.h"

extern Layout layout;
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Hero

IMPLEMENT_DYNCREATE(Hero, CView)

BEGIN_MESSAGE_MAP(Hero, CView)
	//{{AFX_MSG_MAP(Hero)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


Hero::Hero()
{
	heroBitmap.m_hObject=(HBITMAP)::LoadImage(NULL,"D://res//Kabi01.bmp",IMAGE_BITMAP,20,20,LR_LOADFROMFILE);
}
/////////////////////////////////////////////////////////////////////////////
// Hero drawing

void Hero::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// Hero diagnostics

#ifdef _DEBUG
void Hero::AssertValid() const
{
	CView::AssertValid();
}

void Hero::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// Hero message handlers

void Hero::DrawHero(CDC *pDC)
{
	CDC *mdc=new CDC;
	mdc->CreateCompatibleDC(pDC);
	mdc->SelectObject(heroBitmap);
	TransparentBlt(pDC->m_hDC,currentPt.x,currentPt.y,20,20,mdc->m_hDC,0,0,20,20,RGB(0,0,0));
	delete mdc;
}	

void Hero::SetCurrentPosition(int x, int y)
{
	previousPt=currentPt;
	currentPt.x+=x;
	currentPt.y+=y;
}

void Hero::SetMembers()
{
	size.cx=20;
	size.cy=20;
	currentPt.x=0;
	currentPt.y=0;
	previousPt=currentPt;
	currentRect.SetRect(0,0,20,20);
	layout.ChangeState(0,0,HERO);
}

CPoint Hero::GetCurrentPosition()
{
	return currentPt;
}

CPoint Hero::GetPreviousPosition( void )
{
	return previousPt;	
}