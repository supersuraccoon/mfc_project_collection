// Global.cpp: implementation of the CGlobal class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Game.h"
#include "Global.h"

Layout layout;
Enemy enemy;
Wall wall;
CScoreBoard scoreboard;
CCoin coin;
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGlobal::CGlobal()
{

}

CGlobal::~CGlobal()
{

}
