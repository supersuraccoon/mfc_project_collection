// Wall.cpp : implementation file
//

#include "stdafx.h"
#include "Game.h"
#include "Wall.h"
#include "Layout.h"

extern Layout layout;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Wall

IMPLEMENT_DYNCREATE(Wall, CView)

Wall::Wall()
{
		wallBitmap.m_hObject=(HBITMAP)::LoadImage(NULL,"D://res//406.bmp",IMAGE_BITMAP,20,20,LR_LOADFROMFILE);
}

/*Wall::~Wall()
{
}*/


BEGIN_MESSAGE_MAP(Wall, CView)
	//{{AFX_MSG_MAP(Wall)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Wall drawing

void Wall::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// Wall diagnostics

#ifdef _DEBUG
void Wall::AssertValid() const
{
	CView::AssertValid();
}

void Wall::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// Wall message handlers

void Wall::InitWallRect()
{
	int x,y;
	srand((unsigned)time(NULL));
	for (int i=0;i<20;i++)
	{
		do 
		{
			do 
			{
				x=rand()%20;
				y=rand()%20;
			} while (x==0&&y==1||x==1&&y==0);
			
		} while (layout.GetLayoutState(x,y));
		
		layout.ChangeState(x,y,WALL);
		wallPt[i].x=layout.GetLayoutRect(x,y).left;
		wallPt[i].y=layout.GetLayoutRect(x,y).top;
	}
}

void Wall::DrawWall(CDC *pDC,HWND hwnd)
{
	CRect rect(0,0,400,400);
	CBrush bru(layout.crColor);
	CDC *mdc1=new CDC;
	mdc1->CreateCompatibleDC(pDC);
	mdc1->SelectObject(wallBitmap);
	
    pDC->FillRect(rect,&bru);
	for (int i=0;i<20;i++)
	{
		TransparentBlt(pDC->m_hDC,wallPt[i].x,wallPt[i].y,20,20,mdc1->m_hDC,0,0,20,20,RGB(255,255,255));
	}
	delete mdc1;
}

void Wall::ResetState()
{
	int x,y;
	for (int i=0;i<20;i++)
	{
		x=wallPt[i].x;
		y=wallPt[i].y;
		if (layout.GetLayoutState(x/20,y/20)==WALL)
		{
			layout.ChangeState(x/20,y/20,NONE);
		}
	}
}
