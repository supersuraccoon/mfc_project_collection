// Layout.cpp: implementation of the Layout class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Draw.h"
#include "Layout.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

/*Layout::Layout()
{

}

Layout::~Layout()
{

}*/

void Layout::SetMembers(CRect rect)
{
	int R,G,B;
	srand((unsigned)time(NULL));
	R=rand()%256;
	G=rand()%256;
	B=rand()%256;
	crColor=RGB(R,G,B);
	for (int i=0;i<20;i++)
	{
		for (int j=0;j<20;j++)
		{
			layoutRect[i][j].left=rect.Width()/20*i;
			layoutRect[i][j].right=rect.Width()/20*(i+1);
			layoutRect[i][j].top=rect.Height()/20*j;
			layoutRect[i][j].bottom=rect.Width()/20*(j+1);
			layoutState[i][j]=NONE;
		}
	}
}

void Layout::ChangeState(int i,int j,int state)
{
	layoutState[i][j]=state;
}

CRect Layout::GetClientRect() const 
{ 
	return clientRect; 
}

void Layout::SetClientRect(CRect val) 
{ 
	clientRect = val; 
}

int Layout::GetLayoutState(int i,int j)
{

	return layoutState[i][j];
}

CRect Layout::GetLayoutRect(int i,int j)
{
	return layoutRect[i][j];
}

void Layout::DrawBk(CDC *pDC)
{

	CDC *mdc=new CDC;
	mdc->CreateCompatibleDC(pDC);
	CBrush bru(crColor);

	for (int i=0;i<20;i++)
	{
		for (int j=0;j<20;j++)
		{
			if(layoutState[i][j]==NONE)
			{
				pDC->FillRect(layoutRect[i][j],&bru);
			}
		}
	}
	delete mdc;
}
