// GameView.cpp : implementation of the CGameView class
//

#include "stdafx.h"
#include "Game.h"

#include "GameDoc.h"
#include "GameView.h"
#include "Mmsystem.h"

extern Wall wall;
extern Enemy enemy;
extern Layout layout;
extern CScoreBoard scoreboard;
extern CCoin coin;
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

int gx;
int gy;
int gindex;
/////////////////////////////////////////////////////////////////////////////
// CGameView

IMPLEMENT_DYNCREATE(CGameView, CView)

BEGIN_MESSAGE_MAP(CGameView, CView)
	//{{AFX_MSG_MAP(CGameView)
	ON_WM_CHAR()
	ON_WM_KEYDOWN()
	ON_WM_TIMER()
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_CANCELMODE()
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGameView construction/destruction

CGameView::CGameView()
{
	// TODO: add construction code here
	CRect rect(400,0,500,400);
	clientRect.SetRect(0,0,400,400);
	layout.SetClientRect(clientRect);
	layout.SetMembers(clientRect);
	scoreboard.SetScoreboardRect(rect);
	scoreboard.SetMembers();
	hero.SetMembers();
	fire.InitFirePosition();
	fire.SetMembers();
	wall.InitWallRect();
	enemy.InitEnemyPosition(10);
	enemy.SetMembers();
	coin.SetMembers();

	Start=true;
}

CGameView::~CGameView()
{
}

BOOL CGameView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	/*if(dlg.DoModal()==IDOK)
	{
		
	}
	else
	{
		exit(1);
	}*/

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CGameView drawing

void CGameView::OnDraw(CDC* pDC)
{
	CGameDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
	CDC   g_hMemDC;   
	CBitmap   g_hMemBitmap;
	g_hMemDC.CreateCompatibleDC(pDC);   //�����ڴ�DC 
	g_hMemBitmap.CreateCompatibleBitmap(pDC,500,400);
	
	SelectObject(g_hMemDC,g_hMemBitmap);   

	layout.DrawBk(&g_hMemDC);
	wall.DrawWall(&g_hMemDC,m_hWnd);
	enemy.DrawEnemy(&g_hMemDC);
	fire.DrawFire(&g_hMemDC);
	hero.DrawHero(&g_hMemDC);
	coin.DrawCoin(&g_hMemDC);

	scoreboard.DrawScoreboard(&g_hMemDC);
	
	pDC->BitBlt(0,0,500,400,&g_hMemDC,0,0,SRCCOPY); 
}

/////////////////////////////////////////////////////////////////////////////
// CGameView printing

BOOL CGameView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CGameView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CGameView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CGameView diagnostics

#ifdef _DEBUG
void CGameView::AssertValid() const
{
	CView::AssertValid();
}

void CGameView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CGameDoc* CGameView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGameDoc)));
	return (CGameDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGameView message handlers

void CGameView::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default

	
	CView::OnChar(nChar, nRepCnt, nFlags);
}

void CGameView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	if (nChar==32&&Start)
	{
		SetTimer(1,300,NULL);
		Start=false;
	}
	if (!Start)
	{
	int x=hero.GetCurrentPosition().x;
	int y=hero.GetCurrentPosition().y;
	if (nChar==38)
	{
		if (y>0&&layout.GetLayoutState(x/20,y/20-1)!=WALL)
		{
			hero.SetCurrentPosition(0,-20);
			x=hero.GetCurrentPosition().x;
			y=hero.GetCurrentPosition().y;
			if (layout.GetLayoutState(x/20,y/20)==ENEMY1||layout.GetLayoutState(x/20,y/20)==ENEMY2)
			{
				sndPlaySound("D://res//GAME61.WAV",SND_ASYNC);
				scoreboard.SetLife(1);
				scoreboard.CheckGameOver();
			}
			else
				if (layout.GetLayoutState(x/20,y/20)==FIRE)
				{
					gx=x;
					gy=y;
					gindex=fire.SearchFireIndex(x,y);
					SetTimer(2,1,NULL);
				}
				else
					if (layout.GetLayoutState(x/20,y/20)==APPLE)
					{
						coin.CoinEaten(x,y,HERO);
						scoreboard.SetScore(200);
						if (scoreboard.GetScore()>=scoreboard.GetlifeLevel())
						{
							scoreboard.SetlifeLevel();
							scoreboard.AddLife(1);
						}
					}
					else
						if (layout.GetLayoutState(x/20,y/20)==PEAR)
						{
							coin.CoinEaten(x,y,HERO);
							scoreboard.SetScore(300);
							if (scoreboard.GetScore()>=scoreboard.GetlifeLevel())
							{
								scoreboard.SetlifeLevel();
								scoreboard.AddLife(1);
							}
						}
						else
							if (layout.GetLayoutState(x/20,y/20)==ORANGE)
							{
								coin.CoinEaten(x,y,HERO);
								scoreboard.SetScore(400);
								if (scoreboard.GetScore()>=scoreboard.GetlifeLevel())
								{
									scoreboard.SetlifeLevel();
									scoreboard.AddLife(1);
								}
							}
					if (layout.GetLayoutState(x/20,y/20+1)==ENEMY1||layout.GetLayoutState(x/20,y/20)==ENEMY2)
					{
						layout.ChangeState(x/20,y/20,HERO);
					}
					else
					{
						layout.ChangeState(hero.GetPreviousPosition().x/20,hero.GetPreviousPosition().y/20,NONE);
						layout.ChangeState(x/20,y/20,HERO);
					}	
			}		
		}
	else
		if (nChar==40)
		{
			if (y+20<400&&layout.GetLayoutState(x/20,y/20+1)!=WALL)
			{
				hero.SetCurrentPosition(0,20);
				x=hero.GetCurrentPosition().x;
				y=hero.GetCurrentPosition().y;
				if (layout.GetLayoutState(x/20,y/20)==ENEMY1)
				{
					sndPlaySound("D://res//GAME61.WAV",SND_ASYNC);
					scoreboard.SetLife(1);
					scoreboard.CheckGameOver();
				}
				else
					if (layout.GetLayoutState(x/20,y/20)==FIRE)
					{
						gx=x;
						gy=y;
						gindex=fire.SearchFireIndex(x,y);
						SetTimer(2,1,NULL);
					}
					else
						if (layout.GetLayoutState(x/20,y/20)==APPLE)
						{
							coin.CoinEaten(x,y,HERO);
							scoreboard.SetScore(200);
							if (scoreboard.GetScore()>=scoreboard.GetlifeLevel())
							{
								scoreboard.SetlifeLevel();
								scoreboard.AddLife(1);
							}
						}
						else
							if (layout.GetLayoutState(x/20,y/20)==PEAR)
							{
								coin.CoinEaten(x,y,HERO);
								scoreboard.SetScore(300);
								if (scoreboard.GetScore()>=scoreboard.GetlifeLevel())
								{
									scoreboard.SetlifeLevel();
									scoreboard.AddLife(1);
								}
							}
							else
								if (layout.GetLayoutState(x/20,y/20)==ORANGE)
								{
									coin.CoinEaten(x,y,HERO);
									scoreboard.SetScore(400);
									if (scoreboard.GetScore()>=scoreboard.GetlifeLevel())
									{
										scoreboard.SetlifeLevel();
										scoreboard.AddLife(1);
									}
							}
						if (layout.GetLayoutState(x/20,y/20+1)==ENEMY1||layout.GetLayoutState(x/20,y/20)==ENEMY2)
						{
							layout.ChangeState(x/20,y/20,HERO);
						}
						else
						{
							layout.ChangeState(hero.GetPreviousPosition().x/20,hero.GetPreviousPosition().y/20,NONE);
							layout.ChangeState(x/20,y/20,HERO);
							}	
			}
		}
		else
			if (nChar==37)
			{
				if (x>0&&layout.GetLayoutState(x/20-1,y/20)!=WALL)
				{
					hero.SetCurrentPosition(-20,0);
					x=hero.GetCurrentPosition().x;
					y=hero.GetCurrentPosition().y;
					if (layout.GetLayoutState(x/20,y/20)==ENEMY1||layout.GetLayoutState(x/20,y/20)==ENEMY2)
					{
						sndPlaySound("D://res//GAME61.WAV",SND_ASYNC);
						scoreboard.SetLife(1);
						scoreboard.CheckGameOver();
					}
					else
						if (layout.GetLayoutState(x/20,y/20)==FIRE)
						{
							gx=x;
							gy=y;
							gindex=fire.SearchFireIndex(x,y);
							SetTimer(2,1,NULL);
						}
						else
							if (layout.GetLayoutState(x/20,y/20)==APPLE)
							{
								coin.CoinEaten(x,y,HERO);
								scoreboard.SetScore(200);
								if (scoreboard.GetScore()>=scoreboard.GetlifeLevel())
								{
									scoreboard.SetlifeLevel();
									scoreboard.AddLife(1);
								}
							}
							else
								if (layout.GetLayoutState(x/20,y/20)==PEAR)
								{
									coin.CoinEaten(x,y,HERO);
									scoreboard.SetScore(300);
									if (scoreboard.GetScore()>=scoreboard.GetlifeLevel())
									{
										scoreboard.SetlifeLevel();
										scoreboard.AddLife(1);
									}
								}
								else
									if (layout.GetLayoutState(x/20,y/20)==ORANGE)
									{
										coin.CoinEaten(x,y,HERO);
										scoreboard.SetScore(400);
										if (scoreboard.GetScore()>=scoreboard.GetlifeLevel())
										{
											scoreboard.SetlifeLevel();
											scoreboard.AddLife(1);
										}
							}
							if (layout.GetLayoutState(x/20,y/20+1)==ENEMY1||layout.GetLayoutState(x/20,y/20)==ENEMY2)
							{
								layout.ChangeState(x/20,y/20,HERO);
							}
							else
							{
								layout.ChangeState(hero.GetPreviousPosition().x/20,hero.GetPreviousPosition().y/20,NONE);
								layout.ChangeState(x/20,y/20,HERO);
							}		
				}	
			}
			else
				if(nChar==39)
				{
					if (x+20<400&&layout.GetLayoutState(x/20+1,y/20)!=WALL)
					{
						hero.SetCurrentPosition(20,0);
						x=hero.GetCurrentPosition().x;
						y=hero.GetCurrentPosition().y;
						if (layout.GetLayoutState(x/20,y/20)==ENEMY1||layout.GetLayoutState(x/20,y/20)==ENEMY2)
						{
							sndPlaySound("D://res//GAME61.WAV",SND_ASYNC);
							scoreboard.SetLife(1);
							scoreboard.CheckGameOver();
						}
						else
							if (layout.GetLayoutState(x/20,y/20)==FIRE)
							{
								gx=x;
								gy=y;
								gindex=fire.SearchFireIndex(x,y);
								SetTimer(2,1,NULL);
							}
							else
								if (layout.GetLayoutState(x/20,y/20)==APPLE)
								{
									coin.CoinEaten(x,y,HERO);
									scoreboard.SetScore(200);
									if (scoreboard.GetScore()>=scoreboard.GetlifeLevel())
									{
										scoreboard.SetlifeLevel();
										scoreboard.AddLife(1);
									}
								}
								else
									if (layout.GetLayoutState(x/20,y/20)==PEAR)
									{
										coin.CoinEaten(x,y,HERO);
										scoreboard.SetScore(300);
										if (scoreboard.GetScore()>=scoreboard.GetlifeLevel())
										{
											scoreboard.SetlifeLevel();
											scoreboard.AddLife(1);
										}
									}
									else
										if (layout.GetLayoutState(x/20,y/20)==ORANGE)
										{
											coin.CoinEaten(x,y,HERO);
											scoreboard.SetScore(400);
											if (scoreboard.GetScore()>=scoreboard.GetlifeLevel())
											{
												scoreboard.SetlifeLevel();
												scoreboard.AddLife(1);
											}
							}
								if (layout.GetLayoutState(x/20,y/20+1)==ENEMY1||layout.GetLayoutState(x/20,y/20)==ENEMY2)
								{
									layout.ChangeState(x/20,y/20,HERO);
								}
								else
								{
									layout.ChangeState(hero.GetPreviousPosition().x/20,hero.GetPreviousPosition().y/20,NONE);
									layout.ChangeState(x/20,y/20,HERO);
							}	
					}
				}
	Invalidate(TRUE);
	}
	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CGameView::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if (nIDEvent==1)
	{
		if (scoreboard.GetGameOver())
		{
			KillTimer(1);
		}
		CDC    *pDC=CDC::FromHandle(::GetDC(m_hWnd));
		if (scoreboard.GetLevel()==1)
		{
			enemy.SetOrbitOne(10);
		}
		else
			if (scoreboard.GetLevel()>1)
			{
				enemy.SetOrbitTwo(12);
			}
		enemy.DrawEnemy(pDC);
	}
	else
		if (nIDEvent==2)
		{
			KillTimer(2);
			fire.Fireout(gx,gy,gindex,m_hWnd);	
			if (fire.GetFireLeft()==0)
			{
				scoreboard.SetLevel(1);
				layout.SetMembers(clientRect);
				hero.SetMembers();
				fire.InitFirePosition();
				fire.SetMembers();
				wall.ResetState();
				wall.InitWallRect();
				enemy.InitEnemyPosition(12);
				enemy.SetMembers();
				coin.SetMembers();
				KillTimer(1);
				Start=true;
			}
		}
	
	Invalidate(TRUE);
	CView::OnTimer(nIDEvent);
}

int CGameView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	//m_Midi.Open("D://res//marioluigi_battle.mid");
	//m_Midi.Play();

	return 0;
}

void CGameView::OnDestroy() 
{
	CView::OnDestroy();
	
	// TODO: Add your message handler code here
	
}

void CGameView::OnCancelMode() 
{
	CView::OnCancelMode();
	
	// TODO: Add your message handler code here
	KillTimer(1);
	m_Midi.Stop();
}

BOOL CGameView::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default

	return true;

	return CView::OnEraseBkgnd(pDC);
}
