// Global.h: interface for the CGlobal class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GLOBAL_H__253E6BB6_8D99_4EA2_A597_AE715DE04B3F__INCLUDED_)
#define AFX_GLOBAL_H__253E6BB6_8D99_4EA2_A597_AE715DE04B3F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Layout.h"
#include "Enemy.h"
#include "Wall.h"
#include "ScoreBoard.h"
#include "Coin.h"
class CGlobal  
{
public:
	CGlobal();
	virtual ~CGlobal();

};

#endif // !defined(AFX_GLOBAL_H__253E6BB6_8D99_4EA2_A597_AE715DE04B3F__INCLUDED_)
