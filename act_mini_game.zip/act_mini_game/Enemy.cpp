// Enemy.cpp : implementation file
//

#include "stdafx.h"
#include "Game.h"
#include "Enemy.h"
#include "Layout.h"
#include "ScoreBoard.h"
#include "Mmsystem.h"
#include "Coin.h"
#include "MainDailog.h"

extern CCoin coin; 
extern CScoreBoard scoreboard;
extern Layout layout;
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
/////////////////////////////////////////////////////////////////////////////
// Enemy

IMPLEMENT_DYNCREATE(Enemy, CView)

/*Enemy::Enemy()
{
}

Enemy::~Enemy()
{
}*/


BEGIN_MESSAGE_MAP(Enemy, CView)
	//{{AFX_MSG_MAP(Enemy)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Enemy drawing

void Enemy::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// Enemy diagnostics

#ifdef _DEBUG
void Enemy::AssertValid() const
{
	CView::AssertValid();
}

void Enemy::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// Enemy message handlers

void Enemy::InitEnemyPosition(int num)
{
	int x,y;
	int type=-1;
	if (scoreboard.GetLevel()==1)
	{
		type=ENEMY1;
	}
	else
	{
		type=ENEMY2;
	}
	srand((unsigned)time(NULL));
	enemyNum=num;
	totalEnemy=num;
	for (int i=0;i<50;i++)
	{
		enemyPt[i].x=-1;
		enemyPt[i].y=-1;
		enemyEaten[i]=FALSE;
		moveDirection[i]=0;
	}

	for (i=0;i<num;i++)
	{
		do 
		{
			x=rand()%20;
			y=rand()%20;
		} while (layout.GetLayoutState(x,y));
		
		layout.ChangeState(x,y,type);
		enemyPt[i].x=layout.GetLayoutRect(x,y).left;
		enemyPt[i].y=layout.GetLayoutRect(x,y).top;
	}
}

void Enemy::DrawEnemy(CDC *pDC)
{
	CDC *mdc=new CDC;
	mdc->CreateCompatibleDC(pDC);
	for (int i=0;i<totalEnemy;i++)
	{
		if (!enemyEaten[i])
		{
			if (layout.GetLayoutState(enemyPt[i].x/20,enemyPt[i].y/20)==ENEMY2)
			{
				mdc->SelectObject(enemy2bitmap);
			}
			else
				if (layout.GetLayoutState(enemyPt[i].x/20,enemyPt[i].y/20)==ENEMY1)
				{
					mdc->SelectObject(enemy1bitmap);
				}
			TransparentBlt(pDC->m_hDC,enemyPt[i].x,enemyPt[i].y,20,20,mdc->m_hDC,0,0,20,20,RGB(255,255,255));
		}
	}
	delete mdc;
}

void Enemy::SetMembers()
{
	enemy1bitmap.m_hObject=(HBITMAP)::LoadImage(NULL,"D://res//skull.bmp",IMAGE_BITMAP,20,20,LR_LOADFROMFILE);
	enemy2bitmap.m_hObject=(HBITMAP)::LoadImage(NULL,"D://res//10.bmp",IMAGE_BITMAP,20,20,LR_LOADFROMFILE);
}  

void Enemy::SetOrbitOne(int num)
{
	srand((unsigned)time(NULL));
	int direction;
	CPoint temp;
	int opt;
	for (int index=0;index<totalEnemy;index++)
	{
		if (enemyEaten[index])
		{
			continue;
		}
		temp=enemyPt[index];
		
		direction=rand()%2;
		if (direction==XAxis)
		{
			opt=rand()%2;
			if (opt==OptAdd)
			{
				temp.x+=20;
				if (temp.x>380||layout.GetLayoutState(temp.x/20,temp.y/20)==FIRE||layout.GetLayoutState(temp.x/20,temp.y/20)==WALL||layout.GetLayoutState(temp.x/20,temp.y/20)==ENEMY1)
				{
					continue;
				}
				if (layout.GetLayoutState(temp.x/20,temp.y/20)==APPLE||layout.GetLayoutState(temp.x/20,temp.y/20)==PEAR||layout.GetLayoutState(temp.x/20,temp.y/20)==ORANGE)
				{
					coin.CoinEaten(temp.x,temp.y,ENEMY1);
				}
			}
			else
				if (opt==OptMinus)
				{
					temp.x-=20;
					if (temp.x<0||layout.GetLayoutState(temp.x/20,temp.y/20)==FIRE||layout.GetLayoutState(temp.x/20,temp.y/20)==WALL||layout.GetLayoutState(temp.x/20,temp.y/20)==ENEMY1)
					{
						continue;
					}
					if (layout.GetLayoutState(temp.x/20,temp.y/20)==APPLE||layout.GetLayoutState(temp.x/20,temp.y/20)==PEAR||layout.GetLayoutState(temp.x/20,temp.y/20)==ORANGE)
					{
						coin.CoinEaten(temp.x,temp.y,ENEMY1);
					}
				}
			}
			else
				if (direction==YAxis)
				{
					opt=rand()%2;
					if (opt==OptAdd)
					{
						temp.y+=20;
						if (temp.y>380||layout.GetLayoutState(temp.x/20,temp.y/20)==FIRE||layout.GetLayoutState(temp.x/20,temp.y/20)==WALL||layout.GetLayoutState(temp.x/20,temp.y/20)==ENEMY1)
						{
							continue;
						}
						if (layout.GetLayoutState(temp.x/20,temp.y/20)==APPLE||layout.GetLayoutState(temp.x/20,temp.y/20)==PEAR||layout.GetLayoutState(temp.x/20,temp.y/20)==ORANGE)
						{
							coin.CoinEaten(temp.x,temp.y,ENEMY1);
						}
					}
					else
						if (opt==OptMinus)
						{
							temp.y-=20;
							if (temp.y<0||layout.GetLayoutState(temp.x/20,temp.y/20)==FIRE||layout.GetLayoutState(temp.x/20,temp.y/20)==WALL||layout.GetLayoutState(temp.x/20,temp.y/20)==ENEMY1)
							{
								continue;
							}
							if (layout.GetLayoutState(temp.x/20,temp.y/20)==APPLE||layout.GetLayoutState(temp.x/20,temp.y/20)==PEAR||layout.GetLayoutState(temp.x/20,temp.y/20)==ORANGE)
							{
								coin.CoinEaten(temp.x,temp.y,ENEMY1);
							}
						}
				}
				if (layout.GetLayoutState(temp.x/20,temp.y/20)==HERO)
				{
					sndPlaySound("D://res//GAME61.WAV",SND_ASYNC);
					scoreboard.SetLife(1);
					scoreboard.CheckGameOver();
				}
				else
					if(layout.GetLayoutState(temp.x/20,temp.y/20)==FIREORBIT)
					{
						enemyEaten[index]=true;
						if(layout.GetLayoutState(enemyPt[index].x/20,enemyPt[index].y/20==ENEMY1))
							scoreboard.SetScore(100);
						else
							scoreboard.SetScore(50);
						if (scoreboard.GetScore()>=scoreboard.GetlifeLevel())
						{
							scoreboard.SetlifeLevel();
							scoreboard.AddLife(1);
						}
						enemyNum--;
						coin.RandomCoins();
						sndPlaySound("D://res//Game1.WAV",SND_ASYNC);
						continue;
					}
		layout.ChangeState(enemyPt[index].x/20,enemyPt[index].y/20,NONE);
		enemyPt[index]=temp;
		layout.ChangeState(enemyPt[index].x/20,enemyPt[index].y/20,ENEMY1);
	}
}

void Enemy::ChangeEatenState( int i,BOOL state )
{
	enemyEaten[i]=state; 
}

int Enemy::SearchFireIndex( int x,int y )
{
	for (int i=0;i<12;i++)
	{
		if (enemyPt[i].x==x&&enemyPt[i].y==y)
		{
			enemyPt[i]=TRUE;
			return i;
		}
	}
	return -1;	
}

void Enemy::SetOrbitTwo(int num)
{
	CPoint temp;
	int state1=-1;
	int state2=-1;
	int state=-1;
	for (int index=0;index<num;index++)
	{
		if (enemyEaten[index])
		{
			continue;
		}
		temp=enemyPt[index];
		
		temp.x-=20;
		state=layout.GetLayoutState(temp.x/20,temp.y/20);
		if (state==WALL||state==ENEMY1||state==FIRE||temp.x<0)
		{
			if (temp.x<0)
			{
				temp.x=380;

			}
			else
			{
				temp.x+=20;
				if (temp.y>=380)
				{
					temp.y=0;
					state=layout.GetLayoutState(temp.x/20,temp.y/20);
					while (state==WALL||state==ENEMY1||state==FIRE)
					{
						temp.x+=20;
						state=layout.GetLayoutState(temp.x/20,temp.y/20);
					}
				}
				else
				{
					temp.y+=20;
				}
			}	
			state=layout.GetLayoutState(temp.x/20,temp.y/20);
			while (state==WALL||state==ENEMY1||state==FIRE)
			{
				temp.y+=20;
				state=layout.GetLayoutState(temp.x/20,temp.y/20);
			}
		}

		
		state=layout.GetLayoutState(temp.x/20,temp.y/20);
		if (state==HERO)
		{
			sndPlaySound("D://res//GAME61.WAV",SND_ASYNC);
			scoreboard.SetLife(1);
			scoreboard.CheckGameOver();	
		}
		if (state==APPLE||state==PEAR||state==ORANGE)
		{
			coin.CoinEaten(temp.x,temp.y,ENEMY2);
		}
		if(layout.GetLayoutState(temp.x/20,temp.y/20)==FIREORBIT)
		{
			enemyEaten[index]=true;
			if(layout.GetLayoutState(enemyPt[index].x/20,enemyPt[index].y/20==ENEMY1))
				scoreboard.SetScore(100);
			else
				scoreboard.SetScore(50);
			if (scoreboard.GetScore()>=scoreboard.GetlifeLevel())
			{
				scoreboard.SetlifeLevel();
				scoreboard.AddLife(1);
			}
			enemyNum--;
			coin.RandomCoins();
			sndPlaySound("D://res//Game1.WAV",SND_ASYNC);
			continue;
		}
		layout.ChangeState(enemyPt[index].x/20,enemyPt[index].y/20,NONE);
		enemyPt[index]=temp;
		layout.ChangeState(enemyPt[index].x/20,enemyPt[index].y/20,ENEMY2);
	}



		/*	if (moveDirection[index]==0)
		{
			state1=layout.GetLayoutState(temp.x/20-1,temp.y/20);
			state2=layout.GetLayoutState(temp.x/20,temp.y/20+1);
			if (state1==WALL||state1==ENEMY1||state1==FIRE||temp.x<20)
			{
				if (state2==WALL||state2==ENEMY1||state2==FIRE||temp.y>360)
				{
					moveDirection[index]=1;
				}
				else
				{
					moveDirection[index]=2;
				}
			}
			else
			{
				moveDirection[index]=2;
			}
		}
	

		if (moveDirection[index]==2)
		{
			temp.x-=20;
			state=layout.GetLayoutState(temp.x/20,temp.y/20);
			if (state==WALL||state==ENEMY1||state==FIRE||temp.x<20)
			{
				temp.x+=20;
				temp.y+=20;
				state=layout.GetLayoutState(temp.x/20,temp.y/20);
				if (state==WALL||state==ENEMY1||state==FIRE||temp.y>360)
				{
					temp.y-=20;
					moveDirection[index]=1;
				}
			}
		}
		else
			if (moveDirection[index]==1)
			{
				temp.x+=20;
				state=layout.GetLayoutState(temp.x/20,temp.y/20);
				if (state==WALL||state==ENEMY1||state==FIRE||temp.x>360)
				{
					temp.x-=20;
					temp.y-=20;
					state=layout.GetLayoutState(temp.x/20,temp.y/20);
					if (state==WALL||state==ENEMY1||state==FIRE||temp.y<20)
					{
						temp.y+=20;
						moveDirection[index]=2;
					}
				}
			}

		if (state==HERO)
		{
			sndPlaySound("D://res//GAME61.WAV",SND_ASYNC);
			scoreboard.SetLife(1);
			scoreboard.CheckGameOver();	
		}
		if (state==APPLE||state==PEAR||state==ORANGE)
		{
			coin.CoinEaten(temp.x,temp.y,ENEMY2);
		}
		layout.ChangeState(enemyPt[index].x/20,enemyPt[index].y/20,NONE);
		enemyPt[index]=temp;
		layout.ChangeState(enemyPt[index].x/20,enemyPt[index].y/20,ENEMY2);*/
}
