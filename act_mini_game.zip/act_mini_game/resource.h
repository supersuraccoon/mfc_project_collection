//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Game.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_GAMETYPE                    129
#define IDB_HERO                        130
#define IDB_ENEMY                       131
#define IDB_FIRE                        133
#define IDB_BITMAP1                     137
#define IDD_MAINDIALOGUE                139
#define IDC_EDIT1                       1000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        140
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
