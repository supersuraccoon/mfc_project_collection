// DrawView.cpp : implementation of the CDrawView class
//

#include "stdafx.h"
#include "Draw.h"
#include "Layout.h"

#include "DrawDoc.h"
#include "DrawView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDrawView

IMPLEMENT_DYNCREATE(CDrawView, CView)

BEGIN_MESSAGE_MAP(CDrawView, CView)
	//{{AFX_MSG_MAP(CDrawView)
	ON_WM_CREATE()
	ON_WM_CHAR()
	ON_WM_KEYDOWN()
	ON_WM_TIMER()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDrawView construction/destruction

CDrawView::CDrawView()
{
	// TODO: add construction code here
	srand( (unsigned)time( NULL ) );
	for (int i=0;i<20;i++)
	{
		int Xval=0+rand()%800;
		int Yval=0+rand()%800;
		movePt[i].x=Xval;
		movePt[i].y=Yval;
	}
	firePt.x=300;
	firePt.y=300;
	bitmap.LoadBitmap(IDB_BALL);
	bkbitmap.LoadBitmap(IDB_BKBALL);
	firebitmap.LoadBitmap(IDB_FIRE);
	Start=TRUE;
}

CDrawView::~CDrawView()
{
}

BOOL CDrawView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CDrawView drawing

void CDrawView::OnDraw(CDC* pDC)
{
	CDrawDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
	DrawBall(pDC,gPt);
	if (Start)
	{
		SetTimer(1,200,NULL);
		Start=FALSE;
	}
	DrawBKBall(pDC,movePt);
}

/////////////////////////////////////////////////////////////////////////////
// CDrawView printing

BOOL CDrawView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CDrawView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CDrawView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CDrawView diagnostics

#ifdef _DEBUG
void CDrawView::AssertValid() const
{
	CView::AssertValid();
}

void CDrawView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CDrawDoc* CDrawView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDrawDoc)));
	return (CDrawDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDrawView message handlers

void CDrawView::DrawBall(CDC* pDC,CPoint pt)
{
	BITMAP hBMP;
	bitmap.GetObject(sizeof(BITMAP),&hBMP);
	CDC menDC;
	menDC.CreateCompatibleDC(pDC);
	menDC.SelectObject(&bitmap);
	BallRadius=hBMP.bmWidth;
	pDC->BitBlt(pt.x,pt.y,hBMP.bmWidth,hBMP.bmHeight,&menDC,0,0,SRCCOPY);
	firebitmap.GetObject(sizeof(BITMAP),&hBMP);
	menDC.SelectObject(&firebitmap);
	pDC->BitBlt(firePt.x,firePt.y,hBMP.bmWidth,hBMP.bmHeight,&menDC,0,0,SRCCOPY);
	menDC.DeleteDC();
	//if(CheckResult())
//	{
	//	MessageBox("Game Over!!!");
//	}
}

int CDrawView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	gPt.x=100;
	gPt.y=100;

	GetClientRect(&clientRect);
	layout.SetMembers(clientRect);
	
	return 0;
}

void CDrawView::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	
	
	CView::OnChar(nChar, nRepCnt, nFlags);
}

void CDrawView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	if (nChar==38)
	{
		gPt.y-=10;
	}
	else
		if (nChar==40)
		{
			gPt.y+=10;
		}
		else
			if (nChar==37)
			{
				gPt.x-=10;
			}
			else
				if(nChar==39)
				{
					gPt.x+=10;
				}
	
	Invalidate(TRUE);

	if (CheckFire())
	{
		Fire();
	}

	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CDrawView::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	for (int i=0;i<20;i++)
	{
		int Xval=5+rand()%10;
		int Yval=5+rand()%10;
		movePt[i].x+=Xval;
		movePt[i].y-=Yval;
		if (movePt[i].x>clientRect.right)
		{
			movePt[i].x=5+rand()%700;
		}
		if (movePt[i].y<clientRect.top)
		{
			movePt[i].y=5+rand()%700;
		}
	}
	Invalidate(TRUE);
	
	
	CView::OnTimer(nIDEvent);
}

void CDrawView::OnDestroy() 
{
	CView::OnDestroy();
	
	// TODO: Add your message handler code here
	KillTimer(1);
}

void CDrawView::DrawBKBall(CDC *pDC, CPoint[])
{
	BITMAP hBMP;
	bkbitmap.GetObject(sizeof(BITMAP),&hBMP);
	CDC menDC;
	menDC.CreateCompatibleDC(pDC);
	menDC.SelectObject(&bkbitmap);
	for (int i=0;i<20;i++)
	{
		pDC->BitBlt(movePt[i].x,movePt[i].y,hBMP.bmWidth,hBMP.bmHeight,&menDC,0,0,SRCCOPY);
		//if(CheckResult())
		//{
		//	MessageBox("Game Over!!!");
		//}		
	}
	menDC.DeleteDC();

}

BOOL CDrawView::CheckResult()
{
	CPoint pt(gPt.x+10,gPt.y+10);
	CPoint temp;
	CRect rect(gPt,pt);
	for (int i=0;i<20;i++)
	{
		temp=movePt[i];
		temp.Offset(5,5);
		if (rect.PtInRect(temp))
		{
			return TRUE;
		}
	}
	return FALSE;
}

BOOL CDrawView::CheckFire()
{
	CRect rect(firePt.x,firePt.y,firePt.x+10,firePt.y+10);
	if (rect.PtInRect(gPt))
	{
		return true;
	}
	return FALSE;
}

void CDrawView::Fire()
{
	int x=firePt.x;
	int y=firePt.y;
	BITMAP hBMP;
	CDC    *pDC=CDC::FromHandle(::GetDC(m_hWnd));
	firebitmap.GetObject(sizeof(BITMAP),&hBMP);
	CDC menDC;
	menDC.CreateCompatibleDC(pDC);
	menDC.SelectObject(&firebitmap);
	for (;;)
	{
		x-=10;
		pDC->BitBlt(x,y,hBMP.bmWidth,hBMP.bmHeight,&menDC,0,0,SRCCOPY);
		if (x<clientRect.left)
		{
			break;
		}
		for (int i=0;i<1000000/2;i++)
		{
		}
	}
	x=firePt.x;
	y=firePt.y;
	for (;;)
	{
		x+=10;
		pDC->BitBlt(x,y,hBMP.bmWidth,hBMP.bmHeight,&menDC,0,0,SRCCOPY);
		if (x>clientRect.right)
		{
			break;
		}
		for (int i=0;i<1000000/2;i++)
		{
		}
	}
	x=firePt.x;
	y=firePt.y;
	for (;;)
	{
		y-=10;
		pDC->BitBlt(x,y,hBMP.bmWidth,hBMP.bmHeight,&menDC,0,0,SRCCOPY);
		if (y<clientRect.top)
		{
			break;
		}
		Sleep(3);
	}
	x=firePt.x;
	y=firePt.y;
	for (;;)
	{
		y+=10;
		pDC->BitBlt(x,y,hBMP.bmWidth,hBMP.bmHeight,&menDC,0,0,SRCCOPY);
		if (y>clientRect.bottom)
		{
			break;
		}
		Sleep(3);
	}
}
