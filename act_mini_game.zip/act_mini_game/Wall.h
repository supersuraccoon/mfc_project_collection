#if !defined(AFX_WALL_H__5A7009FC_8FFB_4271_A946_8D3757B13D41__INCLUDED_)
#define AFX_WALL_H__5A7009FC_8FFB_4271_A946_8D3757B13D41__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Wall.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// Wall view

class Wall : public CView
{
protected:
	//Wall();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(Wall)

// Attributes
public:

// Operations
public:
	Wall(); 
	void ResetState(void);
	void DrawWall(CDC *pDC,HWND hwnd);
	void InitWallRect(void);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(Wall)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	//virtual ~Wall();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(Wall)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CBitmap wallBitmap;
	CPoint wallPt[20];
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WALL_H__5A7009FC_8FFB_4271_A946_8D3757B13D41__INCLUDED_)
