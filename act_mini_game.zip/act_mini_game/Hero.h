#if !defined(AFX_HERO_H__F586D33D_86E7_4490_9AC1_157F5949004A__INCLUDED_)
#define AFX_HERO_H__F586D33D_86E7_4490_9AC1_157F5949004A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Hero.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// Hero view

class Hero : public CView
{
protected:
	//Hero();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(Hero)

// Attributes
public:

// Operations
public:
	Hero();
	CPoint GetCurrentPosition(void);
	CPoint GetPreviousPosition(void);
	void SetMembers(void);
	void SetCurrentPosition(int x,int y);
	void DrawHero(CDC *pDC);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(Hero)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
//	virtual ~Hero();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(Hero)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CPoint currentPt;
	CPoint previousPt;
	CSize size;
	CRect currentRect;
	CBitmap heroBitmap;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HERO_H__F586D33D_86E7_4490_9AC1_157F5949004A__INCLUDED_)
