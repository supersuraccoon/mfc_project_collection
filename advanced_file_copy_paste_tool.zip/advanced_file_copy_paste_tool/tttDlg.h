// tttDlg.h : header file
//

#if !defined(AFX_TTTDLG_H__D00ECAF8_AF63_423F_9C87_E39B2E1344CF__INCLUDED_)
#define AFX_TTTDLG_H__D00ECAF8_AF63_423F_9C87_E39B2E1344CF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CTttDlg dialog

class CTttDlg : public CDialog
{
// Construction
public:
	bool FileToClipboard(char str[],int length);
	void AddListImage(CString str[]);
	void CopyFileNames( HDROP hDrop );
	CTttDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CTttDlg)
	enum { IDD = IDD_TTT_DIALOG };
	CListCtrl	m_list;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTttDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	int m_nEdgeSnapGap;
	HICON m_hIcon;
	CImageList m_ImageList;

	// Generated message map functions
	//{{AFX_MSG(CTttDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnChangeCbChain(HWND hWndRemove, HWND hWndAfter);
	afx_msg void OnDrawClipboard();
	afx_msg void OnWindowPosChanging(WINDOWPOS FAR* lpwndpos);
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TTTDLG_H__D00ECAF8_AF63_423F_9C87_E39B2E1344CF__INCLUDED_)
