// ClockDlg.h : header file
//

#if !defined(AFX_CLOCKDLG_H__DB41A83A_66D0_49E2_AD21_48A089EAFB50__INCLUDED_)
#define AFX_CLOCKDLG_H__DB41A83A_66D0_49E2_AD21_48A089EAFB50__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CClockDlg dialog

class CClockDlg : public CDialog
{
// Construction
public:
	void Display(void);
	void MyShutdown(void);
	CClockDlg(CWnd* pParent = NULL);	// standard constructor
	int m_nEdgeSnapGap;
	CString shutdown;
	CString alarm;

	BOOL m_bExpand;
	UINT m_nExpandedWidth,m_nNormalWidth;

	BOOL fResult;
	TOKEN_PRIVILEGES tkp;
	HANDLE hToken;

// Dialog Data
	//{{AFX_DATA(CClockDlg)
	enum { IDD = IDD_CLOCK_DIALOG };
	CButton	m_Radio1;
	CComboBox	m_min2;
	CComboBox	m_hour2;
	CButton	m_Radio;
	CComboBox	m_min;
	CComboBox	m_hour;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CClockDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CClockDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnSetfocusEdit1();
	afx_msg void OnClose();
	afx_msg void OnWindowPosChanging(WINDOWPOS FAR* lpwndpos);
	afx_msg void OnRadio1();
	afx_msg void OnRadio2();
	afx_msg void OnButton1();
	afx_msg void OnRadio4();
	afx_msg void OnRadio3();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLOCKDLG_H__DB41A83A_66D0_49E2_AD21_48A089EAFB50__INCLUDED_)
