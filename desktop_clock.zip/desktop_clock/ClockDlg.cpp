// ClockDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Clock.h"
#include "ClockDlg.h"
#include "SkinPPWTL.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


bool lock=true;
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClockDlg dialog

CClockDlg::CClockDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CClockDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CClockDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_nEdgeSnapGap=10;
	shutdown="";
	alarm="";
	m_bExpand=false;
}

void CClockDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CClockDlg)
	DDX_Control(pDX, IDC_RADIO3, m_Radio1);
	DDX_Control(pDX, IDC_MIN2, m_min2);
	DDX_Control(pDX, IDC_HOUR2, m_hour2);
	DDX_Control(pDX, IDC_RADIO1, m_Radio);
	DDX_Control(pDX, IDC_MIN, m_min);
	DDX_Control(pDX, IDC_HOUR, m_hour);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CClockDlg, CDialog)
	//{{AFX_MSG_MAP(CClockDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_TIMER()
	ON_EN_SETFOCUS(IDC_EDIT1, OnSetfocusEdit1)
	ON_WM_CLOSE()
	ON_WM_WINDOWPOSCHANGING()
	ON_BN_CLICKED(IDC_RADIO1, OnRadio1)
	ON_BN_CLICKED(IDC_RADIO2, OnRadio2)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_RADIO4, OnRadio4)
	ON_BN_CLICKED(IDC_RADIO3, OnRadio3)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClockDlg message handlers

BOOL CClockDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	SetFocus();

	::SetWindowPos(this->GetSafeHwnd(),HWND_TOPMOST,0,0,0,0,SWP_NOSIZE|SWP_NOMOVE);

	m_bExpand=FALSE;
	CRect rcDlg, rcMarker;
	GetWindowRect(rcDlg);
	m_nExpandedWidth = rcDlg.Width();
	GetDlgItem(IDC_BORDER)->GetWindowRect(rcMarker);

	m_nNormalWidth = (rcMarker.left - rcDlg.left);
	Display();

	//chour=m_hour.GetDlgItem(IDC_HOUR);
	//cmin=m_min.GetDlgItem(IDC_MIN);

	////////////����24Сʱ///////////////////
	for(int i=0;i<=23;i++)         
	{
		CString s;
		s.Format("%d",i);
		m_hour.AddString(s);
		m_hour2.AddString(s);
	}
	/////////////����60����////////////////
	for(i=0;i<=59;i++)
	{
		CString s;
		s.Format("%d",i);
		m_min.AddString(s);
		m_min2.AddString(s);
	}
	GetDlgItem(IDC_HOUR)->EnableWindow(FALSE);
	GetDlgItem(IDC_MIN)->EnableWindow(FALSE);

	GetDlgItem(IDC_HOUR2)->EnableWindow(FALSE);
	GetDlgItem(IDC_MIN2)->EnableWindow(FALSE);

	((CButton*)GetDlgItem(IDC_RADIO3))->SetCheck(TRUE);

	
	CString hour;
	CString minute;
	CString second;
	CString time=""; 
	CTime t = CTime::GetCurrentTime();
	hour.Format("%d",t.GetHour());
	minute.Format("%d",t.GetMinute());
	second.Format("%d",t.GetSecond());
	
	time+=hour;
	time+="��";
	time+=minute;
	time+="��";
	time+=second;
	time+="��";
	SetDlgItemText(IDC_EDIT1,time);
	
	SetTimer(1,1000,NULL);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CClockDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CClockDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CClockDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CClockDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default

	CString compareTime;
	CString hour;
	CString minute;
	CString second;
	CString time=""; 
	CTime t = CTime::GetCurrentTime();
	hour.Format("%d",t.GetHour());
	minute.Format("%d",t.GetMinute());
	second.Format("%d",t.GetSecond());

	compareTime=hour+"��"+minute+"��";

	if(compareTime==shutdown)
	{
		MyShutdown();
	}
	
	time+=hour;
	time+="��";
	time+=minute;
	time+="��";
	time+=second;
	time+="��";
	SetDlgItemText(IDC_EDIT1,time);
	UpdateWindow();
	CDialog::OnTimer(nIDEvent);
}

void CClockDlg::OnSetfocusEdit1() 
{
	// TODO: Add your control notification handler code here
	PostMessage(WM_KILLFOCUS);
	
}

void CClockDlg::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	//skinppExitSkin();
	
	KillTimer(1);
	CDialog::OnClose();
}

void CClockDlg::OnWindowPosChanging(WINDOWPOS FAR* lpwndpos) 
{
	CDialog::OnWindowPosChanging(lpwndpos);
	
	// TODO: Add your message handler code here
	RECT rcScrn;
	SystemParametersInfo (SPI_GETWORKAREA, 0, &rcScrn, 0);

	// Snap X axis
	if (abs(lpwndpos->x - rcScrn.left) <= m_nEdgeSnapGap)
		lpwndpos->x = rcScrn.left;
	else if (abs(lpwndpos->x + lpwndpos->cx - rcScrn.right) <= m_nEdgeSnapGap)
	lpwndpos->x = rcScrn.right - lpwndpos->cx;

	// Snap Y axis
	if (abs(lpwndpos->y - rcScrn.top) <= m_nEdgeSnapGap)
		lpwndpos->y = rcScrn.top;
	else if (abs(lpwndpos->y + lpwndpos->cy - rcScrn.bottom) <= m_nEdgeSnapGap)
		lpwndpos->y = rcScrn.bottom - lpwndpos->cy;
	
}

void CClockDlg::MyShutdown()
{
	
	//KillTimer(10);
	
	if (!OpenProcessToken(GetCurrentProcess(),
		TOKEN_ADJUST_PRIVILEGES|TOKEN_QUERY, &hToken)) 
		MessageBox("OpenProcessToken failed!");

	//��ñ��ػ�Ψһ�ı�ʶ
	LookupPrivilegeValue(NULL,SE_SHUTDOWN_NAME,&tkp.Privileges[0].Luid); 
	tkp.PrivilegeCount = 1;  
	tkp.Privileges[0].Attributes=SE_PRIVILEGE_ENABLED; 
	 //������õ�Ȩ��
	AdjustTokenPrivileges(hToken,FALSE,&tkp,0,(PTOKEN_PRIVILEGES)NULL,0);
    
	if (GetLastError()!=ERROR_SUCCESS) 
		MessageBox("AdjustTokenPrivileges enable failed!");
	
	fResult =InitiateSystemShutdown( 
		NULL,// Ҫ�صļ�����û���
		"����ϵͳ���ȶ���WINDOWS���������ʱ���ڹػ��������ñ��湤��!",//��ʾ����Ϣ
		10,// �ػ������ʱ��
		TRUE,// ask user to close apps 
		TRUE);//��ΪTRUEΪ������ΪFALSEΪ�ػ�
	if(!fResult) 
		MessageBox("InitiateSystemShutdown failed."); 
	
	tkp.Privileges[0].Attributes=0; 
	AdjustTokenPrivileges(hToken,FALSE,&tkp,0,(PTOKEN_PRIVILEGES)NULL,0); 
	
	if (GetLastError()!=ERROR_SUCCESS)
		MessageBox("AdjustTokenPrivileges disable failed."); 
	
	ExitWindowsEx(EWX_SHUTDOWN,0);
}

void CClockDlg::OnRadio1() 
{
	// TODO: Add your control notification handler code here
	shutdown="";
	GetDlgItem(IDC_HOUR)->EnableWindow(FALSE);
	GetDlgItem(IDC_MIN)->EnableWindow(FALSE);

	((CButton*)GetDlgItem(IDC_RADIO2))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_RADIO1))->SetCheck(TRUE);
}

void CClockDlg::OnRadio2() 
{
	// TODO: Add your control notification handler code here
	GetDlgItem(IDC_HOUR)->EnableWindow(TRUE);
	GetDlgItem(IDC_MIN)->EnableWindow(TRUE);

	CString hour;
	GetDlgItemText(IDC_HOUR,hour);
	CString min;
	GetDlgItemText(IDC_MIN,min);
	shutdown=hour+"��"+min+"��";
	

	((CButton*)GetDlgItem(IDC_RADIO1))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_RADIO2))->SetCheck(TRUE);
}


void CClockDlg::Display()
{
	CRect rcDlg;

	GetWindowRect(rcDlg);

	if (m_bExpand)
	{
		rcDlg.SetRect(rcDlg.left,rcDlg.top,rcDlg.left+m_nExpandedWidth,rcDlg.bottom);
	}
	else
	{
		rcDlg.SetRect(rcDlg.left,rcDlg.top,rcDlg.left+m_nNormalWidth,rcDlg.bottom);
	}

	MoveWindow(rcDlg, TRUE);
}

void CClockDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	if(!m_bExpand)
		m_bExpand=true;
	else
		m_bExpand=false;
	Display();
}

void CClockDlg::OnRadio4() 
{
	// TODO: Add your control notification handler code here
	GetDlgItem(IDC_HOUR2)->EnableWindow(TRUE);
	GetDlgItem(IDC_MIN2)->EnableWindow(TRUE);

	CString hour;
	GetDlgItemText(IDC_HOUR2,hour);
	CString min;
	GetDlgItemText(IDC_MIN2,min);
	alarm=hour+"��"+min+"��";
	

	((CButton*)GetDlgItem(IDC_RADIO3))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_RADIO4))->SetCheck(TRUE);
}

void CClockDlg::OnRadio3() 
{
	// TODO: Add your control notification handler code here
	alarm="";
	GetDlgItem(IDC_HOUR2)->EnableWindow(FALSE);
	GetDlgItem(IDC_MIN2)->EnableWindow(FALSE);

	((CButton*)GetDlgItem(IDC_RADIO4))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_RADIO3))->SetCheck(TRUE);
}

