// EditDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WPS.h"
#include "EditDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEditDlg dialog


CEditDlg::CEditDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEditDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEditDlg)
	//}}AFX_DATA_INIT
}


void CEditDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEditDlg)
	DDX_Control(pDX, IDC_EDIT1, m_add);
	DDX_Control(pDX, IDC_LIST1, m_list);
	DDX_Control(pDX, IDC_COMBO1, m_edit);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CEditDlg, CDialog)
	//{{AFX_MSG_MAP(CEditDlg)
	ON_CBN_CLOSEUP(IDC_COMBO1, OnCloseupCombo1)
	ON_BN_CLICKED(IDC_ADD, OnAdd)
	ON_BN_CLICKED(IDC_DELETE, OnDelete)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditDlg message handlers

BOOL CEditDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CString sql;
	char WpsType[100];
	CWPSApp* pApp=(CWPSApp*)AfxGetApp();  
	DBpath=pApp->DBPath;
	
	m_MyDB = new CAccessDB(DBpath.GetBuffer(MAX_PATH),DBpath.GetBuffer(MAX_PATH),0);
	DBpath.ReleaseBuffer();
	
	if(!m_MyDB->OpenDB(DBpath.GetBuffer(MAX_PATH)))
	{
		AfxMessageBox("DB Open Error!");
		DBpath.ReleaseBuffer();
		return FALSE;
	}
	
	DBpath.ReleaseBuffer();
	
	m_edit.SetCurSel(0);
	sql="select * from WPSNoType";
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return false;
	int iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	if(!iRowCount)
		return false;
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,WpsType);
		m_list.AddString(WpsType);
	}
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CEditDlg::OnCloseupCombo1() 
{
	// TODO: Add your control notification handler code here
	CString str;
	CString sql="select * from ";
	char temp[100];
	m_edit.GetLBText(m_edit.GetCurSel(),str);

	m_list.ResetContent();
	
	sql+=str;
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	int iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,temp);
		m_list.AddString(temp);
	}
}

void CEditDlg::OnAdd() 
{
	// TODO: Add your control notification handler code here
	CString str;
	CString sql;
	CString value;
	CString temp;
	m_edit.GetLBText(m_edit.GetCurSel(),str);
	GetDlgItemText(IDC_EDIT1,value);

	if (value=="")
	{
		return ;
	}

	for (int i=0;i<m_list.GetCount();i++)
	{
		m_list.GetText(i,temp);
		if (value==temp)
		{
			MessageBox("The value is already in!!!");
			return ;
		}
	}
	
	sql.Format("INSERT INTO %s Values('%s')",str,value);
	if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
		return ;
	m_list.AddString(value);
	m_list.Invalidate(true);
}

void CEditDlg::OnDelete() 
{
	// TODO: Add your control notification handler code here
	CString sql;
	CString str;
	CString table;

	m_edit.GetLBText(m_edit.GetCurSel(),table);
	m_list.GetText(m_list.GetCurSel(),str);

	sql.Format("DELETE * From %s where %s='%s'",table,table,str);
	if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
		return ;

	m_list.DeleteString(m_list.GetCurSel());
	m_list.Invalidate(TRUE);

}
