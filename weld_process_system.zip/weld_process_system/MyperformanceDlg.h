#if !defined(AFX_MYPERFORMANCEDLG_H__92CB6D12_FBDF_40CA_BDB6_DD7E123BD8B0__INCLUDED_)
#define AFX_MYPERFORMANCEDLG_H__92CB6D12_FBDF_40CA_BDB6_DD7E123BD8B0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MyperformanceDlg.h : header file
//
#include "AccessDB.h"
/////////////////////////////////////////////////////////////////////////////
// CMyperformanceDlg dialog

class CMyperformanceDlg : public CDialog
{
// Construction
public:
	CMyperformanceDlg(CWnd* pParent = NULL);   // standard constructor
	CAccessDB * m_MyDB;
	CString DBpath;

// Dialog Data
	//{{AFX_DATA(CMyperformanceDlg)
	enum { IDD = IDD_MYPERFORMANCE };
	CComboBox	m_welder;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyperformanceDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMyperformanceDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnCloseupCombo1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYPERFORMANCEDLG_H__92CB6D12_FBDF_40CA_BDB6_DD7E123BD8B0__INCLUDED_)
