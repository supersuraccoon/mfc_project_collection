// MyperformanceDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WPS.h"
#include "MyperformanceDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyperformanceDlg dialog


CMyperformanceDlg::CMyperformanceDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMyperformanceDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMyperformanceDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CMyperformanceDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyperformanceDlg)
	DDX_Control(pDX, IDC_COMBO1, m_welder);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMyperformanceDlg, CDialog)
	//{{AFX_MSG_MAP(CMyperformanceDlg)
	ON_CBN_CLOSEUP(IDC_COMBO1, OnCloseupCombo1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyperformanceDlg message handlers

BOOL CMyperformanceDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra 
	CWPSApp* pApp=(CWPSApp*)AfxGetApp();  
	CString sql="select * From Welder";
	char welder[100];

	DBpath=pApp->DBPath;
	
	m_MyDB = new CAccessDB(DBpath.GetBuffer(MAX_PATH),DBpath.GetBuffer(MAX_PATH),0);
	DBpath.ReleaseBuffer();
	
	if(!m_MyDB->OpenDB(DBpath.GetBuffer(MAX_PATH)))
	{
		AfxMessageBox("DB Open Error!");
		DBpath.ReleaseBuffer();
		return FALSE;
	}
	
	DBpath.ReleaseBuffer();

	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return false;
	int iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	if(iRowCount<=-1)
		iRowCount=0;
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,welder);
		m_welder.AddString(welder);
	}
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CMyperformanceDlg::OnCloseupCombo1() 
{
	// TODO: Add your control notification handler code here
	CString welder;
	CString sql;
	CString temp;

	char WeldNo[100];
	char WeldLength[100];

	double STL=0;
	double SDL=0;
	double SR=100;
	double PTL=0;
	double PDL=0;
	double PR=100;

	m_welder.GetLBText(m_welder.GetCurSel(),welder);

	sql.Format("Select * From Structure Where WelderNo='%s'",welder);
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	int iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	if(iRowCount<=-1)
		iRowCount=0;
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,4,WeldNo);
		m_MyDB->GetDataSetFieldValue(i,11,WeldLength);

		STL+=atof(WeldLength);
		temp=WeldNo;
		int i=temp.GetLength()-2;
		if(temp.GetAt(i)=='R')
		{
			SDL+=atof(WeldLength);
		}
	}
	SR=SDL/STL*100;

	sql.Format("Select * From Piping Where WelderNo='%s'",welder);
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	if(iRowCount<=-1)
		iRowCount=0;
	
	for(i=0;i<iRowCount;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,4,WeldNo);
		m_MyDB->GetDataSetFieldValue(i,10,WeldLength);
		
		PTL+=atof(WeldLength);
		temp=WeldNo;
		int i=temp.GetLength()-2;
		if(temp.GetAt(i)=='R')
		{
			PDL+=atof(WeldLength);
		}
	}
	PR=PDL/PTL*100;

	temp.Format("%f",STL);
	SetDlgItemText(IDC_EDIT2,temp);
	temp.Format("%f",SDL);
	SetDlgItemText(IDC_EDIT3,temp);
	temp.Format("%f",SR);
	SetDlgItemText(IDC_EDIT4,temp);
	temp.Format("%f",PTL);
	SetDlgItemText(IDC_EDIT5,temp);
	temp.Format("%f",PTL);
	SetDlgItemText(IDC_EDIT6,temp);
	temp.Format("%f",PTL);
	SetDlgItemText(IDC_EDIT7,temp);

	temp.Format("%f",STL+PTL);
	SetDlgItemText(IDC_EDIT1,temp);
}
