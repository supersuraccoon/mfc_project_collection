#if !defined(AFX_ADVANCEDSETTINGDLG_H__4F863ED8_03F0_47FA_9ED1_A80F527261C0__INCLUDED_)
#define AFX_ADVANCEDSETTINGDLG_H__4F863ED8_03F0_47FA_9ED1_A80F527261C0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AdvancedSettingDlg.h : header file
//

#include "AccessDB.h"
/////////////////////////////////////////////////////////////////////////////
// CAdvancedSettingDlg dialog

class CAdvancedSettingDlg : public CDialog
{
// Construction
public:
	void InitCombo();
	CAdvancedSettingDlg(CWnd* pParent = NULL);   // standard constructor

	CString WPSNo;
	CString WeldNo;
	CString WeldType;
	CString Status;
	CString WeldLength;
	CString Material;
	CString Block;
	CString Erection;
	CString NDT;
	CString SWeldDate;
	CString EWeldDate;
	CString inCategory;
	CString DrawNo;
	CString Total;

	CString CurPage;
	CString TotalPage;

	CAccessDB *m_MyDB;
	CString DBpath;

// Dialog Data
	//{{AFX_DATA(CAdvancedSettingDlg)
	enum { IDD = IDD_ADVANCEDSETTING };
	CEdit	m_total;
	CComboBox	m_eretion;
	CComboBox	m_block;
	CComboBox	m_incategory;
	CComboBox	m_ndt;
	CComboBox	m_material;
	CComboBox	m_weldlength;
	CComboBox	m_statu;
	CComboBox	m_weldtype;
	CComboBox	m_drawno;
	CComboBox	m_weldnotype;
	CComboBox	m_wpsno;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAdvancedSettingDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CAdvancedSettingDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnEdit();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADVANCEDSETTINGDLG_H__4F863ED8_03F0_47FA_9ED1_A80F527261C0__INCLUDED_)
