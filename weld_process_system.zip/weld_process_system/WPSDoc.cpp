// WPSDoc.cpp : implementation of the CWPSDoc class
//

#include "stdafx.h"
#include "WPS.h"

#include "WPSDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWPSDoc

IMPLEMENT_DYNCREATE(CWPSDoc, CDocument)

BEGIN_MESSAGE_MAP(CWPSDoc, CDocument)
	//{{AFX_MSG_MAP(CWPSDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWPSDoc construction/destruction

CWPSDoc::CWPSDoc()
{
	// TODO: add one-time construction code here

}

CWPSDoc::~CWPSDoc()
{
}

BOOL CWPSDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CWPSDoc serialization

void CWPSDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CWPSDoc diagnostics

#ifdef _DEBUG
void CWPSDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CWPSDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CWPSDoc commands
