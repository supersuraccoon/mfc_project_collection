// ReportManagementDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WPS.h"
#include "ReportManagementDlg.h"
#include "MyExcel.h"

#include <io.h>
#include <odbcinst.h>
#include <afxdb.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CReportManagementDlg dialog


CReportManagementDlg::CReportManagementDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CReportManagementDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CReportManagementDlg)
	//}}AFX_DATA_INIT
}


void CReportManagementDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CReportManagementDlg)
	DDX_Control(pDX, IDC_LIST1, m_list);
	DDX_Control(pDX, IDC_CHOOSEREPORTTYPE, m_report);
	DDX_Control(pDX, IDC_CHOOSEDRAWING, m_drawing);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CReportManagementDlg, CDialog)
	//{{AFX_MSG_MAP(CReportManagementDlg)
	ON_BN_CLICKED(IDC_CONFIRM, OnConfirm)
	ON_BN_CLICKED(IDC_TOEXCEL, OnToexcel)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
// CReportManagementDlg message handlers

BOOL CReportManagementDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CString sql;
	char DrawNo[100];
	CWPSApp* pApp=(CWPSApp*)AfxGetApp();  
	DBpath=pApp->DBPath;
	
	m_MyDB1 = new CAccessDB(DBpath.GetBuffer(MAX_PATH),DBpath.GetBuffer(MAX_PATH),0);
	DBpath.ReleaseBuffer();
	
	m_MyDB2 = new CAccessDB(DBpath.GetBuffer(MAX_PATH),DBpath.GetBuffer(MAX_PATH),0);
	DBpath.ReleaseBuffer();
	
	
	if(!m_MyDB1->OpenDB(DBpath.GetBuffer(MAX_PATH)))
	{
		AfxMessageBox("DB Open Error!");
		DBpath.ReleaseBuffer();
		return FALSE;
	}
	
	DBpath.ReleaseBuffer();
	if(!m_MyDB2->OpenDB(DBpath.GetBuffer(MAX_PATH)))
	{
		AfxMessageBox("DB Open Error!");
		DBpath.ReleaseBuffer();
		return FALSE;
	}
	
	DBpath.ReleaseBuffer();

	sql.Format("select DISTINCT(DrwNo) from Draw ");
	if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
		return false;
	
	int iRowCount=m_MyDB1->GetDataSetRowCount(1);
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB1->GetDataSetFieldValue(i,0,DrawNo);
		m_drawing.AddString(DrawNo);
	}	
	m_drawing.SetCurSel(0);

	m_report.SetCurSel(0);

	m_list.SetExtendedStyle(LVS_EX_FULLROWSELECT);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CReportManagementDlg::OnConfirm() 
{
	// TODO: Add your control notification handler code here
	CString reportType;
	char DrawNo[100];

	CString str;
	CString sql;
	char cDrwNo[100];
	char cid[100];
	int id;

	char SUTTL[3][100];
	char SUTDL[3][100];
	char SPTTL[3][100];
	char SPTDL[3][100];
	char SRTTL[3][100];
	char SRTDL[3][100];

	char PUTTL[3][100];
	char PUTDL[3][100];
	char PPTTL[3][100];
	char PPTDL[3][100];
	char PRTTL[3][100];
	char PRTDL[3][100];


	m_drawing.GetLBText(m_drawing.GetCurSel(),DrawNo);
	m_report.GetLBText(m_report.GetCurSel(),reportType);

	m_list.DeleteAllItems();
	int nColCnt=m_list.GetHeaderCtrl()->GetItemCount();   
	for(int i=0;i<nColCnt;i++)   
	{   
		if (!m_list.DeleteColumn(0))     
			AfxMessageBox("ɾ��ʧ��!");   	
	}  

	if (reportType=="Structure")
	{
		m_list.InsertColumn(0, "No", LVCFMT_LEFT, 30);
		m_list.InsertColumn(1, "DrwNo", LVCFMT_LEFT, 30);
		m_list.InsertColumn(2, "WPSNo", LVCFMT_LEFT, 50);
		m_list.InsertColumn(3, "WeldNo", LVCFMT_LEFT, 50);
		m_list.InsertColumn(4, "WeldType", LVCFMT_LEFT, 55);
		//m_list.InsertColumn(5, "Specification", LVCFMT_LEFT, 80);
		//m_list.InsertColumn(6, "Dimension", LVCFMT_LEFT, 70);
		//m_list.InsertColumn(7, "Thickness", LVCFMT_LEFT, 70);
		m_list.InsertColumn(5, "Status", LVCFMT_LEFT, 50);
		//m_list.InsertColumn(9, "Material", LVCFMT_LEFT, 55);
		m_list.InsertColumn(6, "WeldLength", LVCFMT_LEFT, 70);
		m_list.InsertColumn(7, "Block", LVCFMT_LEFT, 50);
		//m_list.InsertColumn(12, "Erection", LVCFMT_LEFT, 70);
		m_list.InsertColumn(8, "SDate", LVCFMT_LEFT, 70);
		m_list.InsertColumn(9, "EDate", LVCFMT_LEFT, 70);
		m_list.InsertColumn(10, "NDT", LVCFMT_LEFT, 30);
		m_list.InsertColumn(11, "Page", LVCFMT_LEFT, 40);
		//m_list.InsertColumn(12, "TotalPage", LVCFMT_LEFT, 40);
		m_list.InsertColumn(12, "WelderNo", LVCFMT_LEFT, 40);
		
		
		sql.Format("select * from Draw where DrType=1 AND DrwNo='%s'",DrawNo);
		if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
			return ;
		int iRowCount=m_MyDB1->GetDataSetRowCount(1);
		
		if(!iRowCount)
			return ;
		for(i=0;i<iRowCount;i++)
		{
			str.Format("%d",i+1);
			m_list.InsertItem(LVIF_TEXT|LVIF_STATE, i, 
				str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
			
			m_MyDB1->GetDataSetFieldValue(i,0,cid);
			id=atoi(cid);
			m_MyDB1->GetDataSetFieldValue(i,1,cDrwNo);
			m_MyDB1->GetDataSetFieldValue(i,4,page);
			
			sql.Format("select * from Structure where DrwNO=%d",id);
			if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
				return ;
			int jRowCount=m_MyDB2->GetDataSetRowCount(1);
			
			if(!jRowCount)
				return ;		
			
			m_MyDB2->GetDataSetFieldValue(0,3,WPSNo);
			m_MyDB2->GetDataSetFieldValue(0,4,WeldNo);
			m_MyDB2->GetDataSetFieldValue(0,5,WeldType);
			//m_MyDB2->GetDataSetFieldValue(0,6,Specification);
			//m_MyDB2->GetDataSetFieldValue(0,7,Dimension);
			//m_MyDB2->GetDataSetFieldValue(0,8,Thickness);
			m_MyDB2->GetDataSetFieldValue(0,9,Status);
			//m_MyDB2->GetDataSetFieldValue(0,10,Material);
			m_MyDB2->GetDataSetFieldValue(0,11,WeldLength);
			m_MyDB2->GetDataSetFieldValue(0,12,Block);
			//m_MyDB2->GetDataSetFieldValue(0,13,Erection);
			m_MyDB2->GetDataSetFieldValue(0,14,SWeldDate);
			m_MyDB2->GetDataSetFieldValue(0,15,EWeldDate);
			m_MyDB2->GetDataSetFieldValue(0,16,NDT);
			m_MyDB2->GetDataSetFieldValue(0,17,WelderNo);

			
			m_list.SetItemText(i,1,cDrwNo);
			m_list.SetItemText(i,2,WPSNo);
			m_list.SetItemText(i,3,WeldNo);
			m_list.SetItemText(i,4,WeldType);
			m_list.SetItemText(i,5,Status);
			m_list.SetItemText(i,6,WeldLength);
			m_list.SetItemText(i,7,Block);
			m_list.SetItemText(i,8,SWeldDate);
			m_list.SetItemText(i,9,EWeldDate);
			m_list.SetItemText(i,10,NDT);
			m_list.SetItemText(i,11,page);
			m_list.SetItemText(i,12,WelderNo);
		}
	}
	else
		if (reportType=="Pipeline")
		{
			m_list.InsertColumn(0, "No", LVCFMT_LEFT, 30);
			m_list.InsertColumn(1, "DrwNo", LVCFMT_LEFT, 50);
			m_list.InsertColumn(2, "WPSNo", LVCFMT_LEFT, 50);
			m_list.InsertColumn(3, "WeldNo", LVCFMT_LEFT, 50);
			m_list.InsertColumn(4, "WeldType", LVCFMT_LEFT, 55);
			//m_list.InsertColumn(5, "Specification", LVCFMT_LEFT, 80);
			//m_list.InsertColumn(6, "Dimension", LVCFMT_LEFT, 70);
			//m_list.InsertColumn(7, "Thickness", LVCFMT_LEFT, 70);
			//m_list.InsertColumn(8, "Material", LVCFMT_LEFT, 55);
			m_list.InsertColumn(5, "WeldLength", LVCFMT_LEFT, 70);
			//m_list.InsertColumn(10, "InCategory", LVCFMT_LEFT, 70);
			m_list.InsertColumn(6, "Pipeline", LVCFMT_LEFT, 65);
			m_list.InsertColumn(7, "NDT", LVCFMT_LEFT, 30);
			m_list.InsertColumn(8, "Page", LVCFMT_LEFT, 40);
			//m_list.InsertColumn(14, "TotalPage", LVCFMT_LEFT, 40);
			m_list.InsertColumn(9, "WeldNo", LVCFMT_LEFT, 40);

			sql.Format("select * from Draw where DrType=0AND DrwNo='%s'",DrawNo);
			if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
				return ;
			int iRowCount=m_MyDB1->GetDataSetRowCount(1);
			
			if(!iRowCount)
				return ;

			for(i=0;i<iRowCount;i++)
			{
				str.Format("%d",i+1);
				m_list.InsertItem(LVIF_TEXT|LVIF_STATE, i, 
					str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
				
				m_MyDB1->GetDataSetFieldValue(i,0,cid);
				id=atoi(cid);
				m_MyDB1->GetDataSetFieldValue(i,1,cDrwNo);
				m_MyDB1->GetDataSetFieldValue(i,4,page);
				
				sql.Format("select * from Piping where DrwNO=%d",id);
				if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
					return ;
				int jRowCount=m_MyDB2->GetDataSetRowCount(1);
				
				if(!jRowCount)
					return ;		
				
				m_MyDB2->GetDataSetFieldValue(0,3,WPSNo);
				m_MyDB2->GetDataSetFieldValue(0,4,WeldNo);
				m_MyDB2->GetDataSetFieldValue(0,5,WeldType);
				//m_MyDB2->GetDataSetFieldValue(0,6,Specification);
				//m_MyDB2->GetDataSetFieldValue(0,7,Dimension);
				//m_MyDB2->GetDataSetFieldValue(0,8,Thickness);
				//m_MyDB2->GetDataSetFieldValue(0,9,Material);
				m_MyDB2->GetDataSetFieldValue(0,10,WeldLength);
				//m_MyDB2->GetDataSetFieldValue(0,11,inCategory);
				m_MyDB2->GetDataSetFieldValue(0,12,Pipeline);
				m_MyDB2->GetDataSetFieldValue(0,13,NDT);
				m_MyDB2->GetDataSetFieldValue(0,14,WelderNo);
				
				m_list.SetItemText(i,1,cDrwNo);
				m_list.SetItemText(i,2,WPSNo);
				m_list.SetItemText(i,3,WeldNo);
				m_list.SetItemText(i,4,WeldType);
				m_list.SetItemText(i,5,WeldLength);
				m_list.SetItemText(i,6,Pipeline);
				m_list.SetItemText(i,7,NDT);
				m_list.SetItemText(i,8,page);
				m_list.SetItemText(i,9,WelderNo);
			}
		}
		else
			if(reportType=="SNDT")
			{
				m_list.InsertColumn(0, "Status", LVCFMT_LEFT, 50);
				m_list.InsertColumn(1, "PTTested", LVCFMT_LEFT, 80);
				m_list.InsertColumn(2, "PTDefect", LVCFMT_LEFT, 80);
				m_list.InsertColumn(3, "UTTested", LVCFMT_LEFT, 80);
				m_list.InsertColumn(4, "UTDefect", LVCFMT_LEFT, 80);
				m_list.InsertColumn(5, "RTTested", LVCFMT_LEFT, 80);
				m_list.InsertColumn(6, "RTDefect", LVCFMT_LEFT, 80);
				
				sql.Format("select * from Draw where DrType=1 AND DrwNo='%s'",DrawNo);
				if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
					return ;
				int iRowCount=m_MyDB1->GetDataSetRowCount(1);
				
				if(!iRowCount)
					return ;
				for(i=0;i<iRowCount;i++)
				{			
					m_MyDB1->GetDataSetFieldValue(i,0,cid);
					id=atoi(cid);
					
					//sql.Format("select ID from Structure where DrwNO=%d AND Status=1",id);
					sql.Format("select SUM(TLength),SUM(DLength) FROM SPT WHERE DrwID IN (select ID from Structure where DrwNO=%d AND Status=1)",id);
					
					if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
						return ;
					int jRowCount=m_MyDB2->GetDataSetRowCount(1);
					
					if(jRowCount==-1)
						jRowCount=0;
					
					m_MyDB2->GetDataSetFieldValue(0,0,SPTTL[0]);
					m_MyDB2->GetDataSetFieldValue(0,1,SPTDL[0]);
					
					
					sql.Format("select SUM(TLength),SUM(DLength) FROM SUT WHERE DrwID IN (select ID from Structure where DrwNO=%d AND Status=1)",id);
					
					if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
						return ;
					jRowCount=m_MyDB2->GetDataSetRowCount(1);
					
					if(jRowCount==-1)
						jRowCount=0;
					
					m_MyDB2->GetDataSetFieldValue(0,0,SUTTL[0]);
					m_MyDB2->GetDataSetFieldValue(0,1,SUTDL[0]);
					
					sql.Format("select SUM(TLength),SUM(DLength) FROM SRT WHERE DrwID IN (select ID from Structure where DrwNO=%d AND Status=1)",id);
					
					if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
						return ;
					jRowCount=m_MyDB2->GetDataSetRowCount(1);
					
					if(jRowCount==-1)
						jRowCount=0;
					
					m_MyDB2->GetDataSetFieldValue(0,0,SRTTL[0]);
					m_MyDB2->GetDataSetFieldValue(0,1,SRTDL[0]);


					sql.Format("select SUM(TLength),SUM(DLength) FROM SPT WHERE DrwID IN (select ID from Structure where DrwNO=%d AND Status=2)",id);
					
					if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
						return ;
					jRowCount=m_MyDB2->GetDataSetRowCount(1);
					
					if(jRowCount==-1)
						jRowCount=0;
					
					m_MyDB2->GetDataSetFieldValue(0,0,SPTTL[1]);
					m_MyDB2->GetDataSetFieldValue(0,1,SPTDL[1]);
					
					
					sql.Format("select SUM(TLength),SUM(DLength) FROM SUT WHERE DrwID IN (select ID from Structure where DrwNO=%d AND Status=2)",id);
					
					if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
						return ;
					jRowCount=m_MyDB2->GetDataSetRowCount(1);
					
					if(jRowCount==-1)
						jRowCount=0;
					
					m_MyDB2->GetDataSetFieldValue(0,0,SUTTL[1]);
					m_MyDB2->GetDataSetFieldValue(0,1,SUTDL[1]);
					
					sql.Format("select SUM(TLength),SUM(DLength) FROM SRT WHERE DrwID IN (select ID from Structure where DrwNO=%d AND Status=2)",id);
					
					if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
						return ;
					jRowCount=m_MyDB2->GetDataSetRowCount(1);
					
					if(jRowCount==-1)
						jRowCount=0;
					
					m_MyDB2->GetDataSetFieldValue(0,0,SRTTL[1]);
					m_MyDB2->GetDataSetFieldValue(0,1,SRTDL[1]);


					sql.Format("select SUM(TLength),SUM(DLength) FROM SPT WHERE DrwID IN (select ID from Structure where DrwNO=%d AND Status=3)",id);
					
					if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
						return ;
					jRowCount=m_MyDB2->GetDataSetRowCount(1);
					
					if(jRowCount==-1)
						jRowCount=0;
					
					m_MyDB2->GetDataSetFieldValue(0,0,SPTTL[2]);
					m_MyDB2->GetDataSetFieldValue(0,1,SPTDL[2]);
					
					
					sql.Format("select SUM(TLength),SUM(DLength) FROM SUT WHERE DrwID IN (select ID from Structure where DrwNO=%d AND Status=3)",id);
					
					if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
						return ;
					jRowCount=m_MyDB2->GetDataSetRowCount(1);
					
					if(jRowCount==-1)
						jRowCount=0;
					
					m_MyDB2->GetDataSetFieldValue(0,0,SUTTL[2]);
					m_MyDB2->GetDataSetFieldValue(0,1,SUTDL[2]);
					
					sql.Format("select SUM(TLength),SUM(DLength) FROM SRT WHERE DrwID IN (select ID from Structure where DrwNO=%d AND Status=3)",id);
					
					if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
						return ;
					jRowCount=m_MyDB2->GetDataSetRowCount(1);
					
					if(jRowCount==-1)
						jRowCount=0;
					
					m_MyDB2->GetDataSetFieldValue(0,0,SRTTL[2]);
					m_MyDB2->GetDataSetFieldValue(0,1,SRTDL[2]);
				}

				m_list.InsertItem(LVIF_TEXT|LVIF_STATE, 0, 
					"1", LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);

				m_list.SetItemText(0,1,SPTTL[0]);
				m_list.SetItemText(0,2,SPTDL[0]);
				m_list.SetItemText(0,3,SUTTL[0]);
				m_list.SetItemText(0,4,SUTDL[0]);
				m_list.SetItemText(0,5,SRTTL[0]);
				m_list.SetItemText(0,6,SRTDL[0]);

				m_list.InsertItem(LVIF_TEXT|LVIF_STATE, 1, 
					"2", LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
				
				m_list.SetItemText(1,1,SPTTL[1]);
				m_list.SetItemText(1,2,SPTDL[1]);
				m_list.SetItemText(1,3,SUTTL[1]);
				m_list.SetItemText(1,4,SUTDL[1]);
				m_list.SetItemText(1,5,SRTTL[1]);
				m_list.SetItemText(1,6,SRTDL[1]);

				m_list.InsertItem(LVIF_TEXT|LVIF_STATE, 2, 
					"3", LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
				
				m_list.SetItemText(2,1,SPTTL[2]);
				m_list.SetItemText(2,2,SPTDL[2]);
				m_list.SetItemText(2,3,SUTTL[2]);
				m_list.SetItemText(2,4,SUTDL[2]);
				m_list.SetItemText(2,5,SRTTL[2]);
				m_list.SetItemText(2,6,SRTDL[2]);
			}
			else
			{
				m_list.InsertColumn(0, "Status", LVCFMT_LEFT, 50);
				m_list.InsertColumn(1, "PTTested", LVCFMT_LEFT, 80);
				m_list.InsertColumn(2, "PTDefect", LVCFMT_LEFT, 80);
				m_list.InsertColumn(3, "UTTested", LVCFMT_LEFT, 80);
				m_list.InsertColumn(4, "UTDefect", LVCFMT_LEFT, 80);
				m_list.InsertColumn(5, "RTTested", LVCFMT_LEFT, 80);
				m_list.InsertColumn(6, "RTDefect", LVCFMT_LEFT, 80);
				
				sql.Format("select * from Draw where DrType=0 AND DrwNo='%s'",DrawNo);
				if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
					return ;
				int iRowCount=m_MyDB1->GetDataSetRowCount(1);
				
				if(!iRowCount)
					return ;
				for(i=0;i<iRowCount;i++)
				{			
					m_MyDB1->GetDataSetFieldValue(i,0,cid);
					id=atoi(cid);
					
					//sql.Format("select ID from Structure where DrwNO=%d AND Status=1",id);
					sql.Format("select SUM(TLength),SUM(DLength) FROM PPT WHERE DrwID IN (select ID from Structure where DrwNO=%d AND Status=1)",id);
					
					if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
						return ;
					int jRowCount=m_MyDB2->GetDataSetRowCount(1);
					
					if(jRowCount==-1)
						jRowCount=0;
					
					m_MyDB2->GetDataSetFieldValue(0,0,PPTTL[0]);
					m_MyDB2->GetDataSetFieldValue(0,1,PPTDL[0]);
					
					
					sql.Format("select SUM(TLength),SUM(DLength) FROM PUT WHERE DrwID IN (select ID from Structure where DrwNO=%d AND Status=1)",id);
					
					if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
						return ;
					jRowCount=m_MyDB2->GetDataSetRowCount(1);
					
					if(jRowCount==-1)
						jRowCount=0;
					
					m_MyDB2->GetDataSetFieldValue(0,0,PUTTL[0]);
					m_MyDB2->GetDataSetFieldValue(0,1,PUTDL[0]);
					
					sql.Format("select SUM(TLength),SUM(DLength) FROM PRT WHERE DrwID IN (select ID from Structure where DrwNO=%d AND Status=1)",id);
					
					if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
						return ;
					jRowCount=m_MyDB2->GetDataSetRowCount(1);
					
					if(jRowCount==-1)
						jRowCount=0;
					
					m_MyDB2->GetDataSetFieldValue(0,0,PRTTL[0]);
					m_MyDB2->GetDataSetFieldValue(0,1,PRTDL[0]);


					sql.Format("select SUM(TLength),SUM(DLength) FROM PPT WHERE DrwID IN (select ID from Structure where DrwNO=%d AND Status=2)",id);
					
					if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
						return ;
					jRowCount=m_MyDB2->GetDataSetRowCount(1);
					
					if(jRowCount==-1)
						jRowCount=0;
					
					m_MyDB2->GetDataSetFieldValue(0,0,PPTTL[1]);
					m_MyDB2->GetDataSetFieldValue(0,1,PPTDL[1]);
					
					
					sql.Format("select SUM(TLength),SUM(DLength) FROM PUT WHERE DrwID IN (select ID from Structure where DrwNO=%d AND Status=2)",id);
					
					if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
						return ;
					jRowCount=m_MyDB2->GetDataSetRowCount(1);
					
					if(jRowCount==-1)
						jRowCount=0;
					
					m_MyDB2->GetDataSetFieldValue(0,0,PUTTL[1]);
					m_MyDB2->GetDataSetFieldValue(0,1,PUTDL[1]);
					
					sql.Format("select SUM(TLength),SUM(DLength) FROM PRT WHERE DrwID IN (select ID from Structure where DrwNO=%d AND Status=2)",id);
					
					if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
						return ;
					jRowCount=m_MyDB2->GetDataSetRowCount(1);
					
					if(jRowCount==-1)
						jRowCount=0;
					
					m_MyDB2->GetDataSetFieldValue(0,0,SRTTL[1]);
					m_MyDB2->GetDataSetFieldValue(0,1,SRTDL[1]);


					sql.Format("select SUM(TLength),SUM(DLength) FROM PPT WHERE DrwID IN (select ID from Structure where DrwNO=%d AND Status=3)",id);
					
					if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
						return ;
					jRowCount=m_MyDB2->GetDataSetRowCount(1);
					
					if(jRowCount==-1)
						jRowCount=0;
					
					m_MyDB2->GetDataSetFieldValue(0,0,PPTTL[2]);
					m_MyDB2->GetDataSetFieldValue(0,1,PPTDL[2]);
					
					
					sql.Format("select SUM(TLength),SUM(DLength) FROM PUT WHERE DrwID IN (select ID from Structure where DrwNO=%d AND Status=3)",id);
					
					if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
						return ;
					jRowCount=m_MyDB2->GetDataSetRowCount(1);
					
					if(jRowCount==-1)
						jRowCount=0;
					
					m_MyDB2->GetDataSetFieldValue(0,0,PUTTL[2]);
					m_MyDB2->GetDataSetFieldValue(0,1,PUTDL[2]);
					
					sql.Format("select SUM(TLength),SUM(DLength) FROM PRT WHERE DrwID IN (select ID from Structure where DrwNO=%d AND Status=3)",id);
					
					if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
						return ;
					jRowCount=m_MyDB2->GetDataSetRowCount(1);
					
					if(jRowCount==-1)
						jRowCount=0;
					
					m_MyDB2->GetDataSetFieldValue(0,0,PRTTL[2]);
					m_MyDB2->GetDataSetFieldValue(0,1,PRTDL[2]);
				}

				m_list.InsertItem(LVIF_TEXT|LVIF_STATE, 0, 
					"1", LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);

				m_list.SetItemText(0,1,PPTTL[0]);
				m_list.SetItemText(0,2,PPTDL[0]);
				m_list.SetItemText(0,3,PUTTL[0]);
				m_list.SetItemText(0,4,PUTDL[0]);
				m_list.SetItemText(0,5,PRTTL[0]);
				m_list.SetItemText(0,6,PRTDL[0]);

				m_list.InsertItem(LVIF_TEXT|LVIF_STATE, 1, 
					"2", LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
				
				m_list.SetItemText(1,1,PPTTL[1]);
				m_list.SetItemText(1,2,PPTDL[1]);
				m_list.SetItemText(1,3,PUTTL[1]);
				m_list.SetItemText(1,4,PUTDL[1]);
				m_list.SetItemText(1,5,PRTTL[1]);
				m_list.SetItemText(1,6,PRTDL[1]);

				m_list.InsertItem(LVIF_TEXT|LVIF_STATE, 2, 
					"3", LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
				
				m_list.SetItemText(2,1,PPTTL[2]);
				m_list.SetItemText(2,2,PPTDL[2]);
				m_list.SetItemText(2,3,PUTTL[2]);
				m_list.SetItemText(2,4,PUTDL[2]);
				m_list.SetItemText(2,5,PRTTL[2]);
				m_list.SetItemText(2,6,PRTDL[2]);
			}
}

void CReportManagementDlg::OnToexcel() 
{
	// TODO: Add your control notification handler code here
	CMyExcel excel;
	excel.ExportListToExcel(&m_list,"log");
}

void CReportManagementDlg::SetHeader()
{	
	CString DrawNo;

	m_drawing.GetLBText(m_drawing.GetCurSel(),DrawNo);
}
