#if !defined(AFX_REPORTMANAGEMENTDLG_H__13FBF84D_0CF3_47D3_9638_34BD71034581__INCLUDED_)
#define AFX_REPORTMANAGEMENTDLG_H__13FBF84D_0CF3_47D3_9638_34BD71034581__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ReportManagementDlg.h : header file
//

#include "AccessDB.h"
/////////////////////////////////////////////////////////////////////////////
// CReportManagementDlg dialog

class CReportManagementDlg : public CDialog
{
// Construction
public:
	void SetHeader();
	CReportManagementDlg(CWnd* pParent = NULL);   // standard constructor

	CString DBpath;

	char WPSNo[100];
	char WeldNo[100];
	char WeldType[100];
	char Status[100];
	char WeldLength[100];
	char Material[100];
	char Block[100];
	char Erection[100];
	char NDT[100];
	char SWeldDate[100];
	char EWeldDate[100];
	char inCategory[100];
	char page[100];
	char total[100];
	char Specification[100];
	char Dimension[100];
	char Thickness[100];
	char Pipeline[100];
	char WelderNo[100];
	
	CAccessDB * m_MyDB1;
	CAccessDB * m_MyDB2;

// Dialog Data
	//{{AFX_DATA(CReportManagementDlg)
	enum { IDD = IDD_REPORTMANAGEMENT };
	CListCtrl	m_list;
	CComboBox	m_report;
	CComboBox	m_drawing;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CReportManagementDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CReportManagementDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	afx_msg void OnToexcel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REPORTMANAGEMENTDLG_H__13FBF84D_0CF3_47D3_9638_34BD71034581__INCLUDED_)
