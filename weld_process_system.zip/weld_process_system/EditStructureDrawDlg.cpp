// EditStructureDrawDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WPS.h"
#include "EditStructureDrawDlg.h"
#include "AdvancedSettingDlg.h"
#include "NewPageDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEditStructureDrawDlg dialog


CEditStructureDrawDlg::CEditStructureDrawDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEditStructureDrawDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEditStructureDrawDlg)
	//}}AFX_DATA_INIT
}


void CEditStructureDrawDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEditStructureDrawDlg)
	DDX_Control(pDX, IDC_DETAIL, m_detail);
	DDX_Control(pDX, IDC_TYPE, m_type);
	DDX_Control(pDX, IDC_LIST1, m_list);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CEditStructureDrawDlg, CDialog)
	//{{AFX_MSG_MAP(CEditStructureDrawDlg)
	ON_BN_CLICKED(IDC_CONFIRM, OnConfirm)
	ON_CBN_CLOSEUP(IDC_TYPE, OnCloseupType)
	ON_CBN_CLOSEUP(IDC_DETAIL, OnCloseupDetail)
	ON_BN_CLICKED(IDC_ADCANCEDSETTING, OnAdcancedsetting)
	ON_BN_CLICKED(IDC_SAVECHANGE, OnSavechange)
	ON_BN_CLICKED(IDC_ADDPAGE, OnAddpage)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_VALIDATE, OnEndLabelEditVariableCriteria)
	ON_MESSAGE(WM_SET_ITEMS, PopulateComboList)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditStructureDrawDlg message handlers

BOOL CEditStructureDrawDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CString str;
	CString sql;
	CWPSApp* pApp=(CWPSApp*)AfxGetApp();  
	DBpath=pApp->DBPath;
	
	m_MyDB1 = new CAccessDB(DBpath.GetBuffer(MAX_PATH),DBpath.GetBuffer(MAX_PATH),0);
	DBpath.ReleaseBuffer();
	
	m_MyDB2 = new CAccessDB(DBpath.GetBuffer(MAX_PATH),DBpath.GetBuffer(MAX_PATH),0);
	DBpath.ReleaseBuffer();
	
	
	if(!m_MyDB1->OpenDB(DBpath.GetBuffer(MAX_PATH)))
	{
		AfxMessageBox("DB Open Error!");
		DBpath.ReleaseBuffer();
		return FALSE;
	}
	
	DBpath.ReleaseBuffer();
	if(!m_MyDB2->OpenDB(DBpath.GetBuffer(MAX_PATH)))
	{
		AfxMessageBox("DB Open Error!");
		DBpath.ReleaseBuffer();
		return FALSE;
	}
	
	DBpath.ReleaseBuffer();
	
	m_list.InsertColumn(0, "No", LVCFMT_LEFT, 30);
	m_list.InsertColumn(1, "DrwNo", LVCFMT_LEFT, 50);
	m_list.InsertColumn(2, "WPSNo", LVCFMT_LEFT, 50);
	m_list.InsertColumn(3, "WeldNo", LVCFMT_LEFT, 50);
	m_list.InsertColumn(4, "WeldType", LVCFMT_LEFT, 55);
	m_list.InsertColumn(5, "Spec.", LVCFMT_LEFT, 0);
	m_list.InsertColumn(6, "Dimension", LVCFMT_LEFT, 0);
	m_list.InsertColumn(7, "Thickness", LVCFMT_LEFT, 0);
	m_list.InsertColumn(8, "Status", LVCFMT_LEFT, 50);
	m_list.InsertColumn(9, "Material", LVCFMT_LEFT, 0);
	m_list.InsertColumn(10, "WeldLength", LVCFMT_LEFT, 70);
	m_list.InsertColumn(11, "Block", LVCFMT_LEFT, 50);
	m_list.InsertColumn(12, "Erection", LVCFMT_LEFT, 0);
	m_list.InsertColumn(13, "SDate", LVCFMT_LEFT, 70);
	m_list.InsertColumn(14, "EDate", LVCFMT_LEFT, 70);
	m_list.InsertColumn(15, "NDT", LVCFMT_LEFT, 30);
	m_list.InsertColumn(16, "Page", LVCFMT_LEFT, 40);
	m_list.InsertColumn(17, "Total", LVCFMT_LEFT, 40);
	m_list.InsertColumn(18,"DrwID",LVCFMT_LEFT,0);
	m_list.InsertColumn(19,"WelderNo",LVCFMT_LEFT,70);
	
	
	CString strValidChars;//	
	m_list.SetReadOnlyColumns(0);//read only
	m_list.SetReadOnlyColumns(1);//read only
	m_list.SetReadOnlyColumns(18);//read only

	strValidChars = "0123456789.";
	m_list.SetColumnValidEditCtrlCharacters(strValidChars,1);//none control edit 
	
	//strValidChars = "0123456789.";
	strValidChars = "";
	m_list.SetColumnValidEditCtrlCharacters(strValidChars,7);//none control edit 
	m_list.SetColumnValidEditCtrlCharacters(strValidChars,8);
	m_list.SetColumnValidEditCtrlCharacters(strValidChars,10);
	m_list.SetColumnValidEditCtrlCharacters(strValidChars,16);
	m_list.SetColumnValidEditCtrlCharacters(strValidChars,17);

	//m_list.SetComboColumns(2,TRUE);
	//m_list.SetComboColumns(3,TRUE);
	m_list.SetComboColumns(4,TRUE);
	m_list.SetComboColumns(8,TRUE);
	m_list.SetComboColumns(19,TRUE);
	//m_list.SetComboColumns(9,TRUE);
	//m_list.EnableVScroll(); 			
	m_list.SetExtendedStyle(LVS_EX_FULLROWSELECT);


	m_type.SetCurSel(0);
	m_detail.AddString("All");
	m_detail.SetCurSel(0);
	InitList();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CEditStructureDrawDlg::InitWPSCombo(CStringArray &strArr)
{
	CString sql="select * from WPSNoType";
	char WPSNo[100];
	if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	
	int iRowCount=m_MyDB1->GetDataSetRowCount(1);
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB1->GetDataSetFieldValue(i,0,WPSNo);
		strArr.Add(WPSNo);
	}
}

void CEditStructureDrawDlg::InitWeldNoCombo(CStringArray &strArr)
{
	CString sql="select * from WeldNoType";
	char WeldNo[100];
	if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	
	int iRowCount=m_MyDB1->GetDataSetRowCount(1);
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB1->GetDataSetFieldValue(i,0,WeldNo);
		strArr.Add(WeldNo);
	}
}

void CEditStructureDrawDlg::InitMaterialCombo(CStringArray &strArr)
{
	CString sql="select * from MaterialType";
	char Material[100];
	if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	
	int iRowCount=m_MyDB1->GetDataSetRowCount(1);
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB1->GetDataSetFieldValue(i,0,Material);
		strArr.Add(Material);
	}
}

void CEditStructureDrawDlg::InitWeldTypeCombo(CStringArray &strArr)
{
	CString sql="select * from WeldType";
	char WeldType[100];
	if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	
	int iRowCount=m_MyDB1->GetDataSetRowCount(1);
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB1->GetDataSetFieldValue(i,0,WeldType);
		strArr.Add(WeldType);
	}
}

LRESULT CEditStructureDrawDlg::PopulateComboList(WPARAM wParam, LPARAM lParam)
{
	// Get the Combobox window pointer
	CStringArray strArr;
	CComboBox* pInPlaceCombo = static_cast<CComboBox*> (GetFocus());
	// Get the inplace combbox top left
	CRect obWindowRect;
	
	pInPlaceCombo->GetWindowRect(&obWindowRect);
	
	CPoint obInPlaceComboTopLeft(obWindowRect.TopLeft());
	
	// Get the active list
	// Get the control window rect
	// If the inplace combobox top left is in the rect then
	// The control is the active control
	m_list.GetWindowRect(&obWindowRect);
	
	int iColIndex = (int )wParam;
	
	CStringList* pComboList = reinterpret_cast<CStringList*>(lParam);
	pComboList->RemoveAll();
	
	if (obWindowRect.PtInRect(obInPlaceComboTopLeft)) 
	{
		if(iColIndex==2)
		{
			InitWPSCombo(strArr);
			for (int i=0;i<strArr.GetSize();i++)
			{
				pComboList->AddTail(strArr.GetAt(i));
			}
			strArr.RemoveAll();
		}		
		else
			if (iColIndex==3)
			{
				InitWeldNoCombo(strArr);
				for (int i=0;i<strArr.GetSize();i++)
				{
					pComboList->AddTail(strArr.GetAt(i));
				}
				strArr.RemoveAll();
			}
			else
				if (iColIndex==4)
				{
					InitWeldTypeCombo(strArr);
					for (int i=0;i<strArr.GetSize();i++)
					{
						pComboList->AddTail(strArr.GetAt(i));
					}
					strArr.RemoveAll();
				}
				else
					if (iColIndex==8)
					{
						pComboList->AddTail("1");
						pComboList->AddTail("2");
						pComboList->AddTail("3");
					}
					else
						if (iColIndex==9)
						{
							InitMaterialCombo(strArr);
							for (int i=0;i<strArr.GetSize();i++)
							{
								pComboList->AddTail(strArr.GetAt(i));
							}
							strArr.RemoveAll();
						}
						else
							if (iColIndex==19)
							{
								InitWelderCombo(strArr);
								for (int i=0;i<strArr.GetSize();i++)
								{
									pComboList->AddTail(strArr.GetAt(i));
								}
								strArr.RemoveAll();
							}
	}
	return true;
}
	
LRESULT CEditStructureDrawDlg::OnEndLabelEditVariableCriteria(WPARAM wParam, LPARAM lParam) 
{
		LV_DISPINFO* pDispInfo = (LV_DISPINFO*)lParam;
		// TODO: Add your control notification handler code here
		
		return 1;
}

BOOL CEditStructureDrawDlg::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(pMsg->message == WM_KEYDOWN)
    {
        switch(pMsg->wParam)
        {
        case VK_RETURN: 
            // [RETURN] key����
            m_list.GoToNextItem();
            return TRUE;
		case VK_DOWN:
			m_list.GoDownToNextItem();
			return TRUE;
        }
    }
	
	return CDialog::PreTranslateMessage(pMsg);
}

void CEditStructureDrawDlg::OnConfirm() 
{
	// TODO: Add your control notification handler code here
	InitList();
	m_type.SetCurSel(0);
	m_detail.ResetContent();
	m_detail.AddString("All");
	m_detail.SetCurSel(0);
}

void CEditStructureDrawDlg::InitList()
{
	CString str;
	CString sql;
	char cDrwNo[100];
	char cid[100];
	int id;

	m_list.DeleteAllItems();
	
	sql.Format("select * from Draw where DrType=1 AND ProjectID='%s' AND DrwNo='%s 'ORDER BY DrwNo ASC",ProjectID,DrwNo);
	if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	int iRowCount=m_MyDB1->GetDataSetRowCount(1);
	
	if(!iRowCount)
		return ;

	for(int i=0,index=0;i<iRowCount;i++)
	{
		m_MyDB1->GetDataSetFieldValue(i,0,cid);
		id=atoi(cid);
		m_MyDB1->GetDataSetFieldValue(i,1,cDrwNo);
		m_MyDB1->GetDataSetFieldValue(i,3,total);
		m_MyDB1->GetDataSetFieldValue(i,4,page);
		
		sql.Format("select * from Structure where DrwNO=%d",id);
		if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
			return ;
		int jRowCount=m_MyDB2->GetDataSetRowCount(1);
		
		if(!jRowCount)
			return ;		
		
		for (int j=0;j<jRowCount;j++)
		{
			str.Format("%d",index+1);
			m_list.InsertItem(LVIF_TEXT|LVIF_STATE, index, 
				str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
		
			m_MyDB2->GetDataSetFieldValue(j,0,cid);
			id=atoi(cid);
			m_MyDB2->GetDataSetFieldValue(j,3,WPSNo);
			m_MyDB2->GetDataSetFieldValue(j,4,WeldNo);
			m_MyDB2->GetDataSetFieldValue(j,5,WeldType);
			m_MyDB2->GetDataSetFieldValue(j,6,Specification);
			m_MyDB2->GetDataSetFieldValue(j,7,Dimension);
			m_MyDB2->GetDataSetFieldValue(j,8,Thickness);
			m_MyDB2->GetDataSetFieldValue(j,9,Status);
			m_MyDB2->GetDataSetFieldValue(j,10,Material);
			m_MyDB2->GetDataSetFieldValue(j,11,WeldLength);
			m_MyDB2->GetDataSetFieldValue(j,12,Block);
			m_MyDB2->GetDataSetFieldValue(j,13,Erection);
			m_MyDB2->GetDataSetFieldValue(j,14,SWeldDate);
			m_MyDB2->GetDataSetFieldValue(j,15,EWeldDate);
			m_MyDB2->GetDataSetFieldValue(j,16,NDT);
			m_MyDB2->GetDataSetFieldValue(j,17,WelderNo);
			
			m_list.SetItemText(index,1,cDrwNo);
			m_list.SetItemText(index,2,WPSNo);
			m_list.SetItemText(index,3,WeldNo);
			m_list.SetItemText(index,4,WeldType);
			m_list.SetItemText(index,5,Specification);
			m_list.SetItemText(index,6,Dimension);
			m_list.SetItemText(index,7,Thickness);
			m_list.SetItemText(index,8,Status);
			m_list.SetItemText(index,9,Material);
			m_list.SetItemText(index,10,WeldLength);
			m_list.SetItemText(index,11,Block);
			m_list.SetItemText(index,12,Erection);
			m_list.SetItemText(index,13,SWeldDate);
			m_list.SetItemText(index,14,EWeldDate);
			m_list.SetItemText(index,15,NDT);
			m_list.SetItemText(index,16,page);
			m_list.SetItemText(index,17,total);
			m_list.SetItemText(index,18,cid);
			m_list.SetItemText(index,19,WelderNo);

			index++;
		}
	}

}

BOOL CEditStructureDrawDlg::CheckExistence(CString str)
{
	CString temp;
	for (int i=0;i<m_detail.GetCount();i++)
	{
		m_detail.GetLBText(i,temp);
		if (str==temp)
		{
			return false;
		}
	}
	return true;
}

void CEditStructureDrawDlg::OnCloseupType() 
{
	// TODO: Add your control notification handler code here
	CString type;
	
	CString str;
	int index;
	
	index=m_type.GetCurSel();
	m_type.GetLBText(index,type);
	if (type=="All")
	{
		m_detail.ResetContent();
		m_detail.AddString("All");
		m_detail.SetCurSel(0);
		return ;
	}
	
	else
	{
		m_detail.ResetContent();
		m_detail.AddString("All");
		for (int i=0;i<m_list.GetItemCount();i++)
		{
			str=m_list.GetItemText(i,index);
			if (CheckExistence(str))
			{
				m_detail.AddString(str);
			}
		}
		m_detail.SetCurSel(0);
	}
}

void CEditStructureDrawDlg::OnCloseupDetail() 
{
	// TODO: Add your control notification handler code here
	CString detail;
	CString str;
	int index=m_detail.GetCurSel();
	m_detail.GetLBText(index,detail);

	index=m_type.GetCurSel();
	if (detail=="All")
	{
		return;
	}

	for (int i=m_list.GetItemCount();i>=0;i--)
	{
		str=m_list.GetItemText(i,index);
		if (str!=detail)
		{
			m_list.DeleteItem(i);
		}
	}
	m_list.Invalidate();
}



void CEditStructureDrawDlg::OnAdcancedsetting() 
{
	// TODO: Add your control notification handler code here
	CString strWpsNo="";
	CString strWeldNo="";
	CString strWeldType="";
	CString strSpecification="";
	CString strDimension="";
	CString strThickness="";
	CString strStatus="";
	CString strMaterial="";
	CString strWeldLength="";
	CString strBlock="";
	CString strErection="";
	CString strSWeldDate="";
	CString strEWeldDate="";
	CString strNdt="";
	CString strPage="";
	CString strTotal="";
	CString cid="";
	CString sql1="";
	
	int nSpecification=0;
	int nDimension=0;
	int nThickness=0;
	int nStatus=0;
	int nWeldLength=0;
	int nPage=0;
	int nTotal=0;
	int nid=0;
	
	int i=m_list.GetItemCount()-1;
	strWpsNo=m_list.GetItemText(i,2);
	strWeldNo=m_list.GetItemText(i,3);
	strWeldType=m_list.GetItemText(i,4);
	strSpecification=m_list.GetItemText(i,5);
	nSpecification=atoi(strSpecification);
	strDimension=m_list.GetItemText(i,6);
	nDimension=atoi(strDimension);
	strThickness=m_list.GetItemText(i,7);
	nThickness=atoi(strThickness);
	strStatus=m_list.GetItemText(i,8);
	nStatus=atoi(strStatus);
	strMaterial=m_list.GetItemText(i,9);
	strWeldLength=m_list.GetItemText(i,10);
	nWeldLength=atoi(strWeldLength);
	strBlock=m_list.GetItemText(i,11);
	strErection=m_list.GetItemText(i,12);
	strSWeldDate=m_list.GetItemText(i,13);
	strEWeldDate=m_list.GetItemText(i,14);
	strNdt=m_list.GetItemText(i,15);
	strPage=m_list.GetItemText(i,16);
	nPage=atoi(strPage);
	strTotal=m_list.GetItemText(i,17);
	nTotal=atoi(strTotal);
	
	sql1.Format("INSERT INTO Structure (ProjectID,DrwNO,WPSNo,WeldNo,WeldType,Status,WeldLength,Block,SWeldDate,EWeldDate,NDT,WelderNo) VALUES('%s',%d,'%s','%s','%s',%d,%d,'%s','%s','%s','%s','%s')",ProjectID,nid,strWpsNo,strWeldNo,strWeldType,nStatus,nWeldLength,strBlock,strSWeldDate,strEWeldDate,strNdt,WelderNo);
	//sql1.Format("UPDATE Structure SET WPSNo='%s' WHERE ID=%d",strWpsNo,nid);
	
	if(!m_MyDB1->ExecSQL((unsigned char *)sql1.GetBuffer(0)))
		return ;
}

void CEditStructureDrawDlg::OnSavechange() 
{
	// TODO: Add your control notification handler code here
	CString strWpsNo="";
	CString strWeldNo="";
	CString strWeldType="";
	CString strSpecification="";
	CString strDimension="";
	CString strThickness="";
	CString strStatus="";
	CString strMaterial="";
	CString strWeldLength="";
	CString strBlock="";
	CString strErection="";
	CString strSWeldDate="";
	CString strEWeldDate="";
	CString strNdt="";
	CString strPage="";
	CString strTotal="";
	CString cid="";
	CString WelderNo="";
	CString sql1;
	
	int nSpecification=0;
	int nDimension=0;
	int nThickness=0;
	int nStatus=0;
	int nWeldLength=0;
	int nPage=0;
	int nTotal=0;
	int nid;
	
	for(int i=0;i<m_list.GetItemCount();i++)
	{
		strWpsNo=m_list.GetItemText(i,2);
		strWeldNo=m_list.GetItemText(i,3);
		strWeldType=m_list.GetItemText(i,4);
		//strSpecification=m_list.GetItemText(i,5);
		//nSpecification=atoi(strSpecification);
		//strDimension=m_list.GetItemText(i,6);
		//nDimension=atoi(strDimension);
		//strThickness=m_list.GetItemText(i,7);
		//nThickness=atoi(strThickness);
		strStatus=m_list.GetItemText(i,8);
		nStatus=atoi(strStatus);
		//strMaterial=m_list.GetItemText(i,9);
		strWeldLength=m_list.GetItemText(i,10);
		nWeldLength=atoi(strWeldLength);
		strBlock=m_list.GetItemText(i,11);
		//strErection=m_list.GetItemText(i,12);
		strSWeldDate=m_list.GetItemText(i,13);
		strEWeldDate=m_list.GetItemText(i,14);
		strNdt=m_list.GetItemText(i,15);
		strPage=m_list.GetItemText(i,16);
		nPage=atoi(strPage);
		strTotal=m_list.GetItemText(i,17);
		nTotal=atoi(strTotal);
		cid=m_list.GetItemText(i,18);
		nid=atoi(cid);
		WelderNo=m_list.GetItemText(i,19);
		
		sql1.Format("UPDATE Structure SET WPSNo='%s',WeldNo='%s',WeldType='%s',Status=%d,WeldLength=%d,Block='%s',Erection='%s',SWeldDate='%s',EWeldDate='%s',NDT='%s',WelderNo='%s' WHERE ID=%d",strWpsNo,strWeldNo,strWeldType,nStatus,nWeldLength,strBlock,strErection,strSWeldDate,strEWeldDate,strNdt,WelderNo,nid);
		//sql1.Format("UPDATE Structure SET WPSNo='%s' WHERE ID=%d",strWpsNo,nid);
		
		if(!m_MyDB1->ExecSQL((unsigned char *)sql1.GetBuffer(0)))
			return ;
	}
	MessageBox("Saving change over!");
}

void CEditStructureDrawDlg::OnAddpage() 
{
	// TODO: Add your control notification handler code here
	int i =m_list.GetItemCount();

	CString str;

	str.Format("%d",i+1);

	m_list.InsertItem(LVIF_TEXT|LVIF_STATE, i+1, 
						  str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
	UpdateData(FALSE);

	m_list.SetItemText(i,1,DrwNo);
}

void CEditStructureDrawDlg::InitWelderCombo(CStringArray &strArr)
{
	CString sql="select * from Welder";
	char Welder[100];
	if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	
	int iRowCount=m_MyDB1->GetDataSetRowCount(1);
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB1->GetDataSetFieldValue(i,0,Welder);
		strArr.Add(Welder);
	}
}
