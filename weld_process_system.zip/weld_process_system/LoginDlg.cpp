// LoginDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WPS.h"
#include "LoginDlg.h"

#include "USERMANAGMENTDLG.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLoginDlg dialog


CLoginDlg::CLoginDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CLoginDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLoginDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CLoginDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLoginDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	DDX_Control(pDX, IDC_USERCOMBO, m_usercombo);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLoginDlg, CDialog)
	//{{AFX_MSG_MAP(CLoginDlg)
	ON_WM_CTLCOLOR()
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLoginDlg message handlers

BOOL CLoginDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CWPSApp* pApp=(CWPSApp*)AfxGetApp();  
	DBpath=pApp->DBPath;

	m_MyDB = new CAccessDB(DBpath.GetBuffer(MAX_PATH),DBpath.GetBuffer(MAX_PATH),0);
	DBpath.ReleaseBuffer();

	if(!m_MyDB->OpenDB(DBpath.GetBuffer(MAX_PATH)))
	{
		AfxMessageBox("DB Open Error!");
		DBpath.ReleaseBuffer();
		return FALSE;
	}
	
	DBpath.ReleaseBuffer();

	m_usercombo.AddString("Manager");
	m_usercombo.AddString("Worker");
	m_usercombo.SetCurSel(0);
	
	userType="Manager";
	userID="";
	password="";	

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CLoginDlg::OnOK() 
{
	// TODO: Add extra validation here
	GetDlgItemText(IDC_USERID,userID);
	GetDlgItemText(IDC_PASSWORD,password);
	GetDlgItemText(IDC_USERCOMBO,userType);
	
	SetDlgItemText(IDC_PASSWORDERROR,"");
	SetDlgItemText(IDC_USERNAMEERROR,"");
	
	CString sql;
	char curPassword[50];
	char curUserName[50];
	char curUserType[50];
	
	sql.Format("SELECT UserName,PassWord,Type FROM User WHERE UserID='%s'",userID);
	
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
	{
		SetDlgItemText(IDC_PASSWORD,"");
		SetDlgItemText(IDC_USERID,"");
		SetDlgItemText(IDC_USERNAMEERROR,"ERROR");
		return;
	}
	else
	{
		if(!m_MyDB->GetDataSetFieldValue(0,0,curUserName))
		{
			SetDlgItemText(IDC_PASSWORD,"");
			SetDlgItemText(IDC_USERID,"");
			SetDlgItemText(IDC_USERNAMEERROR,"ERROR");
			return;
		}
		m_MyDB->GetDataSetFieldValue(0,1,curPassword);
		userName=curUserName;
		m_MyDB->GetDataSetFieldValue(0,2,curUserType);
		
		if (curUserType!=userType)
		{
			MessageBox("UserType ERROR!!!");
			return;
		}

		if(password!=curPassword)
		{
			SetDlgItemText(IDC_PASSWORD,"");
			SetDlgItemText(IDC_PASSWORDERROR,"ERROR");
			return;
		}
		else
		{
			login=TRUE;
			CDialog::OnOK();
		}
	}
	CDialog::OnOK();
}

HBRUSH CLoginDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if(nCtlColor==CTLCOLOR_STATIC&&pWnd->GetDlgCtrlID()==IDC_PASSWORDERROR||
		pWnd->GetDlgCtrlID()==IDC_USERNAMEERROR)   
	{  
		pDC->SetTextColor(RGB(255,0,0)); 
		pDC->SetBkColor(RGB(128,128,128));//�����ı�����ɫ 
		pDC->SetBkMode(TRANSPARENT);//���ñ���͸�� 
	}
	
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CLoginDlg::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	m_MyDB->CloseDB();
	
	CDialog::OnClose();
}
