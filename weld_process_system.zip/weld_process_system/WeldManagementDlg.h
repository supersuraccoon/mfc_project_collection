#if !defined(AFX_WELDMANAGEMENTDLG_H__04892C14_000B_499B_B0A1_A8DA1F7BE4D2__INCLUDED_)
#define AFX_WELDMANAGEMENTDLG_H__04892C14_000B_499B_B0A1_A8DA1F7BE4D2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WeldManagementDlg.h : header file
//
#include "ComboListCtrl.h"
#include "AccessDB.h"
/////////////////////////////////////////////////////////////////////////////
// CWeldManagementDlg dialog

class CWeldManagementDlg : public CDialog
{
// Construction
public:
	void InitPT(int);
	void InitUT(int);
	void InitRT(int);
	void InitVT(int);
	CWeldManagementDlg(CWnd* pParent = NULL);   // standard constructor
	CAccessDB *m_MyDB1;
	CAccessDB *m_MyDB2;
	CString DBpath;
	char DrawNo[100];

	CString DrawType;
	CString DrawName;
	CString Dlength;

	CString projectID;
	int gRow;

// Dialog Data
	//{{AFX_DATA(CWeldManagementDlg)
	enum { IDD = IDD_WELDMANAGEMENT };
	CComboBox	m_drawtype;
	CComboListCtrl	m_list;
	CComboBox	m_type;
	CComboBox	m_project;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWeldManagementDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CWeldManagementDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnCloseupCombo1();
	afx_msg void OnCloseupCombo2();
	afx_msg void OnConfirm();
	afx_msg void OnCloseupCombo3();
	afx_msg void OnRclickList1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnRedo();
	afx_msg void OnButton1();
	//}}AFX_MSG
	afx_msg LRESULT OnEndLabelEditVariableCriteria(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT PopulateComboList(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WELDMANAGEMENTDLG_H__04892C14_000B_499B_B0A1_A8DA1F7BE4D2__INCLUDED_)
