// WPSView.cpp : implementation of the CWPSView class
//

#include "stdafx.h"
#include "WPS.h"

#include "WPSDoc.h"
#include "WPSView.h"
#include "USERMANAGMENTDLG.h"
#include "MyAccountDlg.h"
#include "MyAssignmentDlg.h"
#include "ProjectManagementDlg.h"
#include "MyperformanceDlg.h"
#include "ReportManagementDlg.h"
#include "WeldManagementDlg.h"
#include "EditDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWPSView

IMPLEMENT_DYNCREATE(CWPSView, CHtmlView)

BEGIN_MESSAGE_MAP(CWPSView, CHtmlView)
	//{{AFX_MSG_MAP(CWPSView)
	ON_WM_CREATE()
	ON_COMMAND(ID_USERMANAGEMENT, OnUsermanagement)
	ON_COMMAND(ID_MYACCOUNT, OnMyaccount)
	ON_COMMAND(ID_MYASSIGNMENT, OnMyassignment)
	ON_COMMAND(ID_MYPERFORMANCE, OnMyperformance)
	ON_COMMAND(ID_PROJECTMANAGEMENT, OnProjectmanagement)
	ON_COMMAND(ID_WELDMANAGEMENT, OnWeldmanagement)
	ON_COMMAND(ID_REPORTMANAGMENT, OnReportmanagment)
	ON_COMMAND(ID_HELP, OnHelp)
	ON_COMMAND(ID_WELDERPERFORMANCE, OnWelderperformance)
	ON_COMMAND(ID_SETTINGEDIT, OnSettingedit)
	ON_COMMAND(ID_WELDERPERFOMANCE, OnWelderperfomance)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CHtmlView::OnFilePrint)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWPSView construction/destruction

CWPSView::CWPSView()
{
	// TODO: add construction code here

}

CWPSView::~CWPSView()
{
}

BOOL CWPSView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CHtmlView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CWPSView drawing

void CWPSView::OnDraw(CDC* pDC)
{
	CWPSDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

void CWPSView::OnInitialUpdate()
{
	CHtmlView::OnInitialUpdate();

	// TODO: This code navigates to a popular spot on the web.
	//  change the code to go where you'd like.
	CWPSApp* pApp=(CWPSApp*)AfxGetApp(); 
	CString html=pApp->strPath;
	Navigate2(_T(html+"\\Sevan Marine ASA.htm"),NULL,NULL);
}

/////////////////////////////////////////////////////////////////////////////
// CWPSView printing


/////////////////////////////////////////////////////////////////////////////
// CWPSView diagnostics

#ifdef _DEBUG
void CWPSView::AssertValid() const
{
	CHtmlView::AssertValid();
}

void CWPSView::Dump(CDumpContext& dc) const
{
	CHtmlView::Dump(dc);
}

CWPSDoc* CWPSView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CWPSDoc)));
	return (CWPSDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CWPSView message handlers


int CWPSView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CHtmlView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	
	return 0;
}

void CWPSView::OnUsermanagement() 
{
	// TODO: Add your command handler code here
	CUSERMANAGMENTDLG dlg;
	dlg.DoModal();
}

void CWPSView::OnMyaccount() 
{
	// TODO: Add your command handler code here
	CMyAccountDlg dlg;
	dlg.DoModal();
}

void CWPSView::OnMyassignment() 
{
	// TODO: Add your command handler code here
	CMyAssignmentDlg dlg;
	dlg.DoModal();
}

void CWPSView::OnMyperformance() 
{
	// TODO: Add your command handler code here
	//CMyperformanceDlg dlg;
	//dlg.DoModal();
}

void CWPSView::OnProjectmanagement() 
{
	// TODO: Add your command handler code here
	CProjectManagementDlg dlg;
	dlg.DoModal();
}

void CWPSView::OnWeldmanagement() 
{
	// TODO: Add your command handler code here
	CWeldManagementDlg dlg;
	dlg.DoModal();
}

void CWPSView::OnReportmanagment() 
{
	// TODO: Add your command handler code here
	CReportManagementDlg dlg;
	dlg.DoModal();
}

void CWPSView::OnHelp() 
{
	// TODO: Add your command handler code here
	MessageBox("If you have any questions, you can either send a email to suxiaochen23@163.com or call 13862941342 for help!");
}

void CWPSView::OnWelderperformance() 
{
	// TODO: Add your command handler code here
	//MessageBox("Incomplete!!!");
}

void CWPSView::OnSettingedit() 
{
	// TODO: Add your command handler code here
	CEditDlg dlg;
	dlg.DoModal();
}

void CWPSView::OnWelderperfomance() 
{
	// TODO: Add your command handler code here
	CMyperformanceDlg dlg;
	dlg.DoModal();
}
