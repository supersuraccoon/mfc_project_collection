#if !defined(AFX_USERMANAGMENTDLG_H__931CB5F3_F858_4263_8F2F_27301DA876A0__INCLUDED_)
#define AFX_USERMANAGMENTDLG_H__931CB5F3_F858_4263_8F2F_27301DA876A0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// USERMANAGMENTDLG.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CUSERMANAGMENTDLG dialog
#include "ComboListCtrl.h"
#include "AccessDB.h"

class CUSERMANAGMENTDLG : public CDialog
{
// Construction
public:
	CUSERMANAGMENTDLG(CWnd* pParent = NULL);   // standard constructor
	CAccessDB * m_MyDB;
	int UserNo;
	CString DBpath;

// Dialog Data
	//{{AFX_DATA(CUSERMANAGMENTDLG)
	enum { IDD = IDD_USERMANAGEMENT };
	CComboListCtrl	m_ListCtrl;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUSERMANAGMENTDLG)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CUSERMANAGMENTDLG)
	virtual BOOL OnInitDialog();
	afx_msg void OnAdd();
	afx_msg void OnDelete();
	afx_msg void OnClickUserlist(NMHDR* pNMHDR, LRESULT* pResult);
	virtual void OnOK();
	afx_msg void OnPrint();
	//}}AFX_MSG
	afx_msg LRESULT OnEndLabelEditVariableCriteria(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT PopulateComboList(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_USERMANAGMENTDLG_H__931CB5F3_F858_4263_8F2F_27301DA876A0__INCLUDED_)
