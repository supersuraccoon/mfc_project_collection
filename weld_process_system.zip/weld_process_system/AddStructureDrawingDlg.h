#if !defined(AFX_ADDSTRUCTUREDRAWINGDLG_H__584438B3_D802_49B3_BB40_1544EB11090C__INCLUDED_)
#define AFX_ADDSTRUCTUREDRAWINGDLG_H__584438B3_D802_49B3_BB40_1544EB11090C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AddStructureDrawingDlg.h : header file
//

#include "ComboListCtrl.h"
#include "AccessDB.h"
/////////////////////////////////////////////////////////////////////////////
// CAddStructureDrawingDlg dialog

class CAddStructureDrawingDlg : public CDialog
{
// Construction
public:
	void InitWelderCombo(CStringArray &strArr);
	CAddStructureDrawingDlg(CWnd* pParent = NULL);   // standard constructor
	void InitWeldTypeCombo(CStringArray &strArr);
	void InitMaterialCombo(CStringArray &strArr);
	void InitWeldNoCombo(CStringArray &strArr);
	void InitWPSCombo(CStringArray& strArr);

	CString projectID;
	CString WPSNo;
	CString WeldNo;
	CString WeldType;
	CString Status;
	CString WeldLength;
	CString Material;
	CString Block;
	CString Erection;
	CString NDT;
	CString SWeldDate;
	CString EWeldDate;
	CString inCategory;
	CString page;
	CString total;
	CString DrwNo;
	CString WelderNo;

	CString TotalPage;
	CString CurPage;

	CAccessDB *m_MyDB;
	CString DBpath;

// Dialog Data
	//{{AFX_DATA(CAddStructureDrawingDlg)
	enum { IDD = IDD_ADDSTRUCTURE };
	CComboListCtrl	m_list;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAddStructureDrawingDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CAddStructureDrawingDlg)
	afx_msg void OnButton1();
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	afx_msg LRESULT OnEndLabelEditVariableCriteria(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT PopulateComboList(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADDSTRUCTUREDRAWINGDLG_H__584438B3_D802_49B3_BB40_1544EB11090C__INCLUDED_)
