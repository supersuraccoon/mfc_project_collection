// ProjectManagementDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WPS.h"
#include "ProjectManagementDlg.h"
#include "NewprojectDlg.h"
#include "AdvancedSettingDlg.h"
#include "AddStructureDrawingDlg.h"
#include "AddPipelineDrawDlg.h"
#include "EditStructureDrawDlg.h"
#include "EditPipelineDrawDlg.h"
#include "WaitingDlg.h"
#include "MyExcel.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CProjectManagementDlg dialog


CProjectManagementDlg::CProjectManagementDlg(CWnd* pParent /*=NULL*/)
: CDialog(CProjectManagementDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CProjectManagementDlg)
	//}}AFX_DATA_INIT
	changed=false;
	m_hPrev=NULL;
}


void CProjectManagementDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CProjectManagementDlg)
	DDX_Control(pDX, IDC_WELDINFO2, m_pipeList);
	DDX_Control(pDX, IDC_WELDINFO, m_list);
	DDX_Control(pDX, IDC_TREE1, m_tree);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CProjectManagementDlg, CDialog)
//{{AFX_MSG_MAP(CProjectManagementDlg)
ON_NOTIFY(TVN_SELCHANGED, IDC_TREE1, OnSelchangedTree1)
ON_BN_CLICKED(IDC_NEWPROJEC, OnNewprojec)
ON_WM_CLOSE()
ON_NOTIFY(NM_RCLICK, IDC_TREE1, OnRclickTree1)
ON_COMMAND(ID_DELETEPROJECT, OnDeleteproject)
	ON_COMMAND(ID_DELETEDRAW, OnDeletedraw)
	ON_NOTIFY(LVN_COLUMNCLICK, IDC_WELDINFO, OnColumnclickWeldinfo)
	ON_COMMAND(ID_ADDDRAW, OnAdddraw)
	ON_COMMAND(ID_EDITDRAW, OnEditdraw)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CProjectManagementDlg message handlers

CString CProjectManagementDlg::GetFullPath(HTREEITEM hCurrent)
{
	CString strReturn = "";
	if(hCurrent != NULL)
		strReturn = m_tree.GetItemText(hCurrent);
	
	return strReturn;
}

void CProjectManagementDlg::MoveItem(CTreeCtrl &myTree, HTREEITEM hFromItem, HTREEITEM hToItem)
{
	HTREEITEM hChild,hItem; 
	if(hFromItem != NULL) 
	{ 
		hChild = myTree.GetChildItem(hFromItem); 
		while(hChild != NULL) 
		{ 
			hItem = myTree.InsertItem(myTree.GetItemText(hChild),hToItem); 
			MoveItem(myTree,hChild,hItem); 
			hChild = myTree.GetNextSiblingItem(hChild); 
		} 
	} 
}

BOOL CProjectManagementDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	DWORD dwStyle = GetWindowLong(m_tree.m_hWnd,GWL_STYLE);
	dwStyle|=TVS_HASBUTTONS|TVS_HASLINES|TVS_LINESATROOT;
	SetWindowLong(m_tree.m_hWnd,GWL_STYLE,dwStyle);	
	
	m_list.InsertColumn(0, "No", LVCFMT_LEFT, 30);
	m_list.InsertColumn(1, "DrwNo", LVCFMT_LEFT, 70);
	m_list.InsertColumn(2, "WPSNo", LVCFMT_LEFT, 50);
	m_list.InsertColumn(3, "WeldNo", LVCFMT_LEFT, 50);
	m_list.InsertColumn(4, "WeldType", LVCFMT_LEFT, 55);
	m_list.InsertColumn(5, "Spec", LVCFMT_LEFT, 0);
	m_list.InsertColumn(6, "Dimension", LVCFMT_LEFT, 0);
	m_list.InsertColumn(7, "Thickness", LVCFMT_LEFT, 0);
	m_list.InsertColumn(8, "Status", LVCFMT_LEFT, 50);
	m_list.InsertColumn(9, "Material", LVCFMT_LEFT, 0);
	m_list.InsertColumn(10, "WeldLength", LVCFMT_LEFT, 70);
	m_list.InsertColumn(11, "Block", LVCFMT_LEFT, 50);
	m_list.InsertColumn(12, "Erection", LVCFMT_LEFT, 0);
	m_list.InsertColumn(13, "SDate", LVCFMT_LEFT, 70);
	m_list.InsertColumn(14, "EDate", LVCFMT_LEFT, 70);
	m_list.InsertColumn(15, "NDT", LVCFMT_LEFT, 30);
	m_list.InsertColumn(16, "Page", LVCFMT_LEFT, 40);
	m_list.InsertColumn(17, "TotalPage", LVCFMT_LEFT, 60);
	
	
	m_pipeList.InsertColumn(0, "No", LVCFMT_LEFT, 30);
	m_pipeList.InsertColumn(1, "DrwNo", LVCFMT_LEFT, 50);
	m_pipeList.InsertColumn(2, "WPSNo", LVCFMT_LEFT, 50);
	m_pipeList.InsertColumn(3, "WeldNo", LVCFMT_LEFT, 50);
	m_pipeList.InsertColumn(4, "WeldType", LVCFMT_LEFT, 55);
	m_pipeList.InsertColumn(5, "Spec", LVCFMT_LEFT, 0);
	m_pipeList.InsertColumn(6, "Dimension", LVCFMT_LEFT, 0);
	m_pipeList.InsertColumn(7, "Thickness", LVCFMT_LEFT, 0);
	m_pipeList.InsertColumn(8, "Material", LVCFMT_LEFT, 0);
	m_pipeList.InsertColumn(9, "WeldLength", LVCFMT_LEFT, 70);
	m_pipeList.InsertColumn(10, "InCategory", LVCFMT_LEFT, 70);
	m_pipeList.InsertColumn(11, "Pipeline", LVCFMT_LEFT, 65);
	m_pipeList.InsertColumn(12, "NDT", LVCFMT_LEFT, 30);
	m_pipeList.InsertColumn(13, "Page", LVCFMT_LEFT, 40);
	m_pipeList.InsertColumn(14, "TotalPage", LVCFMT_LEFT, 60);

	CWPSApp* pApp=(CWPSApp*)AfxGetApp();  
	DBpath=pApp->DBPath;
	
	m_MyDB1 = new CAccessDB(DBpath.GetBuffer(MAX_PATH),DBpath.GetBuffer(MAX_PATH),0);
	DBpath.ReleaseBuffer();
	
	m_MyDB2 = new CAccessDB(DBpath.GetBuffer(MAX_PATH),DBpath.GetBuffer(MAX_PATH),0);
	DBpath.ReleaseBuffer();
	
	
	if(!m_MyDB1->OpenDB(DBpath.GetBuffer(MAX_PATH)))
	{
		AfxMessageBox("DB Open Error!");
		DBpath.ReleaseBuffer();
		return FALSE;
	}
	
	DBpath.ReleaseBuffer();
	if(!m_MyDB2->OpenDB(DBpath.GetBuffer(MAX_PATH)))
	{
		AfxMessageBox("DB Open Error!");
		DBpath.ReleaseBuffer();
		return FALSE;
	}
	
	DBpath.ReleaseBuffer();
	
	InitTree();

	m_pipeList.SetExtendedStyle(LVS_EX_FULLROWSELECT);
	m_list.SetExtendedStyle(LVS_EX_FULLROWSELECT);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CProjectManagementDlg::OnSelchangedTree1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	TVITEM item = pNMTreeView->itemNew;
	
	gFilename= m_tree.GetItemText(item.hItem);
	m_hCurrent=m_tree.GetSelectedItem();
	
	HTREEITEM parent=m_tree.GetParentItem(m_hCurrent);
	
	if (parent==NULL&&gFilename!=""&&m_hCurrent!=m_hPrev)
	{
		//CWaitingDlg* oCTestDlg;	
		//oCTestDlg = new CWaitingDlg (this);

		//oCTestDlg->ShowWindow( SW_SHOW );
		//this->ShowWindow(SW_HIDE);
		//Sleep(3000);

	//	oCTestDlg->Create( IDD_WAITING, this );
		projectID=gFilename;
		m_hPrev=m_hCurrent;
		InitListView();
		SetHeader();
		//oCTestDlg->DestroyWindow();
		//delete oCTestDlg;
		//this->ShowWindow(SW_NORMAL);
	}

	*pResult = 0;
}

void CProjectManagementDlg::OnNewprojec() 
{
	// TODO: Add your control notification handler code here
	// TODO: Add your control notification handler code here
	CNewprojectDlg dlg;
	
	if (dlg.DoModal()==IDOK)
	{
		InitTree();
	}
}

void CProjectManagementDlg::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	m_MyDB1->CloseDB();
	m_MyDB2->CloseDB();
	
	CDialog::OnClose();
}

void CProjectManagementDlg::InitTree()
{
	CString sql="select DISTINCT(ProjectID) from Project";
	CString stemp;
	char projectID[100];
	char type[100];
	char DrwNo[100];
	
	if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	int iRowCount=m_MyDB1->GetDataSetRowCount(1);
	
	if(!iRowCount)
		return ;
	
	m_tree.DeleteAllItems();
	m_tree.Invalidate(true);
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB1->GetDataSetFieldValue(i,0,projectID);
		HTREEITEM temp=m_tree.InsertItem(projectID);
		HTREEITEM tempstruct=m_tree.InsertItem("Structure",temp);
		HTREEITEM temppipe=m_tree.InsertItem("Pipeline",temp);
		
		sql.Format("select DISTINCT(DrwNo),DrType from Draw where ProjectID='%s'",projectID);
		
		if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
			return ;
		int jRowCount=m_MyDB2->GetDataSetRowCount(1);
		
		if(!jRowCount)
			return ;
		for(int j=0;j<jRowCount;j++)
		{
			m_MyDB2->GetDataSetFieldValue(j,0,DrwNo);
			m_MyDB2->GetDataSetFieldValue(j,1,type);
			if (strcmp(type,"1")==0)
			{
				m_tree.InsertItem(DrwNo,tempstruct);
			}
			else
				if (strcmp(type,"0")==0)
				{
					m_tree.InsertItem(DrwNo,temppipe);
				}
		}
	}
	
	m_tree.Invalidate(TRUE);
}

void CProjectManagementDlg::OnRclickTree1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	CPoint cp;
    GetCursorPos(&cp);
    m_tree.ScreenToClient(&cp);
    HTREEITEM titem = m_tree.HitTest(cp, NULL);
	HTREEITEM parent=m_tree.GetParentItem(titem);
	HTREEITEM child=m_tree.GetChildItem(titem);
    // ���Ϻܹؼ�����֤�Ҽ������λ������Ҷ����֦
	
    if(parent==NULL)
    {
        // �����ڴ˹��˵����Ҷ����֦�ŵ����˵�����û������
    }
	
	else
		if (child==NULL&&m_tree.GetItemText(parent)=="Structure"||m_tree.GetItemText(parent)=="Pipeline")
		{
			m_tree.SelectItem(titem);
			m_tree.ClientToScreen(&cp);
			gParent=m_tree.GetItemText(parent);
			
			// �����Զ���˵�
			CMenu *pMenu = new CMenu();
			VERIFY(pMenu->CreatePopupMenu());
			//pMenu->AppendMenu(MF_STRING,ID_ADDPAGE,"Add Page");
			//pMenu->AppendMenu(MF_STRING,ID_MODIFYPAGE,"Modify Page");
			pMenu->AppendMenu(MF_STRING,ID_EDITDRAW,"Edit Draw");
			pMenu->AppendMenu(MF_STRING,ID_DELETEDRAW,"Delete Draw");
			
			
			pMenu->TrackPopupMenu(TPM_LEFTALIGN,cp.x,cp.y,this);
			pMenu->DestroyMenu();
		}
		else
		{
			m_tree.SelectItem(titem);
			m_tree.ClientToScreen(&cp);
			
			// �����Զ���˵�
			CMenu *pMenu = new CMenu();
			VERIFY(pMenu->CreatePopupMenu());
			pMenu->AppendMenu(MF_STRING,ID_ADDDRAW,"Add Draw");
			
			pMenu->TrackPopupMenu(TPM_LEFTALIGN,cp.x,cp.y,this);
			pMenu->DestroyMenu();
		}
		
	*pResult = 0;
}

void CProjectManagementDlg::OnDeleteproject() 
{
	// TODO: Add your command handler code here
	CString sql;
	char cid[100];
	int nid;
	sql.Format("select ID from Draw WHERE ProjectID='%s'",gFilename);
	if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	int iRowCount=m_MyDB1->GetDataSetRowCount(1);
	
	if(!iRowCount)
		return ;
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB1->GetDataSetFieldValue(i,0,cid);
		nid=atoi(cid);
		sql.Format("DELETE * FROM DD WHERE DrwNO=%d",nid);
		if(!m_MyDB2->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			AfxMessageBox("DB Error");
	}

	sql.Format("DELETE * FROM Draw WHERE ProjectID='%s'",gFilename);
	if(!m_MyDB2->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			AfxMessageBox("DB Error");

	sql.Format("DELETE * FROM Project WHERE ProjectID='%s'",gFilename);
	if(!m_MyDB1->ExecSQL((unsigned char *)sql.GetBuffer(0)))
		AfxMessageBox("DB Error");
	sql.Format("DELETE * From PP WHERE ProjectID='%s'",gFilename);
	if(!m_MyDB1->ExecSQL((unsigned char *)sql.GetBuffer(0)))
		AfxMessageBox("DB Error");
	
	InitTree();
	
	m_list.DeleteAllItems();
	m_pipeList.DeleteAllItems();
}

void CProjectManagementDlg::OnDeletedraw() 
{
	// TODO: Add your command handler code here
	CString sql;
	CString sql1;
	char cid[100];
	int nid;

	if(MessageBox("Are you sure?","Warnning",MB_OKCANCEL)==IDCANCEL)
		return ;

	if (gParent=="Structure")
	{
		m_list.DeleteAllItems();
		sql.Format("select ID from Draw WHERE DrwNo='%s' AND DrType=1",gFilename);
		sql1.Format("DELETE * from Draw WHERE DrwNo='%s' AND DrType=1",gFilename);
	}
	else
		if (gParent=="Pipeline")
		{
			m_pipeList.DeleteAllItems();
			sql.Format("select ID from Draw WHERE DrwNo='%s' AND DrType=0",gFilename);
			sql1.Format("DELETE * from Draw WHERE DrwNo='%s' AND DrType=0",gFilename);
		}
	
	if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	int iRowCount=m_MyDB1->GetDataSetRowCount(1);
	
	if(!iRowCount)
		return ;
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB1->GetDataSetFieldValue(i,0,cid);
		nid=atoi(cid);
		sql.Format("DELETE * FROM DD WHERE DrwNO=%d",nid);
		if(!m_MyDB2->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			AfxMessageBox("DB Error");
	}
	if(!m_MyDB2->ExecSQL((unsigned char *)sql1.GetBuffer(0)))
		AfxMessageBox("DB Error");

	InitListView();
	SetHeader();
	m_tree.DeleteItem(m_hCurrent);
	m_tree.Invalidate(TRUE);

}

void CProjectManagementDlg::InitListView()
{
	CString str;
	CString sql;
	char cDrwNo[100];
	char cid[100];
	int id;
	
	m_list.DeleteAllItems();
	m_pipeList.DeleteAllItems();
	sql.Format("select * from Draw where DrType=1 AND ProjectID='%s' ORDER BY DrwNo ASC",projectID);
	
	if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	int iRowCount=m_MyDB1->GetDataSetRowCount(1);
	
	if(!iRowCount)
		return ;
	for(int i=0,index=0;i<iRowCount;i++)
	{	
		m_MyDB1->GetDataSetFieldValue(i,0,cid);
		id=atoi(cid);
		m_MyDB1->GetDataSetFieldValue(i,1,cDrwNo);
		m_MyDB1->GetDataSetFieldValue(i,3,total);
		m_MyDB1->GetDataSetFieldValue(i,4,page);
		
		sql.Format("select * from Structure where DrwNO=%d",id);
		if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
			return ;
		int jRowCount=m_MyDB2->GetDataSetRowCount(1);
		
		if(!jRowCount)
			return ;		
		
		for (int j=0;j<jRowCount;j++)
		{

			str.Format("%d",index+1);
			m_list.InsertItem(LVIF_TEXT|LVIF_STATE, index, 
			str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);

			m_MyDB2->GetDataSetFieldValue(j,3,WPSNo);
			m_MyDB2->GetDataSetFieldValue(j,4,WeldNo);
			m_MyDB2->GetDataSetFieldValue(j,5,WeldType);
			m_MyDB2->GetDataSetFieldValue(j,6,Specification);
			m_MyDB2->GetDataSetFieldValue(j,7,Dimension);
			m_MyDB2->GetDataSetFieldValue(j,8,Thickness);
			m_MyDB2->GetDataSetFieldValue(j,9,Status);
			m_MyDB2->GetDataSetFieldValue(j,10,Material);
			m_MyDB2->GetDataSetFieldValue(j,11,WeldLength);
			m_MyDB2->GetDataSetFieldValue(j,12,Block);
			m_MyDB2->GetDataSetFieldValue(j,13,Erection);
			m_MyDB2->GetDataSetFieldValue(j,14,SWeldDate);
			m_MyDB2->GetDataSetFieldValue(j,15,EWeldDate);
			m_MyDB2->GetDataSetFieldValue(j,16,NDT);
			
			m_list.SetItemText(index,1,cDrwNo);
			m_list.SetItemText(index,2,WPSNo);
			m_list.SetItemText(index,3,WeldNo);
			m_list.SetItemText(index,4,WeldType);
			m_list.SetItemText(index,5,Specification);
			m_list.SetItemText(index,6,Dimension);
			m_list.SetItemText(index,7,Thickness);
			m_list.SetItemText(index,8,Status);
			m_list.SetItemText(index,9,Material);
			m_list.SetItemText(index,10,WeldLength);
			m_list.SetItemText(index,11,Block);
			m_list.SetItemText(index,12,Erection);
			m_list.SetItemText(index,13,SWeldDate);
			m_list.SetItemText(index,14,EWeldDate);
			m_list.SetItemText(index,15,NDT);
			m_list.SetItemText(index,16,page);
			m_list.SetItemText(index,17,total);

			index++;
		}
	}

	m_list.Invalidate(TRUE);
	
	sql.Format("select * from Draw where DrType=0 AND ProjectID='%s' ORDER BY DrwNo ASC",projectID);
	if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	iRowCount=m_MyDB1->GetDataSetRowCount(1);
	
	if(!iRowCount)
		return ;
	for(i=0,index=0;i<iRowCount;i++)
	{
	
		m_MyDB1->GetDataSetFieldValue(i,0,cid);
		id=atoi(cid);
		m_MyDB1->GetDataSetFieldValue(i,1,cDrwNo);
		m_MyDB1->GetDataSetFieldValue(i,3,total);
		m_MyDB1->GetDataSetFieldValue(i,4,page);
		
		sql.Format("select * from Piping where DrwNO=%d",id);
		if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
			return ;
		int jRowCount=m_MyDB2->GetDataSetRowCount(1);
		
		if(!jRowCount)
			return ;
		
		for (int j=0;j<jRowCount;j++)
		{
			str.Format("%d",index+1);
			m_pipeList.InsertItem(LVIF_TEXT|LVIF_STATE, index, 
				str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
		
			m_MyDB2->GetDataSetFieldValue(j,3,WPSNo);
			m_MyDB2->GetDataSetFieldValue(j,4,WeldNo);
			m_MyDB2->GetDataSetFieldValue(j,5,WeldType);
			m_MyDB2->GetDataSetFieldValue(j,6,Specification);
			m_MyDB2->GetDataSetFieldValue(j,7,Dimension);
			m_MyDB2->GetDataSetFieldValue(j,8,Thickness);
			m_MyDB2->GetDataSetFieldValue(j,9,Material);
			m_MyDB2->GetDataSetFieldValue(j,10,WeldLength);
			m_MyDB2->GetDataSetFieldValue(j,11,inCategory);
			m_MyDB2->GetDataSetFieldValue(j,12,Pipeline);
			m_MyDB2->GetDataSetFieldValue(j,13,NDT);
			
			m_pipeList.SetItemText(index,1,cDrwNo);
			m_pipeList.SetItemText(index,2,WPSNo);
			m_pipeList.SetItemText(index,3,WeldNo);
			m_pipeList.SetItemText(index,4,WeldType);
			m_pipeList.SetItemText(index,5,Specification);
			m_pipeList.SetItemText(index,6,Dimension);
			m_pipeList.SetItemText(index,7,Thickness);
			m_pipeList.SetItemText(index,8,Material);
			m_pipeList.SetItemText(index,9,WeldLength);
			m_pipeList.SetItemText(index,10,inCategory);
			m_pipeList.SetItemText(index,11,Pipeline);
			m_pipeList.SetItemText(index,12,NDT);
			m_pipeList.SetItemText(index,13,page);
			m_pipeList.SetItemText(index,14,total);
			index++;
		}	
	}	
	m_pipeList.Invalidate(TRUE);
}

void CProjectManagementDlg::OnColumnclickWeldinfo(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here

	*pResult = 0;
}

void CProjectManagementDlg::SetHeader()
{
	CString tprojectID;
	CString wpsno;
	CString tcreationDate;
	CString str;
	CString sql;
	CString TDL;
	CString strSdl;
	CString strPdl;
	int structNo;
	int pipeNo;
	char creationDate[100];
	char structWeldLength[100]="0";
	char pipelineWeldLength[100]="0";
	char SDL[100];
	char PDL[100];
	int totalNo;
	double totalLength;
	double sdl=0;
	double pdl=0;
	double tdl=0;

	sql.Format("select * from Project where ProjectID='%s'",projectID);
	
	if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	int iRowCount=m_MyDB1->GetDataSetRowCount(1);
	
	if(!iRowCount)
		return ;
	
	m_MyDB1->GetDataSetFieldValue(0,2,creationDate);
	
	//��ȡStructure������Ŀ
	sql.Format("select DISTINCT(DrwNo) from Draw where ProjectID='%s' AND DrType=1",projectID);
	
	if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	structNo=m_MyDB1->GetDataSetRowCount(1);
	if (structNo==-1)
	{
		structNo=0;
	}
	
	//��ȡPipeline������Ŀ
	sql.Format("select DISTINCT(DrwNo) from Draw where ProjectID='%s' AND DrType=0",projectID);
	
	if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	pipeNo=m_MyDB1->GetDataSetRowCount(1);
	if (pipeNo==-1)
	{
		pipeNo=0;
	}
	
	//���������
	totalNo=structNo+pipeNo;
	str.Format("%d",totalNo);
	SetDlgItemText(IDC_TOTALDRAWING,str);
	str.Format("%d",structNo);
	SetDlgItemText(IDC_STRUCTDRAWING,str);
	str.Format("%d",pipeNo);
	SetDlgItemText(IDC_PIPELINEDRAWING,str);
	SetDlgItemText(IDC_PROJECTID2,projectID);
	

	if (structNo!=0)
	{
		//����Structure�����ܳ���
		sql.Format("select SUM(WeldLength) from Structure Where ProjectID='%s'",projectID);
		if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
			return ;
		iRowCount=m_MyDB1->GetDataSetRowCount(1);
		
		if(!iRowCount)
			return ;
		m_MyDB1->GetDataSetFieldValue(0,0,structWeldLength);
		
		
		sql.Format("select WeldNo,WeldLength from Structure Where ProjectID='%s'",projectID);
		if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
			return ;
		iRowCount=m_MyDB1->GetDataSetRowCount(1);
		
		if(iRowCount==-1)
			iRowCount=0;
		for (int k=0;k<iRowCount;k++)
		{
			m_MyDB1->GetDataSetFieldValue(k,0,WPSNo);
			wpsno=WPSNo;
			int temp=wpsno.GetLength();
			if (wpsno.GetAt(temp-2)=='R')
			{
				m_MyDB1->GetDataSetFieldValue(k,1,SDL);
				sdl+=atof(SDL);
			}
		}
	}
	

	if (pipeNo!=0)
	{
		//����Pipeline�����ܳ���
		sql.Format("select SUM(WeldLength) from Piping Where ProjectID='%s'",projectID);
		if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
			return ;
		iRowCount=m_MyDB1->GetDataSetRowCount(1);
		
		if(iRowCount==-1)
			iRowCount=0;
		m_MyDB1->GetDataSetFieldValue(0,0,pipelineWeldLength);
		
		sql.Format("select WeldNumber,WeldLength from Piping Where ProjectID='%s'",projectID);
		if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
			return ;
		iRowCount=m_MyDB1->GetDataSetRowCount(1);
		
		if(iRowCount==-1)
			iRowCount=0;
		for (int k=0;k<iRowCount;k++)
		{
			m_MyDB1->GetDataSetFieldValue(k,0,WPSNo);
			wpsno=WPSNo;
			int temp=wpsno.GetLength();
			if (wpsno.GetAt(temp-2)=='R')
			{
				m_MyDB1->GetDataSetFieldValue(k,1,PDL);
				pdl+=atof(PDL);
			}
		}
	}
	

	tdl=sdl+pdl;
	TDL.Format("%f",tdl);

	//���������
	SetDlgItemText(IDC_STRUCTLENGTH,structWeldLength);
	SetDlgItemText(IDC_PIPELINELENGTH,pipelineWeldLength);
	totalLength=atoi(structWeldLength)+atoi(pipelineWeldLength);
	str.Format("%d",totalLength);
	SetDlgItemText(IDC_TOTALWELDLENGTH,str);
	strSdl.Format("%f",sdl);
	SetDlgItemText(IDC_SDL,strSdl);
	strPdl.Format("%f",pdl);
	SetDlgItemText(IDC_PDL,strPdl);
	SetDlgItemText(IDC_TDL,TDL);
}

void CProjectManagementDlg::OnAdddraw() 
{
	// TODO: Add your command handler code here
	CString drawName;
	if (gFilename=="Structure")
	{
		CAddStructureDrawingDlg dlg;
		dlg.projectID=projectID;
		if (dlg.DoModal()==IDOK)
		{
			drawName=dlg.DrwNo;
			if (dlg.page=="1")
			{
				m_tree.InsertItem(drawName,m_hCurrent);
			}
			InitListView();
			SetHeader();
		}
	}
	else
		if (gFilename=="Pipeline")
		{
			CAddPipelineDrawDlg dlg;
			dlg.projectID=projectID;
			if (dlg.DoModal()==IDOK)
			{
				drawName=dlg.DrwNo;
				if (dlg.page=="1")
				{
					m_tree.InsertItem(drawName,m_hCurrent);
				}
				m_tree.Invalidate(TRUE);
				InitListView();
				SetHeader();
			}
		}
}

void CProjectManagementDlg::OnEditdraw() 
{
	// TODO: Add your command handler code here
	CString drawName;

	if (gParent=="Structure")
	{
		CEditStructureDrawDlg dlg;
		dlg.ProjectID=projectID;
		dlg.DrwNo=gFilename;
		if (dlg.DoModal()==IDCANCEL)
		{
			InitListView();
			SetHeader();
		}
	}
	else
		if (gParent=="Pipeline")
		{
			CEditPipelineDrawDlg dlg;
			dlg.ProjectID=projectID;
			dlg.DrwNo=gFilename;
			if (dlg.DoModal()==IDCANCEL)
			{
				drawName=dlg.DrwNo;
				m_tree.InsertItem(drawName,m_hCurrent);
				m_tree.Invalidate(TRUE);
				InitListView();
				SetHeader();
			}
		}
}

void CProjectManagementDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	CMyExcel excel;
	excel.ExportListToExcel(&m_list,"Structure");
	excel.ExportListToExcel(&m_pipeList,"Piping");
}
