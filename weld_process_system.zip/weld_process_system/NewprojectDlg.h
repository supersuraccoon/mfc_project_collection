#if !defined(AFX_NEWPROJECTDLG_H__89FA79F4_8818_414D_B19E_C743F5A1E25D__INCLUDED_)
#define AFX_NEWPROJECTDLG_H__89FA79F4_8818_414D_B19E_C743F5A1E25D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// NewprojectDlg.h : header file
//

#include "ComboListCtrl.h"
#include "AccessDB.h"
/////////////////////////////////////////////////////////////////////////////
// CNewprojectDlg dialog

class CNewprojectDlg : public CDialog
{
// Construction
public:
	void InitWeldTypeCombo(CStringArray &strArr);
	void InitMaterialCombo(CStringArray &strArr);
	void InitWeldNoCombo(CStringArray &strArr);
	void InitWPSCombo(CStringArray& strArr);
	CNewprojectDlg(CWnd* pParent = NULL);   // standard constructor
	CString projectID;
	CString creationDate;
	CString DrwNo;
	CString DrwNumber;
	CString structNo;
	CString pipelineNo;


	CString WPSNo;
	CString WeldNo;
	CString WeldType;
	CString Status;
	CString WeldLength;
	CString Material;
	CString Block;
	CString Erection;
	CString NDT;
	CString SWeldDate;
	CString EWeldDate;
	CString inCategory;
	CString page;
	CString total;

	CAccessDB *m_MyDB;
	CString DBpath;

	int state;

// Dialog Data
	//{{AFX_DATA(CNewprojectDlg)
	enum { IDD = IDD_NEWPROJECT };
	CComboListCtrl	m_pipeList;
	CComboListCtrl	m_structList;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNewprojectDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CNewprojectDlg)
	virtual void OnOK();
	afx_msg void OnCreateproject();
	virtual BOOL OnInitDialog();
	afx_msg void OnAdvancesetting();
	afx_msg void OnSetfocusList1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSetfocusList2(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnEditsetting();
	//}}AFX_MSG
	afx_msg LRESULT OnEndLabelEditVariableCriteria(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT PopulateComboList(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NEWPROJECTDLG_H__89FA79F4_8818_414D_B19E_C743F5A1E25D__INCLUDED_)
