// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "WPS.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_TIMER()
	ON_COMMAND(ID_EXIT, OnExit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_INDICATOR_CUR,
	ID_INDICATOR_CLOCK,           // status line indicator
	//ID_INDICATOR_CAPS,
	ID_INDICATOR_INFO,
	ID_INDICATOR_LOGININFO,
	//ID_INDICATOR_NUM,
	//ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	CWPSApp* pApp=(CWPSApp*)AfxGetApp();      


	if (pApp->UserType=="Manager")
	{
		if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
			| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
			!m_wndToolBar.LoadToolBar(IDR_MYMENU))
		{
			TRACE0("Failed to create toolbar\n");
			return -1;      // fail to create
		}
		CMenu cMenu; 
		//�����µ���IDR_MENU1��ʾ�Ĳ˵���Դ�� 
		cMenu.LoadMenu(IDR_MYMENU); 
		//��cMenu����Ϊ��ǰ�˵��� 
		SetMenu(&cMenu); 
		//�ͷŲ˵���� 
		cMenu.Detach(); 
		//�ػ��˵����� 
		DrawMenuBar(); 
		//���»��ƴ������� 
		RecalcLayout(TRUE);
	}
	else
	{
		if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
			| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
			!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
		{
			TRACE0("Failed to create toolbar\n");
			return -1;      // fail to create
		}
		CMenu cMenu; 
		//�����µ���IDR_MENU1��ʾ�Ĳ˵���Դ�� 
		cMenu.LoadMenu(IDR_MAINFRAME); 
		//��cMenu����Ϊ��ǰ�˵��� 
		SetMenu(&cMenu); 
		//�ͷŲ˵���� 
		cMenu.Detach(); 
		//�ػ��˵����� 
		DrawMenuBar(); 
		//���»��ƴ������� 
		RecalcLayout(TRUE);
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	//m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	//EnableDocking(CBRS_ALIGN_ANY);
	//DockControlBar(&m_wndToolBar);


	m_wndStatusBar.SetPaneInfo(2,ID_INDICATOR_INFO,SBPS_NORMAL,80);
	m_wndStatusBar.SetPaneInfo(3,ID_INDICATOR_LOGININFO,SBPS_NORMAL,800);
	m_wndStatusBar.SetPaneText(m_wndStatusBar.CommandToIndex(ID_INDICATOR_LOGININFO),"Welcom:"+pApp->UserName);

	SetTimer(1,1000,NULL);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	//cs.cx=902;
	//cs.cy=660;
	cs.style&=~(WS_MAXIMIZEBOX|WS_THICKFRAME);   

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


void CMainFrame::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	CTime time;
	CString t="      ";
	time=CTime::GetCurrentTime();//�õ���ǰʱ��
	CString s=time.Format("%H:%M:%S");//ת��ʱ���ʽ
	
	m_wndStatusBar.SetPaneText(m_wndStatusBar.CommandToIndex(ID_INDICATOR_CLOCK),s);

	CFrameWnd::OnTimer(nIDEvent);
}

void CMainFrame::OnExit() 
{
	// TODO: Add your command handler code here
	if(MessageBox("Are you sure?","Warnning",MB_OKCANCEL)==IDOK)
	{
		PostMessage(WM_CLOSE);
	}
}
