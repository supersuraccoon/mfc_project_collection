// MyAccountDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WPS.h"
#include "MyAccountDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyAccountDlg dialog


CMyAccountDlg::CMyAccountDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMyAccountDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMyAccountDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CMyAccountDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyAccountDlg)
	DDX_Control(pDX, IDC_MYACCOUNT, m_list);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMyAccountDlg, CDialog)
	//{{AFX_MSG_MAP(CMyAccountDlg)
	ON_BN_CLICKED(IDC_CHANGEPASSWORD, OnChangepassword)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyAccountDlg message handlers

BOOL CMyAccountDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CString sql;
	CWPSApp* pApp=(CWPSApp*)AfxGetApp(); 
	id=pApp->UserID;
	CString str;
	char UserID[50];
	char name[50];
	char password[50];
	char type[50];

	sql.Format("select * from user where UserID='%s'",id);


	m_list.InsertColumn(0, "No", LVCFMT_LEFT, 35);
	m_list.InsertColumn(1, "UserID", LVCFMT_LEFT, 60);
	m_list.InsertColumn(2, "Name", LVCFMT_LEFT, 60);
	m_list.InsertColumn(3, "PassWord", LVCFMT_LEFT, 60);
	m_list.InsertColumn(4, "User Type", LVCFMT_LEFT, 60);

	DBpath=pApp->DBPath;
	
	m_MyDB = new CAccessDB(DBpath.GetBuffer(MAX_PATH),DBpath.GetBuffer(MAX_PATH),0);
	DBpath.ReleaseBuffer();

	if(!m_MyDB->OpenDB(DBpath.GetBuffer(MAX_PATH)))
	{
		AfxMessageBox("DB Open Error!");
		DBpath.ReleaseBuffer();
		return FALSE;
	}
	
	DBpath.ReleaseBuffer();
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return false;
	
	str.Format("%d",1);
	m_list.InsertItem(LVIF_TEXT|LVIF_STATE, 0, 
		str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
	
	m_MyDB->GetDataSetFieldValue(0,0,UserID);
	m_list.SetItemText(0,1,UserID);
	m_MyDB->GetDataSetFieldValue(0,1,name);
	m_list.SetItemText(0,2,name);
	m_MyDB->GetDataSetFieldValue(0,2,password);
	m_list.SetItemText(0,3,password);
	m_MyDB->GetDataSetFieldValue(0,3,type);
	m_list.SetItemText(0,4,type);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CMyAccountDlg::OnChangepassword() 
{
	// TODO: Add your control notification handler code here
	CString password="";
	CString sql;
	GetDlgItemText(IDC_PASSWORD,password);

	sql.Format("Update User SET Password='%s' where UserID='%s'",password,id);

	if (password=="")
	{
		MessageBox("The password should not be NULL !!!");
		return ;
	}
	else
	{
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			AfxMessageBox("DB Error");
		else
		{
			m_list.SetItemText(0,3,password);
			MessageBox("Success!!!");
		}
	}
}

void CMyAccountDlg::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	m_MyDB->CloseDB();
	
	CDialog::OnClose();
}
