#if !defined(AFX_EDITSTRUCTUREDRAWDLG_H__281E6070_2A3F_48DE_A0E5_CF4D45771F7A__INCLUDED_)
#define AFX_EDITSTRUCTUREDRAWDLG_H__281E6070_2A3F_48DE_A0E5_CF4D45771F7A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EditStructureDrawDlg.h : header file
//
#include "ComboListCtrl.h"
#include "AccessDB.h"
/////////////////////////////////////////////////////////////////////////////
// CEditStructureDrawDlg dialog

class CEditStructureDrawDlg : public CDialog
{
// Construction
public:
	void InitWelderCombo(CStringArray &strArr);
	BOOL CheckExistence(CString str);
	void InitList(void);
	CEditStructureDrawDlg(CWnd* pParent = NULL);   // standard constructor
	CAccessDB * m_MyDB1;
	CAccessDB * m_MyDB2;
	CString DBpath;

	void InitWeldTypeCombo(CStringArray &strArr);
	void InitMaterialCombo(CStringArray &strArr);
	void InitWeldNoCombo(CStringArray &strArr);
	void InitWPSCombo(CStringArray& strArr);

	CString ProjectID;

	char WPSNo[100];
	char WeldNo[100];
	char WeldType[100];
	char Status[100];
	char WeldLength[100];
	char Material[100];
	char Block[100];
	char Erection[100];
	char NDT[100];
	char SWeldDate[100];
	char EWeldDate[100];
	char page[100];
	char total[100];
	char Specification[100];
	char Dimension[100];
	char Thickness[100];
	char WelderNo[100];

	CString inCategory;
	CString DrwNo;
	CString strPage;
	CString strBlock;


// Dialog Data
	//{{AFX_DATA(CEditStructureDrawDlg)
	enum { IDD = IDD_EDITSTRUCTUREDRAW };
	CComboBox	m_detail;
	CComboBox	m_type;
	CComboListCtrl	m_list;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditStructureDrawDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CEditStructureDrawDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnConfirm();
	afx_msg void OnCloseupWeldtype();
	afx_msg void OnCloseupType();
	afx_msg void OnCloseupDetail();
	afx_msg void OnAdcancedsetting();
	afx_msg void OnSavechange();
	afx_msg void OnAddpage();
	//}}AFX_MSG
	afx_msg LRESULT OnEndLabelEditVariableCriteria(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT PopulateComboList(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDITSTRUCTUREDRAWDLG_H__281E6070_2A3F_48DE_A0E5_CF4D45771F7A__INCLUDED_)
