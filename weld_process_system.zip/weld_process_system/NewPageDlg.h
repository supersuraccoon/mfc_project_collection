#if !defined(AFX_NEWPAGEDLG_H__2AA67E18_33DB_4FF2_8015_A597753BC527__INCLUDED_)
#define AFX_NEWPAGEDLG_H__2AA67E18_33DB_4FF2_8015_A597753BC527__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// NewPageDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CNewPageDlg dialog

class CNewPageDlg : public CDialog
{
// Construction
public:
	CNewPageDlg(CWnd* pParent = NULL);   // standard constructor

	CString drawname;
	CString page;
	CString block;
	int totalpage;

// Dialog Data
	//{{AFX_DATA(CNewPageDlg)
	enum { IDD = IDD_INSERTPAGEDLG };
	CEdit	m_block;
	CEdit	m_drawname;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNewPageDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CNewPageDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NEWPAGEDLG_H__2AA67E18_33DB_4FF2_8015_A597753BC527__INCLUDED_)
