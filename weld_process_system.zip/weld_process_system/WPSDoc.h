// WPSDoc.h : interface of the CWPSDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_WPSDOC_H__6ED876F9_672C_4FC5_AB9E_35F787A649D3__INCLUDED_)
#define AFX_WPSDOC_H__6ED876F9_672C_4FC5_AB9E_35F787A649D3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CWPSDoc : public CDocument
{
protected: // create from serialization only
	CWPSDoc();
	DECLARE_DYNCREATE(CWPSDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWPSDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CWPSDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CWPSDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WPSDOC_H__6ED876F9_672C_4FC5_AB9E_35F787A649D3__INCLUDED_)
