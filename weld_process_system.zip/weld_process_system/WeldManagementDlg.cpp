// WeldManagementDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WPS.h"
#include "WeldManagementDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWeldManagementDlg dialog


CWeldManagementDlg::CWeldManagementDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CWeldManagementDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CWeldManagementDlg)
	//}}AFX_DATA_INIT
}


void CWeldManagementDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWeldManagementDlg)
	DDX_Control(pDX, IDC_COMBO3, m_drawtype);
	DDX_Control(pDX, IDC_LIST1, m_list);
	DDX_Control(pDX, IDC_COMBO2, m_type);
	DDX_Control(pDX, IDC_COMBO1, m_project);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWeldManagementDlg, CDialog)
	//{{AFX_MSG_MAP(CWeldManagementDlg)
	ON_CBN_CLOSEUP(IDC_COMBO1, OnCloseupCombo1)
	ON_CBN_CLOSEUP(IDC_COMBO2, OnCloseupCombo2)
	ON_BN_CLICKED(IDC_CONFIRM, OnConfirm)
	ON_CBN_CLOSEUP(IDC_COMBO3, OnCloseupCombo3)
	ON_NOTIFY(NM_RCLICK, IDC_LIST1, OnRclickList1)
	ON_COMMAND(ID_REDO, OnRedo)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWeldManagementDlg message handlers

BOOL CWeldManagementDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CString sql;
	char ProjectID[100];
	CWPSApp* pApp=(CWPSApp*)AfxGetApp();  
	DBpath=pApp->DBPath;
	
	m_MyDB1 = new CAccessDB(DBpath.GetBuffer(MAX_PATH),DBpath.GetBuffer(MAX_PATH),0);
	DBpath.ReleaseBuffer();
	
	if(!m_MyDB1->OpenDB(DBpath.GetBuffer(MAX_PATH)))
	{
		AfxMessageBox("DB Open Error!");
		DBpath.ReleaseBuffer();
		return FALSE;
	}
	
	DBpath.ReleaseBuffer();
	
	m_MyDB2 = new CAccessDB(DBpath.GetBuffer(MAX_PATH),DBpath.GetBuffer(MAX_PATH),0);
	DBpath.ReleaseBuffer();
	
	if(!m_MyDB2->OpenDB(DBpath.GetBuffer(MAX_PATH)))
	{
		AfxMessageBox("DB Open Error!");
		DBpath.ReleaseBuffer();
		return FALSE;
	}
	
	DBpath.ReleaseBuffer();


	sql="select ProjectID from Project";
	if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
		return false;
	
	int iRowCount=m_MyDB1->GetDataSetRowCount(1);
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB1->GetDataSetFieldValue(i,0,ProjectID);
		SetDlgItemText(IDC_EDIT1,ProjectID);
	}	

	
	m_drawtype.SetCurSel(0);
	DrawType="Structure";

	sql.Format("select DISTINCT(DrwNo) from Draw WHERE ProjectID='%s' AND DrType=1",ProjectID);
	if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
		return false;
	
	iRowCount=m_MyDB1->GetDataSetRowCount(1);
	
	for(i=0;i<iRowCount;i++)
	{
		m_MyDB1->GetDataSetFieldValue(i,0,DrawNo);
		m_project.AddString(DrawNo);
	}	
	m_project.SetCurSel(0);
			
	m_list.SetReadOnlyColumns(0);
	m_list.SetReadOnlyColumns(1);
	m_list.SetReadOnlyColumns(2);
	m_list.SetReadOnlyColumns(3);
	m_list.EnableVScroll(); 			
	m_list.SetExtendedStyle(LVS_EX_FULLROWSELECT);

	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CWeldManagementDlg::OnCloseupCombo1() 
{
	// TODO: Add your control notification handler code here
	
}

void CWeldManagementDlg::OnCloseupCombo2() 
{
	// TODO: Add your control notification handler code here
	
}

void CWeldManagementDlg::OnConfirm() 
{
	// TODO: Add your control notification handler code here
	CString type;
	CString sql;
	int k;

	//m_project.GetLBText(m_project.GetCurSel(),projectID);
	int nColCnt=m_list.GetHeaderCtrl()->GetItemCount();   

	m_list.DeleteAllItems();
	for(int i=0;i<nColCnt;i++)   
	{   
		if (!m_list.DeleteColumn(0))     
			AfxMessageBox("ɾ��ʧ��!");   	
	}  

	m_list.Invalidate(TRUE);

	m_type.GetLBText(m_type.GetCurSel(),type);
	if (DrawType=="Structure")
	{
		k=1;
	}
	else
		k=0;

	if(type=="VT")
	{
		InitVT(k);
	}
	else
		if (type=="RT")
		{
			InitRT(k);
		}
		else
			if (type=="PT")
			{
				InitPT(k);
			}
			else
				if (type=="UT")
				{
					InitUT(k);
				}
}

void CWeldManagementDlg::InitVT(int k)
{
	CString sql;
	CString str;
	char cid[100];
	char Extent[100];
	char Result[100];
	char ReportNo[100];
	char DefectLength[100];
	char Inspector[100];
	char TDate[100];
	char DrawName[100];
	char Block[100];
	char page[100];
	char pipeline[100];
	m_list.InsertColumn(0, "No", LVCFMT_LEFT, 30);
	m_list.InsertColumn(1, "WeldNo", LVCFMT_LEFT, 50);
	m_list.InsertColumn(2, "Block/Pipeline", LVCFMT_LEFT, 100);
	m_list.InsertColumn(3, "Page", LVCFMT_LEFT, 30);

	m_list.InsertColumn(4, "Extent", LVCFMT_LEFT, 50);
	m_list.InsertColumn(5, "Result", LVCFMT_LEFT, 50);
	m_list.InsertColumn(6, "ReportNo", LVCFMT_LEFT, 55);
	m_list.InsertColumn(7, "DLength", LVCFMT_LEFT, 50);
	m_list.InsertColumn(8, "Inspector", LVCFMT_LEFT, 70);
	m_list.InsertColumn(9, "TDate", LVCFMT_LEFT, 70);
	m_list.InsertColumn(10, "ID", LVCFMT_LEFT, 0);

	
	m_project.GetLBText(m_project.GetCurSel(),DrawName);
	sql.Format("select * from Draw WHERE DrwNo='%s'",DrawName);
	if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	
	int iRowCount=m_MyDB1->GetDataSetRowCount(1);
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB1->GetDataSetFieldValue(i,4,page);
		m_MyDB1->GetDataSetFieldValue(i,0,cid);
		if (k==1)
		{
			sql.Format("SELECT * FROM Structure Where DrwNO=%d",atoi(cid));
			if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
				return ;
			int count=m_MyDB1->GetDataSetRowCount(1);
			for (int i=0;i<count;i++)
			{
				m_MyDB1->GetDataSetFieldValue(i,4,DrawName);
				m_MyDB1->GetDataSetFieldValue(i,0,cid);
				m_MyDB1->GetDataSetFieldValue(i,12,Block);
				sql.Format("SELECT * FROM SVT WHERE DrwID=%d",atoi(cid));
				if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
					return ;
				m_MyDB2->GetDataSetFieldValue(i,2,Extent);
				m_MyDB2->GetDataSetFieldValue(i,3,Result);
				m_MyDB2->GetDataSetFieldValue(i,4,ReportNo);
				m_MyDB2->GetDataSetFieldValue(i,5,DefectLength);
				m_MyDB2->GetDataSetFieldValue(i,6,Inspector);
				m_MyDB2->GetDataSetFieldValue(i,7,TDate);
				
				str.Format("%d",i+1);
				m_list.InsertItem(LVIF_TEXT|LVIF_STATE, i, 
					str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
				m_list.SetItemText(i,1,DrawName);
				m_list.SetItemText(i,2,Block);
				m_list.SetItemText(i,3,page);
				m_list.SetItemText(i,4,Extent);
				m_list.SetItemText(i,5,Result);
				m_list.SetItemText(i,6,ReportNo);
				m_list.SetItemText(i,7,DefectLength);
				m_list.SetItemText(i,8,Inspector);
				m_list.SetItemText(i,9,TDate);
				m_list.SetItemText(i,10,cid);
			}
		}
		else
		{
			sql.Format("SELECT * FROM Piping Where DrwNO=%d",atoi(cid));
			if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
				return ;
			int count=m_MyDB1->GetDataSetRowCount(1);

			for (int i=0;i<count;i++)
			{
				m_MyDB1->GetDataSetFieldValue(i,4,DrawName);
				m_MyDB1->GetDataSetFieldValue(i,0,cid);
				m_MyDB1->GetDataSetFieldValue(i,12,pipeline);
				sql.Format("SELECT * FROM PVT WHERE DrwID=%d",atoi(cid));
				if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
					return ;
				m_MyDB2->GetDataSetFieldValue(i,2,Extent);
				m_MyDB2->GetDataSetFieldValue(i,3,Result);
				m_MyDB2->GetDataSetFieldValue(i,4,ReportNo);
				m_MyDB2->GetDataSetFieldValue(i,5,DefectLength);
				m_MyDB2->GetDataSetFieldValue(i,6,Inspector);
				m_MyDB2->GetDataSetFieldValue(i,7,TDate);
				
				str.Format("%d",i+1);
				m_list.InsertItem(LVIF_TEXT|LVIF_STATE, i, 
					str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
				m_list.SetItemText(i,1,DrawName);
				m_list.SetItemText(i,2,pipeline);
				m_list.SetItemText(i,3,page);
				m_list.SetItemText(i,4,Extent);
				m_list.SetItemText(i,5,Result);
				m_list.SetItemText(i,6,ReportNo);
				m_list.SetItemText(i,7,DefectLength);
				m_list.SetItemText(i,8,Inspector);
				m_list.SetItemText(i,9,TDate);
				m_list.SetItemText(i,10,cid);
			}
		}
	}
}

void CWeldManagementDlg::InitRT(int k)
{
	CString sql;
	CString str;
	char cid[100];
	char Extent[100];
	char Result[100];
	char ReportNo[100];
	char DLength[100];
	char TLength[100];
	char TDate[100];
	char DrawName[100];
	char Operator[100];
	char Block[100];
	char page[100];
	char pipeline[100];
	m_list.InsertColumn(0, "No", LVCFMT_LEFT, 30);
	m_list.InsertColumn(1, "WeldNo", LVCFMT_LEFT, 50);
	m_list.InsertColumn(2, "Block/Pipeline", LVCFMT_LEFT, 50);
	m_list.InsertColumn(3, "Page", LVCFMT_LEFT, 30);
	
	m_list.InsertColumn(4, "Extent", LVCFMT_LEFT, 50);
	m_list.InsertColumn(5, "Result", LVCFMT_LEFT, 50);
	m_list.InsertColumn(6, "ReportNo", LVCFMT_LEFT, 55);
	m_list.InsertColumn(7, "TLength", LVCFMT_LEFT, 50);
	m_list.InsertColumn(8, "TDate", LVCFMT_LEFT, 70);
	m_list.InsertColumn(9, "DLength", LVCFMT_LEFT, 70);
	m_list.InsertColumn(10, "Operator", LVCFMT_LEFT, 70);
	m_list.InsertColumn(11, "ID", LVCFMT_LEFT, 0);
	
	m_project.GetLBText(m_project.GetCurSel(),DrawName);
	sql.Format("select * from Draw WHERE DrwNo='%s'",DrawName);
	if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	
	int iRowCount=m_MyDB1->GetDataSetRowCount(1);
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB1->GetDataSetFieldValue(i,0,cid);
		m_MyDB1->GetDataSetFieldValue(i,4,page);
		if (k==1)
		{
			sql.Format("SELECT * FROM Structure Where DrwNO=%d",atoi(cid));
			if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
				return ;
			int count=m_MyDB1->GetDataSetRowCount(1);
			for (int i=0;i<count;i++)
			{
				m_MyDB1->GetDataSetFieldValue(i,4,DrawName);
				m_MyDB1->GetDataSetFieldValue(i,0,cid);
				m_MyDB1->GetDataSetFieldValue(i,12,Block);
				sql.Format("SELECT * FROM SRT WHERE DrwID=%d",atoi(cid));
				if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
					return ;
				m_MyDB2->GetDataSetFieldValue(i,2,Extent);
				m_MyDB2->GetDataSetFieldValue(i,3,Result);
				m_MyDB2->GetDataSetFieldValue(i,4,ReportNo);
				m_MyDB2->GetDataSetFieldValue(i,5,TLength);
				m_MyDB2->GetDataSetFieldValue(i,6,TDate);
				m_MyDB2->GetDataSetFieldValue(i,7,DLength);
				m_MyDB2->GetDataSetFieldValue(i,8,Operator);
				
				str.Format("%d",i+1);
				m_list.InsertItem(LVIF_TEXT|LVIF_STATE, i, 
					str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
				m_list.SetItemText(i,1,DrawName);
				m_list.SetItemText(i,2,Block);
				m_list.SetItemText(i,3,page);
				m_list.SetItemText(i,4,Extent);
				m_list.SetItemText(i,5,Result);
				m_list.SetItemText(i,6,ReportNo);
				m_list.SetItemText(i,7,TLength);
				m_list.SetItemText(i,8,TDate);
				m_list.SetItemText(i,9,DLength);
				m_list.SetItemText(i,10,Operator);
				m_list.SetItemText(i,11,cid);
			}	
		}
		else
		{
			sql.Format("SELECT * FROM Piping Where DrwNO=%d",atoi(cid));
			if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
				return ;
			int count=m_MyDB1->GetDataSetRowCount(1);
			for (int i=0;i<count;i++)
			{
				m_MyDB1->GetDataSetFieldValue(i,4,DrawName);
				m_MyDB1->GetDataSetFieldValue(i,0,cid);
				m_MyDB1->GetDataSetFieldValue(i,12,pipeline);
				sql.Format("SELECT * FROM PRT WHERE DrwID=%d",atoi(cid));
				if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
					return ;
				m_MyDB2->GetDataSetFieldValue(i,2,Extent);
				m_MyDB2->GetDataSetFieldValue(i,3,Result);
				m_MyDB2->GetDataSetFieldValue(i,4,ReportNo);
				m_MyDB2->GetDataSetFieldValue(i,5,TLength);
				m_MyDB2->GetDataSetFieldValue(i,6,TDate);
				m_MyDB2->GetDataSetFieldValue(i,7,DLength);
				m_MyDB2->GetDataSetFieldValue(i,8,Operator);
				
				str.Format("%d",i+1);
				m_list.InsertItem(LVIF_TEXT|LVIF_STATE, i, 
					str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
				m_list.SetItemText(i,1,DrawName);
				m_list.SetItemText(i,2,pipeline);
				m_list.SetItemText(i,3,page);
				m_list.SetItemText(i,4,Extent);
				m_list.SetItemText(i,5,Result);
				m_list.SetItemText(i,6,ReportNo);
				m_list.SetItemText(i,7,TLength);
				m_list.SetItemText(i,8,TDate);
				m_list.SetItemText(i,9,DLength);
				m_list.SetItemText(i,10,Operator);
				m_list.SetItemText(i,11,cid);
			}	
		}
	}
}

void CWeldManagementDlg::InitUT(int k)
{
	CString sql;
	CString str;
	char cid[100];
	char Extent[100];
	char Result[100];
	char ReportNo[100];
	char DLength[100];
	char TLength[100];
	char TDate[100];
	char DrawName[100];
	char Operator[100];
	char Block[100];
	char page[100];
	char pipeline[100];
	m_list.InsertColumn(0, "No", LVCFMT_LEFT, 30);
	m_list.InsertColumn(1, "WeldNo", LVCFMT_LEFT, 50);
	m_list.InsertColumn(2, "Block/Pipeline", LVCFMT_LEFT, 50);
	m_list.InsertColumn(3, "Page", LVCFMT_LEFT, 30);
	
	m_list.InsertColumn(4, "Extent", LVCFMT_LEFT, 50);
	m_list.InsertColumn(5, "Result", LVCFMT_LEFT, 50);
	m_list.InsertColumn(6, "ReportNo", LVCFMT_LEFT, 55);
	m_list.InsertColumn(7, "TLength", LVCFMT_LEFT, 50);
	m_list.InsertColumn(8, "TDate", LVCFMT_LEFT, 70);
	m_list.InsertColumn(9, "DLength", LVCFMT_LEFT, 70);
	m_list.InsertColumn(10, "Operator", LVCFMT_LEFT, 70);
	m_list.InsertColumn(11, "ID", LVCFMT_LEFT, 0);
	
	m_project.GetLBText(m_project.GetCurSel(),DrawName);
	sql.Format("select * from Draw WHERE DrwNo='%s'",DrawName);
	if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	
	int iRowCount=m_MyDB1->GetDataSetRowCount(1);
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB1->GetDataSetFieldValue(i,0,cid);
		m_MyDB1->GetDataSetFieldValue(i,4,page);
		if (k==1)
		{
			sql.Format("SELECT * FROM Structure Where DrwNO=%d",atoi(cid));
			if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
				return ;
			int count=m_MyDB1->GetDataSetRowCount(1);
			for (int i=0;i<count;i++)
			{
				m_MyDB1->GetDataSetFieldValue(i,4,DrawName);
				m_MyDB1->GetDataSetFieldValue(i,0,cid);
				m_MyDB1->GetDataSetFieldValue(i,12,Block);
				sql.Format("SELECT * FROM SUT WHERE DrwID=%d",atoi(cid));
				if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
					return ;
				m_MyDB2->GetDataSetFieldValue(i,2,Extent);
				m_MyDB2->GetDataSetFieldValue(i,3,Result);
				m_MyDB2->GetDataSetFieldValue(i,4,ReportNo);
				m_MyDB2->GetDataSetFieldValue(i,5,TLength);
				m_MyDB2->GetDataSetFieldValue(i,6,TDate);
				m_MyDB2->GetDataSetFieldValue(i,7,DLength);
				m_MyDB2->GetDataSetFieldValue(i,8,Operator);
				
				str.Format("%d",i+1);
				m_list.InsertItem(LVIF_TEXT|LVIF_STATE, i, 
					str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
				m_list.SetItemText(i,1,DrawName);
				m_list.SetItemText(i,2,Block);
				m_list.SetItemText(i,3,page);
				m_list.SetItemText(i,4,Extent);
				m_list.SetItemText(i,5,Result);
				m_list.SetItemText(i,6,ReportNo);
				m_list.SetItemText(i,7,TLength);
				m_list.SetItemText(i,8,TDate);
				m_list.SetItemText(i,9,DLength);
				m_list.SetItemText(i,10,Operator);
				m_list.SetItemText(i,11,cid);
			}	
		}
		else
		{
			sql.Format("SELECT * FROM Piping Where DrwNO=%d",atoi(cid));
			if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
				return ;
			int count=m_MyDB1->GetDataSetRowCount(1);
			for (int i=0;i<count;i++)
			{
				m_MyDB1->GetDataSetFieldValue(i,4,DrawName);
				m_MyDB1->GetDataSetFieldValue(i,0,cid);
				m_MyDB1->GetDataSetFieldValue(i,12,pipeline);
				sql.Format("SELECT * FROM PUT WHERE DrwID=%d",atoi(cid));
				if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
					return ;
				m_MyDB2->GetDataSetFieldValue(i,2,Extent);
				m_MyDB2->GetDataSetFieldValue(i,3,Result);
				m_MyDB2->GetDataSetFieldValue(i,4,ReportNo);
				m_MyDB2->GetDataSetFieldValue(i,5,TLength);
				m_MyDB2->GetDataSetFieldValue(i,6,TDate);
				m_MyDB2->GetDataSetFieldValue(i,7,DLength);
				m_MyDB2->GetDataSetFieldValue(i,8,Operator);
				
				str.Format("%d",i+1);
				m_list.InsertItem(LVIF_TEXT|LVIF_STATE, i, 
					str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
				m_list.SetItemText(i,1,DrawName);
				m_list.SetItemText(i,2,pipeline);
				m_list.SetItemText(i,3,page);
				m_list.SetItemText(i,4,Extent);
				m_list.SetItemText(i,5,Result);
				m_list.SetItemText(i,6,ReportNo);
				m_list.SetItemText(i,7,TLength);
				m_list.SetItemText(i,8,TDate);
				m_list.SetItemText(i,9,DLength);
				m_list.SetItemText(i,10,Operator);
				m_list.SetItemText(i,11,cid);
			}	
		}
	}
}

void CWeldManagementDlg::InitPT(int k)
{
	CString sql;
	CString str;
	char cid[100];
	char Extent[100];
	char Result[100];
	char ReportNo[100];
	char DLength[100];
	char TLength[100];
	char TDate[100];
	char DrawName[100];
	char Operator[100];
	char Block[100];
	char page[100];
	char pipeline[100];
	m_list.InsertColumn(0, "No", LVCFMT_LEFT, 30);
	m_list.InsertColumn(1, "WeldNo", LVCFMT_LEFT, 50);
	m_list.InsertColumn(2, "Block/Pipeline", LVCFMT_LEFT, 50);
	m_list.InsertColumn(3, "Page", LVCFMT_LEFT, 30);
	
	m_list.InsertColumn(4, "Extent", LVCFMT_LEFT, 50);
	m_list.InsertColumn(5, "Result", LVCFMT_LEFT, 50);
	m_list.InsertColumn(6, "ReportNo", LVCFMT_LEFT, 55);
	m_list.InsertColumn(7, "TLength", LVCFMT_LEFT, 50);
	m_list.InsertColumn(8, "TDate", LVCFMT_LEFT, 70);
	m_list.InsertColumn(9, "DLength", LVCFMT_LEFT, 70);
	m_list.InsertColumn(10, "Operator", LVCFMT_LEFT, 70);
	m_list.InsertColumn(11, "ID", LVCFMT_LEFT, 0);
	m_project.GetLBText(m_project.GetCurSel(),DrawName);
	sql.Format("select * from Draw WHERE DrwNo='%s'",DrawName);
	if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	
	int iRowCount=m_MyDB1->GetDataSetRowCount(1);
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB1->GetDataSetFieldValue(i,0,cid);
		m_MyDB1->GetDataSetFieldValue(i,4,page);
		if (k==1)
		{
			sql.Format("SELECT * FROM Structure Where DrwNO=%d",atoi(cid));
			if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
				return ;
			int count=m_MyDB1->GetDataSetRowCount(1);
			for (int i=0;i<count;i++)
			{
				m_MyDB1->GetDataSetFieldValue(i,4,DrawName);
				m_MyDB1->GetDataSetFieldValue(i,0,cid);
				m_MyDB1->GetDataSetFieldValue(i,12,Block);
				sql.Format("SELECT * FROM SPT WHERE DrwID=%d",atoi(cid));
				if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
					return ;
				m_MyDB2->GetDataSetFieldValue(i,2,Extent);
				m_MyDB2->GetDataSetFieldValue(i,3,Result);
				m_MyDB2->GetDataSetFieldValue(i,4,ReportNo);
				m_MyDB2->GetDataSetFieldValue(i,5,TLength);
				m_MyDB2->GetDataSetFieldValue(i,6,TDate);
				m_MyDB2->GetDataSetFieldValue(i,7,DLength);
				m_MyDB2->GetDataSetFieldValue(i,8,Operator);
				
				str.Format("%d",i+1);
				m_list.InsertItem(LVIF_TEXT|LVIF_STATE, i, 
					str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
				m_list.SetItemText(i,1,DrawName);
				m_list.SetItemText(i,2,Block);
				m_list.SetItemText(i,3,page);
				m_list.SetItemText(i,4,Extent);
				m_list.SetItemText(i,5,Result);
				m_list.SetItemText(i,6,ReportNo);
				m_list.SetItemText(i,7,TLength);
				m_list.SetItemText(i,8,TDate);
				m_list.SetItemText(i,9,DLength);
				m_list.SetItemText(i,10,Operator);
				m_list.SetItemText(i,11,cid);
			}	
		}
		else
		{
			sql.Format("SELECT * FROM Piping Where DrwNO=%d",atoi(cid));
			if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
				return ;
			int count=m_MyDB1->GetDataSetRowCount(1);
			for (int i=0;i<count;i++)
			{
				m_MyDB1->GetDataSetFieldValue(i,0,cid);
				m_MyDB1->GetDataSetFieldValue(i,12,pipeline);
				m_MyDB1->GetDataSetFieldValue(i,4,DrawName);
				sql.Format("SELECT * FROM PPT WHERE DrwID=%d",atoi(cid));
				if(!m_MyDB2->SetDataSet(NULL,sql.GetBuffer(0)))
					return ;
				m_MyDB2->GetDataSetFieldValue(i,2,Extent);
				m_MyDB2->GetDataSetFieldValue(i,3,Result);
				m_MyDB2->GetDataSetFieldValue(i,4,ReportNo);
				m_MyDB2->GetDataSetFieldValue(i,5,TLength);
				m_MyDB2->GetDataSetFieldValue(i,6,TDate);
				m_MyDB2->GetDataSetFieldValue(i,7,DLength);
				m_MyDB2->GetDataSetFieldValue(i,8,Operator);
				
				str.Format("%d",i+1);
				m_list.InsertItem(LVIF_TEXT|LVIF_STATE, i, 
					str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
				m_list.SetItemText(i,1,DrawName);
				m_list.SetItemText(i,2,pipeline);
				m_list.SetItemText(i,3,page);
				m_list.SetItemText(i,4,Extent);
				m_list.SetItemText(i,5,Result);
				m_list.SetItemText(i,6,ReportNo);
				m_list.SetItemText(i,7,TLength);
				m_list.SetItemText(i,8,TDate);
				m_list.SetItemText(i,9,DLength);
				m_list.SetItemText(i,10,Operator);
				m_list.SetItemText(i,11,cid);
			}	
		}
	}
}

void CWeldManagementDlg::OnCloseupCombo3() 
{
	// TODO: Add your control notification handler code here
	CString sql;
	m_drawtype.GetLBText(m_drawtype.GetCurSel(),DrawType);

	m_project.ResetContent();
	if (DrawType=="Structure")
	{
		sql.Format("select DISTINCT(DrwNo) from Draw WHERE DrType=1");
		if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
			return ;
		
		int iRowCount=m_MyDB1->GetDataSetRowCount(1);
		
		for(int i=0;i<iRowCount;i++)
		{
			m_MyDB1->GetDataSetFieldValue(i,0,DrawNo);
			m_project.AddString(DrawNo);
		}	
		m_project.SetCurSel(0);
	}
	else
	{
		sql.Format("select DISTINCT(DrwNo) from Draw WHERE DrType=0");
		if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
			return ;
		
		int iRowCount=m_MyDB1->GetDataSetRowCount(1);
		
		for(int i=0;i<iRowCount;i++)
		{
			m_MyDB1->GetDataSetFieldValue(i,0,DrawNo);
			m_project.AddString(DrawNo);
		}	
		m_project.SetCurSel(0);
	}
}

void CWeldManagementDlg::OnRclickList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	CPoint cp;
	gRow=m_list.GetSelectionMark();
    GetCursorPos(&cp);
    if(pNMListView->iItem == -1)
    {
        return ;
    }
    else
    {
        CMenu *pMenu = new CMenu();
		VERIFY(pMenu->CreatePopupMenu());
		pMenu->AppendMenu(MF_STRING,ID_REDO,"REDO!!!");
		
		pMenu->TrackPopupMenu(TPM_LEFTALIGN,cp.x,cp.y,this);
		pMenu->DestroyMenu();
    }	

	*pResult = 0;
}

void CWeldManagementDlg::OnRedo() 
{
	// TODO: Add your command handler code here
	CString type;
	CString ttype;
	CString sql;
	CString ID;
	CString weldNo;
	CString temp;
	char Project[100];
	
	char WPSNo[100];
	char WeldNo[100];
	char WeldType[100];
	char Status[100];
	CString WeldLength;
	char Material[100];
	char Block[100];
	char Erection[100];
	char NDT[100];
	char SWeldDate[100];
	char EWeldDate[100];
	char Specification[100];
	char Dimension[100];
	char Thickness[100];
	char WelderNo[100];
	char inCategory[100];
	char Pipeline[100];
	char DrawNo[100];

	char cid[100];
	int nid;
	int nnid;
	int length;

	int sstatus;

	ID=m_list.GetItemText(gRow,11);
	m_drawtype.GetLBText(m_drawtype.GetCurSel(),type);
	m_type.GetLBText(m_type.GetCurSel(),ttype);

	if (ttype=="VT")
	{
		WeldLength=m_list.GetItemText(gRow,7);
	}
	else
		WeldLength=m_list.GetItemText(gRow,9);

	length=atoi(WeldLength);
	if (type=="Structure")
	{
		sql.Format("select * from Structure WHERE ID=%d",atoi(ID));
		if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
			return ;
		
		m_MyDB1->GetDataSetFieldValue(0,1,Project);
		m_MyDB1->GetDataSetFieldValue(0,2,DrawNo);
		nid=atoi(DrawNo);
		m_MyDB1->GetDataSetFieldValue(0,3,WPSNo);
		m_MyDB1->GetDataSetFieldValue(0,4,WeldNo);
		m_MyDB1->GetDataSetFieldValue(0,5,WeldType);
		m_MyDB1->GetDataSetFieldValue(0,6,Specification);
		m_MyDB1->GetDataSetFieldValue(0,7,Dimension);
		m_MyDB1->GetDataSetFieldValue(0,8,Thickness);
		m_MyDB1->GetDataSetFieldValue(0,9,Status);
		sstatus=atoi(Status);
		m_MyDB1->GetDataSetFieldValue(0,10,Material);
		//m_MyDB1->GetDataSetFieldValue(0,11,WeldLength);
		m_MyDB1->GetDataSetFieldValue(0,12,Block);
		m_MyDB1->GetDataSetFieldValue(0,13,Erection);
		//m_MyDB1->GetDataSetFieldValue(0,14,SWeldDate);
		//m_MyDB1->GetDataSetFieldValue(0,15,EWeldDate);
		m_MyDB1->GetDataSetFieldValue(0,16,NDT);
		//m_MyDB1->GetDataSetFieldValue(0,17,WelderNo);

		weldNo=WeldNo;
		
		if (weldNo.Find("R1")==-1)
		{
			weldNo+="R1";
		}
		else
		{
			int temp=weldNo.GetLength()-1;
			char ch=weldNo.GetAt(temp)+1;
			weldNo.SetAt(temp,ch);
		}

		sql.Format("INSERT INTO Structure (ProjectID,DrwNO,WPSNo,WeldNo,WeldType,Status,WeldLength,Block,NDT) VALUES('%s',%d,'%s','%s','%s',%d,%d,'%s','%s')",Project,nid,WPSNo,weldNo,WeldType,sstatus,length,Block,NDT);
		if(!m_MyDB1->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;
		
		sql="select ID from Structure";
		if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
			return ;
		int count=m_MyDB1->GetDataSetRowCount(1);
		m_MyDB1->GetDataSetFieldValue(count-1,0,cid);
		nnid=atoi(cid);
		
		sql.Format("INSERT INTO SVT (DrwID,Extent,Result,ReportNo,DefectLength,Inspector,TDate) VALUES(%d,%d,NULL,NULL,%d,NULL,NULL)",nnid,100,0);
		if(!m_MyDB1->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;
		
		sql.Format("INSERT INTO SPT (DrwID,Extent,Result,ReportNo,TLength,TDate,DLength,Operator) VALUES(%d,%d,NULL,NULL,%d,NULL,NULL,NULL)",nnid,100,0);
		if(!m_MyDB1->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;
		
		sql.Format("INSERT INTO SUT (DrwID,Extent,Result,ReportNo,TLength,TDate,DLength,Operator) VALUES(%d,%d,NULL,NULL,%d,NULL,NULL,NULL)",nnid,100,0);
		if(!m_MyDB1->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;
		
		sql.Format("INSERT INTO SRT (DrwID,Extent,Result,ReportNo,TLength,TDate,DLength,Operator) VALUES(%d,%d,NULL,NULL,%d,NULL,NULL,NULL)",nnid,100,0);
		if(!m_MyDB1->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;
	}
	else
	{
		sql.Format("select * from Piping WHERE ID=%d",atoi(ID));
		if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
			return ;
		m_MyDB1->GetDataSetFieldValue(0,1,Project);
		m_MyDB1->GetDataSetFieldValue(0,2,DrawNo);
		nid=atoi(DrawNo);
		m_MyDB1->GetDataSetFieldValue(0,3,WPSNo);
		m_MyDB1->GetDataSetFieldValue(0,4,WeldNo);
		m_MyDB1->GetDataSetFieldValue(0,5,WeldType);
		m_MyDB1->GetDataSetFieldValue(0,6,Specification);
		m_MyDB1->GetDataSetFieldValue(0,7,Dimension);
		m_MyDB1->GetDataSetFieldValue(0,8,Thickness);
		m_MyDB1->GetDataSetFieldValue(0,9,Material);
		//m_MyDB1->GetDataSetFieldValue(0,10,WeldLength);
		m_MyDB1->GetDataSetFieldValue(0,11,inCategory);
		m_MyDB1->GetDataSetFieldValue(0,12,Pipeline);
		m_MyDB1->GetDataSetFieldValue(0,13,NDT);

		weldNo=WeldNo;
		
		if (weldNo.Find("R1")==-1)
		{
			weldNo+="R1";
		}
		else
		{
			int temp=weldNo.GetLength()-1;
			char ch=weldNo.GetAt(temp)+1;
			weldNo.SetAt(temp,ch);
		}

		sql.Format("INSERT INTO Piping (ProjectID,DrwNO,WPSNo,WeldNumber,WeldType,WeldLength,Pipeline,NDT) VALUES('%s',%d,'%s','%s','%s',%d,'%s','%s','%s','%s')",projectID,nid,WPSNo,weldNo,WeldType,length,Pipeline,NDT);
		
		if(!m_MyDB1->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;
		
		sql="select ID from Piping";
		if(!m_MyDB1->SetDataSet(NULL,sql.GetBuffer(0)))
			return ;
		int count=m_MyDB1->GetDataSetRowCount(1);
		m_MyDB1->GetDataSetFieldValue(count-1,0,cid);
		nnid=atoi(cid);
		
		sql.Format("INSERT INTO PVT (DrwID,Extent,Result,ReportNo,DefectLength,Inspector,TDate) VALUES(%d,%d,NULL,NULL,%d,NULL,NULL)",nnid,100,0);
		if(!m_MyDB1->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;
		
		sql.Format("INSERT INTO PPT (DrwID,Extent,Result,ReportNo,TLength,TDate,DLength,Operator) VALUES(%d,%d,NULL,NULL,%d,NULL,NULL,NULL)",nnid,100,0);
		if(!m_MyDB1->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;
		
		sql.Format("INSERT INTO PUT (DrwID,Extent,Result,ReportNo,TLength,TDate,DLength,Operator) VALUES(%d,%d,NULL,NULL,%d,NULL,NULL,NULL)",nnid,100,0);
		if(!m_MyDB1->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;
		
		sql.Format("INSERT INTO PRT (DrwID,Extent,Result,ReportNo,TLength,TDate,DLength,Operator) VALUES(%d,%d,NULL,NULL,%d,NULL,NULL,NULL)",nnid,100,0);
		if(!m_MyDB1->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;
	}
}

BOOL CWeldManagementDlg::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(pMsg->message == WM_KEYDOWN)
    {
        switch(pMsg->wParam)
        {
        case VK_RETURN: 
            // [RETURN] key����
            m_list.GoToNextItem();
            return TRUE;
		case VK_DOWN:
			m_list.GoDownToNextItem();
			return TRUE;
        }
    }

	return CDialog::PreTranslateMessage(pMsg);
}
LRESULT CWeldManagementDlg::PopulateComboList(WPARAM wParam, LPARAM lParam)
{
	// Get the Combobox window pointer
	CComboBox* pInPlaceCombo = static_cast<CComboBox*> (GetFocus());
	// Get the inplace combbox top left
	CRect obWindowRect;
	
	pInPlaceCombo->GetWindowRect(&obWindowRect);
	
	CPoint obInPlaceComboTopLeft(obWindowRect.TopLeft());
	
	// Get the active list
	// Get the control window rect
	// If the inplace combobox top left is in the rect then
	// The control is the active control
	m_list.GetWindowRect(&obWindowRect);
	
	int iColIndex = (int )wParam;
	
	CStringList* pComboList = reinterpret_cast<CStringList*>(lParam);
	pComboList->RemoveAll();
	
	if (obWindowRect.PtInRect(obInPlaceComboTopLeft)) 
	{				
		if(iColIndex==4)
		{
			pComboList->AddTail("Manager");
			pComboList->AddTail("Worker");
		}		
	}
	return true;
}

LRESULT CWeldManagementDlg::OnEndLabelEditVariableCriteria(WPARAM wParam, LPARAM lParam) 
{
	LV_DISPINFO* pDispInfo = (LV_DISPINFO*)lParam;
	// TODO: Add your control notification handler code here
	
	return 1;
}

void CWeldManagementDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	CString Extent="";
	CString Result="";
	CString ReportNo="";
	CString DefectLength="";
	CString Inspector="";
	CString TDate="";
	CString TLength="";
	CString Operator="";
	CString id;
	CString sql;
	
	int nid;
	int nExtent;
	int nReportNo;
	int nDefectLength;
	CString ttype;
	CString type;
	m_drawtype.GetLBText(m_drawtype.GetCurSel(),type);
	m_type.GetLBText(m_type.GetCurSel(),ttype);
	for(int i=0;i<m_list.GetItemCount();i++)
	{
		if (ttype=="VT")
		{
			Extent=m_list.GetItemText(i,4);
			nExtent=atoi(Extent);
			Result=m_list.GetItemText(i,5);
			ReportNo=m_list.GetItemText(i,6);
			nReportNo=atoi(ReportNo);
			Dlength=m_list.GetItemText(i,7);
			nDefectLength=atoi(DefectLength);
			Inspector=m_list.GetItemText(i,8);
			TDate=m_list.GetItemText(i,9);
			id=m_list.GetItemText(i,10);
			nid=atoi(id);
					
			if (type=="Structure")
			{
				sql.Format("UPDATE SVT SET Extent=%d,Result='%s',ReportNo=%d,DefectLength=%d,Inspector='%s',TDate='%s' WHERE DrwID=%d",nExtent,Result,nReportNo,nDefectLength,Inspector,TDate,nid);
				
				if(!m_MyDB1->ExecSQL((unsigned char *)sql.GetBuffer(0)))
				return ;
			}
			else
			{
				sql.Format("UPDATE PVT SET Extent=%d,Result='%s',ReportNo=%d,DefectLength=%d,Inspector='%s',TDate='%s' WHERE DrwID=%d",nExtent,Result,nReportNo,nDefectLength,Inspector,TDate,nid);
				
				if(!m_MyDB1->ExecSQL((unsigned char *)sql.GetBuffer(0)))
				return ;
			}
		}

		else
		{

		}
	}
	MessageBox("Saving change over!");
}
