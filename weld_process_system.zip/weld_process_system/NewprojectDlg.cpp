// NewprojectDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WPS.h"
#include "NewprojectDlg.h"
#include "AdvancedSettingDlg.h"
#include "EditDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNewprojectDlg dialog


CNewprojectDlg::CNewprojectDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CNewprojectDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNewprojectDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	state=0;
}


void CNewprojectDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNewprojectDlg)
	DDX_Control(pDX, IDC_LIST2, m_pipeList);
	DDX_Control(pDX, IDC_LIST1, m_structList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNewprojectDlg, CDialog)
	//{{AFX_MSG_MAP(CNewprojectDlg)
	ON_BN_CLICKED(IDC_CREATEPROJECT, OnCreateproject)
	ON_BN_CLICKED(IDC_ADVANCESETTING, OnAdvancesetting)
	ON_NOTIFY(NM_SETFOCUS, IDC_LIST1, OnSetfocusList1)
	ON_NOTIFY(NM_SETFOCUS, IDC_LIST2, OnSetfocusList2)
	ON_BN_CLICKED(IDC_EDITSETTING, OnEditsetting)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_VALIDATE, OnEndLabelEditVariableCriteria)
	ON_MESSAGE(WM_SET_ITEMS, PopulateComboList)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNewprojectDlg message handlers

void CNewprojectDlg::OnOK() 
{
	// TODO: Add extra validation here
	CString strDrwNo="";
	CString strWpsNo="";
	CString strWeldNo="";
	CString strWeldType="";
	CString strSpecification="";
	CString strDimension="";
	CString strThickness="";
	CString strStatus="";
	CString strMaterial="";
	CString strWeldLength="";
	CString strBlock="";
	CString strErection="";
	CString strSWeldDate="";
	CString strEWeldDate="";
	CString strNdt="";
	CString strPage="";
	CString strTotal="";
	CString strInCategory="";
	CString strPipeline="";
	char cid[100];

	int nSpecification=0;
	int nDimension=0;
	int nThickness=0;
	int nStatus=0;
	int nWeldLength=0;
	int nPage=0;
	int nTotal=0;
	int nid;

	CString sql;
	sql.Format("INSERT INTO PP (ProjectID) VALUES('%s')",projectID);

	if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			AfxMessageBox("DB Error");

	for(int i=0;i<m_structList.GetItemCount();i++)
	{
		strDrwNo=m_structList.GetItemText(i,1);
		strWpsNo=m_structList.GetItemText(i,2);
		strWeldNo=m_structList.GetItemText(i,3);
		strWeldType=m_structList.GetItemText(i,4);
		strSpecification=m_structList.GetItemText(i,5);
		nSpecification=atoi(strSpecification);
		strDimension=m_structList.GetItemText(i,6);
		nDimension=atoi(strDimension);
		strThickness=m_structList.GetItemText(i,7);
		nThickness=atoi(strThickness);
		strStatus=m_structList.GetItemText(i,8);
		nStatus=atoi(strStatus);
		strMaterial=m_structList.GetItemText(i,9);
		strWeldLength=m_structList.GetItemText(i,10);
		nWeldLength=atoi(strWeldLength);
		strBlock=m_structList.GetItemText(i,11);
		strErection=m_structList.GetItemText(i,12);
		strSWeldDate=m_structList.GetItemText(i,13);
		strEWeldDate=m_structList.GetItemText(i,14);
		strNdt=m_structList.GetItemText(i,15);
		strPage=m_structList.GetItemText(i,16);
		nPage=atoi(strPage);
		strTotal=m_structList.GetItemText(i,17);
		nTotal=atoi(strTotal);

		sql.Format("INSERT INTO Draw (DrwNo,ProjectID,Total,Page,DrType) VALUES('%s','%s',%d,%d,1)",strDrwNo,projectID,nTotal,nPage);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			AfxMessageBox("DB Error");
		
		sql="select ID from Draw";
		if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
			return ;
		int count=m_MyDB->GetDataSetRowCount(1);
		m_MyDB->GetDataSetFieldValue(count-1,0,cid);
		nid=atoi(cid);


		sql.Format("INSERT INTO DD (DrwNO) VALUES(%d)",nid);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;

		sql.Format("INSERT INTO Structure (ProjectID,DrwNO,WPSNo,WeldNo,WeldType,Specification,Dimension,Thickness,Status,Material,WeldLength,Block,Erection,SWeldDate,EWeldDate,NDT) VALUES('%s',%d,'%s','%s','%s',%d,%d,%d,%d,'%s',%d,'%s','%s','%s','%s','%s')",projectID,nid,strWpsNo,strWeldNo,strWeldType,nSpecification,nDimension,nThickness,nStatus,strMaterial,nWeldLength,strBlock,strErection,strSWeldDate,strEWeldDate,strNdt);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;

		sql.Format("INSERT INTO VT (DrwID,Extent,Result,ReportNo,DefectLength,Inspector,TDate) VALUES(%d,%d,NULL,NULL,%d,NULL,NULL)",nid,100,0);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;

		sql.Format("INSERT INTO PT (DrwID,Extent,Result,ReportNo,TLength,TDate,DLength,Operator) VALUES(%d,%d,NULL,NULL,%d,NULL,NULL,NULL)",nid,100,0);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;

		sql.Format("INSERT INTO UT (DrwID,Extent,Result,ReportNo,TLength,TDate,DLength,Operator) VALUES(%d,%d,NULL,NULL,%d,NULL,NULL,NULL)",nid,100,0);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;

		sql.Format("INSERT INTO RT (DrwID,Extent,Result,ReportNo,TLength,TDate,DLength,Operator) VALUES(%d,%d,NULL,NULL,%d,NULL,NULL,NULL)",nid,100,0);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;
	}

	for(i=0;i<m_pipeList.GetItemCount();i++)
	{
		strDrwNo=m_pipeList.GetItemText(i,1);
		strWpsNo=m_pipeList.GetItemText(i,2);
		strWeldNo=m_pipeList.GetItemText(i,3);
		strWeldType=m_pipeList.GetItemText(i,4);
		strSpecification=m_pipeList.GetItemText(i,5);
		nSpecification=atoi(strSpecification);
		strDimension=m_pipeList.GetItemText(i,6);
		nDimension=atoi(strDimension);
		strThickness=m_pipeList.GetItemText(i,7);
		nThickness=atoi(strThickness);
		strMaterial=m_pipeList.GetItemText(i,8);
		strWeldLength=m_pipeList.GetItemText(i,9);
		nWeldLength=atoi(strWeldLength);
		strInCategory=m_pipeList.GetItemText(i,10);
		strPipeline=m_pipeList.GetItemText(i,11);
		strNdt=m_pipeList.GetItemText(i,12);
		strPage=m_pipeList.GetItemText(i,13);
		nPage=atoi(strPage);
		strTotal=m_pipeList.GetItemText(i,14);
		nTotal=atoi(strTotal);
		
		sql.Format("INSERT INTO Draw (DrwNo,ProjectID,Total,Page,DrType) VALUES('%s','%s',%d,%d,0)",strDrwNo,projectID,nTotal,nPage);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			AfxMessageBox("DB Error");
		
		sql="select ID from Draw";
		if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
			return ;
		int count=m_MyDB->GetDataSetRowCount(1);
		m_MyDB->GetDataSetFieldValue(count-1,0,cid);
		nid=atoi(cid);
		
		
		sql.Format("INSERT INTO DD (DrwNO) VALUES(%d)",nid);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;
		
		sql.Format("INSERT INTO Piping (ProjectID,DrwNO,WPSNo,WeldNumber,WeldType,Specification,Dimension,Thickness,Material,WeldLength,InCategory,Pipeline,NDT) VALUES('%s',%d,'%s','%s','%s',%d,%d,%d,'%s',%d,'%s','%s','%s')",projectID,nid,strWpsNo,strWeldNo,strWeldType,nSpecification,nDimension,nThickness,strMaterial,nWeldLength,strInCategory,strPipeline,strNdt);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
				return ;

			sql.Format("INSERT INTO VT (DrwID,Extent,Result,ReportNo,DefectLength,Inspector,TDate) VALUES(%d,%d,NULL,NULL,%d,NULL,NULL)",nid,100,0);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;
		
		sql.Format("INSERT INTO PT (DrwID,Extent,Result,ReportNo,TLength,TDate,DLength,Operator) VALUES(%d,%d,NULL,NULL,%d,NULL,NULL,NULL)",nid,100,0);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;
		
		sql.Format("INSERT INTO UT (DrwID,Extent,Result,ReportNo,TLength,TDate,DLength,Operator) VALUES(%d,%d,NULL,NULL,%d,NULL,NULL,NULL)",nid,100,0);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;
		
		sql.Format("INSERT INTO RT (DrwID,Extent,Result,ReportNo,TLength,TDate,DLength,Operator) VALUES(%d,%d,NULL,NULL,%d,NULL,NULL,NULL)",nid,100,0);
			if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;
	}

	sql.Format("INSERT INTO Project(ProjectID,CreationDate) VALUES('%s','%s')",projectID,creationDate);
	if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			AfxMessageBox("DB Error");
	
	CDialog::OnOK();
}

void CNewprojectDlg::OnCreateproject() 
{
	// TODO: Add your control notification handler code here
	GetDlgItemText(IDC_PROJECTID,projectID);
	GetDlgItemText(IDC_CREATIONDATE1,creationDate);
	GetDlgItemText(IDC_DRWNO,DrwNumber);
	GetDlgItemText(IDC_STRUCTNO,structNo);
	GetDlgItemText(IDC_PIPELINENO,pipelineNo);
	
	if (projectID==""||structNo==""||creationDate==""||DrwNumber==""||pipelineNo=="")
	{
		MessageBox("Project Infomation Incomplete!!!");
		return ;
	}

	int nstructNo=atoi(structNo);
	int npipeNo=atoi(pipelineNo);
	int totalpage=atoi(total);
	CString str;
	
	for(int i=0;i<nstructNo;i++)
	{	
		CString temp=DrwNo+"-";
		CString strno;
		strno.Format("%d",i+1);
		temp+=strno;
		for (int j=0;j<totalpage;j++)
		{
			str.Format("%d",j+i*totalpage+1);
			m_structList.InsertItem(LVIF_TEXT|LVIF_STATE, j+i*totalpage, 
			str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);

			m_structList.SetItemText(j+i*totalpage,1,temp);
			m_structList.SetItemText(j+i*totalpage,2,WPSNo);
			m_structList.SetItemText(j+i*totalpage,3,WeldNo);
			m_structList.SetItemText(j+i*totalpage,4,WeldType);
			m_structList.SetItemText(j+i*totalpage,8,Status);
			m_structList.SetItemText(j+i*totalpage,9,Material);
			m_structList.SetItemText(j+i*totalpage,10,WeldLength);
			m_structList.SetItemText(j+i*totalpage,11,Block);
			m_structList.SetItemText(j+i*totalpage,12,Erection);
			m_structList.SetItemText(j+i*totalpage,13,SWeldDate);
			m_structList.SetItemText(j+i*totalpage,14,EWeldDate);
			m_structList.SetItemText(j+i*totalpage,15,NDT);
			CString spage;
			spage.Format("%d",j+1);
			m_structList.SetItemText(j+i*totalpage,16,spage);
			m_structList.SetItemText(j+i*totalpage,17,total);
		}
	}
	
	Invalidate(TRUE);
	
	for(i=0;i<npipeNo;i++)
	{	
		CString temp=DrwNo+"-";
		CString strno;
		strno.Format("%d",i+1);
		temp+=strno;
		for (int j=0;j<totalpage;j++)
		{
			str.Format("%d",j+i*totalpage+1);
			m_pipeList.InsertItem(LVIF_TEXT|LVIF_STATE, j+i*totalpage, 
				str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
			m_pipeList.SetItemText(j+i*totalpage,1,temp);
			m_pipeList.SetItemText(j+i*totalpage,2,WPSNo);
			m_pipeList.SetItemText(j+i*totalpage,3,WeldNo);
			m_pipeList.SetItemText(j+i*totalpage,4,WeldType);
			m_pipeList.SetItemText(j+i*totalpage,8,Material);
			m_pipeList.SetItemText(j+i*totalpage,9,WeldLength);
			m_pipeList.SetItemText(j+i*totalpage,10,inCategory);
			m_pipeList.SetItemText(j+i*totalpage,12,NDT);
			CString spage;
			spage.Format("%d",j+1);
			m_pipeList.SetItemText(j+i*totalpage,13,spage);
			m_pipeList.SetItemText(j+i*totalpage,14,total);
		}
	}
}

BOOL CNewprojectDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CWPSApp* pApp=(CWPSApp*)AfxGetApp();  
	DBpath=pApp->DBPath;
	
	m_MyDB = new CAccessDB(DBpath.GetBuffer(MAX_PATH),DBpath.GetBuffer(MAX_PATH),0);
	DBpath.ReleaseBuffer();
	
	if(!m_MyDB->OpenDB(DBpath.GetBuffer(MAX_PATH)))
	{
		AfxMessageBox("DB Open Error!");
		DBpath.ReleaseBuffer();
		return FALSE;
	}
	
	DBpath.ReleaseBuffer();

	m_structList.InsertColumn(0, "No", LVCFMT_LEFT, 30);
	m_structList.InsertColumn(1, "DrwNo", LVCFMT_LEFT, 50);
	m_structList.InsertColumn(2, "WPSNo", LVCFMT_LEFT, 50);
	m_structList.InsertColumn(3, "WeldNo", LVCFMT_LEFT, 50);
	m_structList.InsertColumn(4, "WeldType", LVCFMT_LEFT, 55);
	m_structList.InsertColumn(5, "Spec.", LVCFMT_LEFT, 50);
	m_structList.InsertColumn(6, "Dimension", LVCFMT_LEFT, 70);
	m_structList.InsertColumn(7, "Thickness", LVCFMT_LEFT, 70);
	m_structList.InsertColumn(8, "Status", LVCFMT_LEFT, 50);
	m_structList.InsertColumn(9, "Material", LVCFMT_LEFT, 55);
	m_structList.InsertColumn(10, "WeldLength", LVCFMT_LEFT, 70);
	m_structList.InsertColumn(11, "Block", LVCFMT_LEFT, 50);
	m_structList.InsertColumn(12, "Erection", LVCFMT_LEFT, 70);
	m_structList.InsertColumn(13, "SDate", LVCFMT_LEFT, 70);
	m_structList.InsertColumn(14, "EDate", LVCFMT_LEFT, 70);
	m_structList.InsertColumn(15, "NDT", LVCFMT_LEFT, 30);
	m_structList.InsertColumn(16, "Page", LVCFMT_LEFT, 40);
	m_structList.InsertColumn(17, "Total", LVCFMT_LEFT, 40);

	
	CString strValidChars;//	
	m_structList.SetReadOnlyColumns(0);//read only
	
	strValidChars = "0123456789.";
	m_structList.SetColumnValidEditCtrlCharacters(strValidChars,7);//none control edit 
	m_structList.SetColumnValidEditCtrlCharacters(strValidChars,8);
	m_structList.SetColumnValidEditCtrlCharacters(strValidChars,10);
	m_structList.SetColumnValidEditCtrlCharacters(strValidChars,16);
	m_structList.SetColumnValidEditCtrlCharacters(strValidChars,17);
	
	//strValidChars = "0123456789.";
	strValidChars = "";
	
	
	m_structList.SetComboColumns(2,TRUE);
	m_structList.SetComboColumns(3,TRUE);
	m_structList.SetComboColumns(4,TRUE);
	m_structList.SetComboColumns(8,TRUE);
	m_structList.SetComboColumns(9,TRUE);

	m_structList.EnableVScroll(); 			
	m_structList.SetExtendedStyle(LVS_EX_FULLROWSELECT);


	m_pipeList.InsertColumn(0, "No", LVCFMT_LEFT, 30);
	m_pipeList.InsertColumn(1, "DrwNo", LVCFMT_LEFT, 50);
	m_pipeList.InsertColumn(2, "WPSNo", LVCFMT_LEFT, 50);
	m_pipeList.InsertColumn(3, "WeldNo", LVCFMT_LEFT, 50);
	m_pipeList.InsertColumn(4, "WeldType", LVCFMT_LEFT, 55);
	m_pipeList.InsertColumn(5, "Spec.", LVCFMT_LEFT, 50);
	m_pipeList.InsertColumn(6, "Dimension", LVCFMT_LEFT, 70);
	m_pipeList.InsertColumn(7, "Thickness", LVCFMT_LEFT, 70);
	m_pipeList.InsertColumn(8, "Material", LVCFMT_LEFT, 55);
	m_pipeList.InsertColumn(9, "WeldLength", LVCFMT_LEFT, 70);
	m_pipeList.InsertColumn(10, "InCategory", LVCFMT_LEFT, 70);
	m_pipeList.InsertColumn(11, "Pipeline", LVCFMT_LEFT, 65);
	m_pipeList.InsertColumn(12, "NDT", LVCFMT_LEFT, 30);
	m_pipeList.InsertColumn(13, "Page", LVCFMT_LEFT, 40);
	m_pipeList.InsertColumn(14, "Total", LVCFMT_LEFT, 40);

	m_pipeList.SetReadOnlyColumns(0);//read only
	
	strValidChars = "0123456789.";
	m_pipeList.SetColumnValidEditCtrlCharacters(strValidChars,7);//none control edit 
	m_pipeList.SetColumnValidEditCtrlCharacters(strValidChars,9);
	m_pipeList.SetColumnValidEditCtrlCharacters(strValidChars,13);
	m_pipeList.SetColumnValidEditCtrlCharacters(strValidChars,14);
	
	m_pipeList.SetComboColumns(2,TRUE);
	m_pipeList.SetComboColumns(3,TRUE);
	m_pipeList.SetComboColumns(4,TRUE);
	m_pipeList.SetComboColumns(7,TRUE);
	m_pipeList.EnableVScroll(); 			
	m_pipeList.SetExtendedStyle(LVS_EX_FULLROWSELECT);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

LRESULT CNewprojectDlg::PopulateComboList(WPARAM wParam, LPARAM lParam)
{
	// Get the Combobox window pointer
	CStringArray strArr;

	CComboBox* pInPlaceCombo = static_cast<CComboBox*> (GetFocus());
	CComboBox* pInPlaceCombo1 = static_cast<CComboBox*> (GetFocus());
	
	// Get the inplace combbox top left
	CRect obWindowRect;
	CRect obWindowRect1;
	
	pInPlaceCombo->GetWindowRect(&obWindowRect);
	pInPlaceCombo1->GetWindowRect(&obWindowRect1);
	
	CPoint obInPlaceComboTopLeft(obWindowRect.TopLeft());
	CPoint obInPlaceComboTopLeft1(obWindowRect1.TopLeft());
	
	// Get the active list
	// Get the control window rect
	// If the inplace combobox top left is in the rect then
	// The control is the active control
	m_structList.GetWindowRect(&obWindowRect);
	m_pipeList.GetWindowRect(&obWindowRect1);
	
	int iColIndex = (int )wParam;
	int iColIndex1 = (int )wParam;
	
	CStringList* pComboList = reinterpret_cast<CStringList*>(lParam);
	pComboList->RemoveAll();
	
	CStringList* pComboList1 = reinterpret_cast<CStringList*>(lParam);
	pComboList1->RemoveAll();
	
	if (obWindowRect.PtInRect(obInPlaceComboTopLeft)) 
	{				
		if(iColIndex==2)
		{
			InitWPSCombo(strArr);
			for (int i=0;i<strArr.GetSize();i++)
			{
				pComboList->AddTail(strArr.GetAt(i));
			}
			strArr.RemoveAll();
		}		
		else
			if (iColIndex==3)
			{
				InitWeldNoCombo(strArr);
				for (int i=0;i<strArr.GetSize();i++)
				{
					pComboList->AddTail(strArr.GetAt(i));
				}
				strArr.RemoveAll();
			}
			else
				if (iColIndex==4)
				{
					InitWeldTypeCombo(strArr);
					for (int i=0;i<strArr.GetSize();i++)
					{
						pComboList->AddTail(strArr.GetAt(i));
					}
					strArr.RemoveAll();
				}
				else
					if (iColIndex==8)
					{
						pComboList->AddTail("1");
						pComboList->AddTail("2");
						pComboList->AddTail("3");
					}
					else
						if (iColIndex==9)
						{
							InitMaterialCombo(strArr);
							for (int i=0;i<strArr.GetSize();i++)
							{
								pComboList->AddTail(strArr.GetAt(i));
							}
							strArr.RemoveAll();
						}
	}

	
	if (obWindowRect1.PtInRect(obInPlaceComboTopLeft1)) 
	{				
		if(iColIndex==2)
		{
			InitWPSCombo(strArr);
			for (int i=0;i<strArr.GetSize();i++)
			{
				pComboList1->AddTail(strArr.GetAt(i));
			}
			strArr.RemoveAll();
		}
		else
			if (iColIndex==3)
			{
				InitWeldNoCombo(strArr);
				for (int i=0;i<strArr.GetSize();i++)
				{
					pComboList1->AddTail(strArr.GetAt(i));
				}
				strArr.RemoveAll();
			}
			else
				if (iColIndex==4)
				{
					InitWeldTypeCombo(strArr);
					for (int i=0;i<strArr.GetSize();i++)
					{
						pComboList1->AddTail(strArr.GetAt(i));
					}
					strArr.RemoveAll();
				}	
				else
					if (iColIndex==8)
					{
						InitMaterialCombo(strArr);
						for (int i=0;i<strArr.GetSize();i++)
						{
							pComboList1->AddTail(strArr.GetAt(i));
						}
						strArr.RemoveAll();
					}
	}
	return true;
}

LRESULT CNewprojectDlg::OnEndLabelEditVariableCriteria(WPARAM wParam, LPARAM lParam) 
{
	LV_DISPINFO* pDispInfo = (LV_DISPINFO*)lParam;
	// TODO: Add your control notification handler code here
	
	return 1;
}

void CNewprojectDlg::OnAdvancesetting() 
{
	// TODO: Add your control notification handler code here
	CAdvancedSettingDlg dlg;
	if (dlg.DoModal()==IDOK)
	{
		 WPSNo=dlg.WPSNo;
		 WeldNo=dlg.WeldNo;
		 WeldType=dlg.WeldType;
		 Status=dlg.Status;
		 WeldLength=dlg.WeldLength;
		 Material=dlg.Material;
		 Block=dlg.Block;
		 Erection=dlg.Erection;
		 NDT=dlg.NDT;
		 SWeldDate=dlg.SWeldDate;
		 EWeldDate=dlg.EWeldDate;
		 inCategory=dlg.inCategory;
		 DrwNo=dlg.DrawNo;
		 total=dlg.Total;
	}
}

BOOL CNewprojectDlg::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(pMsg->message == WM_KEYDOWN)
    {
        switch(pMsg->wParam)
        {
        case VK_RETURN: 
            // [RETURN] key����
			if (state==1)
			{
				m_structList.GoToNextItem();
			}
			else
				if (state==2)
				{
					m_pipeList.GoToNextItem();
				}
			
            return TRUE;
        }
    }
	
	return CDialog::PreTranslateMessage(pMsg);
}

void CNewprojectDlg::OnSetfocusList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	state=1;

	*pResult = 0;
}

void CNewprojectDlg::OnSetfocusList2(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	state=2;
	
	*pResult = 0;
}

void CNewprojectDlg::OnEditsetting() 
{
	// TODO: Add your control notification handler code here
	CEditDlg dlg;
	if (dlg.DoModal()==IDOK)
	{
		
	}
}

void CNewprojectDlg::InitWPSCombo(CStringArray &strArr)
{
	CString sql="select * from WPSNoType";
	char WPSNo[100];
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	
	int iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,WPSNo);
		strArr.Add(WPSNo);
	}
}

void CNewprojectDlg::InitWeldNoCombo(CStringArray &strArr)
{
	CString sql="select * from WeldNoType";
	char WeldNo[100];
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	
	int iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,WeldNo);
		strArr.Add(WeldNo);
	}
}

void CNewprojectDlg::InitMaterialCombo(CStringArray &strArr)
{
	CString sql="select * from MaterialType";
	char Material[100];
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	
	int iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,Material);
		strArr.Add(Material);
	}
}

void CNewprojectDlg::InitWeldTypeCombo(CStringArray &strArr)
{
	CString sql="select * from WeldType";
	char WeldType[100];
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	
	int iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,WeldType);
		strArr.Add(WeldType);
	}
}
