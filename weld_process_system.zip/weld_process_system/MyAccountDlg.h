#if !defined(AFX_MYACCOUNTDLG_H__F46FC104_D9B8_4A81_A7EF_515FF9DDFAE6__INCLUDED_)
#define AFX_MYACCOUNTDLG_H__F46FC104_D9B8_4A81_A7EF_515FF9DDFAE6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MyAccountDlg.h : header file
//

#include "AccessDB.h"
/////////////////////////////////////////////////////////////////////////////
// CMyAccountDlg dialog

class CMyAccountDlg : public CDialog
{
// Construction
public:
	CMyAccountDlg(CWnd* pParent = NULL);   // standard constructor
	CAccessDB * m_MyDB;
	CString id;
	CString DBpath;

// Dialog Data
	//{{AFX_DATA(CMyAccountDlg)
	enum { IDD = IDD_MYACCOUNT };
	CListCtrl	m_list;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyAccountDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMyAccountDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnChangepassword();
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYACCOUNTDLG_H__F46FC104_D9B8_4A81_A7EF_515FF9DDFAE6__INCLUDED_)
