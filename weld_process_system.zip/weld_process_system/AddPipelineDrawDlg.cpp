// AddPipelineDrawDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WPS.h"
#include "AddPipelineDrawDlg.h"
#include "AdvancedSettingDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAddPipelineDrawDlg dialog


CAddPipelineDrawDlg::CAddPipelineDrawDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAddPipelineDrawDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAddPipelineDrawDlg)
	//}}AFX_DATA_INIT
}


void CAddPipelineDrawDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAddPipelineDrawDlg)
	DDX_Control(pDX, IDC_LIST1, m_pipeList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAddPipelineDrawDlg, CDialog)
	//{{AFX_MSG_MAP(CAddPipelineDrawDlg)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_VALIDATE, OnEndLabelEditVariableCriteria)
	ON_MESSAGE(WM_SET_ITEMS, PopulateComboList)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAddPipelineDrawDlg message handlers

BOOL CAddPipelineDrawDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CWPSApp* pApp=(CWPSApp*)AfxGetApp();  
	DBpath=pApp->DBPath;
	
	m_MyDB = new CAccessDB(DBpath.GetBuffer(MAX_PATH),DBpath.GetBuffer(MAX_PATH),0);
	DBpath.ReleaseBuffer();
	
	if(!m_MyDB->OpenDB(DBpath.GetBuffer(MAX_PATH)))
	{
		AfxMessageBox("DB Open Error!");
		DBpath.ReleaseBuffer();
		return FALSE;
	}
	
	DBpath.ReleaseBuffer();

	CString strValidChars;//
	m_pipeList.InsertColumn(0, "No", LVCFMT_LEFT, 30);
	m_pipeList.InsertColumn(1, "DrwNo", LVCFMT_LEFT, 50);
	m_pipeList.InsertColumn(2, "WPSNo", LVCFMT_LEFT, 50);
	m_pipeList.InsertColumn(3, "WeldNo", LVCFMT_LEFT, 50);
	m_pipeList.InsertColumn(4, "WeldType", LVCFMT_LEFT, 55);
	m_pipeList.InsertColumn(5, "Spec.", LVCFMT_LEFT, 0);
	m_pipeList.InsertColumn(6, "Dimension", LVCFMT_LEFT, 0);
	m_pipeList.InsertColumn(7, "Thickness", LVCFMT_LEFT, 0);
	m_pipeList.InsertColumn(8, "Material", LVCFMT_LEFT, 0);
	m_pipeList.InsertColumn(9, "WeldLength", LVCFMT_LEFT, 70);
	m_pipeList.InsertColumn(10, "InCategory", LVCFMT_LEFT, 70);
	m_pipeList.InsertColumn(11, "Pipeline", LVCFMT_LEFT, 65);
	m_pipeList.InsertColumn(12, "NDT", LVCFMT_LEFT, 30);
	m_pipeList.InsertColumn(13, "Page", LVCFMT_LEFT, 40);
	m_pipeList.InsertColumn(14, "Total", LVCFMT_LEFT, 40);
	m_pipeList.InsertColumn(15, "WelderNo", LVCFMT_LEFT, 40);
	
	m_pipeList.SetReadOnlyColumns(0);//read only
	
	strValidChars = "0123456789.";
	m_pipeList.SetColumnValidEditCtrlCharacters(strValidChars,1);//none control edit 
	
	//m_pipeList.SetComboColumns(2,TRUE);
	m_pipeList.SetComboColumns(7,TRUE);
	m_pipeList.SetComboColumns(15,TRUE);
	m_pipeList.EnableVScroll(); 			
	m_pipeList.SetExtendedStyle(LVS_EX_FULLROWSELECT);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

LRESULT CAddPipelineDrawDlg::PopulateComboList(WPARAM wParam, LPARAM lParam)
{
	// Get the Combobox window pointer
	CStringArray strArr;
	CComboBox* pInPlaceCombo = static_cast<CComboBox*> (GetFocus());
	// Get the inplace combbox top left
	CRect obWindowRect;
	
	pInPlaceCombo->GetWindowRect(&obWindowRect);
	
	CPoint obInPlaceComboTopLeft(obWindowRect.TopLeft());
	
	// Get the active list
	// Get the control window rect
	// If the inplace combobox top left is in the rect then
	// The control is the active control
	m_pipeList.GetWindowRect(&obWindowRect);
	
	int iColIndex = (int )wParam;
	
	CStringList* pComboList = reinterpret_cast<CStringList*>(lParam);
	pComboList->RemoveAll();
	
	if (obWindowRect.PtInRect(obInPlaceComboTopLeft)) 
	{				
		if(iColIndex==2)
		{
			pComboList->AddTail("WPS054");
			pComboList->AddTail("WPS052");
			pComboList->AddTail("WI-01");
		}		
		else
			if (iColIndex==7)
			{
				pComboList->AddTail("1");
				pComboList->AddTail("2");
				pComboList->AddTail("3");
			}
			else
				if (iColIndex==15)
				{
					InitWelderCombo(strArr);
					for (int i=0;i<strArr.GetSize();i++)
					{
						pComboList->AddTail(strArr.GetAt(i));
					}
					strArr.RemoveAll();
				}
	}
	return true;
}

LRESULT CAddPipelineDrawDlg::OnEndLabelEditVariableCriteria(WPARAM wParam, LPARAM lParam) 
{
	LV_DISPINFO* pDispInfo = (LV_DISPINFO*)lParam;
	// TODO: Add your control notification handler code here
	
	return 1;
}

BOOL CAddPipelineDrawDlg::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(pMsg->message == WM_KEYDOWN)
    {
        switch(pMsg->wParam)
        {
        case VK_RETURN: 
            // [RETURN] key����
            m_pipeList.GoToNextItem();
            return TRUE;
        }
    }
	
	return CDialog::PreTranslateMessage(pMsg);
}

void CAddPipelineDrawDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	CAdvancedSettingDlg dlg;
	int totalpage;
	CString temp;
	CString str;
	if (dlg.DoModal()==IDOK)
	{
		WPSNo=dlg.WPSNo;
		WeldNo=dlg.WeldNo;
		WeldType=dlg.WeldType;
		Status=dlg.Status;
		WeldLength=dlg.WeldLength;
		Material=dlg.Material;
		Block=dlg.Block;
		Erection=dlg.Erection;
		NDT=dlg.NDT;
		SWeldDate=dlg.SWeldDate;
		EWeldDate=dlg.EWeldDate;
		Pipeline=dlg.inCategory;
		DrwNo=dlg.DrawNo;
		total=dlg.Total;
		TotalPage=dlg.TotalPage;
		CurPage=dlg.CurPage;
		
		totalpage=atoi(total);
		
		for (int j=0;j<totalpage;j++)
		{
			str.Format("%d",j+1);
			m_pipeList.InsertItem(LVIF_TEXT|LVIF_STATE, j, 
				str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
			m_pipeList.SetItemText(j,1,DrwNo);
			m_pipeList.SetItemText(j,2,WPSNo);
			m_pipeList.SetItemText(j,3,WeldNo);
			m_pipeList.SetItemText(j,4,WeldType);
			m_pipeList.SetItemText(j,8,Material);
			m_pipeList.SetItemText(j,9,WeldLength);
			m_pipeList.SetItemText(j,10,inCategory);
			m_pipeList.SetItemText(j,11,Pipeline);
			m_pipeList.SetItemText(j,12,NDT);

			m_pipeList.SetItemText(j,13,CurPage);
			m_pipeList.SetItemText(j,14,TotalPage);
		}
	}
	
	Invalidate(TRUE);
}



void CAddPipelineDrawDlg::OnOK() 
{
	// TODO: Add extra validation here
	CString strDrwNo="";
	CString strWpsNo="";
	CString strWeldNo="";
	CString strWeldType="";
	CString strSpecification="";
	CString strDimension="";
	CString strThickness="";
	CString strMaterial="";
	CString strWeldLength="";
	CString strBlock="";
	CString strSWeldDate="";
	CString strEWeldDate="";
	CString strNdt="";
	CString strPage="";
	CString strTotal="";
	CString strInCategory="";
	CString strPipeline="";
	char cid[100];
	
	int nDrwNo=0;
	int nSpecification=0;
	int nDimension=0;
	int nThickness=0;
	int nStatus=0;
	int nWeldLength=0;
	int nPage=0;
	int nTotal=0;
	int nid;
	int nnid;
	
	CString sql;

	strDrwNo=m_pipeList.GetItemText(0,1);
	nDrwNo=atoi(strDrwNo);
	strPage=m_pipeList.GetItemText(0,13);
	nPage=atoi(strPage);
	strTotal=m_pipeList.GetItemText(0,14);
	nTotal=atoi(strTotal);

	sql.Format("INSERT INTO Draw (DrwNo,ProjectID,Total,Page,DrType) VALUES('%s','%s',%d,%d,0)",strDrwNo,projectID,nTotal,nPage);
	if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
		AfxMessageBox("DB Error");
	
	sql="select ID from Draw";
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	int count=m_MyDB->GetDataSetRowCount(1);
	m_MyDB->GetDataSetFieldValue(count-1,0,cid);
	nid=atoi(cid);
	
	
	sql.Format("INSERT INTO DD (DrwNO) VALUES(%d)",nid);
	if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
		return ;
		
	for(int i=0;i<m_pipeList.GetItemCount();i++)
	{
		strWpsNo=m_pipeList.GetItemText(i,2);
		strWeldNo=m_pipeList.GetItemText(i,3);
		strWeldType=m_pipeList.GetItemText(i,4);
		//strSpecification=m_pipeList.GetItemText(i,5);
		//nSpecification=atoi(strSpecification);
		//strDimension=m_pipeList.GetItemText(i,6);
		//nDimension=atoi(strDimension);
		//strThickness=m_pipeList.GetItemText(i,7);
		//nThickness=atoi(strThickness);
		//strMaterial=m_pipeList.GetItemText(i,8);
		strWeldLength=m_pipeList.GetItemText(i,9);
		nWeldLength=atoi(strWeldLength);
		strInCategory=m_pipeList.GetItemText(i,10);
		strPipeline=m_pipeList.GetItemText(i,11);
		strNdt=m_pipeList.GetItemText(i,12);
		WelderNo=m_pipeList.GetItemText(i,15);

		
		//sql.Format("INSERT INTO Piping (ProjectID,DrwNO,WPSNo,WeldNumber,WeldType,Specification,Dimension,Thickness,Material,WeldLength,InCategory,Pipeline,NDT) VALUES('%s',%d,'%s','%s','%s',%d,%d,%d,'%s',%d,'%s','%s','%s')",projectID,nid,strWpsNo,strWeldNo,strWeldType,nSpecification,nDimension,nThickness,strMaterial,nWeldLength,strInCategory,strPipeline,strNdt);
		sql.Format("INSERT INTO Piping (ProjectID,DrwNO,WPSNo,WeldNumber,WeldType,WeldLength,InCategory,Pipeline,NDT,WelderNo) VALUES('%s',%d,'%s','%s','%s',%d,'%s','%s','%s','%s')",projectID,nid,strWpsNo,strWeldNo,strWeldType,nWeldLength,strInCategory,strPipeline,strNdt,WelderNo);
		
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;

		sql="select ID from Piping";
		if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
			return ;
		int count=m_MyDB->GetDataSetRowCount(1);
		m_MyDB->GetDataSetFieldValue(count-1,0,cid);
		nnid=atoi(cid);

		sql.Format("INSERT INTO PVT (DrwID,Extent,Result,ReportNo,DefectLength,Inspector,TDate) VALUES(%d,%d,NULL,NULL,%d,NULL,NULL)",nnid,100,0);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;

		sql.Format("INSERT INTO PPT (DrwID,Extent,Result,ReportNo,TLength,TDate,DLength,Operator) VALUES(%d,%d,NULL,NULL,%d,NULL,NULL,NULL)",nnid,20,0);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;

		sql.Format("INSERT INTO PUT (DrwID,Extent,Result,ReportNo,TLength,TDate,DLength,Operator) VALUES(%d,%d,NULL,NULL,%d,NULL,NULL,NULL)",nnid,20,0);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;

		sql.Format("INSERT INTO PRT (DrwID,Extent,Result,ReportNo,TLength,TDate,DLength,Operator) VALUES(%d,%d,NULL,NULL,%d,NULL,NULL,NULL)",nnid,20,0);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;
	}

	
	CDialog::OnOK();
}

void CAddPipelineDrawDlg::InitWelderCombo(CStringArray &strArr)
{
	CString sql="select * from Welder";
	char Welder[100];
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	
	int iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,Welder);
		strArr.Add(Welder);
	}
}
