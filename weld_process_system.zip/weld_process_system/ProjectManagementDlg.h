#if !defined(AFX_PROJECTMANAGEMENTDLG_H__2D021E61_D236_4C33_A958_6D46B0016BEA__INCLUDED_)
#define AFX_PROJECTMANAGEMENTDLG_H__2D021E61_D236_4C33_A958_6D46B0016BEA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ProjectManagementDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CProjectManagementDlg dialog

#include "AccessDB.h"

class CProjectManagementDlg : public CDialog
{
// Construction
public:
	void SetHeader(void);
	void InitListView(void);
	void InitTree(void);
	void MoveItem(CTreeCtrl &myTree, HTREEITEM hFromItem, HTREEITEM hToItem);
	CString GetFullPath(HTREEITEM hCurrent);
	CProjectManagementDlg(CWnd* pParent = NULL);   // standard constructor

	HTREEITEM m_hCurrent;
	HTREEITEM m_hPrev;
	HTREEITEM m_hRoot;
	
	CString projectName;
	CString projectID;
	CString creationDate;
	CString DrwNo;
	CString gFilename;
	CString gParent;

	bool changed;

	char WPSNo[100];
	char WeldNo[100];
	char WeldType[100];
	char Status[100];
	char WeldLength[100];
	char Material[100];
	char Block[100];
	char Erection[100];
	char NDT[100];
	char SWeldDate[100];
	char EWeldDate[100];
	char inCategory[100];
	char page[100];
	char total[100];
	char Specification[100];
	char Dimension[100];
	char Thickness[100];
	char Pipeline[100];

	CAccessDB * m_MyDB1;
	CAccessDB * m_MyDB2;

	CString DBpath;
// Dialog Data
	//{{AFX_DATA(CProjectManagementDlg)
	enum { IDD = IDD_PROJECTMANAGEMENT };
	CListCtrl	m_pipeList;
	CListCtrl	m_list;
	CTreeCtrl	m_tree;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CProjectManagementDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CProjectManagementDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangedTree1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnNewprojec();
	afx_msg void OnClose();
	afx_msg void OnRclickTree1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeleteproject();
	afx_msg void OnDeletedraw();
	afx_msg void OnColumnclickWeldinfo(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnAdddraw();
	afx_msg void OnEditdraw();
	afx_msg void OnButton1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROJECTMANAGEMENTDLG_H__2D021E61_D236_4C33_A958_6D46B0016BEA__INCLUDED_)
