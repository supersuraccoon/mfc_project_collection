// NewPageDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WPS.h"
#include "NewPageDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNewPageDlg dialog


CNewPageDlg::CNewPageDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CNewPageDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNewPageDlg)
	//}}AFX_DATA_INIT
}


void CNewPageDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNewPageDlg)
	DDX_Control(pDX, IDC_BLOCK, m_block);
	DDX_Control(pDX, IDC_DRAWNAME, m_drawname);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNewPageDlg, CDialog)
	//{{AFX_MSG_MAP(CNewPageDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNewPageDlg message handlers

BOOL CNewPageDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CString str;
	SetDlgItemText(IDC_DRAWNAME,drawname);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CNewPageDlg::OnOK() 
{
	// TODO: Add extra validation here
	GetDlgItemText(IDC_EDIT1,page);
	GetDlgItemText(IDC_BLOCK,block);
	
	CDialog::OnOK();
}
