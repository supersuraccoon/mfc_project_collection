// AddStructureDrawingDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WPS.h"
#include "AddStructureDrawingDlg.h"
#include "AdvancedSettingDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAddStructureDrawingDlg dialog


CAddStructureDrawingDlg::CAddStructureDrawingDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAddStructureDrawingDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAddStructureDrawingDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CAddStructureDrawingDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAddStructureDrawingDlg)
	DDX_Control(pDX, IDC_LIST1, m_list);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAddStructureDrawingDlg, CDialog)
	//{{AFX_MSG_MAP(CAddStructureDrawingDlg)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_VALIDATE, OnEndLabelEditVariableCriteria)
	ON_MESSAGE(WM_SET_ITEMS, PopulateComboList)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAddStructureDrawingDlg message handlers

void CAddStructureDrawingDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	CAdvancedSettingDlg dlg;
	int totalpage;
	CString str;
	if (dlg.DoModal()==IDOK)
	{
		WPSNo=dlg.WPSNo;
		WeldNo=dlg.WeldNo;
		WeldType=dlg.WeldType;
		Status=dlg.Status;
		WeldLength=dlg.WeldLength;
		Material=dlg.Material;
		Block=dlg.Block;
		Erection=dlg.Erection;
		NDT=dlg.NDT;
		SWeldDate=dlg.SWeldDate;
		EWeldDate=dlg.EWeldDate;
		inCategory=dlg.inCategory;
		DrwNo=dlg.DrawNo;
		total=dlg.Total;
		TotalPage=dlg.TotalPage;
		CurPage=dlg.CurPage;

		totalpage=atoi(total);

		for (int j=0;j<totalpage;j++)
		{
			str.Format("%d",j+1);
			m_list.InsertItem(LVIF_TEXT|LVIF_STATE, j, 
				str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
			
			m_list.SetItemText(j,1,DrwNo);
			m_list.SetItemText(j,2,WPSNo);
			m_list.SetItemText(j,3,WeldNo);
			m_list.SetItemText(j,4,WeldType);
			m_list.SetItemText(j,8,Status);
			m_list.SetItemText(j,9,Material);
			m_list.SetItemText(j,10,WeldLength);
			m_list.SetItemText(j,11,Block);
			m_list.SetItemText(j,12,Erection);
			m_list.SetItemText(j,13,SWeldDate);
			m_list.SetItemText(j,14,EWeldDate);
			m_list.SetItemText(j,15,NDT);
			m_list.SetItemText(j,16,CurPage);
			m_list.SetItemText(j,17,TotalPage);
		}
	}
	
	Invalidate(TRUE);
}

BOOL CAddStructureDrawingDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CWPSApp* pApp=(CWPSApp*)AfxGetApp();  
	DBpath=pApp->DBPath;
	
	m_MyDB = new CAccessDB(DBpath.GetBuffer(MAX_PATH),DBpath.GetBuffer(MAX_PATH),0);
	DBpath.ReleaseBuffer();
	
	if(!m_MyDB->OpenDB(DBpath.GetBuffer(MAX_PATH)))
	{
		AfxMessageBox("DB Open Error!");
		DBpath.ReleaseBuffer();
		return FALSE;
	}
	
	DBpath.ReleaseBuffer();

	m_list.InsertColumn(0, "No", LVCFMT_LEFT, 30);
	m_list.InsertColumn(1, "DrwNo", LVCFMT_LEFT, 50);
	m_list.InsertColumn(2, "WPSNo", LVCFMT_LEFT, 50);
	m_list.InsertColumn(3, "WeldNo", LVCFMT_LEFT, 50);
	m_list.InsertColumn(4, "WeldType", LVCFMT_LEFT, 55);
	m_list.InsertColumn(5, "Spec.", LVCFMT_LEFT, 0);
	m_list.InsertColumn(6, "Dimension", LVCFMT_LEFT, 0);
	m_list.InsertColumn(7, "Thickness", LVCFMT_LEFT, 0);
	m_list.InsertColumn(8, "Status", LVCFMT_LEFT, 50);
	m_list.InsertColumn(9, "Material", LVCFMT_LEFT, 0);
	m_list.InsertColumn(10, "WeldLength", LVCFMT_LEFT, 70);
	m_list.InsertColumn(11, "Block", LVCFMT_LEFT, 50);
	m_list.InsertColumn(12, "Erection", LVCFMT_LEFT, 0);
	m_list.InsertColumn(13, "SDate", LVCFMT_LEFT, 70);
	m_list.InsertColumn(14, "EDate", LVCFMT_LEFT, 70);
	m_list.InsertColumn(15, "NDT", LVCFMT_LEFT, 0);
	m_list.InsertColumn(16, "Page", LVCFMT_LEFT, 40);
	m_list.InsertColumn(17, "Total", LVCFMT_LEFT, 40);
	m_list.InsertColumn(18, "Welder", LVCFMT_LEFT, 70);
	
	
	CString strValidChars;//	
	m_list.SetReadOnlyColumns(0);//read only
	
	strValidChars = "0123456789.";
	m_list.SetColumnValidEditCtrlCharacters(strValidChars,1);//none control edit 
	
	//strValidChars = "0123456789.";
	strValidChars = "";
	m_list.SetColumnValidEditCtrlCharacters(strValidChars,4);//digital only edit
	m_list.SetColumnValidEditCtrlCharacters(strValidChars,5);//digital only edit
	m_list.SetColumnValidEditCtrlCharacters(strValidChars,6);//digital only edit
	m_list.SetColumnValidEditCtrlCharacters(strValidChars,8);//digital only edit
	m_list.SetColumnValidEditCtrlCharacters(strValidChars,9);//digital only edit
	m_list.SetColumnValidEditCtrlCharacters(strValidChars,10);//digital only edit
	
	//m_list.SetComboColumns(2,TRUE);
	m_list.SetComboColumns(7,TRUE);
	m_list.SetComboColumns(18,TRUE);
	m_list.EnableVScroll(); 			
	m_list.SetExtendedStyle(LVS_EX_FULLROWSELECT);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

LRESULT CAddStructureDrawingDlg::PopulateComboList(WPARAM wParam, LPARAM lParam)
{
	// Get the Combobox window pointer
	CStringArray strArr;
	CComboBox* pInPlaceCombo = static_cast<CComboBox*> (GetFocus());
	// Get the inplace combbox top left
	CRect obWindowRect;
	
	pInPlaceCombo->GetWindowRect(&obWindowRect);
	
	CPoint obInPlaceComboTopLeft(obWindowRect.TopLeft());
	
	// Get the active list
	// Get the control window rect
	// If the inplace combobox top left is in the rect then
	// The control is the active control
	m_list.GetWindowRect(&obWindowRect);
	
	int iColIndex = (int )wParam;
	
	CStringList* pComboList = reinterpret_cast<CStringList*>(lParam);
	pComboList->RemoveAll();
	
	if (obWindowRect.PtInRect(obInPlaceComboTopLeft)) 
	{				
		if(iColIndex==2)
		{
			InitWPSCombo(strArr);
			for (int i=0;i<strArr.GetSize();i++)
			{
				pComboList->AddTail(strArr.GetAt(i));
			}
			strArr.RemoveAll();
		}		
		else
			if (iColIndex==3)
			{
				InitWeldNoCombo(strArr);
				for (int i=0;i<strArr.GetSize();i++)
				{
					pComboList->AddTail(strArr.GetAt(i));
				}
				strArr.RemoveAll();
			}
			else
				if (iColIndex==4)
				{
					InitWeldTypeCombo(strArr);
					for (int i=0;i<strArr.GetSize();i++)
					{
						pComboList->AddTail(strArr.GetAt(i));
					}
					strArr.RemoveAll();
				}
				else
					if (iColIndex==8)
					{
						pComboList->AddTail("1");
						pComboList->AddTail("2");
						pComboList->AddTail("3");
					}
					else
						if (iColIndex==9)
						{
							InitMaterialCombo(strArr);
							for (int i=0;i<strArr.GetSize();i++)
							{
								pComboList->AddTail(strArr.GetAt(i));
							}
							strArr.RemoveAll();
						}
						else
							if (iColIndex==18)
							{
								InitWelderCombo(strArr);
								for (int i=0;i<strArr.GetSize();i++)
								{
									pComboList->AddTail(strArr.GetAt(i));
								}
								strArr.RemoveAll();
							}
	}
	return true;
}

LRESULT CAddStructureDrawingDlg::OnEndLabelEditVariableCriteria(WPARAM wParam, LPARAM lParam) 
{
	LV_DISPINFO* pDispInfo = (LV_DISPINFO*)lParam;
	// TODO: Add your control notification handler code here
	
	return 1;
}

void CAddStructureDrawingDlg::OnOK() 
{
	// TODO: Add extra validation here
	CString strDrwNo="";
	CString strWpsNo="";
	CString strWeldNo="";
	CString strWeldType="";
	CString strSpecification="";
	CString strDimension="";
	CString strThickness="";
	CString strStatus="";
	CString strMaterial="";
	CString strWeldLength="";
	CString strBlock="";
	CString strErection="";
	CString strSWeldDate="";
	CString strEWeldDate="";
	CString strNdt="";
	CString strPage="";
	CString strTotal="";
	CString strInCategory="";
	CString strPipeline="";
	char cid[100];
	
	int nDrwNo=0;
	int nSpecification=0;
	int nDimension=0;
	int nThickness=0;
	int nStatus=0;
	int nWeldLength=0;
	int nPage=0;
	int nTotal=0;
	int nid;
	int nnid;
	
	CString sql;
	strDrwNo=m_list.GetItemText(0,1);
	nDrwNo=atoi(strDrwNo);
	strPage=m_list.GetItemText(0,16);
	nPage=atoi(strPage);
	strTotal=m_list.GetItemText(0,17);
	nTotal=atoi(strTotal);
	sql.Format("INSERT INTO Draw (DrwNo,ProjectID,Total,Page,DrType) VALUES('%s','%s',%d,%d,1)",strDrwNo,projectID,nTotal,nPage);
	if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
		AfxMessageBox("DB Error");
	
	sql="select ID from Draw";
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	int count=m_MyDB->GetDataSetRowCount(1);
	m_MyDB->GetDataSetFieldValue(count-1,0,cid);
	nid=atoi(cid);
	
	
	sql.Format("INSERT INTO DD (DrwNO) VALUES(%d)",nid);
	if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;

	for(int i=0;i<m_list.GetItemCount();i++)
	{
		strWpsNo=m_list.GetItemText(i,2);
		strWeldNo=m_list.GetItemText(i,3);
		strWeldType=m_list.GetItemText(i,4);
		//strSpecification=m_list.GetItemText(i,5);
		//nSpecification=atoi(strSpecification);
		//strDimension=m_list.GetItemText(i,6);
		//nDimension=atoi(strDimension);
		//strThickness=m_list.GetItemText(i,7);
		//nThickness=atoi(strThickness);
		strStatus=m_list.GetItemText(i,8);
		nStatus=atoi(strStatus);
		//strMaterial=m_list.GetItemText(i,9);
		strWeldLength=m_list.GetItemText(i,10);
		nWeldLength=atoi(strWeldLength);
		strBlock=m_list.GetItemText(i,11);
		//strErection=m_list.GetItemText(i,12);
		strSWeldDate=m_list.GetItemText(i,13);
		strEWeldDate=m_list.GetItemText(i,14);
		strNdt=m_list.GetItemText(i,15);
		WelderNo=m_list.GetItemText(i,18);
		
		//sql.Format("INSERT INTO Structure (ProjectID,DrwNO,WPSNo,WeldNo,WeldType,Specification,Dimension,Thickness,Status,Material,WeldLength,Block,Erection,SWeldDate,EWeldDate,NDT) VALUES('%s',%d,'%s','%s','%s',%d,%d,%d,%d,'%s',%d,'%s','%s','%s','%s','%s')",projectID,nid,strWpsNo,strWeldNo,strWeldType,nSpecification,nDimension,nThickness,nStatus,strMaterial,nWeldLength,strBlock,strErection,strSWeldDate,strEWeldDate,strNdt);
		sql.Format("INSERT INTO Structure (ProjectID,DrwNO,WPSNo,WeldNo,WeldType,Status,WeldLength,Block,SWeldDate,EWeldDate,NDT,WelderNo) VALUES('%s',%d,'%s','%s','%s',%d,%d,'%s','%s','%s','%s','%s')",projectID,nid,strWpsNo,strWeldNo,strWeldType,nStatus,nWeldLength,strBlock,strSWeldDate,strEWeldDate,strNdt,WelderNo);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;

		sql="select ID from Structure";
		if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
			return ;
		int count=m_MyDB->GetDataSetRowCount(1);
		m_MyDB->GetDataSetFieldValue(count-1,0,cid);
		nnid=atoi(cid);
		
		sql.Format("INSERT INTO SVT (DrwID,Extent,Result,ReportNo,DefectLength,Inspector,TDate) VALUES(%d,%d,NULL,NULL,%d,NULL,NULL)",nnid,100,0);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;
		
		sql.Format("INSERT INTO SPT (DrwID,Extent,Result,ReportNo,TLength,TDate,DLength,Operator) VALUES(%d,%d,NULL,NULL,%d,NULL,NULL,NULL)",nnid,20,0);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;
		
		sql.Format("INSERT INTO SUT (DrwID,Extent,Result,ReportNo,TLength,TDate,DLength,Operator) VALUES(%d,%d,NULL,NULL,%d,NULL,NULL,NULL)",nnid,20,0);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;
		
		sql.Format("INSERT INTO SRT (DrwID,Extent,Result,ReportNo,TLength,TDate,DLength,Operator) VALUES(%d,%d,NULL,NULL,%d,NULL,NULL,NULL)",nnid,20,0);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			return ;
	}

	CDialog::OnOK();
}

BOOL CAddStructureDrawingDlg::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(pMsg->message == WM_KEYDOWN)
    {
        switch(pMsg->wParam)
        {
        case VK_RETURN: 
            // [RETURN] key����
            m_list.GoToNextItem();
            return TRUE;
		case VK_DOWN:
			m_list.GoDownToNextItem();
			return TRUE;
        }
    }
	
	return CDialog::PreTranslateMessage(pMsg);
}

void CAddStructureDrawingDlg::InitWPSCombo(CStringArray &strArr)
{
	CString sql="select * from WPSNoType";
	char WPSNo[100];
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	
	int iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,WPSNo);
		strArr.Add(WPSNo);
	}
}

void CAddStructureDrawingDlg::InitWeldNoCombo(CStringArray &strArr)
{
	CString sql="select * from WeldNoType";
	char WeldNo[100];
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	
	int iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,WeldNo);
		strArr.Add(WeldNo);
	}
}

void CAddStructureDrawingDlg::InitMaterialCombo(CStringArray &strArr)
{
	CString sql="select * from MaterialType";
	char Material[100];
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	
	int iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,Material);
		strArr.Add(Material);
	}
}

void CAddStructureDrawingDlg::InitWeldTypeCombo(CStringArray &strArr)
{
	CString sql="select * from WeldType";
	char WeldType[100];
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	
	int iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,WeldType);
		strArr.Add(WeldType);
	}
}

void CAddStructureDrawingDlg::InitWelderCombo(CStringArray &strArr)
{
	CString sql="select * from Welder";
	char Welder[100];
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	
	int iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,Welder);
		strArr.Add(Welder);
	}
}
