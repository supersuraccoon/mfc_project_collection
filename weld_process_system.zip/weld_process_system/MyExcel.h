// MyExcel.h: interface for the CMyExcel class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYEXCEL_H__08C1C2B3_97AD_4B90_8187_888E04E29646__INCLUDED_)
#define AFX_MYEXCEL_H__08C1C2B3_97AD_4B90_8187_888E04E29646__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <io.h>
#include <odbcinst.h>
#include <afxdb.h>

class CMyExcel  
{
public:
	CMyExcel();
	virtual ~CMyExcel();


	CString		GetExcelDriver();
	BOOL		MakeSurePathExists( CString &Path,	bool FilenameIncluded=true);
	void		ExportListToExcel(CListCtrl* pList, CString strTitle);
	BOOL        GetDefaultXlsFileName(CString& sExcelFile);
};

#endif // !defined(AFX_MYEXCEL_H__08C1C2B3_97AD_4B90_8187_888E04E29646__INCLUDED_)
