// MyAssignmentDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WPS.h"
#include "MyAssignmentDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyAssignmentDlg dialog


CMyAssignmentDlg::CMyAssignmentDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMyAssignmentDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMyAssignmentDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CMyAssignmentDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyAssignmentDlg)
	DDX_Control(pDX, IDC_ASSIGNMENT, m_list);
	DDX_Control(pDX, IDC_DRWINGNO, m_drawingno);
	DDX_Control(pDX, IDC_PROJECTNAME, m_projectname);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMyAssignmentDlg, CDialog)
	//{{AFX_MSG_MAP(CMyAssignmentDlg)
	ON_CBN_CLOSEUP(IDC_DRWINGNO, OnCloseupDrwingno)
	ON_CBN_CLOSEUP(IDC_PROJECTNAME, OnCloseupProjectname)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyAssignmentDlg message handlers

BOOL CMyAssignmentDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_list.InsertColumn(0, "No", LVCFMT_LEFT, 30);
	m_list.InsertColumn(1, "WeldID", LVCFMT_LEFT, 100);
	m_list.InsertColumn(2, "WeldDate", LVCFMT_LEFT, 100);

	CString sql;
	CWPSApp* pApp=(CWPSApp*)AfxGetApp(); 
	id=pApp->UserID;
	CString str;
	char projectID[50];
	
	sql.Format("select DISTINCT(projectID) from weld where WelderID='%s'",id);

	DBpath=pApp->DBPath;
	
	m_MyDB = new CAccessDB(DBpath.GetBuffer(MAX_PATH),DBpath.GetBuffer(MAX_PATH),0);
	DBpath.ReleaseBuffer();
	if(!m_MyDB->OpenDB(DBpath.GetBuffer(MAX_PATH)))
	{
		AfxMessageBox("DB Open Error!");
		DBpath.ReleaseBuffer();
		return FALSE;
	}
	
	DBpath.ReleaseBuffer();
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return false;
	int iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	if(!iRowCount)
		return false;
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,projectID);
		m_projectname.AddString(projectID);
	}
	
	m_projectname.SetCurSel(0);

	OnCloseupProjectname();
	//OnCloseupDrwingno();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CMyAssignmentDlg::OnCloseupDrwingno() 
{
	// TODO: Add your control notification handler code here
	CString drawingID="";
	CString projectID="";
	CString sql;
	CString str;

	char WeldID[50];
	char WeldDate[50];
	
	m_drawingno.GetLBText(m_drawingno.GetCurSel(),drawingID);
	GetDlgItemText(IDC_PROJECTNAME,projectID);
	
	m_list.DeleteAllItems();

	if (drawingID=="")
	{
		return;
	}
	
	sql.Format("Select * from weld where DrwID='%s' AND ProjectID='%s'",drawingID,projectID);
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	int iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	if(!iRowCount)
		return ;
	
	for(int i=0;i<iRowCount;i++)
	{
		str.Format("%d",i+1);
		m_list.InsertItem(LVIF_TEXT|LVIF_STATE, i, 
			str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);

		m_MyDB->GetDataSetFieldValue(i,1,WeldID);
		m_list.SetItemText(i,1,WeldID);
		m_MyDB->GetDataSetFieldValue(i,5,WeldDate);
		m_list.SetItemText(i,2,WeldDate);
	}
}

void CMyAssignmentDlg::OnCloseupProjectname() 
{
	// TODO: Add your control notification handler code here
	CString projectID="";
	CString sql;
	char DrwID[50];
	GetDlgItemText(IDC_PROJECTNAME,projectID);
	
	if (projectID=="")
	{
		return;
	}
	
	sql.Format("Select DrwID from Drw where projectID='%s'",projectID);
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	int iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	if(!iRowCount)
		return ;
	
	m_drawingno.ResetContent();
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,DrwID);
		m_drawingno.AddString(DrwID);
	}
	m_drawingno.SetCurSel(0);
}

void CMyAssignmentDlg::OnClose() 
{
	// TODO: Add your message handler code here and/or call default

	
	CDialog::OnClose();
}





















