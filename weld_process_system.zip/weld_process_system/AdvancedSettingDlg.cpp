// AdvancedSettingDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WPS.h"
#include "AdvancedSettingDlg.h"
#include "EditDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAdvancedSettingDlg dialog


CAdvancedSettingDlg::CAdvancedSettingDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAdvancedSettingDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAdvancedSettingDlg)
	//}}AFX_DATA_INIT
}


void CAdvancedSettingDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAdvancedSettingDlg)
	DDX_Control(pDX, IDC_TOTAL, m_total);
	DDX_Control(pDX, IDC_ERETION1, m_eretion);
	DDX_Control(pDX, IDC_BLOCK1, m_block);
	DDX_Control(pDX, IDC_INGATEGORY1, m_incategory);
	DDX_Control(pDX, IDC_NDT1, m_ndt);
	DDX_Control(pDX, IDC_MATERIAL1, m_material);
	DDX_Control(pDX, IDC_WELDLENGTH, m_weldlength);
	DDX_Control(pDX, IDC_STATUS, m_statu);
	DDX_Control(pDX, IDC_WELDTYPE, m_weldtype);
	DDX_Control(pDX, IDC_DRAWNO, m_drawno);
	DDX_Control(pDX, IDC_WELDNO, m_weldnotype);
	DDX_Control(pDX, IDC_WPSNO, m_wpsno);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAdvancedSettingDlg, CDialog)
	//{{AFX_MSG_MAP(CAdvancedSettingDlg)
	ON_BN_CLICKED(IDC_EDIT, OnEdit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAdvancedSettingDlg message handlers

BOOL CAdvancedSettingDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CWPSApp* pApp=(CWPSApp*)AfxGetApp();  
	DBpath=pApp->DBPath;
	
	m_MyDB = new CAccessDB(DBpath.GetBuffer(MAX_PATH),DBpath.GetBuffer(MAX_PATH),0);
	DBpath.ReleaseBuffer();
	
	if(!m_MyDB->OpenDB(DBpath.GetBuffer(MAX_PATH)))
	{
		AfxMessageBox("DB Open Error!");
		DBpath.ReleaseBuffer();
		return FALSE;
	}
	
	DBpath.ReleaseBuffer();

	InitCombo();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CAdvancedSettingDlg::OnOK() 
{
	// TODO: Add extra validation here
	GetDlgItemText(IDC_WPSNO,WPSNo);
	GetDlgItemText(IDC_WELDNO,WeldNo);
	GetDlgItemText(IDC_WELDTYPE,WeldType);
	GetDlgItemText(IDC_STATUS,Status);
	GetDlgItemText(IDC_WELDLENGTH,WeldLength);
	GetDlgItemText(IDC_MATERIAL1,Material);
	GetDlgItemText(IDC_BLOCK1,Block);
	GetDlgItemText(IDC_ERETION1,Erection);
	GetDlgItemText(IDC_NDT1,NDT);
	GetDlgItemText(IDC_SWELDDATE,SWeldDate);
	GetDlgItemText(IDC_EWELDDATE,EWeldDate);
	GetDlgItemText(IDC_INGATEGORY1,inCategory);
	GetDlgItemText(IDC_DRAWNO,DrawNo);
	GetDlgItemText(IDC_TOTAL,Total);
	GetDlgItemText(IDC_CURPAGE,CurPage);
	GetDlgItemText(IDC_TOTALPAGE,TotalPage);
	
	CDialog::OnOK();
}

void CAdvancedSettingDlg::OnEdit() 
{
	// TODO: Add your control notification handler code here
	CEditDlg dlg;
	dlg.DoModal();
	InitCombo();
}

void CAdvancedSettingDlg::InitCombo()
{
	char WPSNo[100];
	char WeldNo[100];
	char WeldType[100];
	char Status[100];
	char InCategory[100];
	char WeldLength[100];
	char Material[100];
	char Block[100];
	char Erection[100];
	char NDT[100];
	char DrawNo[100];
	CString sql;

	m_wpsno.ResetContent();
	m_weldnotype.ResetContent();
	m_weldlength.ResetContent();
	m_weldtype.ResetContent();
	m_statu.ResetContent();
	m_incategory.ResetContent();
	m_material.ResetContent();
	m_block.ResetContent();
	m_eretion.ResetContent();
	m_ndt.ResetContent();
	m_drawno.ResetContent();

	sql="select * from WPSNoType";
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	
	int iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	for(int i=0;i<iRowCount;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,WPSNo);
		m_wpsno.AddString(WPSNo);
	}	
	m_wpsno.SetCurSel(0);
	
	sql="select * from WeldNoType";
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	for(i=0;i<iRowCount;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,WeldNo);
		m_weldnotype.AddString(WeldNo);
	}	
	m_weldnotype.SetCurSel(0);

	sql="select * from WeldType";
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	iRowCount=m_MyDB->GetDataSetRowCount(1);

	for(i=0;i<iRowCount;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,WeldType);
		m_weldtype.AddString(WeldType);
	}	
	m_weldtype.SetCurSel(0);

	sql="select * from StatuType";
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	iRowCount=m_MyDB->GetDataSetRowCount(1);

	
	for(i=0;i<iRowCount;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,Status);
		m_statu.AddString(Status);
	}	
	m_statu.SetCurSel(0);

	sql="select * from WeldLengthType";
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	
	for(i=0;i<iRowCount;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,WeldLength);
		m_weldlength.AddString(WeldLength);
	}	
	m_weldlength.SetCurSel(0);

	sql="select * from MaterialType";
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	for(i=0;i<iRowCount;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,Material);
		m_material.AddString(Material);
	}	
	m_material.SetCurSel(0);

	sql="select * from BlockType";
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	for(i=0;i<iRowCount;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,Block);
		m_block.AddString(Block);
	}	
	m_block.SetCurSel(0);
		
	sql="select * from ErectionType";
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	for(i=0;i<iRowCount;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,Erection);
		m_eretion.AddString(Erection);
	}	
	m_eretion.SetCurSel(0);

	sql="select * from InCategoryType";
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	for(i=0;i<iRowCount;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,InCategory);
		m_incategory.AddString(InCategory);
	}	
	m_incategory.SetCurSel(0);

	sql="select * from NDTType";
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	for(i=0;i<iRowCount;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,NDT);
		m_ndt.AddString(NDT);
	}	
	m_ndt.SetCurSel(0);

	sql="select * from DrawNoType";
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	for(i=0;i<iRowCount;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,DrawNo);
		m_drawno.AddString(DrawNo);
	}	
	m_drawno.SetCurSel(0);

	m_drawno.AddString("N/A");
	m_drawno.SetCurSel(0);
}
