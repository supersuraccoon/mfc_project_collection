#if !defined(AFX_ADDPIPELINEDRAWDLG_H__F9DDB181_52B9_4597_8A6B_227418DD5AFC__INCLUDED_)
#define AFX_ADDPIPELINEDRAWDLG_H__F9DDB181_52B9_4597_8A6B_227418DD5AFC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AddPipelineDrawDlg.h : header file
//
#include "ComboListCtrl.h"
#include "AccessDB.h"
/////////////////////////////////////////////////////////////////////////////
// CAddPipelineDrawDlg dialog

class CAddPipelineDrawDlg : public CDialog
{
// Construction
public:
	void InitWelderCombo(CStringArray &strArr);
	CAddPipelineDrawDlg(CWnd* pParent = NULL);   // standard constructor
	CString projectID;
	CString WPSNo;
	CString WeldNo;
	CString WeldType;
	CString Status;
	CString WeldLength;
	CString Material;
	CString Block;
	CString Erection;
	CString NDT;
	CString SWeldDate;
	CString EWeldDate;
	CString inCategory;
	CString page;
	CString total;
	CString DrwNo;
	CString WelderNo;
	CString Pipeline;

	CString TotalPage;
	CString CurPage;

	
	CAccessDB *m_MyDB;
	CString DBpath;

// Dialog Data
	//{{AFX_DATA(CAddPipelineDrawDlg)
	enum { IDD = IDD_ADDPIPELINEDRAW };
	CComboListCtrl	m_pipeList;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAddPipelineDrawDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CAddPipelineDrawDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnButton1();
	virtual void OnOK();
	//}}AFX_MSG
	afx_msg LRESULT OnEndLabelEditVariableCriteria(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT PopulateComboList(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADDPIPELINEDRAWDLG_H__F9DDB181_52B9_4597_8A6B_227418DD5AFC__INCLUDED_)
