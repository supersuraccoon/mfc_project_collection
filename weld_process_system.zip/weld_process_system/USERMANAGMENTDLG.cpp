// USERMANAGMENTDLG.cpp : implementation file
//

#include "stdafx.h"
#include "WPS.h"
#include "USERMANAGMENTDLG.h"
#include "MyExcel.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


int gRow=-1;
int gCount=1;
/////////////////////////////////////////////////////////////////////////////
// CUSERMANAGMENTDLG dialog


CUSERMANAGMENTDLG::CUSERMANAGMENTDLG(CWnd* pParent /*=NULL*/)
	: CDialog(CUSERMANAGMENTDLG::IDD, pParent)
{
	//{{AFX_DATA_INIT(CUSERMANAGMENTDLG)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

}


void CUSERMANAGMENTDLG::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUSERMANAGMENTDLG)
	DDX_Control(pDX, IDC_USERLIST, m_ListCtrl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CUSERMANAGMENTDLG, CDialog)
	//{{AFX_MSG_MAP(CUSERMANAGMENTDLG)
	ON_BN_CLICKED(IDC_ADD, OnAdd)
	ON_BN_CLICKED(IDC_DELETE, OnDelete)
	ON_NOTIFY(NM_CLICK, IDC_USERLIST, OnClickUserlist)
	ON_BN_CLICKED(IDC_PRINT, OnPrint)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_VALIDATE, OnEndLabelEditVariableCriteria)
	ON_MESSAGE(WM_SET_ITEMS, PopulateComboList)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUSERMANAGMENTDLG message handlers

BOOL CUSERMANAGMENTDLG::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here	
	m_ListCtrl.InsertColumn(0, "No", LVCFMT_LEFT, 30);
	m_ListCtrl.InsertColumn(1, "Name", LVCFMT_LEFT, 100);
	m_ListCtrl.InsertColumn(2, "PassWord", LVCFMT_LEFT, 100);
	m_ListCtrl.InsertColumn(3, "User Type", LVCFMT_LEFT, 80);
	
	CString strValidChars;//	
	//m_ListCtrl.SetReadOnlyColumns(0);//read only
	
	
	strValidChars = "0123456789.";
	m_ListCtrl.SetColumnValidEditCtrlCharacters(strValidChars,1);//none control edit 
	
	//strValidChars = "0123456789.";
	strValidChars = "";
	m_ListCtrl.SetColumnValidEditCtrlCharacters(strValidChars,2);//digital only edit	
	
	m_ListCtrl.SetComboColumns(4,TRUE);
	m_ListCtrl.EnableVScroll(); 			
	m_ListCtrl.SetExtendedStyle(LVS_EX_FULLROWSELECT);
	
	
	CString sql="select * from User";
	CString str;
	char UserID[50];
	char name[50];
	char password[50];
	char type[50];
	
	CWPSApp* pApp=(CWPSApp*)AfxGetApp();  
	DBpath=pApp->DBPath;
	
	m_MyDB = new CAccessDB(DBpath.GetBuffer(MAX_PATH),DBpath.GetBuffer(MAX_PATH),0);
	DBpath.ReleaseBuffer();

	if(!m_MyDB->OpenDB(DBpath.GetBuffer(MAX_PATH)))
	{
		AfxMessageBox("DB Open Error!");
		DBpath.ReleaseBuffer();
		return FALSE;
	}
	
	DBpath.ReleaseBuffer();
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return false;
	int iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	if(!iRowCount)
		return false;
	
	UserNo=iRowCount;
	
	for(int i=0;i<iRowCount;i++)
	{
		
		str.Format("%d",i+1);
		m_ListCtrl.InsertItem(LVIF_TEXT|LVIF_STATE, i, 
			str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
		
		m_MyDB->GetDataSetFieldValue(i,0,UserID);
		m_ListCtrl.SetItemText(i,1,UserID);
		m_MyDB->GetDataSetFieldValue(i,1,name);
		m_ListCtrl.SetItemText(i,2,name);
		m_MyDB->GetDataSetFieldValue(i,2,password);
		m_ListCtrl.SetItemText(i,3,password);
		m_MyDB->GetDataSetFieldValue(i,3,type);
		m_ListCtrl.SetItemText(i,4,type);
	}
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CUSERMANAGMENTDLG::OnAdd() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	
	(CButton*)GetDlgItem(IDOK)->EnableWindow(TRUE);
	(CButton*)GetDlgItem(IDC_ADD)->EnableWindow(FALSE);
	
	int i =m_ListCtrl.GetItemCount();
	
	CString str;
	
	str.Format("%d",i+1);
	
	m_ListCtrl.InsertItem(LVIF_TEXT|LVIF_STATE, i+1, 
		str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
	UpdateData(FALSE);
}
 

void CUSERMANAGMENTDLG::OnDelete() 
{
	// TODO: Add your control notification handler code here
	CString name;
	CString userID;
	CString password;
	CString type;
	CString sql;
	CString str;
	
	if (gRow==-1)
	{
		MessageBox("Please select a user!!!");
		return ;
	}
	
	if(MessageBox("The data selected is being deleted!!!","WARNING!!!",MB_OKCANCEL)==IDOK)
	{
		userID=m_ListCtrl.GetItemText(gRow,1);
		
		sql.Format("DELETE * FROM User WHERE UserID='%s'",userID);
		
		m_ListCtrl.DeleteItem(gRow);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			AfxMessageBox("DB Error");
		
		UserNo--;
		
		for(int i=gRow;i<=UserNo;i++)
		{
			gRow++;
			str.Format("%d",gRow);
			m_ListCtrl.SetItemText(i,0,str);
		}
	}
}

void CUSERMANAGMENTDLG::OnClickUserlist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	LPNMITEMACTIVATE temp=(LPNMITEMACTIVATE)pNMHDR;  
	gRow=temp->iItem;

	*pResult = 0;
}

void CUSERMANAGMENTDLG::OnOK() 
{
	// TODO: Add extra validation here
	CString name="";
	CString password="";
	CString type="";
	CString userID="";
	CString sql;
	int i=m_ListCtrl.GetItemCount();
	
	userID=m_ListCtrl.GetItemText(i-1,1);
	name=m_ListCtrl.GetItemText(i-1,2);
	password=m_ListCtrl.GetItemText(i-1,3);
	type=m_ListCtrl.GetItemText(i-1,4);
	
	if (name!=""&&password!=""&&type!=""&&userID!="")
	{
		sql.Format("INSERT INTO User VALUES('%s','%s','%s','%s')",userID,name,password,type);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			AfxMessageBox("DB Error");
		
		(CButton*)GetDlgItem(IDOK)->EnableWindow(FALSE);
		(CButton*)GetDlgItem(IDC_ADD)->EnableWindow(TRUE);
		
		UserNo++;
	}
	else
	{
		MessageBox("User Infomation Incomplete!");
	}

	//CDialog::OnOK();
}

BOOL CUSERMANAGMENTDLG::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(pMsg->message == WM_KEYDOWN)
    {
        switch(pMsg->wParam)
        {
        case VK_RETURN: 
            // [RETURN] key����
            m_ListCtrl.GoToNextItem();
            return TRUE;
        }
    }
	
	return CDialog::PreTranslateMessage(pMsg);
}

void CUSERMANAGMENTDLG::OnPrint() 
{
	// TODO: Add your control notification handler code here

}

LRESULT CUSERMANAGMENTDLG::PopulateComboList(WPARAM wParam, LPARAM lParam)
{
	// Get the Combobox window pointer
	CComboBox* pInPlaceCombo = static_cast<CComboBox*> (GetFocus());
	// Get the inplace combbox top left
	CRect obWindowRect;
	
	pInPlaceCombo->GetWindowRect(&obWindowRect);
	
	CPoint obInPlaceComboTopLeft(obWindowRect.TopLeft());
	
	// Get the active list
	// Get the control window rect
	// If the inplace combobox top left is in the rect then
	// The control is the active control
	m_ListCtrl.GetWindowRect(&obWindowRect);
	
	int iColIndex = (int )wParam;
	
	CStringList* pComboList = reinterpret_cast<CStringList*>(lParam);
	pComboList->RemoveAll();
	
	if (obWindowRect.PtInRect(obInPlaceComboTopLeft)) 
	{				
		if(iColIndex==4)
		{
			pComboList->AddTail("Manager");
			pComboList->AddTail("Worker");
		}		
	}
	return true;
}

LRESULT CUSERMANAGMENTDLG::OnEndLabelEditVariableCriteria(WPARAM wParam, LPARAM lParam) 
{
	LV_DISPINFO* pDispInfo = (LV_DISPINFO*)lParam;
	// TODO: Add your control notification handler code here
	
	return 1;
}
