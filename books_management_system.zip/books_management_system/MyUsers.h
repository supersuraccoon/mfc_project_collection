// MyUsers.h: interface for the MyUsers class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYUSERS_H__9CA4AD44_5B82_417F_A86F_3EFF034CFADF__INCLUDED_)
#define AFX_MYUSERS_H__9CA4AD44_5B82_417F_A86F_3EFF034CFADF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class MyUsers  
{
public:
	MyUsers();
	virtual ~MyUsers();
private:
	CString Name;
	CString Pwd;
	CString Type;
public:
	CString GetUserName(void);
	CString GetPwd(void);
	CString GetType(void);
	void SetName(CString name);
	void SetPwd(CString pwd);
	void SetType(CString type);
	void GetData(CString name);
};

#endif // !defined(AFX_MYUSERS_H__9CA4AD44_5B82_417F_A86F_3EFF034CFADF__INCLUDED_)
