// Books.cpp: implementation of the Books class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "LibraryManagement.h"
#include "Books.h"
#include "ADOConn.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Books::Books()
{

}

Books::~Books()
{

}

CString Books::GetBookName( void )
{
	return BookName;
}

void Books::SetBookName( CString bookname )
{
	BookName=bookname;
}

int Books::GetBookNum( void )
{
	return BookNum;
}

void Books::SetBookNum( int booknum )
{
	BookNum=booknum;
}

int Books::GetBookAvail( void )
{
	return BookAvail;
}

void Books::SetBookAvail( int bookavail )
{
	BookAvail=bookavail;
}

void Books::GetData( CString bookname )
{
	ADOConn m_AdoConn;
	m_AdoConn.OnInitDBConnect();
	_bstr_t vSQL;
	vSQL="SELECT *FROM [Books] WHERE BookName='"+bookname+"'";
	_RecordsetPtr m_pRecordset;
	m_pRecordset=m_AdoConn.GetRecordSet(vSQL);
	
	if(m_pRecordset->adoEOF)
		::AfxMessageBox("���鲻����!");		
	else
	{
		BookName=(LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("BookName");
		BookNum=atoi((LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("BookNum"));
		BookAvail=atoi((LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("BookAvail"));
	}
}

void Books::sql_update( CString name )
{
	ADOConn m_AdoConn;
	m_AdoConn.OnInitDBConnect();
	BookAvail--;
	_bstr_t vSQL;
	vSQL="UPDATE Books SET BookAvail='BookAvail' WHERE BookName='"+name+"'";
	m_AdoConn.ExecuteSQL(vSQL);
	m_AdoConn.ExitConnect();	
}