// MyUsers.cpp: implementation of the MyUsers class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "LibraryManagement.h"
#include "MyUsers.h"
#include "ADOConn.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

MyUsers::MyUsers()
{

}

MyUsers::~MyUsers()
{

}

CString MyUsers::GetUserName()
{
	return Name;
}

CString MyUsers::GetPwd()
{
	return Pwd;
}

CString MyUsers::GetType()
{
	return Type;
}

void MyUsers::SetName(CString name)
{
	Name=name;
}
void MyUsers::SetPwd(CString pwd)
{
	Pwd=pwd;
}
void MyUsers::SetType(CString type)
{
	Type=type;
}
void MyUsers::GetData(CString name)
{
	ADOConn m_AdoConn;
	m_AdoConn.OnInitDBConnect();
	_bstr_t vSQL;
	vSQL="SELECT *FROM [Users] WHERE Users='"+name+"'";
	_RecordsetPtr m_pRecordset;
	m_pRecordset=m_AdoConn.GetRecordSet(vSQL);

	if(m_pRecordset->adoEOF)
		::AfxMessageBox("�û�������!");
	else
	{
		Name=(LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("Users");
		Pwd=(LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("Pwd");
		Type=(LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("Type");
	}
}
