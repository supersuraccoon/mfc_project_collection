// BookInfo.cpp : implementation file
//

#include "stdafx.h"
#include "LibraryManagement.h"
#include "BookInfo.h"
#include "column.h"
#include "columns.h"
#include "COMDEF.h"
#include "Books.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBookInfo dialog


CBookInfo::CBookInfo(CWnd* pParent /*=NULL*/)
	: CDialog(CBookInfo::IDD, pParent)
{
	//{{AFX_DATA_INIT(CBookInfo)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CBookInfo::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBookInfo)
	DDX_Control(pDX, IDC_ADODC1, m_ado);
	DDX_Control(pDX, IDC_DATAGRID1, m_datagrid);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CBookInfo, CDialog)
	//{{AFX_MSG_MAP(CBookInfo)
	ON_BN_CLICKED(IDC_BOOKSEARCH, OnBooksearch)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBookInfo message handlers

BOOL CBookInfo::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_ado.SetRecordSource("select BookName as ����,BookNum as �ܲ���,BookAvail as ʣ����� from [Books]");
	m_ado.Refresh();
	
	_variant_t index;
	index=long(0);
	m_datagrid.GetColumns().GetItem(index).SetWidth(90);
	index=long(1);
	m_datagrid.GetColumns().GetItem(index).SetWidth(60);
	index=long(2);
	m_datagrid.GetColumns().GetItem(index).SetWidth(60);

	SetDlgItemText(IDC_EDIT2,"�������ѯ������");
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CBookInfo::OnBooksearch() 
{
	// TODO: Add your control notification handler code here
	CString bookname;
	GetDlgItemText(IDC_BOOK,bookname);
	Books books;
	books.GetData(bookname);
	m_ado.SetRecordSource("select BookName as ����,BookNum as �ܲ���,BookAvail as ʣ����� from [Books] where BookName='"+books.GetBookName()+"'");
	m_ado.Refresh();
	
	_variant_t index;
	index=long(0);
	m_datagrid.GetColumns().GetItem(index).SetWidth(90);
	index=long(1);
	m_datagrid.GetColumns().GetItem(index).SetWidth(60);
	index=long(2);
	m_datagrid.GetColumns().GetItem(index).SetWidth(60);
}
