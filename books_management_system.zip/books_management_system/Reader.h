// Reader.h: interface for the Reader class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_READER_H__E8F925C8_F16D_475B_8D00_48A76451007F__INCLUDED_)
#define AFX_READER_H__E8F925C8_F16D_475B_8D00_48A76451007F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class Reader  
{
public:
	Reader();
	virtual ~Reader();
private:
	CString Name;
	CString CardId;
public:
	CString GetName(void);
	void SetName(CString name);
	CString GetCardId(void);
	void SetCardId(CString cardid);
	void GetData(CString cardid);
};

#endif // !defined(AFX_READER_H__E8F925C8_F16D_475B_8D00_48A76451007F__INCLUDED_)
