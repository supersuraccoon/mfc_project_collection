class StudentInfo
{
private:
	CString Name;
	CString CardId;
	CString Sex;
	
public:
	CString GetStudentName(void);
	void SetStudentName(CString name);
	CString GetStudentSex(void);
	void SetStudentSex(CString name);
	CString GetStudentCardId(void);
	void SetStudentCardId(CString name);
}

CString StudentInfo::GetStudentName()
{
	return Name;
}

void StudentInfo::SetStudentName(CString name)
{
	Name=name;
}

CString StudentInfo::GetStudentSex(void)
{
	return Sex;
}
void StudentInfo::SetStudentSex(CString name)
{
	Name=name;
}
CString StudentInfo::GetStudentCardId(void)
{
	return CardId;
}
void StudentInfo::SetStudentCardId(CString name)
{
	Name=name;
}