// Global.h: interface for the CGlobal class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GLOBAL_H__54967F20_2580_44C2_BDC9_42E1C8669066__INCLUDED_)
#define AFX_GLOBAL_H__54967F20_2580_44C2_BDC9_42E1C8669066__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "MyUsers.h"

class CGlobal  
{
public:
	CGlobal();
	virtual ~CGlobal();
};

#endif // !defined(AFX_GLOBAL_H__54967F20_2580_44C2_BDC9_42E1C8669066__INCLUDED_)
