#if !defined(AFX_ADMINMAINDLG_H__EB7D6B17_3DB0_49B1_9CB0_2485056CA099__INCLUDED_)
#define AFX_ADMINMAINDLG_H__EB7D6B17_3DB0_49B1_9CB0_2485056CA099__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AdminMainDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAdminMainDlg dialog

class CAdminMainDlg : public CDialog
{
// Construction
public:
	CAdminMainDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CAdminMainDlg)
	enum { IDD = IDD_DIALOG2 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAdminMainDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CAdminMainDlg)
	virtual void OnOK();
	afx_msg void OnButton1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADMINMAINDLG_H__EB7D6B17_3DB0_49B1_9CB0_2485056CA099__INCLUDED_)
