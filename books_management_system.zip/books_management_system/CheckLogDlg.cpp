// CheckLogDlg.cpp : implementation file
//

#include "stdafx.h"
#include "LibraryManagement.h"
#include "CheckLogDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCheckLogDlg dialog


CCheckLogDlg::CCheckLogDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCheckLogDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCheckLogDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CCheckLogDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCheckLogDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCheckLogDlg, CDialog)
	//{{AFX_MSG_MAP(CCheckLogDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCheckLogDlg message handlers
