// ADOConn.h: interface for the ADOConn class.
//
//////////////////////////////////////////////////////////////////////
#import "c:\Program Files\common Files\System\ado\msado15.dll" no_namespace rename("EOF","adoEOF") rename("BOF","adoBOF")

#if !defined(AFX_ADOCONN_H__CE6D182B_DDE4_49BF_A02B_D85C14CFD023__INCLUDED_)
#define AFX_ADOCONN_H__CE6D182B_DDE4_49BF_A02B_D85C14CFD023__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ADOConn  
{
public:
	_ConnectionPtr m_pConnection;
	_RecordsetPtr m_pRecordset;
public:
	ADOConn();
	virtual ~ADOConn();
	void OnInitDBConnect();
	_RecordsetPtr &GetRecordSet(_bstr_t bstrSQL);
	BOOL ExecuteSQL(_bstr_t bstrSQL);
	void ExitConnect();
};

#endif // !defined(AFX_ADOCONN_H__CE6D182B_DDE4_49BF_A02B_D85C14CFD023__INCLUDED_)
