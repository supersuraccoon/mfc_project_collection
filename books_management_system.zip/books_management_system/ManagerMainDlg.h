#if !defined(AFX_MANAGERMAINDLG_H__A49FC106_DD26_4CE0_8562_69CD2ADA6E7C__INCLUDED_)
#define AFX_MANAGERMAINDLG_H__A49FC106_DD26_4CE0_8562_69CD2ADA6E7C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ManagerMainDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CManagerMainDlg dialog

class CManagerMainDlg : public CDialog
{
// Construction
public:
	CManagerMainDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CManagerMainDlg)
	enum { IDD = IDD_MANAGERMAINDLG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CManagerMainDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CManagerMainDlg)
	afx_msg void OnBrbooks();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MANAGERMAINDLG_H__A49FC106_DD26_4CE0_8562_69CD2ADA6E7C__INCLUDED_)
