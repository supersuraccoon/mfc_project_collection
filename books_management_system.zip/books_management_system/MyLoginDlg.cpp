// MyLoginDlg.cpp : implementation file
//

#include "stdafx.h"
#include "LibraryManagement.h"
#include "MyLoginDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyLoginDlg dialog


CMyLoginDlg::CMyLoginDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMyLoginDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMyLoginDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CMyLoginDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyLoginDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMyLoginDlg, CDialog)
	//{{AFX_MSG_MAP(CMyLoginDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyLoginDlg message handlers
