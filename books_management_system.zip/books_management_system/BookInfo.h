//{{AFX_INCLUDES()
#include "adodc.h"
#include "datagrid.h"
//}}AFX_INCLUDES
#if !defined(AFX_BOOKINFO_H__F64EF616_3F2E_4A59_8317_E20826C958CD__INCLUDED_)
#define AFX_BOOKINFO_H__F64EF616_3F2E_4A59_8317_E20826C958CD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// BookInfo.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CBookInfo dialog

class CBookInfo : public CDialog
{
// Construction
public:
	CBookInfo(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CBookInfo)
	enum { IDD = IDD_BOOKINFO };
	CAdodc	m_ado;
	CDataGrid	m_datagrid;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBookInfo)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CBookInfo)
	virtual BOOL OnInitDialog();
	afx_msg void OnBooksearch();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BOOKINFO_H__F64EF616_3F2E_4A59_8317_E20826C958CD__INCLUDED_)
