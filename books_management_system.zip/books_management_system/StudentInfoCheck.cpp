// StudentInfoCheck.cpp : implementation file
//

#include "stdafx.h"
#include "LibraryManagement.h"
#include "StudentInfoCheck.h"
#include "MyUsers.h"
#include "column.h"
#include "columns.h"
#include "COMDEF.h"

extern MyUsers curUser;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStudentInfoCheck dialog


CStudentInfoCheck::CStudentInfoCheck(CWnd* pParent /*=NULL*/)
	: CDialog(CStudentInfoCheck::IDD, pParent)
{
	//{{AFX_DATA_INIT(CStudentInfoCheck)
	//}}AFX_DATA_INIT
}


void CStudentInfoCheck::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CStudentInfoCheck)
	DDX_Control(pDX, IDC_ADODC1, m_ado);
	DDX_Control(pDX, IDC_DATAGRID2, m_datagrid);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CStudentInfoCheck, CDialog)
	//{{AFX_MSG_MAP(CStudentInfoCheck)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStudentInfoCheck message handlers

BOOL CStudentInfoCheck::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_ado.SetRecordSource("select Name as ����,BookName as ����,BookBorrowTime as ��������,BookTimeup as �������� from ReadersBooks where Name='"+curUser.GetUserName()+"'");
	m_ado.Refresh();

	_variant_t index;
	index=long(0);
	m_datagrid.GetColumns().GetItem(index).SetWidth(45);
	index=long(1);
	m_datagrid.GetColumns().GetItem(index).SetWidth(90);
	index=long(2);
	m_datagrid.GetColumns().GetItem(index).SetWidth(90);
	index=long(3);
	m_datagrid.GetColumns().GetItem(index).SetWidth(90);


	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
