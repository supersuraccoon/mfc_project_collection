// BookBorrowInfo.h: interface for the BookBorrowInfo class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BOOKBORROWINFO_H__AFE21570_FC55_46CB_BAB1_FF1B30A131D6__INCLUDED_)
#define AFX_BOOKBORROWINFO_H__AFE21570_FC55_46CB_BAB1_FF1B30A131D6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class BookBorrowInfo  
{
public:
	BookBorrowInfo();
	virtual ~BookBorrowInfo();
	
};

#endif // !defined(AFX_BOOKBORROWINFO_H__AFE21570_FC55_46CB_BAB1_FF1B30A131D6__INCLUDED_)
