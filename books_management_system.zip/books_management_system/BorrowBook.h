#if !defined(AFX_BORROWBOOK_H__B11E2A65_1CBF_4FC3_944B_9184F532F40A__INCLUDED_)
#define AFX_BORROWBOOK_H__B11E2A65_1CBF_4FC3_944B_9184F532F40A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// BorrowBook.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CBorrowBook dialog

class CBorrowBook : public CDialog
{
// Construction
public:
	CBorrowBook(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CBorrowBook)
	enum { IDD = IDD_BORROW };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBorrowBook)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CBorrowBook)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BORROWBOOK_H__B11E2A65_1CBF_4FC3_944B_9184F532F40A__INCLUDED_)
