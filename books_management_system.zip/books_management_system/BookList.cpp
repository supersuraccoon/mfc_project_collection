// BookList.cpp: implementation of the BookList class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "LibraryManagement.h"
#include "BookList.h"
#include "ADOConn.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

BookList::BookList()
{

}

BookList::~BookList()
{

}

CString BookList::GetBookName( void )
{
	return BookName;
}

void BookList::SetBookName( CString bookname )
{
	BookName=bookname;	
}

CString BookList::GetBookNo( void )
{
	return BookNo;
}

void BookList::SetBookNo( CString bookno )
{
	BookNo=bookno;
}

bool BookList::GetData( CString bookno )
{
	ADOConn m_AdoConn;
	m_AdoConn.OnInitDBConnect();
	_bstr_t vSQL;
	vSQL="SELECT *FROM [BooksList] WHERE BookNo='"+bookno+"'AND BookAvail=1";
	_RecordsetPtr m_pRecordset;
	m_pRecordset=m_AdoConn.GetRecordSet(vSQL);
	
	if(m_pRecordset->adoEOF)
	{
		::AfxMessageBox("���鲻����!");
		return false;
		
	}
	else
	{
		BookName=(LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("BookName");
		BookNo=(LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("BookNo");
		BookAvail=atoi((LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("BookAvail"));
		return true;
	}	
}

void BookList::sql_UPDATE( CString bookno )
{
	ADOConn m_AdoConn;
	m_AdoConn.OnInitDBConnect();
	BookAvail--;
	_bstr_t vSQL;
	vSQL="UPDATE BooksList SET BookAvail=BookAvail WHERE BookNo='"+bookno+"'";
	m_AdoConn.ExecuteSQL(vSQL);
	m_AdoConn.ExitConnect();	
}