// BookBorrowInfo.cpp: implementation of the BookBorrowInfo class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "LibraryManagement.h"
#include "BookBorrowInfo.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

BookBorrowInfo::BookBorrowInfo()
{

}

BookBorrowInfo::~BookBorrowInfo()
{

}
