// SMainDlg.cpp : implementation file
//

#include "stdafx.h"
#include "LibraryManagement.h"
#include "SMainDlg.h"
#include "StudentInfoCheck.h"
#include "BookInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSMainDlg dialog


CSMainDlg::CSMainDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSMainDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSMainDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CSMainDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSMainDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSMainDlg, CDialog)
	//{{AFX_MSG_MAP(CSMainDlg)
	ON_BN_CLICKED(IDC_BOOKBORROWINFO, OnBookborrowinfo)
	ON_BN_CLICKED(IDC_BOOKSEARCH, OnBooksearch)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSMainDlg message handlers

void CSMainDlg::OnBookborrowinfo() 
{
	// TODO: Add your control notification handler code here
	CStudentInfoCheck dlg;
	ShowWindow(SW_HIDE);
	dlg.DoModal();
	ShowWindow(SW_NORMAL);
}

void CSMainDlg::OnBooksearch() 
{
	// TODO: Add your control notification handler code here
	CBookInfo dlg;
	ShowWindow(SW_HIDE);
	dlg.DoModal();
	ShowWindow(SW_NORMAL);
}

void CSMainDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	OnOK();
}
