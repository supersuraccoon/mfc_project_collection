// BookList.h: interface for the BookList class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BOOKLIST_H__774C0670_9FF4_47C5_B292_28CEF0FAEE59__INCLUDED_)
#define AFX_BOOKLIST_H__774C0670_9FF4_47C5_B292_28CEF0FAEE59__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class BookList  
{
public:
	BookList();
	virtual ~BookList();
private:
	CString BookName;
	CString BookNo;
	int BookAvail;
public:
	CString GetBookName(void);
	void SetBookName(CString bookname);
	CString GetBookNo(void);
	void SetBookNo(CString bookno);
	bool GetData(CString bookno);
	void sql_UPDATE(CString bookno);
};

#endif // !defined(AFX_BOOKLIST_H__774C0670_9FF4_47C5_B292_28CEF0FAEE59__INCLUDED_)
