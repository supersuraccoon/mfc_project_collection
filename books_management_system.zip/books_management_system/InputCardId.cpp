// InputCardId.cpp : implementation file
//

#include "stdafx.h"
#include "LibraryManagement.h"
#include "InputCardId.h"
#include "Reader.h"
#include "ReadersBooks.h"
#include "BookList.h"
#include "Books.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BookList booklist;
Reader reader;
Books books;
/////////////////////////////////////////////////////////////////////////////
// CInputCardId dialog


CInputCardId::CInputCardId(CWnd* pParent /*=NULL*/)
	: CDialog(CInputCardId::IDD, pParent)
{
	//{{AFX_DATA_INIT(CInputCardId)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CInputCardId::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CInputCardId)
	DDX_Control(pDX, IDC_ADODC1, m_ado);
	DDX_Control(pDX, IDC_DATAGRID1, m_datagrid);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CInputCardId, CDialog)
	//{{AFX_MSG_MAP(CInputCardId)
	ON_BN_CLICKED(IDC_CONFIRM, OnConfirm)
	ON_BN_CLICKED(IDC_BORROW, OnBorrow)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInputCardId message handlers

void CInputCardId::OnConfirm() 
{
	// TODO: Add your control notification handler code here
	CString cardid;
	GetDlgItemText(IDC_CARDID,cardid);
	reader.GetData(cardid);
	m_ado.SetRecordSource("select Name as ����,BookName as ����,BookBorrowTime as ��������,BookTimeup as �������� from ReadersBooks where Name='"+reader.GetName()+"'");
	m_ado.Refresh();
}

void CInputCardId::OnBorrow() 
{
	// TODO: Add your control notification handler code here
	CString bookno;
	GetDlgItemText(IDC_BOOKNO,bookno);
	ReadersBooks readersbooks;
	if(booklist.GetData(bookno))
	{
		readersbooks.SetName(reader.GetName());
		readersbooks.SetBookName(booklist.GetBookName());
		readersbooks.SetBookNo(bookno);
		readersbooks.sql_insert();
		m_ado.Refresh();
		
		books.GetData(booklist.GetBookName());
		books.sql_update(booklist.GetBookName());
		booklist.sql_UPDATE(bookno);
	}	
}
