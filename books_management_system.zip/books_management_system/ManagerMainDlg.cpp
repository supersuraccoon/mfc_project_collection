// ManagerMainDlg.cpp : implementation file
//

#include "stdafx.h"
#include "LibraryManagement.h"
#include "ManagerMainDlg.h"
#include "InputCardId.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CManagerMainDlg dialog


CManagerMainDlg::CManagerMainDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CManagerMainDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CManagerMainDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CManagerMainDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CManagerMainDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CManagerMainDlg, CDialog)
	//{{AFX_MSG_MAP(CManagerMainDlg)
	ON_BN_CLICKED(IDC_BRBOOKS, OnBrbooks)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CManagerMainDlg message handlers

void CManagerMainDlg::OnBrbooks() 
{
	// TODO: Add your control notification handler code here
	CInputCardId dlg;
	ShowWindow(SW_HIDE);
	dlg.DoModal();
	ShowWindow(SW_NORMAL);
}

void CManagerMainDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	OnOK();
}
