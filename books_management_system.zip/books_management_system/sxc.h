#if !defined(AFX_SXC_H__D806AF5E_70D4_4056_BBE4_37205DD654BD__INCLUDED_)
#define AFX_SXC_H__D806AF5E_70D4_4056_BBE4_37205DD654BD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// sxc.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// Csxc dialog

class Csxc : public CDialog
{
// Construction
public:
	Csxc(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(Csxc)
	enum { IDD = IDD_LOGIN };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(Csxc)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(Csxc)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SXC_H__D806AF5E_70D4_4056_BBE4_37205DD654BD__INCLUDED_)
