// Books.h: interface for the Books class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BOOKS_H__29861EF2_0944_4A80_BEAF_14FF13CADA93__INCLUDED_)
#define AFX_BOOKS_H__29861EF2_0944_4A80_BEAF_14FF13CADA93__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class Books  
{
public:
	Books();
	virtual ~Books();
private:
	CString BookName;
	int BookNum;
	int BookAvail;
public:
	CString GetBookName(void);
	void SetBookName(CString bookname);
	int GetBookNum(void);
	void SetBookNum(int booknum);
	int GetBookAvail(void);
	void SetBookAvail(int bookavail);
	void GetData(CString bookname);
	void sql_update(CString name);
};

#endif // !defined(AFX_BOOKS_H__29861EF2_0944_4A80_BEAF_14FF13CADA93__INCLUDED_)
