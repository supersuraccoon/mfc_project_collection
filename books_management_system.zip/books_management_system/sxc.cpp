// sxc.cpp : implementation file
//

#include "stdafx.h"
#include "LibraryManagement.h"
#include "sxc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Csxc dialog


Csxc::Csxc(CWnd* pParent /*=NULL*/)
	: CDialog(Csxc::IDD, pParent)
{
	//{{AFX_DATA_INIT(Csxc)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void Csxc::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Csxc)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(Csxc, CDialog)
	//{{AFX_MSG_MAP(Csxc)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Csxc message handlers
