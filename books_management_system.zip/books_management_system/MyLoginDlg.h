#if !defined(AFX_MYLOGINDLG_H__7E2CBDAD_AC06_4EC5_808B_67C36534D436__INCLUDED_)
#define AFX_MYLOGINDLG_H__7E2CBDAD_AC06_4EC5_808B_67C36534D436__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MyLoginDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMyLoginDlg dialog

class CMyLoginDlg : public CDialog
{
// Construction
public:
	CMyLoginDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMyLoginDlg)
	enum { IDD = IDD_LOGIN };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyLoginDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMyLoginDlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYLOGINDLG_H__7E2CBDAD_AC06_4EC5_808B_67C36534D436__INCLUDED_)
