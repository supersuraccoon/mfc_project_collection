// AdminMainDlg.cpp : implementation file
//

#include "stdafx.h"
#include "LibraryManagement.h"
#include "AdminMainDlg.h"
#include "AdminMangermentDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAdminMainDlg dialog


CAdminMainDlg::CAdminMainDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAdminMainDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAdminMainDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CAdminMainDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAdminMainDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAdminMainDlg, CDialog)
	//{{AFX_MSG_MAP(CAdminMainDlg)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAdminMainDlg message handlers

void CAdminMainDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	OnOK();
}

void CAdminMainDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	CAdminMangermentDlg dlg;
	ShowWindow(SW_HIDE);
	dlg.DoModal();
	ShowWindow(SW_NORMAL);
}
