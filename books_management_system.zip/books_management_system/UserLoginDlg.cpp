// UserLoginDlg.cpp : implementation file
//

#include "stdafx.h"
#include "LibraryManagement.h"
#include "UserLoginDlg.h"
#include "MyUsers.h"
#include "SMainDlg.h"
#include "ManagerMainDlg.h"
#include "AdminMainDlg.h"

extern MyUsers curUser;
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUserLoginDlg dialog


CUserLoginDlg::CUserLoginDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CUserLoginDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CUserLoginDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CUserLoginDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUserLoginDlg)
	DDX_Control(pDX, IDC_CHOICE, m_choice);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CUserLoginDlg, CDialog)
	//{{AFX_MSG_MAP(CUserLoginDlg)
	ON_BN_CLICKED(IDC_CONFIRM, OnConfirm)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUserLoginDlg message handlers

void CUserLoginDlg::OnConfirm() 
{
	// TODO: Add your control notification handler code here
	CString name;
	CString pwd;
	CString type;
	GetDlgItemText(IDC_NAME,name);
	GetDlgItemText(IDC_PWD,pwd);
	GetDlgItemText(IDC_CHOICE,type);
	if(name==""||pwd=="")
	{
		SetDlgItemText(IDC_NAME,"");
		SetDlgItemText(IDC_PWD,"");
		return;
	}
	MyUsers user;
	user.GetData(name);
	if (user.GetPwd()!=pwd||user.GetType()!=type)
	{
		::MessageBox(m_hWnd,"��½ʧ��!","����",MB_OK);
		SetDlgItemText(IDC_NAME,"");
		SetDlgItemText(IDC_PWD,"");
		return;
	}
	::MessageBox(m_hWnd,"��½�ɹ�!","ϵͳ��Ϣ",MB_OK);
	curUser.GetData(name);

	if (curUser.GetType()=="ѧ��")
	{
		CSMainDlg dlg;
		ShowWindow(SW_HIDE);
		dlg.DoModal();
		ShowWindow(SW_NORMAL);
	}
	else
		if(curUser.GetType()=="ͼ�����Ա")
		{
			CManagerMainDlg dlg;
			ShowWindow(SW_HIDE);
			dlg.DoModal();
			ShowWindow(SW_NORMAL);
		}
		else
		{
			CAdminMainDlg dlg;
			ShowWindow(SW_HIDE);
			dlg.DoModal();
			ShowWindow(SW_NORMAL);
		}
	
	
	CDialog::OnOK();
}

BOOL CUserLoginDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_choice.AddString("ѧ��");
	m_choice.AddString("ͼ�����Ա");
	m_choice.AddString("ϵͳ����Ա");
	m_choice.SetCurSel(0);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
