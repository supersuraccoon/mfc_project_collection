//{{AFX_INCLUDES()
#include "adodc.h"
#include "datagrid.h"
//}}AFX_INCLUDES
#if !defined(AFX_ADMINMANGERMENTDLG_H__62CDEF41_D475_4738_AB5C_3B5F6E1199C6__INCLUDED_)
#define AFX_ADMINMANGERMENTDLG_H__62CDEF41_D475_4738_AB5C_3B5F6E1199C6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AdminMangermentDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAdminMangermentDlg dialog

class CAdminMangermentDlg : public CDialog
{
// Construction
public:
	CAdminMangermentDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CAdminMangermentDlg)
	enum { IDD = IDD_DIALOG3 };
	CAdodc	m_ado;
	CDataGrid	m_datagrid;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAdminMangermentDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CAdminMangermentDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADMINMANGERMENTDLG_H__62CDEF41_D475_4738_AB5C_3B5F6E1199C6__INCLUDED_)
