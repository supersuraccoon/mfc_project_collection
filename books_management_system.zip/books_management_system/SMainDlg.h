#if !defined(AFX_SMAINDLG_H__D1DB6CD9_8409_4BE5_B0D0_01FC817D6DA1__INCLUDED_)
#define AFX_SMAINDLG_H__D1DB6CD9_8409_4BE5_B0D0_01FC817D6DA1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SMainDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSMainDlg dialog

class CSMainDlg : public CDialog
{
// Construction
public:
	CSMainDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSMainDlg)
	enum { IDD = IDD_SMAINDLG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSMainDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSMainDlg)
	afx_msg void OnBookborrowinfo();
	afx_msg void OnBooksearch();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SMAINDLG_H__D1DB6CD9_8409_4BE5_B0D0_01FC817D6DA1__INCLUDED_)
