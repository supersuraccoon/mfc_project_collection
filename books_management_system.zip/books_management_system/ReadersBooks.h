// ReadersBooks.h: interface for the ReadersBooks class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_READERSBOOKS_H__CAB9FEC0_F3D1_48CD_B8D8_727E037FABF5__INCLUDED_)
#define AFX_READERSBOOKS_H__CAB9FEC0_F3D1_48CD_B8D8_727E037FABF5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ReadersBooks  
{
public:
	ReadersBooks();
	virtual ~ReadersBooks();
private:
	CString Name;
	CString BookName;
	CString BorrowTime;
	CString BookTimeup;
	CString BookNo;
public:
	CString GetName(void);
	void SetName(CString name);
	CString GetBookName(void);
	void SetBookName(CString bookname);
	void sql_insert(void);
	void SetBookNo(CString bookno);
};

#endif // !defined(AFX_READERSBOOKS_H__CAB9FEC0_F3D1_48CD_B8D8_727E037FABF5__INCLUDED_)
