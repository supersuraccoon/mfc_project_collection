// Reader.cpp: implementation of the Reader class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "LibraryManagement.h"
#include "Reader.h"
#include "ADOConn.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Reader::Reader()
{

}

Reader::~Reader()
{

}

CString Reader::GetName( void )
{
	return Name;
}

void Reader::SetName( CString name )
{
	Name=name;	
}

CString Reader::GetCardId( void )
{
	return CardId;	
}

void Reader::SetCardId( CString cardid )
{
	CardId=cardid;	
}

void Reader::GetData( CString cardid )
{
	ADOConn m_AdoConn;
	m_AdoConn.OnInitDBConnect();
	_bstr_t vSQL;
	vSQL="SELECT *FROM [Readers] WHERE CardId='"+cardid+"'";
	_RecordsetPtr m_pRecordset;
	m_pRecordset=m_AdoConn.GetRecordSet(vSQL);
	
	if(m_pRecordset->adoEOF)
		::AfxMessageBox("�ö��߲�����!");
	else
	{
		Name=(LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("Name");
		CardId=cardid;
	}
}