// ReadersBooks.cpp: implementation of the ReadersBooks class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "LibraryManagement.h"
#include "ReadersBooks.h"
#include "ADOConn.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

ReadersBooks::ReadersBooks()
{
	BorrowTime="2007-12-12";
	BookTimeup="2008-1-2";
}

ReadersBooks::~ReadersBooks()
{

}

CString ReadersBooks::GetName( void )
{
	return Name;
}

void ReadersBooks::SetName( CString name )
{
	Name=name;
}

CString ReadersBooks::GetBookName( void )
{
	return BookName;
}

void ReadersBooks::SetBookName( CString bookname )
{
	BookName=bookname;
}
void ReadersBooks::sql_insert(void)
{
	ADOConn m_AdoConn;
	m_AdoConn.OnInitDBConnect();
	_bstr_t vSQL;
	vSQL="INSERT INTO ReadersBooks(Name,BookName,BookBorrowTime,BookTimeup,BookNo)VALUES('"+Name+"','"+BookName+"','"+BorrowTime+"','"+BookTimeup+"','"+BookNo+"')";
	m_AdoConn.ExecuteSQL(vSQL);
	m_AdoConn.ExitConnect();
}

void ReadersBooks::SetBookNo( CString bookno )
{
	BookNo=bookno;	
}