//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by LibraryManagement.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_LIBRARYMANAGEMENT_DIALOG    102
#define IDR_MAINFRAME                   128
#define IDD_LOGIN                       129
#define IDD_DIALOG1                     130
#define IDD_STUDENTINFO                 131
#define IDD_SMAINDLG                    133
#define IDD_BOOKINFO                    134
#define IDD_MANAGERMAINDLG              136
#define IDD_INPUTCARDID                 137
#define IDD_DIALOG2                     140
#define IDD_DIALOG3                     141
#define IDB_BITMAP1                     146
#define IDB_BITMAP2                     148
#define IDB_BITMAP3                     149
#define IDC_LOGIN                       1000
#define IDC_CHOICE                      1001
#define IDC_SHOW                        1002
#define IDC_CONFIRM                     1003
#define IDC_RETURN                      1004
#define IDC_EDIT1                       1006
#define IDC_NAME                        1006
#define IDC_BOOK                        1006
#define IDC_CARDID                      1006
#define IDC_EDIT2                       1007
#define IDC_PWD                         1007
#define IDC_BOOKNO                      1007
#define IDC_DATAGRID1                   1009
#define IDC_ADODC1                      1010
#define IDC_BOOKBORROWINFO              1011
#define IDC_BUTTON2                     1012
#define IDC_BOOKSEARCH                  1012
#define IDC_BORROW                      1012
#define IDC_DATAGRID2                   1013
#define IDC_BUTTON1                     1015
#define IDC_BRBOOKS                     1017
#define IDC_BOOKINSTORE                 1018
#define IDC_BUTTON3                     1019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        150
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
