// AdminMangermentDlg.cpp : implementation file
//

#include "stdafx.h"
#include "LibraryManagement.h"
#include "AdminMangermentDlg.h"
#include "column.h"
#include "columns.h"
#include "COMDEF.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAdminMangermentDlg dialog


CAdminMangermentDlg::CAdminMangermentDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAdminMangermentDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAdminMangermentDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CAdminMangermentDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAdminMangermentDlg)
	DDX_Control(pDX, IDC_ADODC1, m_ado);
	DDX_Control(pDX, IDC_DATAGRID1, m_datagrid);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAdminMangermentDlg, CDialog)
	//{{AFX_MSG_MAP(CAdminMangermentDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAdminMangermentDlg message handlers

BOOL CAdminMangermentDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_ado.SetRecordSource("select Users as �û���,Pwd as ����,Type as �˺����� from Users ORDER BY Type");
	m_ado.Refresh();
	
	_variant_t index;
	index=long(0);
	m_datagrid.GetColumns().GetItem(index).SetWidth(50);
	index=long(1);
	m_datagrid.GetColumns().GetItem(index).SetWidth(50);
	index=long(2);
	m_datagrid.GetColumns().GetItem(index).SetWidth(70);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
