// FileToListDlg.cpp : implementation file
//

#include "stdafx.h"
#include "FileToList.h"
#include "FileToListDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BOOL Sort=FALSE;
BOOL Path=FALSE;
BOOL ExtName=FALSE;
BOOL Single=FALSE;
BOOL Pause=FALSE;
BOOL Stop=FALSE;
BOOL Run=FALSE;
int subItem=0;
CWinThread*   pthread   =  NULL;
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFileToListDlg dialog

CFileToListDlg::CFileToListDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFileToListDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFileToListDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CFileToListDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFileToListDlg)
	DDX_Control(pDX, IDC_SHOWFILES, m_caller_list);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CFileToListDlg, CDialog)
	//{{AFX_MSG_MAP(CFileToListDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_DROPFILES()
	ON_WM_CREATE()
	ON_BN_CLICKED(IDC_TOLIST, OnTolist)
	ON_NOTIFY(LVN_COLUMNCLICK, IDC_SHOWFILES, OnColumnclickShowfiles)
	ON_BN_CLICKED(IDC_RADIO1, OnRadio1)
	ON_BN_CLICKED(IDC_RADIO3, OnRadio3)
	ON_BN_CLICKED(IDC_CLEAR, OnClear)
	ON_BN_CLICKED(IDC_RADIO2, OnRadio2)
	ON_BN_CLICKED(IDC_DELETE, OnDelete)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFileToListDlg message handlers

BOOL CFileToListDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	char *szColumn[]={"·��","�ļ���","�ļ�����"};
	int widths[]={150,200,100};
	LV_COLUMN lvc;
	lvc.mask=LVCF_FMT|LVCF_WIDTH|LVCF_TEXT|LVCF_SUBITEM;
	lvc.fmt=LVCFMT_LEFT;
	for(int i=0;i<3;i++) 
	{//�������
		lvc.pszText=szColumn[i];
		lvc.cx=widths[i];
		lvc.iSubItem=i;
		m_caller_list.InsertColumn(i,&lvc);
	}
	m_caller_list.SetExtendedStyle(m_caller_list.GetExtendedStyle()|LVS_EX_GRIDLINES|
		LVS_EX_FULLROWSELECT); 

	m_myToolTip.Create(this);   
	m_myToolTip.Activate(TRUE);    
	m_myToolTip.AddTool(GetDlgItem(IDC_SHOWFILES),"����");
	m_myToolTip.AddTool(GetDlgItem(IDC_RADIO2),"����");
	
	// CG: The following block was added by the ToolTips component.
	{
		// Create the ToolTip control.
		m_tooltip.Create(this);
		m_tooltip.Activate(TRUE);

		// TODO: Use one of the following forms to add controls:
		// m_tooltip.AddTool(GetDlgItem(IDC_<name>), <string-table-id>);
		// m_tooltip.AddTool(GetDlgItem(IDC_<name>), "<text>");
	}
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CFileToListDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CFileToListDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CFileToListDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CFileToListDlg::OnDropFiles(HDROP hDropInfo) 
{
	// TODO: Add your message handler code here and/or call default

	TCHAR  tch[10000];   
	CString DropPath;
    CFileFind  ff;
	int  iCnt=::DragQueryFile(hDropInfo,0xFFFFFFFF,NULL,0);  
	for(int i=0;i<iCnt;i++)   
	{   
		memset(tch,0,sizeof TCHAR*10000);   
		::DragQueryFile(hDropInfo,i,tch,10000);   
		DropPath=tch;
	}   
	::DragFinish(hDropInfo);   
	
	if (!Pause&&!Run)
	{
		SetDlgItemText(IDC_HELPTEXT,"�ļ������У�����ͣ");
		(CButton*)GetDlgItem(IDC_BUTTON2)->EnableWindow(TRUE);
		(CButton*)GetDlgItem(IDC_BUTTON3)->EnableWindow(FALSE);
		Run=TRUE;
		ShowFiles(DropPath);
		if (!Stop)
		{
			(CButton*)GetDlgItem(IDC_BUTTON3)->EnableWindow(FALSE);
			(CButton*)GetDlgItem(IDC_BUTTON2)->EnableWindow(FALSE);
			SetDlgItemText(IDC_HELPTEXT,"��������ɣ��ɿ�ʼ�µ�����");
		}
		Stop=FALSE;
		Run=FALSE;
	}
	
	ff.Close();
	
	CDialog::OnDropFiles(hDropInfo);
}

int CFileToListDlg::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	DragAcceptFiles(TRUE);

	return 0;
}

BOOL CFileToListDlg::ShowFiles(CString path)
{
	
    static int index=0;
	CFileFind  ff;
	BOOL  bFound; 

	bFound=ff.FindFile(path+"\\*.*"); 
	while(bFound)  
	{  
		bFound=ff.FindNextFile();  
		CString sFilePath=ff.GetFilePath();
		CString pathName=ff.GetFileName();
		CString extName;
		CString fileName;
		
		MSG msg; 
		while(PeekMessage(&msg, NULL, NULL, NULL, PM_REMOVE)) 
		{ 
			TranslateMessage(&msg); 
			DispatchMessage(&msg); 
		}
		
		if (Stop)
		{
			ff.Close();
			Pause=FALSE;
			return true;
		}

		if(ff.IsDirectory())  
		{  
			if(!ff.IsDots()&&!Single)  
			{	
				ListFolder(sFilePath);
			}
		}
		else
		{
			fileName=ff.GetFileTitle();
			extName=sFilePath.Right(3);
			m_caller_list.InsertItem(0,path);
			m_caller_list.SetItemText(0,1,fileName);
			m_caller_list.SetItemText(0,2,extName);
		}
	}  	
	
	return true;
}

BOOL CFileToListDlg::ListFolder(CString sPath)
{
	CFileFind  ff;  
	CString extName;
	CString fileName;
	BOOL  bFound;  
	bFound=ff.FindFile(sPath+"\\*.*");  

	MSG msg; 
	while(PeekMessage(&msg, NULL, NULL, NULL, PM_REMOVE)) 
	{ 
		TranslateMessage(&msg); 
		DispatchMessage(&msg); 
	}

	while(Pause)
	{
		while(PeekMessage(&msg, NULL, NULL, NULL, PM_REMOVE)) 
		{ 
			TranslateMessage(&msg); 
			DispatchMessage(&msg); 
		}
		if (Stop)
		{
			return true;
		}
	}
	while(bFound)  
	{  
		bFound=ff.FindNextFile();  
		CString sFilePath=ff.GetFilePath();  
		
		if(ff.IsDirectory())  
		{  
			if(!ff.IsDots())  
				ListFolder(sFilePath); 
		}  
		else  
		{  
			fileName=ff.GetFileTitle();
			extName=sFilePath.Right(3);
			m_caller_list.InsertItem(0,sPath);
			m_caller_list.SetItemText(0,1,fileName);
			m_caller_list.SetItemText(0,2,extName);
		}  
	}  
	ff.Close();

	return true;
}

void CFileToListDlg::OnTolist() 
{
	// TODO: Add your control notification handler code here
	int count=0;
	CFileDialog fileDlg(FALSE);
	CString savePath;
	CString text="";
	fileDlg.m_ofn.lpstrTitle="�ļ�����Ի���";
	fileDlg.m_ofn.lpstrFilter="Text Files(*.txt)\0*.txt\0All Files(*.*)\0*.*\0\0";

	if(IDOK==fileDlg.DoModal())
	{
		savePath=fileDlg.GetFileName();
	}
	
	if (savePath=="")
	{
		return;
	}
	else
	{
		CStdioFile file(savePath+=".txt",CFile::modeWrite|CFile::modeCreate|CFile::modeNoTruncate);
		file.SeekToEnd();
		count=m_caller_list.GetItemCount();
		if (!count)
		{
			file.Close();
			return ;
		}
		for (int i=0;i<count;i++)
		{
			if (Path)
			{
				file.WriteString(m_caller_list.GetItemText(i,0));
				file.WriteString("  ");
			}
			if (ExtName)
			{
				file.WriteString(m_caller_list.GetItemText(i,1)+"."+
					m_caller_list.GetItemText(i,2));
				file.WriteString("\r\n");
			}
			else
			{
				file.WriteString(m_caller_list.GetItemText(i,1));
				file.WriteString("\r\n");
			}
		}
		file.Close();
	}
}

static int CALLBACK ListCompare(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort)
{
	CListCtrl* pListCtrl = (CListCtrl*) lParamSort;
	CString    strItem1 = pListCtrl->GetItemText(lParam1, subItem);
	CString    strItem2 = pListCtrl->GetItemText(lParam2, subItem);
	
	if (Sort)
		return strcmp(strItem2, strItem1);
	else
		return strcmp(strItem1, strItem2);

}

void CFileToListDlg::OnColumnclickShowfiles(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	int  i=m_caller_list.GetItemCount();   
    while(i--)
		m_caller_list.SetItemData(i,i);
	subItem=pNMListView->iSubItem;

	m_caller_list.SortItems(ListCompare,(LPARAM)&m_caller_list);

	Sort=Sort?FALSE:TRUE;
	
	*pResult = 0;
}

void CFileToListDlg::OnRadio1() 
{
	// TODO: Add your control notification handler code here
	Path=Path?FALSE:TRUE;
	((CButton*)GetDlgItem(IDC_RADIO1))->SetCheck(Path);
}

void CFileToListDlg::OnRadio3() 
{
	// TODO: Add your control notification handler code here
	ExtName=ExtName?FALSE:TRUE;
	((CButton*)GetDlgItem(IDC_RADIO3))->SetCheck(ExtName);
}

void CFileToListDlg::OnClear() 
{
	// TODO: Add your control notification handler code here
	m_caller_list.DeleteAllItems();
}

void CFileToListDlg::OnRadio2() 
{
	// TODO: Add your control notification handler code here
	Single=Single?FALSE:TRUE;
	((CButton*)GetDlgItem(IDC_RADIO2))->SetCheck(Single);
	if (Single)
	{	
		SetDlgItemText(IDC_HELPTEXT,"ȡ��\"����Ŀ¼\" ѡ��,�ɶ�Ŀ¼�е������ļ����б���");
	}
	else
	{
		SetDlgItemText(IDC_HELPTEXT,"ѡ��\"����Ŀ¼\" ѡ��,�ɽ��Ե���Ŀ¼���б���");
	}
}

void CFileToListDlg::OnDelete() 
{
	// TODO: Add your control notification handler code here
	int   i;   
	for(i=m_caller_list.GetItemCount()-1;i>=0;i--)   
	{   
        if(m_caller_list.GetItemState(i,LVIS_SELECTED)==LVIS_SELECTED)   
			m_caller_list.DeleteItem(i);     
	}   

}

BOOL CFileToListDlg::PreTranslateMessage(MSG* pMsg)
{
	// CG: The following block was added by the ToolTips component.
	{
		// Let the ToolTip process this message.
		m_tooltip.RelayEvent(pMsg);
	}

	m_tooltip.RelayEvent(pMsg);
	return CDialog::PreTranslateMessage(pMsg);	// CG: This was added by the ToolTips component.
}

void CFileToListDlg::OnButton2() 
{
	// TODO: Add your control notification handler code here
	Pause=Pause?FALSE:TRUE; 
	if (!Pause)
	{
		(CButton*)GetDlgItem(IDC_BUTTON3)->EnableWindow(FALSE);
		SetDlgItemText(IDC_BUTTON2,"��ͣ");
	}
	else
	{
		SetDlgItemText(IDC_HELPTEXT,"��ͣ�У��ɼ�����ֹͣ��ʼ�µ�����");
		(CButton*)GetDlgItem(IDC_BUTTON3)->EnableWindow(TRUE);
		SetDlgItemText(IDC_BUTTON2,"����");
	}
}


void CFileToListDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	exit(0);
	
	CDialog::OnCancel();
}

void CFileToListDlg::OnButton3() 
{
	// TODO: Add your control notification handler code here
	Stop=TRUE;
	SetDlgItemText(IDC_BUTTON2,"��ͣ");
	SetDlgItemText(IDC_HELPTEXT,"�����ѱ���ֹ���ɿ�ʼ�µ�����");
	(CButton*)GetDlgItem(IDC_BUTTON3)->EnableWindow(FALSE);
	(CButton*)GetDlgItem(IDC_BUTTON2)->EnableWindow(FALSE);
}
