// FileToListDlg.h : header file
//

#if !defined(AFX_FILETOLISTDLG_H__01E03CB3_4E4F_4DF1_A02B_348A50C33F90__INCLUDED_)
#define AFX_FILETOLISTDLG_H__01E03CB3_4E4F_4DF1_A02B_348A50C33F90__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CFileToListDlg dialog

class CFileToListDlg : public CDialog
{
// Construction
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	CFileToListDlg(CWnd* pParent = NULL);	// standard constructor
	CToolTipCtrl   m_myToolTip;

// Dialog Data
	//{{AFX_DATA(CFileToListDlg)
	enum { IDD = IDD_FILETOLIST_DIALOG };
	CListCtrl	m_caller_list;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFileToListDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CToolTipCtrl m_tooltip;
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CFileToListDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnDropFiles(HDROP hDropInfo);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnTolist();
	afx_msg void OnColumnclickShowfiles(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnRadio1();
	afx_msg void OnRadio3();
	afx_msg void OnClear();
	afx_msg void OnRadio2();
	afx_msg void OnDelete();
	afx_msg void OnButton2();
	virtual void OnCancel();
	afx_msg void OnButton3();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	BOOL ListFolder(CString sPath);
	BOOL ShowFiles(CString path);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILETOLISTDLG_H__01E03CB3_4E4F_4DF1_A02B_348A50C33F90__INCLUDED_)
