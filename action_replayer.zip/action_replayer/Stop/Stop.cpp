#include <windows.h>

HHOOK g_hook=NULL;
HHOOK g_hKeyboard=NULL;

#pragma data_seg("MySec")
HWND g_hWnd=NULL;
#pragma data_seg()


LRESULT CALLBACK KeyboardProc(int code,WPARAM wParam,LPARAM lParam)
{

	if((GetKeyState(VK_MENU)<0)&&(wParam=='S'))
	{   
		
		ShowWindow(g_hWnd,SW_SHOWNORMAL);
		UnhookWindowsHookEx(g_hKeyboard);
		UnhookWindowsHookEx(g_hook);
	}	

	return CallNextHookEx(g_hKeyboard,code,wParam,lParam);

}

void ReleaseHook(HWND hwnd,HHOOK hook)
{
	g_hWnd=hwnd;
	g_hook=hook;
	g_hKeyboard=SetWindowsHookEx(WH_KEYBOARD,KeyboardProc,GetModuleHandle("Stop"),0);
}