// 19Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "19.h"
#include "19Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


_declspec(dllimport) void ReleaseHook(HWND hwnd,HHOOK hook);

HHOOK recHook,playHook;
EVENTMSG EventArray[10000];
int recordedEvent=0;
int playedEvent=0;

LRESULT CALLBACK RecHook(int code,WPARAM wParam,LPARAM lParam);
LRESULT CALLBACK PlayHook(int code,WPARAM wParam,LPARAM lParam);
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMy19Dlg dialog

CMy19Dlg::CMy19Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMy19Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMy19Dlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMy19Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMy19Dlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMy19Dlg, CDialog)
	//{{AFX_MSG_MAP(CMy19Dlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CREATE()
	ON_COMMAND(ID_EXIT, OnExit)
	ON_COMMAND(ID_RECORD, OnRecord)
	ON_COMMAND(ID_STOP, OnStop)
	ON_COMMAND(ID_REPLAY, OnReplay)
	ON_COMMAND(ID_SAVE, OnSave)
	ON_COMMAND(ID_LOAD, OnLoad)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMy19Dlg message handlers

BOOL CMy19Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	 ModifyIcon(".sxc","D:\\Abu.ico");

	CMy19App* app=(CMy19App*)::AfxGetApp();
	//::AfxMessageBox(app->strURL);
	if(app->strURL!="")
	{
		CString path;
		path=app->strURL;
		CStdioFile file(path,CFile::modeRead);
		CString str;
		file.ReadString(str);
		int no=atoi(str);
		recordedEvent=no;
		
		for(int i=0;i<no;i++)
		{
			file.ReadString(str);
			EventArray[i].message=atoi(str);
			file.ReadString(str);
			EventArray[i].paramH=atoi(str);
			file.ReadString(str);
			EventArray[i].paramL=atoi(str);
			file.ReadString(str);
			EventArray[i].time=atoi(str);	
			file.ReadString(str);
			EventArray[i].hwnd=HWND((atoi(str)));
		}
		file.Close();
		OnReplay();
	}
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMy19Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMy19Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMy19Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

int CMy19Dlg::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	if(!m_wndToolBar.Create(this)   ||   !m_wndToolBar.LoadToolBar(IDR_TOOLBAR1))   
	{   
		TRACE0("Failed to Create Dialog Toolbar\n");   
		EndDialog(IDCANCEL);   
	}   
    
	CRect rcClientOld;    
	CRect rcClientNew;     
	GetClientRect(rcClientOld);    
	
	RepositionBars(AFX_IDW_CONTROLBAR_FIRST,AFX_IDW_CONTROLBAR_LAST,0,reposQuery,rcClientNew);   
    
	CPoint ptOffset(rcClientNew.left-rcClientOld.left,   
	rcClientNew.top-rcClientOld.top);   
    
	CRect rcChild;   
	CWnd* pwndChild=GetWindow(GW_CHILD);     
	while(pwndChild)   
	{  
		pwndChild->GetWindowRect(rcChild);   
		ScreenToClient(rcChild);     
		rcChild.OffsetRect(ptOffset);     
		pwndChild->MoveWindow(rcChild,FALSE);     
		pwndChild=pwndChild->GetNextWindow();   
	}   
    
	CRect rcWindow;   
	GetWindowRect(rcWindow);  
	rcWindow.right+=rcClientOld.Width()-rcClientNew.Width();  
	rcWindow.bottom+=rcClientOld.Height()-rcClientNew.Height();     
	MoveWindow(rcWindow,FALSE);    
    
	RepositionBars(AFX_IDW_CONTROLBAR_FIRST,AFX_IDW_CONTROLBAR_LAST,0);   
	
	return 0;
}

void CMy19Dlg::OnExit() 
{
	// TODO: Add your command handler code here
	OnOK();
}

void CMy19Dlg::OnRecord() 
{
	// TODO: Add your command handler code here
	::ShowWindow(::AfxGetApp()->GetMainWnd()->m_hWnd,SW_MINIMIZE);
	recordedEvent=0;
	recHook=SetWindowsHookEx(WH_JOURNALRECORD,(HOOKPROC)RecHook,
		(HINSTANCE)AfxGetApp()->m_hInstance,0);
	ReleaseHook(m_hWnd,recHook);
}

void CMy19Dlg::OnStop() 
{
	// TODO: Add your command handler code here
	UnhookWindowsHookEx(recHook);
}

void CMy19Dlg::OnReplay() 
{
	// TODO: Add your command handler code here
	::ShowWindow(::AfxGetApp()->GetMainWnd()->m_hWnd,SW_MINIMIZE);
	playedEvent=0;
	playHook=SetWindowsHookEx(WH_JOURNALPLAYBACK,(HOOKPROC)PlayHook,
		(HINSTANCE)AfxGetApp()->m_hInstance,0);
}

LRESULT CALLBACK RecHook(int code,WPARAM wParam,LPARAM lParam)
{
	
	static int recOK=1;
	if(code<0)
		return CallNextHookEx(recHook,code,wParam,lParam);
	else if(code==HC_SYSMODALON)
		recOK=0;
	else if(code==HC_SYSMODALOFF)
		recOK=1;
	else if(recOK && (code==HC_ACTION))
	{
		EventArray[recordedEvent]= *((PEVENTMSG)lParam);
		recordedEvent++;
		if(recordedEvent==10000)
		{
			UnhookWindowsHookEx(recHook);
		}
	}
	return 0;
}


LRESULT CALLBACK PlayHook(int code,WPARAM wParam,LPARAM lParam)
{
	static BOOL fDelay;
	static int playOK=1;
	if(code<0)
		return CallNextHookEx(playHook,code,wParam,lParam);
	else if(code==HC_SYSMODALON)
		playOK=0;
	else if(code==HC_SYSMODALOFF)
	{
		playOK=1;
	}
	else if(playOK && (code==HC_GETNEXT))
	{
		if(fDelay)
		{
			fDelay=false;
			return 25;
			//(EventArray[playedEvent].time-EventArray[playedEvent-1].time);
		}
		*((PEVENTMSG)lParam)=EventArray[playedEvent];
	}
	else if(playOK && (code==HC_SKIP))
	{
		fDelay=TRUE;
		playedEvent++;
	}
	if(playedEvent>=recordedEvent)
	{
		UnhookWindowsHookEx(playHook);
		exit(0);
		//::ShowWindow(::AfxGetApp()->GetMainWnd()->m_hWnd,SW_NORMAL);
	}
	return 0;
}

void CMy19Dlg::OnSave() 
{
	// TODO: Add your command handler code here
	CString str;

	CFileDialog dlg(FALSE);
	dlg.m_ofn.lpstrTitle="�ҵ��ļ�����Ի���";
	dlg.m_ofn.lpstrFilter="SXC Files(*.sxc)\0*.sxc\0All Files(*.*)\0*.*\0\0";
	dlg.m_ofn.lpstrDefExt="sxc";
	
	str.Format("%d",recordedEvent);

	if(IDOK==dlg.DoModal())
	{
		CStdioFile file(dlg.GetFileName(),CFile::modeCreate | CFile::modeWrite);
		str+="\r\n";
		file.WriteString(str);
	
		for(int i=0;i<recordedEvent;i++)
		{
			str.Format("%d",EventArray[i].message);
			str+="\r\n";
			file.WriteString(str);
			str.Format("%d",EventArray[i].paramH);
			str+="\r\n";
			file.WriteString(str);
			str.Format("%d",EventArray[i].paramL);
			str+="\r\n";
			file.WriteString(str);
			str.Format("%d",EventArray[i].time);
			str+="\r\n";
			file.WriteString(str);
			str.Format("%d",EventArray[i].hwnd);
			str+="\r\n";
			file.WriteString(str);
		}
		file.Close();
	}
}

void CMy19Dlg::OnLoad() 
{
	// TODO: Add your command handler code here
	CString str;
	CFileDialog dlg(TRUE);
	dlg.m_ofn.lpstrTitle="�ҵ��ļ��򿪶Ի���";
	dlg.m_ofn.lpstrFilter="SXC Files(*.sxc)\0*.sxc\0All Files(*.*)\0*.*\0\0";
	
	if(IDOK==dlg.DoModal())
	{
		CStdioFile file(dlg.GetFileName(),CFile::modeRead);
		
		file.ReadString(str);
		int no=atoi(str);
		recordedEvent=no;
		
		for(int i=0;i<no;i++)
		{
			file.ReadString(str);
			EventArray[i].message=atoi(str);
			file.ReadString(str);
			EventArray[i].paramH=atoi(str);
			file.ReadString(str);
			EventArray[i].paramL=atoi(str);
			file.ReadString(str);
			EventArray[i].time=atoi(str);	
			file.ReadString(str);
			EventArray[i].hwnd=HWND((atoi(str)));
		}
		file.Close();
	}	
}

BOOL CMy19Dlg::ModifyIcon(LPCSTR ExtName, LPCSTR IconFile)
{
	BOOL   ret;   
	LONG   nLen;   
	char   Key[65];   
	char   buf[MAX_PATH];   
    
	nLen=sizeof(Key);   
	if(RegQueryValue(HKEY_CLASSES_ROOT,ExtName,Key,	&nLen)!=ERROR_SUCCESS)   
		return   FALSE;   
	if(Key[0]=='\0')   
		return   FALSE;   
	strcat(Key,"\\DefaultIcon");   
	strcpy(buf,IconFile);strcat(buf,",0");   
	ret=RegSetValue(HKEY_CLASSES_ROOT,Key,REG_SZ,buf,sizeof(buf)+1)==ERROR_SUCCESS;
	SHChangeNotify(SHCNE_ASSOCCHANGED,SHCNF_FLUSHNOWAIT,0,0);   
	return  ret;   
}
