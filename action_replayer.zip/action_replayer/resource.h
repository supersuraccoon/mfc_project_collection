//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by 19.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MY19_DIALOG                 102
#define IDR_MAINFRAME                   128
#define IDR_TOOLBAR1                    129
#define IDR_MENU1                       131
#define ID_RECORD                       32777
#define ID_EXIT                         32778
#define ID_STOP                         32779
#define ID_REPLAY                       32780
#define ID_SAVE                         32781
#define ID_LOAD                         32782

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32783
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
