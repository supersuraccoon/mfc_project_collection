// MazeView.h : interface of the CMazeView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAZEVIEW_H__1F530036_1974_4602_8C3D_4F59471787BB__INCLUDED_)
#define AFX_MAZEVIEW_H__1F530036_1974_4602_8C3D_4F59471787BB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CMazeView : public CView
{
protected: // create from serialization only
	CMazeView();
	DECLARE_DYNCREATE(CMazeView)

// Attributes
public:
	CMazeDoc* GetDocument();

	CRect m_rectClient;
	CRect m_rectWall[50][50];
	int b_capturedWall[50][50];
	int count;
	bool m_fModified;
	bool m_drew;
	bool NextPos(CRect &,int&,int&,int&);
	void RadomMap(void);
	void Solution(void);
	void ShowSolution(void);

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMazeView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMazeView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMazeView)
	afx_msg void OnMenuitem32773();
	afx_msg void OnSolution();
	afx_msg void OnRefreash();
	afx_msg void OnShowsolution();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in MazeView.cpp
inline CMazeDoc* CMazeView::GetDocument()
   { return (CMazeDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAZEVIEW_H__1F530036_1974_4602_8C3D_4F59471787BB__INCLUDED_)
