// MazeView.cpp : implementation of the CMazeView class
//

#include "stdafx.h"
#include "Maze.h"

#include "MazeDoc.h"
#include "MazeView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

struct CurrentPos
{
	int i;
	int j;
	int di;
	CRect curPos;
};

vector<CurrentPos> m_rectSolution;
/////////////////////////////////////////////////////////////////////////////
// CMazeView

IMPLEMENT_DYNCREATE(CMazeView, CView)

BEGIN_MESSAGE_MAP(CMazeView, CView)
	//{{AFX_MSG_MAP(CMazeView)
	ON_COMMAND(ID_MENUITEM32773, OnMenuitem32773)
	ON_COMMAND(IDR_SOLUTION, OnSolution)
	ON_COMMAND(IDR_REFREASH, OnRefreash)
	ON_COMMAND(IDR_SHOWSOLUTION, OnShowsolution)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMazeView construction/destruction

CMazeView::CMazeView()
{
	// TODO: add construction code here
	count=0;
	m_drew=true;
	m_fModified=true;
	for(int i=0;i<50;i++)
		for(int j=0;j<50;j++)
		{
			b_capturedWall[i][j]=0;
		}
}

CMazeView::~CMazeView()
{
}

BOOL CMazeView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMazeView drawing

void CMazeView::OnDraw(CDC* pDC)
{
	CMazeDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
	CSize m_size;
	GetClientRect(m_rectClient);
	CPoint m_Pt[50][50];
	for(int j=0;j<=m_rectClient.Width();j+=m_rectClient.Width()/50)
	{
		pDC->MoveTo(j,0);
		pDC->LineTo(j,m_rectClient.Height());
	}
	for(int i=0;i<=m_rectClient.Height();i+=m_rectClient.Height()/50)
	{
		pDC->MoveTo(0,i);
		pDC->LineTo(m_rectClient.Width(),i);
	}
	m_size.cx=m_rectClient.Width()/50;
	m_size.cy=m_rectClient.Height()/50;
	for(i=0;i<50;i++)
		for(int j=0;j<50;j++)
		{
			m_Pt[i][j].x=j*m_rectClient.Width()/50;
			m_Pt[i][j].y=i*m_rectClient.Height()/50;
		}
		for(i=0;i<50;i++)
			for(int j=0;j<50;j++)
			{
				CRect m_rectTemp(m_Pt[i][j],m_size);
				m_rectWall[i][j].CopyRect(m_rectTemp);
			}
			for(i=0;i<50;i++)
				for(int j=0;j<50;j++)
				{
					CBrush brush;
					brush.CreateSolidBrush(RGB(0,0,255));
					if(b_capturedWall[i][j]==1)
						pDC->FillRect(m_rectWall[i][j],&brush);
				}
			CClientDC dc(this);
			CPen pen;
			pen.CreatePen(PS_SOLID,2,(RGB(255,0,0)));
			dc.SelectObject(&pen);

			if (!m_drew)
			{
				for(i=0;i<m_rectSolution.size();)
				{
					dc.MoveTo(m_rectSolution.at(i).curPos.CenterPoint());
					i++;
					if(i>=m_rectSolution.size())
						break;
					dc.LineTo(m_rectSolution.at(i).curPos.CenterPoint());
				}
			}
}

/////////////////////////////////////////////////////////////////////////////
// CMazeView printing

BOOL CMazeView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CMazeView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CMazeView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CMazeView diagnostics

#ifdef _DEBUG
void CMazeView::AssertValid() const
{
	CView::AssertValid();
}

void CMazeView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMazeDoc* CMazeView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMazeDoc)));
	return (CMazeDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMazeView message handlers

void CMazeView::OnMenuitem32773() 
{
	// TODO: Add your command handler code here
	RadomMap();
}


void CMazeView::RadomMap()
{
	CClientDC dc(this);
	CBrush brush;
    brush.CreateSolidBrush(RGB(0,0,255));
	srand((unsigned)time(NULL));
	while(count<810)
	{
		int i=rand()%50;
		int j=rand()%50;
		if(b_capturedWall[i][j]==0)
		{
			dc.FillRect(m_rectWall[i][j],&brush);
			b_capturedWall[i][j]=1;
			count++;
		}
	}
}

void CMazeView::OnSolution() 
{
	// TODO: Add your command handler code here
	Solution();
}

void CMazeView::Solution(void)
{
	int i=0;
	int j=0;
	int di=0;
	bool flag=true;
	CurrentPos m_currentPos;
	m_currentPos.curPos.CopyRect(&m_rectWall[0][0]);
	m_currentPos.i=0;
	m_currentPos.j=0;
	m_currentPos.di=0;
	b_capturedWall[0][0]=2;//��ʼ����һ��������
	if(count&&!m_rectSolution.size())
	{
		do
		{
			if(b_capturedWall[0][0]==1||b_capturedWall[49][49]==1)
				MessageBox("No Solution!",NULL,MB_ICONERROR);
			else
			{
				m_rectSolution.push_back(m_currentPos);
				if(m_currentPos.curPos==m_rectWall[49][49])
				{
					MessageBox("SUCCESS!");
					break;
				}
				m_currentPos.di=0;
				if(NextPos(m_currentPos.curPos,i,j,m_currentPos.di))
				{
					m_currentPos.i=i;
					m_currentPos.j=j;
				}
				else
				{
					do
					{
						if(flag)
						{
							m_rectSolution.pop_back();
							flag=false;
						}
						CurrentPos m_temp;
						m_temp=m_rectSolution.back();
						m_currentPos.curPos.CopyRect(&m_temp.curPos);
						i=m_temp.i;
						j=m_temp.j;
						m_currentPos.di=0;
						m_currentPos.i=i;
						m_currentPos.j=j;
						if(NextPos(m_currentPos.curPos,i,j,m_currentPos.di))
						{
							m_currentPos.i=i;
							m_currentPos.j=j;
							flag=true;
							break;
						}
						else
						{
							m_rectSolution.pop_back();
						}
					}
					while(!m_rectSolution.empty());
					if(m_rectSolution.empty())
						MessageBox("No Solution!",NULL,MB_ICONERROR);
				}
			}
		}
		while(!m_rectSolution.empty());
	}
}

bool CMazeView::NextPos(CRect &m_rectRe,int &i,int &j,int &di)
{
	di++;
	switch(di)
	{
	case 1:
		
		if(b_capturedWall[i][j+1]==0&&i<50&&(j+1)<50)
		{
			m_rectRe.CopyRect(&m_rectWall[i][j+1]);
			j++;
			b_capturedWall[i][j]=2;
			return true;
		}
		di++;
	case 2:
		
		if(b_capturedWall[i+1][j]==0&&(i+1)<50&&j<50)
		{
			m_rectRe.CopyRect(&m_rectWall[i+1][j]);
			i++;
			b_capturedWall[i][j]=2;
			return true;
		}
		di++;
	case 3:
		if(b_capturedWall[i][j-1]==0&&(j-1)>=0)
		{
			m_rectRe.CopyRect(&m_rectWall[i][j-1]);
			j--;
			b_capturedWall[i][j]=2;
			return true;
		}
		di++;
	case 4:
		if(b_capturedWall[i-1][j]==0&&(i-1)>=0)
		{
			m_rectRe.CopyRect(&m_rectWall[i-1][j]);
			i--;
			b_capturedWall[i][j]=2;
			return true;
		}	
		di++;
	default: ;
	}
	return false;
}

void CMazeView::OnRefreash() 
{
	// TODO: Add your command handler code here
	for(int i=0;i<50;i++)
		for(int j=0;j<50;j++)
		{
			b_capturedWall[i][j]=0;
		}
		m_rectSolution.clear();
		count=0;
		m_drew=true;
	Invalidate();
}

void CMazeView::OnShowsolution() 
{
	// TODO: Add your command handler code here
	ShowSolution();
}

void CMazeView::ShowSolution(void)
{
	CClientDC dc(this);
	CPen pen;
	pen.CreatePen(PS_SOLID,2,(RGB(255,0,0)));
	dc.SelectObject(&pen);
	if(m_drew)
	{
		for(int i=0;i<m_rectSolution.size();)
		{
			dc.MoveTo(m_rectSolution.at(i).curPos.CenterPoint());
			i++;
			if(i>=m_rectSolution.size())
				break;
			Sleep(50);
			dc.LineTo(m_rectSolution.at(i).curPos.CenterPoint());
		}
	}
	m_drew=false;
}
