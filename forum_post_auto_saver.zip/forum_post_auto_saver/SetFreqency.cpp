// SetFreqency.cpp : implementation file
//

#include "stdafx.h"
#include "Test.h"
#include "SetFreqency.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSetFreqency dialog


CSetFreqency::CSetFreqency(CWnd* pParent /*=NULL*/)
	: CDialog(CSetFreqency::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSetFreqency)
	//}}AFX_DATA_INIT
}


void CSetFreqency::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSetFreqency)
	DDX_Control(pDX, IDC_SPIN1, m_spinButton);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSetFreqency, CDialog)
	//{{AFX_MSG_MAP(CSetFreqency)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN1, OnDeltaposSpin1)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSetFreqency message handlers

void CSetFreqency::OnDeltaposSpin1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
	

	*pResult = 0;
}

BOOL CSetFreqency::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	SetDlgItemText(IDC_STATIC,"5");
	m_spinButton.SetRange(1,30);
	m_spinButton.SetBuddy(GetDlgItem(IDC_STATIC));
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSetFreqency::OnButton1() 
{
	// TODO: Add your control notification handler code here
	CString str;
	GetDlgItemText(IDC_STATIC,str);
	fy=atoi(str);
	
	CDialog::OnOK();
}
