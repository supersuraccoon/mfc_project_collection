#if !defined(AFX_SETFREQENCY_H__6B48E4F4_8C34_4622_B2B0_188C7FFDBB3C__INCLUDED_)
#define AFX_SETFREQENCY_H__6B48E4F4_8C34_4622_B2B0_188C7FFDBB3C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SetFreqency.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSetFreqency dialog

class CSetFreqency : public CDialog
{
// Construction
public:
	CSetFreqency(CWnd* pParent = NULL);   // standard constructor
	int fy;

// Dialog Data
	//{{AFX_DATA(CSetFreqency)
	enum { IDD = IDD_DIALOG1 };
	CSpinButtonCtrl	m_spinButton;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSetFreqency)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CSetFreqency)
	afx_msg void OnDeltaposSpin1(NMHDR* pNMHDR, LRESULT* pResult);
	virtual BOOL OnInitDialog();
	afx_msg void OnButton1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SETFREQENCY_H__6B48E4F4_8C34_4622_B2B0_188C7FFDBB3C__INCLUDED_)
