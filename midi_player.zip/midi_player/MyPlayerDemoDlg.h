// MyPlayerDemoDlg.h : header file
//

#if !defined(AFX_MYPLAYERDEMODLG_H__950F47CB_CD0F_46C0_80C1_2788EC93CA21__INCLUDED_)
#define AFX_MYPLAYERDEMODLG_H__950F47CB_CD0F_46C0_80C1_2788EC93CA21__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Midi.h"
#include "CDAudio.h"
/////////////////////////////////////////////////////////////////////////////
// CMyPlayerDemoDlg dialog

class CMyPlayerDemoDlg : public CDialog
{
// Construction
public:
	CMyPlayerDemoDlg(CWnd* pParent = NULL);	// standard constructor
	CToolBar m_wndToolBar;
	CMidi m_Midi;
	CCDAudio m_CDAudio;

// Dialog Data
	//{{AFX_DATA(CMyPlayerDemoDlg)
	enum { IDD = IDD_MYPLAYERDEMO_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyPlayerDemoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMyPlayerDemoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnPlay();
	afx_msg void OnStop();
	afx_msg void OnOpen();
	afx_msg void OnPlaycd();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYPLAYERDEMODLG_H__950F47CB_CD0F_46C0_80C1_2788EC93CA21__INCLUDED_)
