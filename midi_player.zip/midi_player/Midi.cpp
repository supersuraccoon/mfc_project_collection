// Midi.cpp

#include "stdafx.h"
#include "Midi.h"

CMidi::CMidi()
{

	m_nDevices = midiOutGetNumDevs();//��ȡ�豸��
	m_bOpened = m_bPaused = m_bPlaying = FALSE;
	m_wDeviceID = 0;

}

CMidi::~CMidi()
{

	Close();

}

BOOL CMidi::Open( const char *lpszFilename )
{

	if( !m_bOpened )
	{
		m_bPaused = m_bPlaying = FALSE;
		m_wDeviceID = 0;

		// �ж��ļ��Ƿ����
		CFileStatus Status;
		if( !CFile::GetStatus( lpszFilename, Status ) )
			return( FALSE );

		// ���豸
		MCI_OPEN_PARMS OpenParms;
		OpenParms.lpstrDeviceType = (LPCSTR) MCI_DEVTYPE_SEQUENCER;
		OpenParms.lpstrElementName = (LPCSTR) lpszFilename;
		OpenParms.wDeviceID = 0;
		if( mciSendCommand( NULL, MCI_OPEN, MCI_WAIT | MCI_OPEN_TYPE | MCI_OPEN_TYPE_ID | MCI_OPEN_ELEMENT, (DWORD)(LPVOID) &OpenParms ) )
			return( FALSE );
		m_wDeviceID = OpenParms.wDeviceID;
		m_bOpened = TRUE;

		// ��ʱ���ʽ����Ϊ����
		MCI_SET_PARMS SetParms;
		SetParms.dwTimeFormat = MCI_FORMAT_MILLISECONDS;
		if( mciSendCommand( m_wDeviceID, MCI_SET, MCI_SET_TIME_FORMAT, (DWORD)(LPVOID) &SetParms ) ){
			Close();
			return( FALSE );
			}
		mciSendCommand( m_wDeviceID, MCI_SEEK, MCI_SEEK_TO_START, NULL );
		return( TRUE );
		}

	return( FALSE );

}

BOOL CMidi::Close( void )
{

	if( m_bOpened ){

		// ֹͣ���Źر��豸
		if( m_bPlaying || m_bPaused )
			mciSendCommand( m_wDeviceID, MCI_STOP, NULL, NULL );
		mciSendCommand( m_wDeviceID, MCI_CLOSE, NULL, NULL );

		// �����Ա����
		m_bOpened = m_bPaused = m_bPlaying = FALSE;
		m_wDeviceID = 0;

		return( TRUE );
		}

	return( FALSE );

}

BOOL CMidi::Play( void )
{

	if( m_bOpened )
	{

		//���Ͳ���ָ��
		MCI_PLAY_PARMS PlayParms;
		PlayParms.dwCallback = NULL;
		PlayParms.dwFrom = ( ( GetMinutes() * 60 ) + GetSeconds () ) * 1000;
		if( mciSendCommand( m_wDeviceID, MCI_PLAY, MCI_FROM, (DWORD)(LPVOID) &PlayParms ) )
			return( FALSE );

		//���ó�Ա����
		m_bPlaying = TRUE;
		m_bPaused = FALSE;

		return( TRUE );
		}

	return( FALSE );

}

BOOL CMidi::Stop( void )
{

	if( m_bOpened && m_bPlaying ){
		// ָֹͣ��
		mciSendCommand( m_wDeviceID, MCI_STOP, NULL, NULL );
		// ��ͷ��ʼ����
		mciSendCommand( m_wDeviceID, MCI_SEEK, MCI_SEEK_TO_START, NULL );
		m_bPaused = m_bPlaying = FALSE;

		return( TRUE );
		}

	return( FALSE );

}

BOOL CMidi::IsPlaying( void )
{

	if( m_bOpened ){

		// ״ָ̬��
		MCI_STATUS_PARMS StatusParms;
		StatusParms.dwItem = MCI_STATUS_MODE;
		if( mciSendCommand( m_wDeviceID, MCI_STATUS, MCI_WAIT | MCI_STATUS_ITEM, (DWORD)(LPVOID) &StatusParms ) )
			return( FALSE );

		if( StatusParms.dwReturn == MCI_MODE_PLAY ){
			m_bPlaying = TRUE;
			m_bPaused = FALSE;
			return( TRUE );
			}
		else if( StatusParms.dwReturn == MCI_MODE_PAUSE ){
			m_bPlaying = TRUE;
			m_bPaused = FALSE;
			return( TRUE );
			}
		else{
			m_bPlaying = FALSE;
			m_bPaused = FALSE;
			return( FALSE );
			}
		}

	return( FALSE );
}

int CMidi::GetMinutes( void )
{

	if( m_bOpened )
	{

		// ��ȡ��ǰ����λ��
		MCI_STATUS_PARMS StatusParms;
		StatusParms.dwItem = MCI_STATUS_POSITION;
		if( mciSendCommand( m_wDeviceID, MCI_STATUS, MCI_WAIT | MCI_STATUS_ITEM, (DWORD)(LPVOID) &StatusParms ) )
			return( -1 );

		return( (int) ( ( StatusParms.dwReturn / 1000 ) / 60 ) );
		}

	return( -1 );

}

int CMidi::GetSeconds( void )
{

	if( m_bOpened )
	{
		// ��ȡ��ǰ����λ��
		MCI_STATUS_PARMS StatusParms;
		StatusParms.dwItem = MCI_STATUS_POSITION;
		if( mciSendCommand( m_wDeviceID, MCI_STATUS, MCI_WAIT | MCI_STATUS_ITEM, (DWORD)(LPVOID) &StatusParms ) )
			return( -1 );

		return( (int) ( ( StatusParms.dwReturn / 1000 ) % 60 ) );
		}

	return( -1 );

}
