// Midi.h

#ifndef __MIDI_H__
#define __MIDI_H__

#include <mmsystem.h>

class CMidi
{

public:
	CMidi();
	~CMidi();


	BOOL Open( const char * );
	BOOL Close( void );
	BOOL Play( void );
	BOOL Stop( void );
	BOOL IsPlaying( void );

	int GetMinutes( void );
	int GetSeconds( void );

protected:
	BOOL m_bOpened, m_bPaused, m_bPlaying;
	WORD m_wDeviceID;
	int m_nDevices;

};

#endif
