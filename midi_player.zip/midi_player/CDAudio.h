// CDAudio.h

#ifndef __CDAUDIO_H__
#define __CDAUDIO_H__

class CCDAudio
{

public:
	CCDAudio();
	~CCDAudio();

	BOOL Open( void );
	void Close( void );
	BOOL Play( void );
	void Stop( void );
	int GetCurrentTrack( void );
	BOOL IsDriveReady( void );
	void CloseDrive( void );
	void OpenDrive( void );
	int GetMinutes( void );
	int GetSeconds( void );
	int GetFrames( void );
	BOOL IsAudioTrack( int );

private:
	BOOL m_bOpened, m_bPaused, m_bPlaying;
	WORD m_wDeviceID;

};


#endif
