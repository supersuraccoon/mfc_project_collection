// UnlockerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "test.h"
#include "UnlockerDlg.h"
#include "LockDlg.h"
#include "testDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

int countDown;

CTestDlg dlg;
//_declspec(dllimport) HHOOK SetMouseHook(HWND hwnd);
//_declspec(dllimport) HHOOK SetKeyboardHook(HWND hwnd);
/////////////////////////////////////////////////////////////////////////////
// CUnlockerDlg dialog


CUnlockerDlg::CUnlockerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CUnlockerDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CUnlockerDlg)
	//}}AFX_DATA_INIT
}


void CUnlockerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUnlockerDlg)
	DDX_Control(pDX, IDC_EDIT1, m_psw);
	DDX_Control(pDX, IDC_EDIT2, m_time);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CUnlockerDlg, CDialog)
	//{{AFX_MSG_MAP(CUnlockerDlg)
	ON_WM_TIMER()
	ON_WM_DESTROY()
	ON_WM_HELPINFO()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUnlockerDlg message handlers

BOOL CUnlockerDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	SetForegroundWindow();
	UpdateWindow();
	::SetWindowPos(m_hWnd,HWND_TOPMOST,0,0,0,0,SWP_NOSIZE|SWP_NOMOVE);
	countDown=5;
	SetDlgItemText(IDC_EDIT2,"5");
	SetTimer(1,1000,NULL);
	need=0;
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CUnlockerDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	CString ps;
	char time[10];
	countDown--;
	if (countDown>0)
	{
		itoa(countDown,time,10);	
		SetDlgItemText(IDC_EDIT2,time);
	}
	else
	{
		GetDlgItemText(IDC_EDIT1,ps);
		if (ps==passWord)
		{
			KillTimer(1);
			//MessageBox("UnLocked!!!");
			need=1;
			SendMessage(WM_CLOSE);
		}
		else
		{
			KillTimer(1);
			//MessageBox("PassWord Incorrent!!!");
			need=2;
			SendMessage(WM_CLOSE);
		}
	}
	
	CDialog::OnTimer(nIDEvent);
}

void CUnlockerDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	dlg.hotKeyLocker=true;
}

void CUnlockerDlg::SetPsw(CString str)
{
	passWord=str;
}	

void CUnlockerDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	CDialog::OnCancel();
}

void CUnlockerDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	CDialog::OnOK();
}


BOOL CUnlockerDlg::OnHelpInfo(HELPINFO* pHelpInfo) 
{
	// TODO: Add your message handler code here and/or call default
	return true;
	
	return CDialog::OnHelpInfo(pHelpInfo);
}
