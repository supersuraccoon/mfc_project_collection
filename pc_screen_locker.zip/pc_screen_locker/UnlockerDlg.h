#if !defined(AFX_UNLOCKERDLG_H__A7654352_8A27_46CE_81C3_AA39780B0C59__INCLUDED_)
#define AFX_UNLOCKERDLG_H__A7654352_8A27_46CE_81C3_AA39780B0C59__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// UnlockerDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CUnlockerDlg dialog

class CUnlockerDlg : public CDialog
{
// Construction
public:
	void SetPsw(CString str);
	int need;
	CString passWord;
	CUnlockerDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CUnlockerDlg)
	enum { IDD = IDD_DIALOG1 };
	CEdit	m_psw;
	CEdit	m_time;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUnlockerDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CUnlockerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnDestroy();
	virtual void OnCancel();
	virtual void OnOK();
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_UNLOCKERDLG_H__A7654352_8A27_46CE_81C3_AA39780B0C59__INCLUDED_)
