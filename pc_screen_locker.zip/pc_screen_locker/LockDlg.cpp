// LockDlg.cpp : implementation file
//

#include "stdafx.h"
#include "test.h"
#include "LockDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLockDlg dialog


CLockDlg::CLockDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CLockDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLockDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CLockDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLockDlg)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLockDlg, CDialog)
	//{{AFX_MSG_MAP(CLockDlg)
	ON_WM_ERASEBKGND()
	ON_WM_HELPINFO()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLockDlg message handlers

BOOL CLockDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	// TODO: Add extra initialization here
	SetWindowLong(this->GetSafeHwnd(),GWL_EXSTYLE, 
		GetWindowLong(this->GetSafeHwnd(),GWL_EXSTYLE)^0x80000); 
	HINSTANCE hInst = LoadLibrary("User32.DLL"); 
	if(hInst) 
	{ 
		typedef BOOL (WINAPI *MYFUNC)(HWND,COLORREF,BYTE,DWORD); 
		MYFUNC fun = NULL; 
		//ȡ��SetLayeredWindowAttributes����ָ�� 
		fun=(MYFUNC)GetProcAddress(hInst, "SetLayeredWindowAttributes"); 
		if(fun)fun(this->GetSafeHwnd(),0,150,2); 
		FreeLibrary(hInst); 
	} 
	/*CFont   font;   
	LOGFONT   log;   
	GetObject(::GetStockObject(DEFAULT_GUI_FONT),sizeof(log),&log);   
	log.lfHeight=120;   
	log.lfWidth=120;   
	log.lfCharSet=GB2312_CHARSET;   
	lstrcpy(log.lfFaceName,"����");   
	font.CreateFontIndirect(&log);   
	m_static.SetFont(&font);*/


	SetForegroundWindow();
	UpdateWindow();
	::SetWindowPos(m_hWnd,HWND_TOPMOST,0,0,GetSystemMetrics(SM_CXSCREEN),
	GetSystemMetrics(SM_CYSCREEN),SWP_SHOWWINDOW);


	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CLockDlg::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default

	return CDialog::OnEraseBkgnd(pDC);
}

BOOL CLockDlg::OnHelpInfo(HELPINFO* pHelpInfo) 
{
	// TODO: Add your message handler code here and/or call default
	return true;
	
	return CDialog::OnHelpInfo(pHelpInfo);
}
