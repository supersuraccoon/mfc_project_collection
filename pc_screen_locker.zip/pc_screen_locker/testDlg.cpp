// testDlg.cpp : implementation file
//

#include "stdafx.h"
#include "test.h"
#include "testDlg.h"
#include "UnlockerDlg.h"
#include "LockDlg.h"
#include "TaskKeyMgr.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CString psw="111111";
CLockDlg gdlg;
CUnlockerDlg dlg;
CString hotkey="";
int VK;
HHOOK hMouse=NULL;
HHOOK hKeyboard=NULL;

_declspec(dllimport) HHOOK SetMouseHook(HWND hwnd,int vk);
_declspec(dllimport) HHOOK SetKeyboardHook(HWND hwnd);
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestDlg dialog

CTestDlg::CTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	hotKeyLocker=false;
}

void CTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestDlg)
	DDX_Control(pDX, ID_KEY, m_com);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTestDlg, CDialog)
	//{{AFX_MSG_MAP(CTestDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CREATE()
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_WM_DESTROY()
	ON_WM_CLOSE()
	ON_CBN_SELCHANGE(ID_KEY, OnSelchangeKey)
	ON_MESSAGE(WM_HOTKEY,OnHotKey)
	ON_WM_HELPINFO()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestDlg message handlers

BOOL CTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_com.AddString("F1");
	m_com.AddString("F2");
	m_com.AddString("F3");
	m_com.AddString("F4");
	m_com.AddString("F5");
	m_com.AddString("F6");
	m_com.AddString("F7");
	m_com.AddString("F8");
	m_com.AddString("F9");
	m_com.AddString("F10");
	m_com.SetCurSel(0);
	SetDlgItemText(IDC_EDIT3,"F1");
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTestDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTestDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTestDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

int CTestDlg::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	
	return 0;
}

LRESULT CTestDlg::OnHotKey(WPARAM wParam,LPARAM lParam) 
{
	if(hotKeyLocker)
	{
		if(wParam==1001)
		{
			hotKeyLocker=false;
			dlg.SetPsw(psw);
			::ShowWindow(gdlg.m_hWnd,SW_HIDE);
			dlg.DoModal();
			
			if (dlg.need==1)
			{
				::SendMessage(gdlg.m_hWnd,WM_CLOSE,NULL,NULL);
				SendMessage(WM_CLOSE);
			}
			else
				if (dlg.need==2)
				{
					hotKeyLocker=true;
					::ShowWindow(gdlg.m_hWnd,SW_SHOWNORMAL);
				}
		}	
	}
	return true;
}

void CTestDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here	
	GetDlgItemText(ID_KEY,hotkey);
	GetDlgItemText(IDC_EDIT1,psw);
	if(hotkey=="F1")
	{	
		VK=VK_F1;
	}
	else
		if (hotkey=="F2")
		{
			VK=VK_F2;
		}
		else
			if (hotkey=="F3")
			{
				VK=VK_F3;
			}
			else
				if (hotkey=="F4")
				{
					VK=VK_F4;
				}
				else
					if (hotkey=="F5")
					{
						VK=VK_F5;
					}
					else
						if (hotkey=="F6")
						{
							VK=VK_F6;
						}
						else
							if (hotkey=="F7")
							{
								VK=VK_F7;
							}
							else
								if (hotkey=="F8")
								{
									VK=VK_F8;
								}
								else
									if (hotkey=="F9")
									{
										VK=VK_F9;
									}
									else
										if (hotkey=="F10")
										{
											VK=VK_F10;
										}
	MessageBox("\n     Please remember your password!!!\n     The unlock key:"+hotkey+"\n     The password is:"+psw,"Warning!!!");
	RegisterHotKey(m_hWnd,1001,0,VK);

	ShowDesktop();
	Sleep(10);
	CTaskKeyMgr::Disable(CTaskKeyMgr::TASKKEYS|CTaskKeyMgr::TASKBAR|CTaskKeyMgr::TASKMGR,TRUE);
	ShowWindow(SW_HIDE);
	Sleep(10);
	hMouse=SetMouseHook(m_hWnd,VK);
	//hKeyboard=SetKeyboardHook(m_hWnd);
	hotKeyLocker=true;
	gdlg.DoModal();
}

void CTestDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	::SendMessage(dlg.m_hWnd,WM_CLOSE,NULL,NULL);
	UnhookWindowsHookEx(hMouse);
	UnhookWindowsHookEx(hKeyboard);
	UnregisterHotKey(m_hWnd,1001);
}

void CTestDlg::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	CTaskKeyMgr::Disable(CTaskKeyMgr::TASKKEYS|CTaskKeyMgr::TASKBAR|CTaskKeyMgr::TASKMGR,FALSE);
	::SendMessage(dlg.m_hWnd,WM_CLOSE,NULL,NULL);
	UnhookWindowsHookEx(hMouse);
	UnhookWindowsHookEx(hKeyboard);

	CDialog::OnClose();
}

void CTestDlg::ShowDesktop()
{
	char csExeFilePath[255];
	CString min;
	GetCurrentDirectory(MAX_PATH,csExeFilePath);
	min=csExeFilePath;
	min+="\\Release\\MIN.scf";
	ShellExecute(m_hWnd,"open",min,NULL,NULL,SW_SHOWNORMAL);
}

void CTestDlg::OnSelchangeKey() 
{
	// TODO: Add your control notification handler code here
	int index;
	CString str;
	index=m_com.GetCurSel();
	m_com.GetLBText(index,str);
	SetDlgItemText(IDC_EDIT3,str);
}

BOOL CTestDlg::OnHelpInfo(HELPINFO* pHelpInfo) 
{
	// TODO: Add your message handler code here and/or call default
	return true;
	
	return CDialog::OnHelpInfo(pHelpInfo);
}
