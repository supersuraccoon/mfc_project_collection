// 123Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "123.h"
#include "123Dlg.h"
#include <winsock2.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMy123Dlg dialog

CMy123Dlg::CMy123Dlg(CWnd* pParent /*=NULL*/)
: CDialog(CMy123Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMy123Dlg)
	// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMy123Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMy123Dlg)
	DDX_Control(pDX, IDC_LIST2, m_list);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMy123Dlg, CDialog)
//{{AFX_MSG_MAP(CMy123Dlg)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMy123Dlg message handlers

BOOL CMy123Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	CenterWindow(GetDesktopWindow());	// center to the hpc screen
	
	// TODO: Add extra initialization here
	m_list.InsertColumn(0, _T("No"), LVCFMT_LEFT, 10);
	m_list.InsertColumn(1, _T("Device No"), LVCFMT_LEFT, 10);
	m_list.InsertColumn(2, _T("State"), LVCFMT_LEFT, 10);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

int hwSnprintf ( LPTSTR buffer, int count, LPCTSTR format, ... )
{
	if ( count < 1 ) return 0;
	//ASSERT_ADDRESS ( buffer, count );
	memset ( buffer, 0, count );
	// ��ʽ��
	va_list  va;
	va_start (va, format);
#ifdef UNICODE
	int nRet = _vsnwprintf ( buffer, count, (const wchar_t*)format, va);
#else
	int nRet = _vsnprintf ( buffer, count, (const char*)format, va);
#endif
	va_end(va);
	buffer [count-1] = _T('\0');

	int nLen = nRet;
	//if ( nLen < 0 ) nLen = (int)strlen_s(buffer);
	if ( nLen > count ) nLen = count;

	return nLen;
}


int CMy123Dlg::Add_RemoteBthDevInfo(t_RemoteBthDevInfo &RemoteBthDevInfo)
{
 	if (Find_RemoteBthDevInfo( RemoteBthDevInfo.RemoteAddr ) >= 0 )
 		return TRUE;
 	m_Ary_RemoteBthDevInfo.Add ( RemoteBthDevInfo );
}

int CMy123Dlg::ScanNearbyBthDev_Direct()
{
 	m_Ary_RemoteBthDevInfo.RemoveAll ();
 
 	WSAQUERYSET querySet;
 	HANDLE hLookup;
 	DWORD flags = LUP_RETURN_NAME | LUP_RETURN_ADDR; 
 	union
 	{
 		CHAR buf[5000];
 		double __unused; // ensure proper alignment
 	};
 	LPWSAQUERYSET pwsaResults = (LPWSAQUERYSET) buf;
 	DWORD dwSize = sizeof(buf);
 	ZeroMemory(pwsaResults, sizeof(WSAQUERYSET));
 	pwsaResults->dwSize = sizeof(WSAQUERYSET);
 	pwsaResults->dwNameSpace = NS_BTH;
 	pwsaResults->lpBlob = NULL;
 	BOOL bError = FALSE;
 	BOOL bHaveName;
 	ZeroMemory(&querySet, sizeof(querySet));
 	querySet.dwSize = sizeof(querySet);
 	querySet.dwNameSpace = NS_BTH;
 	if ( ::WaitForSingleObject ( m_hEvtEndModule, 0 ) == WAIT_OBJECT_0 )
 		return -1;
 
 	if (ERROR_SUCCESS != WSALookupServiceBegin (&querySet, LUP_CONTAINERS, &hLookup))
 	{
 		MessageBox ( _T("WSALookupServiceBegin failed") );
 		return (-1);
 	}
 	
 	while ( TRUE )
 	{
 		if ( ::WaitForSingleObject ( m_hEvtEndModule, 0 ) == WAIT_OBJECT_0 )
 			break;
 		if ( ERROR_SUCCESS == WSALookupServiceNext (hLookup, flags, &dwSize, pwsaResults) )
 		{
 			ASSERT (pwsaResults->dwNumberOfCsAddrs == 1);
 			BT_ADDR b = ((SOCKADDR_BTH *)pwsaResults->lpcsaBuffer->RemoteAddr.lpSockaddr)->btAddr;
 			bHaveName = pwsaResults->lpszServiceInstanceName && *(pwsaResults->lpszServiceInstanceName);
 			t_RemoteBthDevInfo RemoteBthDevInfo;
 			if ( bHaveName )
 			{
 				hwSnprintf ( RemoteBthDevInfo.szName, sizeof(RemoteBthDevInfo.szName), _T("%s"), 
 					pwsaResults->lpszServiceInstanceName );
 			}
 			RemoteBthDevInfo.RemoteAddr = b;
 			CSADDR_INFO* pCSAddr = (CSADDR_INFO *)pwsaResults->lpcsaBuffer;
 			RemoteBthDevInfo.LocalAddr = ((SOCKADDR_BTH *)pCSAddr->LocalAddr.lpSockaddr)->btAddr;
 			Add_RemoteBthDevInfo ( RemoteBthDevInfo );
 		}
 		else
 		{
 			if ( WSAGetLastError() != WSA_E_NO_MORE )
 			{
 				bError = TRUE;
 				MessageBox ( L"Lookup bluetooth device failed" );
 			}
 			break;
 		}
 	}
 	WSALookupServiceEnd(hLookup);
 
 }

 int CMy123Dlg::Find_RemoteBthDevInfo(BT_ADDR Addr_Found, t_RemoteBthDevInfo *pRemoteBthDevInfo)
 {
 	for ( int i=0; i<m_Ary_RemoteBthDevInfo.GetSize(); i++ )
 	{
 		t_RemoteBthDevInfo &RemoteBthDevInfoRef = m_Ary_RemoteBthDevInfo.GetAt(i);
 		if ( RemoteBthDevInfoRef.RemoteAddr == Addr_Found )
 		{
 			if ( pRemoteBthDevInfo )
 			{
 				memcpy ( pRemoteBthDevInfo, &RemoteBthDevInfoRef, sizeof(t_RemoteBthDevInfo) );
 			}
 			return i;
 		}
 	}
 	return -1;
 }

void CMy123Dlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	ScanNearbyBthDev_Direct();	
}

