//{{NO_DEPENDENCIES}}
// Microsoft eMbedded Visual C++ generated include file.
// Used by 123.rc
//
#define IDR_MAINFRAMEwqe                3
#define IDD_MY123_DIALOG                102
#define IDR_MAINFRAME                   128
#define IDR_SXC                         128
#define IDI_ICON1                       129
#define IDI_ICON2                       130
#define IDC_BUTTON1                     1000
#define IDC_LIST2                       1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
