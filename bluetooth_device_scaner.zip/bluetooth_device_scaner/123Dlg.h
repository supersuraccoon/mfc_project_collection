// 123Dlg.h : header file
//

#if !defined(AFX_123DLG_H__9DA284AB_5D23_4246_A922_F020DBF1CDBE__INCLUDED_)
#define AFX_123DLG_H__9DA284AB_5D23_4246_A922_F020DBF1CDBE__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "afxtempl.h"

// Զ�������豸��ϸ��Ϣ

typedef ULONGLONG bt_addr,*pbt_addr,BT_ADDR,*PBT_ADDR;

typedef struct _RemoteBthDevInfo
{
	_RemoteBthDevInfo ()
	{
		memset ( szName, 0, sizeof(szName) );
		memset ( &RemoteAddr, 0, sizeof(BT_ADDR) );
		memset ( &LocalAddr, 0, sizeof(BT_ADDR) );
	}
	TCHAR szName[64];
	BT_ADDR RemoteAddr;
	BT_ADDR LocalAddr;
	
} t_RemoteBthDevInfo;
typedef CArray<t_RemoteBthDevInfo,t_RemoteBthDevInfo&> t_Ary_RemoteBthDevInfo;

/////////////////////////////////////////////////////////////////////////////
// CMy123Dlg dialog

class CMy123Dlg : public CDialog
{
// Construction
public:
	int ScanNearbyBthDev_Direct();
	int Find_RemoteBthDevInfo(BT_ADDR Addr_Found, t_RemoteBthDevInfo *pRemoteBthDevInfo=NULL);
	int Add_RemoteBthDevInfo(t_RemoteBthDevInfo &RemoteBthDevInfo);
	CMy123Dlg(CWnd* pParent = NULL);	// standard constructor
	t_Ary_RemoteBthDevInfo m_Ary_RemoteBthDevInfo;
	HANDLE m_hEvtEndModule;


// Dialog Data
	//{{AFX_DATA(CMy123Dlg)
	enum { IDD = IDD_MY123_DIALOG };
	CListCtrl	m_list;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMy123Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMy123Dlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnButton1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft eMbedded Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_123DLG_H__9DA284AB_5D23_4246_A922_F020DBF1CDBE__INCLUDED_)
