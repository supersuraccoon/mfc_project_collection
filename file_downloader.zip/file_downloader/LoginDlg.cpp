// LoginDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MyFileDownloader.h"
#include "LoginDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLoginDlg dialog


CLoginDlg::CLoginDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CLoginDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLoginDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CLoginDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLoginDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLoginDlg, CDialog)
	//{{AFX_MSG_MAP(CLoginDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLoginDlg message handlers

void CLoginDlg::OnOK() 
{
	// TODO: Add extra validation here
	CString Password;
	CString Psw;
	SetDlgItemText(IDC_INFO,"������֤��,���Ժ�...");

	ado.OnInitDBConnect();

	GetDlgItemText(IDC_USERNAME,Name);
	GetDlgItemText(IDC_PASSWORD,Password);

	_bstr_t vSQL;
	vSQL="SELECT * FROM [Regediter] WHERE UserName='"+Name+"'";
	_RecordsetPtr m_pRecordset;
	m_pRecordset=ado.GetRecordSet(vSQL);
	
	if(!m_pRecordset->adoEOF)
	{
		Psw=(LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("Psw");
		Psw.TrimRight(" ");
		if (Psw==Password)
		{
			UserID=(LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("ID");
			UserID.TrimRight(" ");
			MessageBox("��ӭ"+Name+"ʹ��MyFileDownloader!!!");
			CDialog::OnOK();
		}
		else
		{
			MessageBox("�û�������!!!");
			SetDlgItemText(IDC_USERNAME,"");
			SetDlgItemText(IDC_PASSWORD,"");
		}
	}
	else
	{
		MessageBox("�������!!!");
		SetDlgItemText(IDC_PASSWORD,"");
	}
	SetDlgItemText(IDC_INFO,"");

}

BOOL CLoginDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
