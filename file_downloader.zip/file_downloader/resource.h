//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MyFileDownloader.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MYFILEDOWNLOADER_DIALOG     102
#define IDR_MAINFRAME                   128
#define IDD_LOGIN                       129
#define IDR_MYMENU                      130
#define IDI_ICON1                       135
#define IDB_BITMAP1                     136
#define IDC_PATH                        1001
#define IDC_FILEINFO                    1002
#define IDC_USERNAME                    1003
#define IDC_PASSWORD                    1004
#define IDC_EXPORT                      1004
#define IDC_CONTACT                     1005
#define IDC_COMBO1                      1006
#define IDC_INFO                        1007
#define IDC_GO                          1008
#define ID_DOWNLOAD                     32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
