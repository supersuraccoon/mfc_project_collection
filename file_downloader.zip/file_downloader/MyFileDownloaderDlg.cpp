// MyFileDownloaderDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MyFileDownloader.h"
#include "MyFileDownloaderDlg.h"
#include "MyExcel.h"
#include  <afxinet.h> 

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyFileDownloaderDlg dialog

CMyFileDownloaderDlg::CMyFileDownloaderDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMyFileDownloaderDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMyFileDownloaderDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMyFileDownloaderDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyFileDownloaderDlg)
	DDX_Control(pDX, IDC_FILEINFO, m_list);
	DDX_Control(pDX, IDC_PATH, m_tree);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMyFileDownloaderDlg, CDialog)
	//{{AFX_MSG_MAP(CMyFileDownloaderDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_NOTIFY(TVN_SELCHANGED, IDC_PATH, OnSelchangedPath)
	ON_NOTIFY(NM_RCLICK, IDC_FILEINFO, OnRclickFileinfo)
	ON_COMMAND(ID_DOWNLOAD, OnDownload)
	ON_BN_CLICKED(IDC_EXPORT, OnExport)
	ON_BN_CLICKED(IDC_GO, OnGo)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyFileDownloaderDlg message handlers

BOOL CMyFileDownloaderDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	CMyFileDownloaderApp* pApp=(CMyFileDownloaderApp*)AfxGetApp();  
	UserName=pApp->UserName;
	UserID=pApp->UserID;
	ado.OnInitDBConnect();

	m_list.InsertColumn(0, "No", LVCFMT_LEFT, 30);
	m_list.InsertColumn(1, "FileName", LVCFMT_LEFT, 100);
	m_list.InsertColumn(2, "FileLength", LVCFMT_LEFT, 120);
	m_list.InsertColumn(3, "FileType", LVCFMT_LEFT, 90);
	m_list.InsertColumn(4, "UploadDate", LVCFMT_LEFT, 200);
	m_list.InsertColumn(5, "DownloadLink", LVCFMT_LEFT, 0);
	m_list.SetExtendedStyle(LVS_EX_FULLROWSELECT);

	InitTree();
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMyFileDownloaderDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMyFileDownloaderDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMyFileDownloaderDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

BOOL CMyFileDownloaderDlg::InitTree()
{
	DWORD dwStyle = GetWindowLong(m_tree.m_hWnd,GWL_STYLE);
	dwStyle|=TVS_HASBUTTONS|TVS_HASLINES|TVS_LINESATROOT;
	SetWindowLong(m_tree.m_hWnd,GWL_STYLE,dwStyle);	

	CString FileName;
	CString ParentID;
	HTREEITEM temp;

	_bstr_t vSQL;
	vSQL="SELECT *FROM [File] WHERE UserID='"+UserID+"' AND ParentID=0";
	_RecordsetPtr m_pRecordset;
	m_pRecordset=ado.GetRecordSet(vSQL);
	
	
	while(!m_pRecordset->adoEOF)
	{
		ParentID=(LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("ID");
		FileName=(LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("FileName");
		FileName.TrimRight(" ");
		temp=m_tree.InsertItem(FileName);
		m_tree.SetItemData(temp,(DWORD)atoi(ParentID));
	
		Tranvse(ParentID,temp);

		m_pRecordset->MoveNext();
	}
	return true;
}

void CMyFileDownloaderDlg::Tranvse(CString ID,HTREEITEM temp)
{
	CString FileName;
	CString ParentID;
	HTREEITEM root;
	
	_bstr_t vSQL;
	vSQL="SELECT *FROM [File] WHERE UserID='"+UserID+"' AND ParentID='"+ID+"'";
	_RecordsetPtr m_pRecordset;
	m_pRecordset=ado.GetRecordSet(vSQL);

	while(!m_pRecordset->adoEOF)
	{
		ParentID=(LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("ID");
		FileName=(LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("FileName");
		FileName.TrimRight(" ");
		root=m_tree.InsertItem(FileName,temp);
		m_tree.SetItemData(root,(DWORD)atoi(ParentID));

		Tranvse(ParentID,root);
		
		m_pRecordset->MoveNext();
	}

	return ;
}

BOOL CMyFileDownloaderDlg::InitList()
{
	CString UploadFileName;
	CString FileLength;
	CString FileType;
	CString UploadDate;
	CString Downlink;

	CString str;
	CString id;
	int i=0;
	DWORD did;
	_bstr_t vSQL;
	did=m_tree.GetItemData(m_hCurrent);
	id.Format("%d",did);

	vSQL="SELECT *FROM [UpLoadFile] WHERE FileID='"+id+"'";
	_RecordsetPtr m_pRecordset;
	m_pRecordset=ado.GetRecordSet(vSQL);

	m_list.DeleteAllItems();

	while(!m_pRecordset->adoEOF)
	{
		str.Format("%d",i+1);
		m_list.InsertItem(LVIF_TEXT|LVIF_STATE, i, 
			str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
		
		UploadFileName=(LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("UploadFileName");
		UploadFileName.TrimRight(" ");
		FileLength=(LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("SoftLength");
		FileLength.TrimRight(" ");
		UploadDate=(LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("Date");
		UploadDate.TrimRight(" ");
		FileType=(LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("Type");
		FileType.TrimRight(" ");
		Downlink=(LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("FilePath");
		Downlink.TrimRight(" ");

		m_list.SetItemText(i,1,UploadFileName);
		m_list.SetItemText(i,2,FileLength);
		m_list.SetItemText(i,3,FileType);
		m_list.SetItemText(i,4,UploadDate);
		m_list.SetItemText(i,5,Downlink);
		
		m_pRecordset->MoveNext();
		i++;
	}

	return TRUE;
}

void CMyFileDownloaderDlg::OnSelchangedPath(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	TVITEM item = pNMTreeView->itemNew;
	
	gFilename= m_tree.GetItemText(item.hItem);
	m_hCurrent=m_tree.GetSelectedItem();
	
	HTREEITEM Child=m_tree.GetChildItem(m_hCurrent);
	
	if (Child==NULL)
	{
		InitList();
	}
	*pResult = 0;
}

void CMyFileDownloaderDlg::OnRclickFileinfo(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	CPoint cp;
    GetCursorPos(&cp);
    if(pNMListView->iItem == -1)
    {
        return ;
    }
    else
    {
		gRow=pNMListView->iItem;
        CMenu *pMenu = new CMenu();
		VERIFY(pMenu->CreatePopupMenu());
		pMenu->AppendMenu(MF_STRING,ID_DOWNLOAD,"Download!!!");
		
		pMenu->TrackPopupMenu(TPM_LEFTALIGN,cp.x,cp.y,this);
		pMenu->DestroyMenu();
    }	
	*pResult = 0;
}

void CMyFileDownloaderDlg::OnDownload() 
{
	// TODO: Add your command handler code here
	CString DownloadLink;
	CString type;
	CString SaveFilePath;
	type=m_list.GetItemText(gRow,3);
	DownloadLink=m_list.GetItemText(gRow,5);
	
	CFileDialog dlgFile(FALSE,"","Default");

	if (dlgFile.DoModal()==IDOK)
	{
		SaveFilePath=dlgFile.GetPathName();
		SaveFilePath+=".";
		SaveFilePath+=type;
		
		//MessageBox(DownloadLink);
		HRESULT hr = URLDownloadToFile(0, DownloadLink,SaveFilePath, 0,NULL);
		if (hr<0)
		{
			MessageBox("����ʧ��@_@");
			return ;
		}
		MessageBox("���سɹ�^_^");
	}
}

void CMyFileDownloaderDlg::OnExport() 
{
	// TODO: Add your control notification handler code here
	CMyExcel excel;
	excel.ExportListToExcel(&m_list,"log");
}

void CMyFileDownloaderDlg::OnGo() 
{
	// TODO: Add your control notification handler code here
	
}
