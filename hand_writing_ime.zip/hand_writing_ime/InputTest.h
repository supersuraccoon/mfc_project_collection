// InputTest.h : main header file for the INPUTTEST application
//

#if !defined(AFX_INPUTTEST_H__B04ADFBA_467A_41DC_A5EA_CAA749A964F4__INCLUDED_)
#define AFX_INPUTTEST_H__B04ADFBA_467A_41DC_A5EA_CAA749A964F4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CInputTestApp:
// See InputTest.cpp for the implementation of this class
//

class CInputTestApp : public CWinApp
{
public:
	CInputTestApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInputTestApp)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CInputTestApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INPUTTEST_H__B04ADFBA_467A_41DC_A5EA_CAA749A964F4__INCLUDED_)
