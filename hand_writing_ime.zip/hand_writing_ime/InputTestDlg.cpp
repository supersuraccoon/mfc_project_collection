// InputTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "InputTest.h"
#include "InputTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BOOL start=TRUE;
int direct=0;
int predirect=0;
BOOL drawLeft=false;
BOOL drawRight=false;
CRect rectLeft(13,11,78,70);
CRect rectRight(100,10,166,70);
CString gStr="";
bool btnCliked=FALSE;
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInputTestDlg dialog

CInputTestDlg::CInputTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CInputTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CInputTestDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	number=-1;
	no=0;
	totalNum=0;
}

void CInputTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CInputTestDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CInputTestDlg, CDialog)
	//{{AFX_MSG_MAP(CInputTestDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInputTestDlg message handlers

BOOL CInputTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	SetForegroundWindow();   
	UpdateWindow();   
	::SetWindowPos(this->GetSafeHwnd(),HWND_TOPMOST,0,0,0,0,SWP_NOSIZE|SWP_NOMOVE);

	InitData();
	classify.LoadFile("D://Sample//hand.bmp");
	m_pData=classify.m_pData;	
	wide=classify.GetWidth();
	LineBytes=(wide*8+31)/32*4;
	height=classify.GetHeight();
	SendMessage(WM_PAINT);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CInputTestDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CInputTestDlg::OnPaint() 
{
	CClientDC dc(this);
	
	if (classify.GetRGB()) // Has a color table
	{
		CPalette * hPalette1=CreateBitmapPalette(&classify);
		CPalette * hOldPalette =
			dc.SelectPalette(hPalette1, true);
		dc.RealizePalette();
		if (drawLeft)
		{
			BYTE* pBitmapData = classify.GetData();
			LPBITMAPINFO pBitmapInfo = classify.GetInfo();
			int bitmapHeight = classify.GetHeight();
			int bitmapWidth = classify.GetWidth();
			::StretchDIBits(dc.GetSafeHdc(),13,11,67,60,
				0, 0, bitmapWidth , bitmapHeight ,
				pBitmapData, pBitmapInfo,
			DIB_RGB_COLORS, SRCCOPY);
		}
		
		if (drawRight)
		{
			BYTE* pBitmapData = classify.GetData();
			LPBITMAPINFO pBitmapInfo = classify.GetInfo();
			int bitmapHeight = classify.GetHeight();
			int bitmapWidth = classify.GetWidth();
			::StretchDIBits(dc.GetSafeHdc(),100,10,67,60,
				0, 0, bitmapWidth , bitmapHeight ,
				pBitmapData, pBitmapInfo,
				DIB_RGB_COLORS, SRCCOPY);
		dc.SelectPalette(hOldPalette, true);
		}
	
            hPalette.DeleteObject();
	}

	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CInputTestDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CInputTestDlg::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if (rectLeft.PtInRect(point))
	{
		predirect=direct;
		direct=1;
		drawLeft=true;
		CRect cr=rectLeft;
		ClientToScreen(&cr);
		ClipCursor(&cr);
	}

	if (rectRight.PtInRect(point))
	{
		predirect=direct;
		direct=2;
		drawRight=true;
		CRect cr=rectRight;
		ClientToScreen(&cr);
		ClipCursor(&cr);
	}
	

	if (!start)
	{
		if (predirect!=direct)
		{
			CClientDC dc(this);
			if (direct==2)
				dc.FillRect(rectLeft,WHITE_BRUSH);
			else
				dc.FillRect(rectRight,WHITE_BRUSH);

			if (!btnCliked)
			{
				Recognize();
			}
			else
				btnCliked=FALSE;
			
			classify.LoadFile("D://Sample//hand.bmp");
			m_pData=classify.m_pData;	
			wide=classify.GetWidth();
			LineBytes=(wide*8+31)/32*4;
			height=classify.GetHeight();
			SendMessage(WM_PAINT);
		}
	}

	CDialog::OnLButtonDown(nFlags, point);
}

void CInputTestDlg::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	drawLeft=false;
	drawRight=false;
	ClipCursor(NULL);
	start=false;

	CDialog::OnLButtonUp(nFlags, point);
}

void CInputTestDlg::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if (drawLeft&&rectLeft.PtInRect(point))
	{
		CRect rc;
		rc.left=point.x-2;
		rc.right=point.x+2;
		rc.top=point.y-2;
		rc.bottom=point.y+2;
		for(int x=point.x-2;x<point.x+2;x++)
			for(int y=point.y-2;y<point.y+2;y++)
				if((x-point.x)*(x-point.x)+(y-point.y)*(y-point.y)<16)
					*(m_pData+LineBytes*(height-y+8)+x-10)=0;
				SendMessage(WM_PAINT);
	}

	if (drawRight&&rectRight.PtInRect(point))
	{
		CRect rc;
		rc.left=point.x-2;
		rc.right=point.x+2;
		rc.top=point.y-2;
		rc.bottom=point.y+2;
		for(int x=point.x-2;x<point.x+2;x++)
			for(int y=point.y-2;y<point.y+2;y++)
				if((x-point.x)*(x-point.x)+(y-point.y)*(y-point.y)<16)
					*(m_pData+LineBytes*(height-y+8)+x-30)=0;
				SendMessage(WM_PAINT);
	}

	
	CDialog::OnMouseMove(nFlags, point);
}

CPalette* CInputTestDlg::CreateBitmapPalette( CDib *pBitmap )
{
	struct
	{
		WORD Version;
		WORD NumberOfEntries;
		PALETTEENTRY aEntries[256];
	} palette = { 0x300, 256 };
	
	LPRGBQUAD pRGBTable = pBitmap->GetRGB();
	UINT numberOfColors = pBitmap->GetNumberOfColors();
	
	for(UINT x=0; x<numberOfColors; ++x)
	{
		palette.aEntries[x].peRed =
			pRGBTable[x].rgbRed;
		palette.aEntries[x].peGreen =
			pRGBTable[x].rgbGreen;
		palette.aEntries[x].peBlue =
			pRGBTable[x].rgbBlue;
		palette.aEntries[x].peFlags = 0;
	}
	
	hPalette.CreatePalette((LPLOGPALETTE)&palette);
	return &hPalette;	
}

void CInputTestDlg::Recognize()
{
	CString str;
	number_no number_no;

	classify.GetPosition();
	classify.SetFeature();

	number_no=classify.LeastDistance(totalNum);
	number=number_no.number;
	no=number_no.no;

	CStdioFile saveFile;
	CString temp;
	CString path="D://sample//";
	CString ext=".txt";
	int count=0;
	
	
	saveFile.Open("D://sample//save.txt",CFile::modeRead);
	saveFile.ReadString(temp);
	
	
	for(int i=0;i<=totalNum;i++,count++)
	{
		if (count!=number)
		{
			saveFile.ReadString(temp);
		}
		else
		{
			saveFile.ReadString(temp);
			str=temp;
			break;
		}
	}
	saveFile.Close();

	char *ch=new char;

	HWND hWnd=::FindWindow("Notepad",NULL);   
	if(hWnd)   
	{   
		HWND  hEdit=FindWindowEx(hWnd,NULL,"Edit",NULL);   
		if(hEdit)   
		{
			gStr+=str;
			ch=gStr.GetBuffer(10);
			::SendMessage(hEdit,WM_SETTEXT,NULL,(LPARAM)ch);
		}
	}     
	gStr.ReleaseBuffer();
}

void CInputTestDlg::InitData()
{
	CStdioFile file;
	CStdioFile saveFile;
	CString temp;
	CString path="D://sample//";
	CString ext=".txt";
	CString test;
	int num=0;
	saveFile.Open("D://sample//save.txt",CFile::modeRead|CFile::modeNoTruncate);
	saveFile.ReadString(temp);
	totalNum=atoi(temp);
	
	for(int i=0;i<totalNum;i++)
	{
		num=0;
		classify.pattern[i].feature=new double[30][100];
		saveFile.ReadString(temp);
		
		path=path+temp+ext;
		file.Open(path,CFile::modeRead|CFile::modeNoTruncate);
		file.SeekToBegin();
		file.ReadString(temp);
		for(int n=0;n<200;n++)
		{		
			if (temp=="")
			{
				classify.pattern[i].number=num;
				file.Close();
				path="D://sample//";
				temp.Empty();
				break;
			}
			for(int j=0;j<100;j++)
			{
				classify.pattern[i].feature[num][j]=atof(temp);
				file.ReadString(temp);
			}
			num++;
		}
	}
	saveFile.Close();
}

void CInputTestDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	Recognize();
	btnCliked=TRUE;
	HWND hWnd=::FindWindow("Notepad",NULL);   
	char *ch=new char;
	if(hWnd)   
	{   
		HWND  hEdit=FindWindowEx(hWnd,NULL,"Edit",NULL);   
		if(hEdit)   
		{
			gStr+=" ";
			ch=gStr.GetBuffer(10);
			::SendMessage(hEdit,WM_SETTEXT,NULL,(LPARAM)ch);
		}
	}     
	gStr.ReleaseBuffer();
}

void CInputTestDlg::OnButton3() 
{
	// TODO: Add your control notification handler code here
	Recognize();
	btnCliked=TRUE;
	HWND hWnd=::FindWindow("Notepad",NULL);   
	char *ch=new char;
	if(hWnd)   
	{   
		HWND  hEdit=FindWindowEx(hWnd,NULL,"Edit",NULL);   
		if(hEdit)   
		{
			gStr.Delete(gStr.GetLength()-1, 1);
			ch=gStr.GetBuffer(10);
			::SendMessage(hEdit,WM_SETTEXT,NULL,(LPARAM)ch);
		}
	}     
	gStr.ReleaseBuffer();
}

void CInputTestDlg::OnButton2() 
{
	// TODO: Add your control notification handler code here
	Recognize();
	btnCliked=TRUE;
	HWND hWnd=::FindWindow("Notepad",NULL);   
	char *ch=new char;
	if(hWnd)   
	{   
		HWND  hEdit=FindWindowEx(hWnd,NULL,"Edit",NULL);   
		if(hEdit)   
		{
			gStr+="\r\n";
			ch=gStr.GetBuffer(10);
			::SendMessage(hEdit,WM_SETTEXT,NULL,(LPARAM)ch);
		}
	}     
	gStr.ReleaseBuffer();
}
