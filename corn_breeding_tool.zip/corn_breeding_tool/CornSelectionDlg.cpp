// ornSelectionDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CornSystem.h"
#include "CornSelectionDlg.h"
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CornSelectionDlg dialog


CornSelectionDlg::CornSelectionDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CornSelectionDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CornSelectionDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CornSelectionDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CornSelectionDlg)
	DDX_Control(pDX, IDC_LIST1, m_List);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CornSelectionDlg, CDialog)
	//{{AFX_MSG_MAP(CornSelectionDlg)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CornSelectionDlg message handlers

void CornSelectionDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	Sp1.clear();
	Sw1.clear();
	Sy1.clear();	
	Sp2.clear();
	Sw2.clear();
	Sy2.clear();
	S1.clear();
	S2.clear();	
	P1Move.clear();
	P2Move.clear();
	Sw1_Level1.clear();
	Sw1_Level2.clear();
	Sw1_Level3.clear();
	Sw2_Level1.clear();
	Sw2_Level2.clear();
	Sw2_Level3.clear();
	Sp1_Level1.clear();
	Sp1_Level2.clear();
	Sp1_Level3.clear();
	Sp2_Level1.clear();
	Sp2_Level2.clear();
	Sp2_Level3.clear();
	Sy1_Level1.clear();
	Sy1_Level2.clear();
	Sy1_Level3.clear();
	Sy2_Level1.clear();
	Sy2_Level2.clear();
	Sy2_Level3.clear();
	
	m_List.DeleteAllItems();
	GetPWY();
}

BOOL CornSelectionDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_List.DeleteAllItems();
	m_List.InsertColumn(0, "No", LVCFMT_LEFT, 25);
	m_List.InsertColumn(1, "Ʒ�ִ���", LVCFMT_LEFT, 70);
	m_List.InsertColumn(2, "ȫ������", LVCFMT_LEFT, 70);
	m_List.InsertColumn(3, "���", LVCFMT_LEFT, 40);
	m_List.InsertColumn(4, "���", LVCFMT_LEFT, 40);
	m_List.InsertColumn(5, "�볤", LVCFMT_LEFT, 40);
	m_List.InsertColumn(6, "���", LVCFMT_LEFT, 40);
	m_List.InsertColumn(7, "ǧ����", LVCFMT_LEFT, 60);
	m_List.InsertColumn(8, "С������", LVCFMT_LEFT, 70);
	m_List.InsertColumn(9, "�ȶ���", LVCFMT_LEFT, 60);
	
    CCornSystemApp* pApp=(CCornSystemApp*)AfxGetApp();  
	DBpath=pApp->DBPath;
	
	m_MyDB = new CAccessDB(DBpath.GetBuffer(MAX_PATH),DBpath.GetBuffer(MAX_PATH),0);
	DBpath.ReleaseBuffer();
	
	if(!m_MyDB->OpenDB(DBpath.GetBuffer(MAX_PATH)))
	{
		AfxMessageBox("DB Open Error!");
		DBpath.ReleaseBuffer();
		return FALSE;
	}
	
	DBpath.ReleaseBuffer();


	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CornSelectionDlg::GetPWY()
{
	CString sql="SELECT Sid,Speriod,Sweight,Syield From Son";

	int totle;
	int result;

	char ID[100];
	char P[100];
	char W[100];
	char Y[100];
	char fatherID[100];
	char motherID[100];
	char Corn_name[50];
	char Corn_period[50];
	char Corn_high[50];
	char Corn_shigh[50];
	char Corn_length[50];
	char Corn_wide[50];
	char Corn_weight[50];
	char Corn_yeild[50];
	char Corn_percent[50];
	
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	totle=m_MyDB->GetDataSetRowCount(1);
	
	if(!totle)
		totle=0;

	for(int i=0;i<totle;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,ID);
		m_MyDB->GetDataSetFieldValue(i,1,P);
		m_MyDB->GetDataSetFieldValue(i,2,W);
		m_MyDB->GetDataSetFieldValue(i,3,Y);

		if (i<=totle/2)
		{
			S1.push_back(atoi(ID));
			Sp1.push_back(atof(P));
			Sw1.push_back(atof(W));
			Sy1.push_back(atof(Y));
		}
		else
		{
			S2.push_back(atoi(ID));
			Sp2.push_back(atof(P));
			Sw2.push_back(atof(W));
			Sy2.push_back(atof(Y));
		}
	}

	CalCenterPoint();
	MakeDivision();
	Classification();

	SwEn1=CalEntropy(Sw1_Level1_Num/double(Sw1.size()),Sw1_Level2_Num/double(Sw1.size()),
		Sw1_Level3_Num/double(Sw1.size()));

	SwEn2=CalEntropy(Sw2_Level1_Num/double(Sw2.size()),Sw2_Level2_Num/double(Sw2.size()),
		Sw2_Level3_Num/double(Sw2.size()));

	SpEn1=CalEntropy(Sp1_Level1_Num/double(Sp1.size()),Sp1_Level2_Num/double(Sp1.size()),
		Sp1_Level3_Num/double(Sp1.size()));
	
	SpEn2=CalEntropy(Sp2_Level1_Num/double(Sp2.size()),Sp2_Level2_Num/double(Sp2.size()),
		Sp2_Level3_Num/double(Sp2.size()));

	SyEn1=CalEntropy(Sy1_Level1_Num/double(Sy1.size()),Sy1_Level2_Num/double(Sy1.size()),
		Sy1_Level3_Num/double(Sy1.size()));
	
	SyEn2=CalEntropy(Sy2_Level1_Num/double(Sy2.size()),Sy2_Level2_Num/double(Sy2.size()),
		Sy2_Level3_Num/double(Sy2.size()));

	CString iP;
	CString iW;
	CString iY;

	double dp;
	double dw;
	double dy;

	GetDlgItemText(IDC_EDIT1,iP);
	GetDlgItemText(IDC_EDIT2,iW);
	GetDlgItemText(IDC_EDIT3,iY);
	dp=atof(iP);
	dw=atof(iW);
	dy=atof(iY);


	result=MakeSelection(dp,dw,dy);

	sql.Format("SELECT fathername,mothername FROM son WHERE Sid=%d",result);
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	m_MyDB->GetDataSetFieldValue(0,0,fatherID);
	m_MyDB->GetDataSetFieldValue(0,1,motherID);

	sql.Format("SELECT * FROM Corn WHERE Corn_name='%s'",fatherID);
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;

	m_List.InsertItem(LVIF_TEXT|LVIF_STATE, 0, 
		"1", LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
	m_MyDB->GetDataSetFieldValue(0,1,Corn_name);
	m_List.SetItemText(0,1,Corn_name);
	m_MyDB->GetDataSetFieldValue(0,2,Corn_period);
	m_List.SetItemText(0,2,Corn_period);
	m_MyDB->GetDataSetFieldValue(0,3,Corn_high);
	m_List.SetItemText(0,3,Corn_high);
	m_MyDB->GetDataSetFieldValue(0,4,Corn_shigh);
	m_List.SetItemText(0,4,Corn_shigh);
	m_MyDB->GetDataSetFieldValue(0,5,Corn_length);
	m_List.SetItemText(0,5,Corn_length);
	m_MyDB->GetDataSetFieldValue(0,6,Corn_wide);
	m_List.SetItemText(0,6,Corn_wide);
	m_MyDB->GetDataSetFieldValue(0,7,Corn_weight);
	m_List.SetItemText(0,7,Corn_weight);
	m_MyDB->GetDataSetFieldValue(0,8,Corn_yeild);
	m_List.SetItemText(0,8,Corn_yeild);
	m_MyDB->GetDataSetFieldValue(0,9,Corn_percent);
	m_List.SetItemText(0,9,Corn_percent);


	sql.Format("SELECT * FROM Corn WHERE Corn_name='%s'",motherID);
	
	m_List.InsertItem(LVIF_TEXT|LVIF_STATE, 1, 
		"2", LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	m_MyDB->GetDataSetFieldValue(0,1,Corn_name);
	m_List.SetItemText(1,1,Corn_name);
	m_MyDB->GetDataSetFieldValue(0,2,Corn_period);
	m_List.SetItemText(1,2,Corn_period);
	m_MyDB->GetDataSetFieldValue(0,3,Corn_high);
	m_List.SetItemText(1,3,Corn_high);
	m_MyDB->GetDataSetFieldValue(0,4,Corn_shigh);
	m_List.SetItemText(1,4,Corn_shigh);
	m_MyDB->GetDataSetFieldValue(0,5,Corn_length);
	m_List.SetItemText(1,5,Corn_length);
	m_MyDB->GetDataSetFieldValue(0,6,Corn_wide);
	m_List.SetItemText(1,6,Corn_wide);
	m_MyDB->GetDataSetFieldValue(0,7,Corn_weight);
	m_List.SetItemText(1,7,Corn_weight);
	m_MyDB->GetDataSetFieldValue(0,8,Corn_yeild);
	m_List.SetItemText(1,8,Corn_yeild);
	m_MyDB->GetDataSetFieldValue(0,9,Corn_percent);
	m_List.SetItemText(1,9,Corn_percent);

}	

void CornSelectionDlg::CalCenterPoint()
{
	double sumP=0;
	double sumW=0;
	double sumY=0;

	for (int i=0;i<S1.size();i++)
	{
		sumP+=Sp1[i];
		sumW+=Sw1[i];
		sumY+=Sy1[i];
	}
	P1[0]=sumP/S1.size();
	P1[1]=sumW/S1.size();
	P1[2]=sumY/S1.size();

	sumP=0;
	sumW=0;
	sumY=0;
	for (i=0;i<S2.size();i++)
	{
		sumP+=Sp2[i];
		sumW+=Sw2[i];
		sumY+=Sy2[i];
	}
	P2[0]=sumP/S2.size();
	P2[1]=sumW/S2.size();
	P2[2]=sumY/S2.size();
}

void CornSelectionDlg::MakeDivision()
{
	BOOL flag=TRUE;
	double dp1,dp2;

	while (flag)
	{
		P1Move.clear();
		P2Move.clear();
		for (int i=0;i<S1.size();i++)
		{
			CalDistance(Sp1[i],Sw1[i],Sy1[i],dp1,dp2);
			
			if (dp1<=dp2)
			{
				continue;
			}
			else
			{
				P1Move.push_back(i);
			}
		}
		
		for (i=0;i<S2.size();i++)
		{
			CalDistance(Sp2[i],Sw2[i],Sy2[i],dp1,dp2);
			
			if (dp2<=dp1)
			{
				continue;
			}
			else
			{
				P2Move.push_back(i);
			}
		}

 		if (P1Move.size()==0&&P2Move.size()==0)
		{
			flag=FALSE;
		}
		else
			MakeMove();
	}
}

void CornSelectionDlg::CalDistance(double x,double y,double z,double &dp1,double &dp2)
{
	dp1=sqrt(pow(x-P1[0],2)+pow(y-P1[1],2)+pow(z-P1[2],2));
	dp2=sqrt(pow(x-P2[0],2)+pow(y-P2[1],2)+pow(z-P2[2],2));
}

void CornSelectionDlg::MakeMove()
{
	sort(P1Move.begin(),P1Move.end());
	sort(P2Move.begin(),P2Move.end());

	for (int i=P1Move.size()-1;i>=0;i--)
	{
		S2.push_back(S1[P1Move[i]]);
		Sp2.push_back(Sp1[P1Move[i]]);
		Sw2.push_back(Sw1[P1Move[i]]);
		Sy2.push_back(Sy1[P1Move[i]]);

		S1.erase(S1.begin()+P1Move[i]);
		Sp1.erase(Sp1.begin()+P1Move[i]);
		Sw1.erase(Sw1.begin()+P1Move[i]);
		Sy1.erase(Sy1.begin()+P1Move[i]);
	}

	for (i=P2Move.size()-1;i>=0;i--)
	{
		S1.push_back(S2[P2Move[i]]);
		Sp1.push_back(Sp2[P2Move[i]]);
		Sw1.push_back(Sw2[P2Move[i]]);
		Sy1.push_back(Sy2[P2Move[i]]);
		
		S2.erase(S2.begin()+P2Move[i]);
		Sp2.erase(Sp2.begin()+P2Move[i]);
		Sw2.erase(Sw2.begin()+P2Move[i]);
		Sy2.erase(Sy2.begin()+P2Move[i]);
	}
}

void CornSelectionDlg::Classification()
{	
	vector<double> temp;
	double low;
	double high;

	temp=Sw1;

	sort(temp.begin(),temp.end());
	low=temp[0];
	high=temp[temp.size()-1];

	Sw1_level12=low+(high-low)/3;
	Sw1_level23=low+(high-low)*2/3;

	for (int i=0;i<Sw1.size();i++)
	{
		if (Sw1[i]<=Sw1_level12)
		{
			Sw1_Level1.push_back(S1[i]);
		}
		else
			if (Sw1[i]>Sw1_level12&&Sw1[i]<Sw1_level23)
			{
				Sw1_Level2.push_back(S1[i]);
			}
			else
				Sw1_Level3.push_back(S1[i]);
	}

	Sw1_Level1_Num=Sw1_Level1.size();
	Sw1_Level2_Num=Sw1_Level2.size();
	Sw1_Level3_Num=Sw1_Level3.size();

	temp.clear();
	temp=Sw2;	
	sort(temp.begin(),temp.end());
	low=temp[0];
	high=temp[temp.size()-1];
	
	Sw2_level12=low+(high-low)/3;
	Sw2_level23=low+(high-low)*2/3;
	
	for (i=0;i<Sw2.size();i++)
	{
		if (Sw2[i]<=Sw2_level12)
		{
			Sw2_Level1.push_back(S2[i]);
		}
		else
			if (Sw2[i]>Sw2_level12&&Sw2[i]<Sw2_level23)
			{
				Sw2_Level2.push_back(S2[i]);
			}
			else
				Sw2_Level3.push_back(S2[i]);
	}

	Sw2_Level1_Num=Sw2_Level1.size();
	Sw2_Level2_Num=Sw2_Level2.size();
	Sw2_Level3_Num=Sw2_Level3.size();

	temp.clear();
	temp=Sp1;	
	sort(temp.begin(),temp.end());
	low=temp[0];
	high=temp[temp.size()-1];
	
	Sp1_level12=low+(high-low)/3;
	Sp1_level23=low+(high-low)*2/3;
	
	for (i=0;i<Sp1.size();i++)
	{
		if (Sp1[i]<=Sp1_level12)
		{
			Sp1_Level1.push_back(S1[i]);
		}
		else
			if (Sp1[i]>Sp1_level12&&Sp1[i]<Sp1_level12)
			{
				Sp1_Level2.push_back(S1[i]);
			}
			else
				Sp1_Level3.push_back(S1[i]);
	}
	
	Sp1_Level1_Num=Sp1_Level1.size();
	Sp1_Level2_Num=Sp1_Level2.size();
	Sp1_Level3_Num=Sp1_Level3.size();

	temp.clear();
	temp=Sp2;	
	sort(temp.begin(),temp.end());
	low=temp[0];
	high=temp[temp.size()-1];
	
	Sp2_level12=low+(high-low)/3;
	Sp2_level23=low+(high-low)*2/3;
	
	for (i=0;i<Sp2.size();i++)
	{
		if (Sp2[i]<=Sp2_level12)
		{
			Sp2_Level1.push_back(S2[i]);
		}
		else
			if (Sp2[i]>Sp2_level12&&Sp2[i]<Sp2_level23)
			{
				Sp2_Level2.push_back(S2[i]);
			}
			else
				Sp2_Level3.push_back(S2[i]);
	}
	
	Sp2_Level1_Num=Sp2_Level1.size();
	Sp2_Level2_Num=Sp2_Level2.size();
	Sp2_Level3_Num=Sp2_Level3.size();

	temp.clear();
	temp=Sy1;	
	sort(temp.begin(),temp.end());
	low=temp[0];
	high=temp[temp.size()-1];
	
	Sy1_level12=low+(high-low)/3;
	Sy1_level23=low+(high-low)*2/3;
	
	for (i=0;i<Sy1.size();i++)
	{
		if (Sy1[i]<=Sy1_level12)
		{
			Sy1_Level1.push_back(S1[i]);
		}
		else
			if (Sy1[i]>Sy1_level12&&Sy1[i]<Sy1_level23)
			{
				Sy1_Level2.push_back(S1[i]);
			}
			else
				Sy1_Level3.push_back(S1[i]);
	}
	
	Sy1_Level1_Num=Sy1_Level1.size();
	Sy1_Level2_Num=Sy1_Level2.size();
	Sy1_Level3_Num=Sy1_Level3.size();

	temp.clear();
	temp=Sy2;	
	sort(temp.begin(),temp.end());
	low=temp[0];
	high=temp[temp.size()-1];
	
	Sy2_level12=low+(high-low)/3;
	Sy2_level23=low+(high-low)*2/3;
	
	for (i=0;i<Sy2.size();i++)
	{
		if (Sy2[i]<=Sy2_level12)
		{
			Sy2_Level1.push_back(S2[i]);
		}
		else
			if (Sy2[i]>Sy2_level12&&Sy2[i]<Sy2_level23)
			{
				Sy2_Level2.push_back(S2[i]);
			}
			else
				Sy2_Level3.push_back(S2[i]);
	}
	
	Sy2_Level1_Num=Sy2_Level1.size();
	Sy2_Level2_Num=Sy2_Level2.size();
	Sy2_Level3_Num=Sy2_Level3.size();
}

double CornSelectionDlg::CalEntropy(double P1, double P2, double P3)
{
	return -(P1*MyLog(P1)+P2*MyLog(P2)+P3*MyLog(P3));
}

double CornSelectionDlg::MyLog(double n)
{
	if (n==0)
	{
		return 0;
	}
	return log10(n)/log10(2);
}

int CornSelectionDlg::MakeSelection(double P, double W, double Y)
{
	double dp1;
	double dp2;

	CalDistance(P,W,Y,dp1,dp2);
	if (dp1<=dp2)
	{
		return SelectionOne(P,W,Y);
	}
	else
	{
		return SelectionTwo(P,W,Y);
	}
}

int CornSelectionDlg::SelectionOne(double P, double W, double Y)
{
	if (SwEn1-SpEn1>=SwEn1-SyEn1)
	{
		return PeriodPrior(P,W,Y,1);
	}
	else
	{
		return YieldPrior(P,W,Y,1);
	}
}

int CornSelectionDlg::SelectionTwo(double P, double W, double Y)
{
	if (SwEn2-SpEn2>=SwEn2-SyEn2)
	{
		return PeriodPrior(P,W,Y,2);
	}
	else
	{
		return YieldPrior(P,W,Y,2);
	}
}


int CornSelectionDlg::PeriodPrior(double P, double W, double Y,int choose)
{
	double temp=INT_MAX;
	double dp1;
	double dp2;
	int res;

	if (choose==1)
	{
		if (P<=Sp1_level12)
		{
			for (int i=0;i<Sy1.size();i++)
			{
				dp1=CalDistance2(P,W,Y,Sp1[i],Sw1[i],Sy1[i]);
				if (dp1<temp)
				{
					temp=dp1;
					res=S1[i];
				}
			}
		}

		if (P>Sp1_level12&&P<=Sp1_level23)
		{
			for (int i=0;i<Sy1.size();i++)
			{
				dp1=CalDistance2(P,W,Y,Sp1[i],Sw1[i],Sy1[i]);
				if (dp1<temp)
				{
					temp=dp1;
					res=S1[i];
				}
			}
		}

		if (P>Sp1_level23)
		{
			for (int i=0;i<Sy1.size();i++)
			{
				dp1=CalDistance2(P,W,Y,Sp1[i],Sw1[i],Sy1[i]);
				if (dp1<temp)
				{
					temp=dp1;
					res=S1[i];
				}
			}
		}
	}
	else
		if (choose==2)
		{
			if (P<=Sp2_level12)
			{
				for (int i=0;i<Sy2.size();i++)
				{
					dp1=CalDistance2(P,W,Y,Sp2[i],Sw2[i],Sy2[i]);
					if (dp1<temp)
					{
						temp=dp1;
						res=S2[i];
					}
				}
			}
			
			if (P>Sp2_level12&&P<=Sp2_level23)
			{
				for (int i=0;i<Sy2.size();i++)
				{
					dp1=CalDistance2(P,W,Y,Sp2[i],Sw2[i],Sy2[i]);
					if (dp1<temp)
					{
						temp=dp1;
						res=S2[i];
					}
				}
			}
			
			if (P>Sp2_level23)
			{
				for (int i=0;i<Sy2.size();i++)
				{
					dp1=CalDistance2(P,W,Y,Sp2[i],Sw2[i],Sy2[i]);
					if (dp1<temp)
					{
						temp=dp1;
						res=S2[i];
					}
				}
			}
		}

		return res;
}

int CornSelectionDlg::YieldPrior(double P, double W, double Y,int choose)
{	
	double temp=INT_MIN;
	double dp1;
	double dp2;
	int res;
	
	if (choose==1)
	{
		if (Y<=Sy1_level12)
		{
			for (int i=0;i<Sp1.size();i++)
			{
				dp1=CalDistance2(P,W,Y,Sp1[i],Sw1[i],Sy1[i]);
				if (dp1<temp)
				{
					temp=dp1;
					res=S1[i];
				}
			}
		}
		
		if (Y>Sy1_level12&&Y<=Sy1_level23)
		{
			for (int i=0;i<Sp1.size();i++)
			{
				dp1=CalDistance2(P,W,Y,Sp1[i],Sw1[i],Sy1[i]);
				if (dp1<temp)
				{
					temp=dp1;
					res=S1[i];
				}
			}
		}
		
		if (Y>Sy1_level23)
		{
			for (int i=0;i<Sp1.size();i++)
			{
				if (P1[S1[i]]>Sy1_level23)
				{
					CalDistance(P,W,Y,dp1,dp2);
					if (dp1<temp)
					{
						temp=dp1;
						res=i;
					}
				}
			}
		}
	}
	else
		if (choose==2)
		{
			if (Y<=Sy2_level12)
			{
				for (int i=0;i<Sp2.size();i++)
				{
					dp1=CalDistance2(P,W,Y,Sp2[i],Sw2[i],Sy2[i]);
					if (dp1<temp)
					{
						temp=dp1;
						res=S2[i];
					}
				}
			}
			
			if (Y>Sy2_level12&&P<=Sy2_level23)
			{
				for (int i=0;i<Sp2.size();i++)
				{
					dp1=CalDistance2(P,W,Y,Sp2[i],Sw2[i],Sy2[i]);
					if (dp1<temp)
					{
						temp=dp1;
						res=S2[i];
					}
				}
			}
			
			if (Y>Sy2_level23)
			{
				for (int i=0;i<Sp2.size();i++)
				{
					dp1=CalDistance2(P,W,Y,Sp2[i],Sw2[i],Sy2[i]);
					if (dp1<temp)
					{
						temp=dp1;
						res=S2[i];
					}
				}
			}
		}

		return res;
}

double CornSelectionDlg::CalDistance2(double x1, double y1, double z1, double x2, double y2, double z2)
{
	return sqrt(pow(x1-x2,2)+pow(y1-y2,2)+pow(z1-z2,2));
}
