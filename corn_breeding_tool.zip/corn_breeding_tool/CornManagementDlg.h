#if !defined(AFX_CORNMANAGEMENTDLG_H__B5D6CE72_6676_4341_9D0A_AA58FADDE5B6__INCLUDED_)
#define AFX_CORNMANAGEMENTDLG_H__B5D6CE72_6676_4341_9D0A_AA58FADDE5B6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CornManagementDlg.h : header file
//

#include "ComboListCtrl.h"
#include "AccessDB.h"
/////////////////////////////////////////////////////////////////////////////
// CCornManagementDlg dialog

class CCornManagementDlg : public CDialog
{
// Construction
public:
	void InitList();
	void InitCornCombo();
	CCornManagementDlg(CWnd* pParent = NULL);   // standard constructor
	CAccessDB * m_MyDB;
	CString DBpath;

// Dialog Data
	//{{AFX_DATA(CCornManagementDlg)
	enum { IDD = IDD_DIALOG3 };
	CComboBox	m_word;
	CComboListCtrl	m_ListCtrl;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCornManagementDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCornManagementDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnButton1();
	afx_msg void OnButton2();
	afx_msg void OnButton3();
	afx_msg void OnButton4();
	afx_msg void OnCloseupCombo1();
	afx_msg void OnButton5();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CORNMANAGEMENTDLG_H__B5D6CE72_6676_4341_9D0A_AA58FADDE5B6__INCLUDED_)
