// CornManagementDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CornSystem.h"
#include "CornManagementDlg.h"
#include "MyExcel.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCornManagementDlg dialog


CCornManagementDlg::CCornManagementDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCornManagementDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCornManagementDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CCornManagementDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCornManagementDlg)
	DDX_Control(pDX, IDC_COMBO1, m_word);
	DDX_Control(pDX, IDC_LIST1, m_ListCtrl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCornManagementDlg, CDialog)
	//{{AFX_MSG_MAP(CCornManagementDlg)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	ON_BN_CLICKED(IDC_BUTTON4, OnButton4)
	ON_CBN_CLOSEUP(IDC_COMBO1, OnCloseupCombo1)
	ON_BN_CLICKED(IDC_BUTTON5, OnButton5)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCornManagementDlg message handlers

BOOL CCornManagementDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_ListCtrl.InsertColumn(0, "No", LVCFMT_LEFT, 30);
	m_ListCtrl.InsertColumn(1, "Ʒ�ִ���", LVCFMT_LEFT, 100);
	m_ListCtrl.InsertColumn(2, "ȫ������", LVCFMT_LEFT, 100);
	m_ListCtrl.InsertColumn(3, "���", LVCFMT_LEFT, 120);
	m_ListCtrl.InsertColumn(4, "���", LVCFMT_LEFT, 120);
	m_ListCtrl.InsertColumn(5, "�볤", LVCFMT_LEFT, 120);
	m_ListCtrl.InsertColumn(6, "���", LVCFMT_LEFT, 120);
	m_ListCtrl.InsertColumn(7, "ǧ����", LVCFMT_LEFT, 120);
	m_ListCtrl.InsertColumn(8, "С������", LVCFMT_LEFT, 120);
	m_ListCtrl.InsertColumn(9, "�ȶ���", LVCFMT_LEFT, 120);
	
	CString strValidChars;//	
	m_ListCtrl.SetReadOnlyColumns(0);//read only

	
	m_ListCtrl.EnableVScroll(); 			
	m_ListCtrl.SetExtendedStyle(LVS_EX_FULLROWSELECT);
	
	CCornSystemApp* pApp=(CCornSystemApp*)AfxGetApp();  
	DBpath=pApp->DBPath;
	
	m_MyDB = new CAccessDB(DBpath.GetBuffer(MAX_PATH),DBpath.GetBuffer(MAX_PATH),0);
	DBpath.ReleaseBuffer();
	
	if(!m_MyDB->OpenDB(DBpath.GetBuffer(MAX_PATH)))
	{
		AfxMessageBox("DB Open Error!");
		DBpath.ReleaseBuffer();
		return FALSE;
	}
	
	DBpath.ReleaseBuffer();

	InitList();
	InitCornCombo();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CCornManagementDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	
	(CButton*)GetDlgItem(IDC_BUTTON2)->EnableWindow(TRUE);
	(CButton*)GetDlgItem(IDC_BUTTON1)->EnableWindow(FALSE);
	
	int i =m_ListCtrl.GetItemCount();
	
	CString str;
	
	str.Format("%d",i+1);
	
	m_ListCtrl.InsertItem(LVIF_TEXT|LVIF_STATE, i+1, 
		str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
	UpdateData(FALSE);

	m_ListCtrl.EnsureVisible(i,TRUE);
}

void CCornManagementDlg::OnButton2() 
{
	// TODO: Add your control notification handler code here
	CString Corn_name;
	CString Corn_period;
	CString Corn_high;
	CString Corn_shigh;
	CString Corn_length;
	CString Corn_wide;
	CString Corn_weight;
	CString Corn_yeild;
	CString Corn_percent;

	CString sql;
	int i=m_ListCtrl.GetItemCount();
	
	Corn_name=m_ListCtrl.GetItemText(i-1,1);
	Corn_period=m_ListCtrl.GetItemText(i-1,2);
	Corn_high=m_ListCtrl.GetItemText(i-1,3);
	Corn_shigh=m_ListCtrl.GetItemText(i-1,4);
	Corn_length=m_ListCtrl.GetItemText(i-1,5);
	Corn_wide=m_ListCtrl.GetItemText(i-1,6);
	Corn_weight=m_ListCtrl.GetItemText(i-1,7);
	Corn_yeild=m_ListCtrl.GetItemText(i-1,8);
	Corn_percent=m_ListCtrl.GetItemText(i-1,9);
	
	if (Corn_name!=""&&Corn_period!=""&&Corn_high!=""&&Corn_shigh!=""&&Corn_length!=""&&Corn_wide!=""&&Corn_weight!=""&&Corn_yeild!=""&&Corn_percent!="")
	{
		sql.Format("INSERT INTO corn(Corn_name,Corn_period,Corn_high,Corn_shigh,Corn_length,Corn_wide,Corn_weight,Corn_yield,Corn_percent) VALUES('%s','%s','%s','%s','%s','%s','%s','%s','%s')",Corn_name,Corn_period,Corn_high,Corn_shigh,Corn_length,Corn_wide,Corn_weight,Corn_yeild,Corn_percent);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			AfxMessageBox("DB Error");
		
		(CButton*)GetDlgItem(IDC_BUTTON2)->EnableWindow(FALSE);
		(CButton*)GetDlgItem(IDC_BUTTON1)->EnableWindow(TRUE);
	}
	else
	{
		MessageBox("Corn Infomation Incomplete!");
	}
}

void CCornManagementDlg::OnButton3() 
{
	// TODO: Add your control notification handler code here
	CString Corn_name;

	CString sql;
	CString str;
	
	int gRow=m_ListCtrl.GetSelectionMark();
	
	if (gRow==-1)
	{
		MessageBox("Please select a corn!!!");
		return ;
	}
	
	if(MessageBox("The data selected is being deleted!!!","WARNING!!!",MB_OKCANCEL)==IDOK)
	{
		Corn_name=m_ListCtrl.GetItemText(gRow,1);
		
		sql.Format("DELETE * FROM corn WHERE Corn_name='%s'",Corn_name);
		
		m_ListCtrl.DeleteItem(gRow);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			AfxMessageBox("DB Error");
	}
}

BOOL CCornManagementDlg::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(pMsg->message == WM_KEYDOWN)
    {
        switch(pMsg->wParam)
        {
        case VK_RETURN: 
            // [RETURN] key����
            m_ListCtrl.GoToNextItem();
            return TRUE;
        }
    }

	return CDialog::PreTranslateMessage(pMsg);
}

void CCornManagementDlg::OnButton4() 
{
	// TODO: Add your control notification handler code here
	CMyExcel excel;
	excel.ExportListToExcel(&m_ListCtrl,"Corn");
}

void CCornManagementDlg::InitCornCombo()
{
	CString sql="SELECT Corn_name From corn";
	CString word;
	
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	int WordNo=m_MyDB->GetDataSetRowCount(1);
	
	if(!WordNo)
		WordNo=0;
	
	m_word.ResetContent();

	for(int i=0;i<WordNo;i++)
	{
		m_MyDB->GetDataSetFieldValue(i,0,word.GetBuffer(0));
		m_word.AddString(word);
	}

	m_word.AddString("*");
	m_word.SetCurSel(0);
}

void CCornManagementDlg::OnCloseupCombo1() 
{
	// TODO: Add your control notification handler code here
	CString cornname;
	CString temp;

	m_word.GetLBText(m_word.GetCurSel(),cornname);

	for (int i=m_ListCtrl.GetItemCount()-1;i>=0;i--)
	{	
		temp=m_ListCtrl.GetItemText(i,1);
		if (cornname!=temp)
		{
			m_ListCtrl.DeleteItem(i);
		}
	}
}

void CCornManagementDlg::OnButton5() 
{
	// TODO: Add your control notification handler code here
	InitList();
	InitCornCombo();
}

void CCornManagementDlg::InitList()
{	
	CString sql="select * from corn";
	CString str;
	char Corn_name[50];
	char Corn_period[50];
	char Corn_high[50];
	char Corn_shigh[50];
	char Corn_length[50];
	char Corn_wide[50];
	char Corn_weight[50];
	char Corn_yeild[50];
	char Corn_percent[50];
	
	
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return ;
	int iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	if(!iRowCount)
		return ;
	
	m_ListCtrl.DeleteAllItems();

	for(int i=0;i<iRowCount;i++)
	{
		
		str.Format("%d",i+1);
		m_ListCtrl.InsertItem(LVIF_TEXT|LVIF_STATE, i, 
			str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
		
		m_MyDB->GetDataSetFieldValue(i,1,Corn_name);
		m_ListCtrl.SetItemText(i,1,Corn_name);
		m_MyDB->GetDataSetFieldValue(i,2,Corn_period);
		m_ListCtrl.SetItemText(i,2,Corn_period);
		m_MyDB->GetDataSetFieldValue(i,3,Corn_high);
		m_ListCtrl.SetItemText(i,3,Corn_high);
		m_MyDB->GetDataSetFieldValue(i,4,Corn_shigh);
		m_ListCtrl.SetItemText(i,4,Corn_shigh);
		m_MyDB->GetDataSetFieldValue(i,5,Corn_length);
		m_ListCtrl.SetItemText(i,5,Corn_length);
		m_MyDB->GetDataSetFieldValue(i,6,Corn_wide);
		m_ListCtrl.SetItemText(i,6,Corn_wide);
		m_MyDB->GetDataSetFieldValue(i,7,Corn_weight);
		m_ListCtrl.SetItemText(i,7,Corn_weight);
		m_MyDB->GetDataSetFieldValue(i,8,Corn_yeild);
		m_ListCtrl.SetItemText(i,8,Corn_yeild);
		m_MyDB->GetDataSetFieldValue(i,9,Corn_percent);
		m_ListCtrl.SetItemText(i,9,Corn_percent);
	}
}	
