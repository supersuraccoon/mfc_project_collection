// UserManagement.cpp : implementation file
//

#include "stdafx.h"
#include "CornSystem.h"
#include "UserManagement.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUserManagement dialog


CUserManagement::CUserManagement(CWnd* pParent /*=NULL*/)
	: CDialog(CUserManagement::IDD, pParent)
{
	//{{AFX_DATA_INIT(CUserManagement)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CUserManagement::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUserManagement)
	DDX_Control(pDX, IDC_LIST1, m_ListCtrl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CUserManagement, CDialog)
	//{{AFX_MSG_MAP(CUserManagement)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	ON_BN_CLICKED(IDC_BUTTON4, OnButton4)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_VALIDATE, OnEndLabelEditVariableCriteria)
	ON_MESSAGE(WM_SET_ITEMS, PopulateComboList)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUserManagement message handlers

BOOL CUserManagement::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_ListCtrl.InsertColumn(0, "No", LVCFMT_LEFT, 30);
	m_ListCtrl.InsertColumn(1, "Name", LVCFMT_LEFT, 100);
	m_ListCtrl.InsertColumn(2, "PassWord", LVCFMT_LEFT, 100);
	m_ListCtrl.InsertColumn(3, "User Type", LVCFMT_LEFT, 120);
	
	CString strValidChars;//	
	m_ListCtrl.SetReadOnlyColumns(0);//read only

	m_ListCtrl.SetComboColumns(3,TRUE);
	m_ListCtrl.EnableVScroll(); 			
	m_ListCtrl.SetExtendedStyle(LVS_EX_FULLROWSELECT);
	
	
	CString sql="select * from uesr_info";
	CString str;
	char name[50];
	char password[50];
	char type[50];
	
	CCornSystemApp* pApp=(CCornSystemApp*)AfxGetApp();  
	DBpath=pApp->DBPath;
	
	m_MyDB = new CAccessDB(DBpath.GetBuffer(MAX_PATH),DBpath.GetBuffer(MAX_PATH),0);
	DBpath.ReleaseBuffer();
	
	if(!m_MyDB->OpenDB(DBpath.GetBuffer(MAX_PATH)))
	{
		AfxMessageBox("DB Open Error!");
		DBpath.ReleaseBuffer();
		return FALSE;
	}
	
	DBpath.ReleaseBuffer();
	if(!m_MyDB->SetDataSet(NULL,sql.GetBuffer(0)))
		return false;
	int iRowCount=m_MyDB->GetDataSetRowCount(1);
	
	if(!iRowCount)
		return false;
	
	
	for(int i=0;i<iRowCount;i++)
	{
		
		str.Format("%d",i+1);
		m_ListCtrl.InsertItem(LVIF_TEXT|LVIF_STATE, i, 
			str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
		
		m_MyDB->GetDataSetFieldValue(i,1,name);
		m_ListCtrl.SetItemText(i,1,name);
		m_MyDB->GetDataSetFieldValue(i,2,password);
		m_ListCtrl.SetItemText(i,2,password);
		m_MyDB->GetDataSetFieldValue(i,3,type);
		m_ListCtrl.SetItemText(i,3,type);
	}
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CUserManagement::OnButton1() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	
	(CButton*)GetDlgItem(IDC_BUTTON2)->EnableWindow(TRUE);
	(CButton*)GetDlgItem(IDC_BUTTON1)->EnableWindow(FALSE);
	
	int i =m_ListCtrl.GetItemCount();
	
	CString str;
	
	str.Format("%d",i+1);
	
	m_ListCtrl.InsertItem(LVIF_TEXT|LVIF_STATE, i+1, 
		str, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED, 0, 0);
	UpdateData(FALSE);
}

void CUserManagement::OnButton2() 
{
	// TODO: Add your control notification handler code here
	CString name="";
	CString password="";
	CString type="";
	CString sql;
	int i=m_ListCtrl.GetItemCount();
	
	name=m_ListCtrl.GetItemText(i-1,1);
	password=m_ListCtrl.GetItemText(i-1,2);
	type=m_ListCtrl.GetItemText(i-1,3);
	
	if (name!=""&&password!=""&&type!="")
	{
		sql.Format("INSERT INTO uesr_info(User_name,User_password,User_level) VALUES('%s','%s','%s')",name,password,type);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			AfxMessageBox("DB Error");
		
		(CButton*)GetDlgItem(IDC_BUTTON2)->EnableWindow(FALSE);
		(CButton*)GetDlgItem(IDC_BUTTON1)->EnableWindow(TRUE);
	}
	else
	{
		MessageBox("User Infomation Incomplete!");
	}
}

BOOL CUserManagement::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(pMsg->message == WM_KEYDOWN)
    {
        switch(pMsg->wParam)
        {
        case VK_RETURN: 
            // [RETURN] key����
            m_ListCtrl.GoToNextItem();
            return TRUE;
        }
    }

	return CDialog::PreTranslateMessage(pMsg);
}

LRESULT CUserManagement::PopulateComboList(WPARAM wParam, LPARAM lParam)
{
	// Get the Combobox window pointer
	CComboBox* pInPlaceCombo = static_cast<CComboBox*> (GetFocus());
	
	// Get the inplace combbox top left
	CRect obWindowRect;
	
	pInPlaceCombo->GetWindowRect(&obWindowRect);
	
	CPoint obInPlaceComboTopLeft(obWindowRect.TopLeft()); 
	
	// Get the active list
	// Get the control window rect
	// If the inplace combobox top left is in the rect then
	// The control is the active control
	m_ListCtrl.GetWindowRect(&obWindowRect);
	
	int iColIndex = (int )wParam;
	
	CStringList* pComboList = reinterpret_cast<CStringList*>(lParam);
	pComboList->RemoveAll(); 
	
	if (obWindowRect.PtInRect(obInPlaceComboTopLeft)) 
	{				
		if(iColIndex==3)
		{
			pComboList->AddTail("Administrator");
			pComboList->AddTail("User");		
		}			
	}
	return true;
}

LRESULT CUserManagement::OnEndLabelEditVariableCriteria(WPARAM wParam, LPARAM lParam) 
{
	LV_DISPINFO* pDispInfo = (LV_DISPINFO*)lParam;
	// TODO: Add your control notification handler code here
	
	return 1;
}

void CUserManagement::OnButton3() 
{
	// TODO: Add your control notification handler code here
	CString name;
	CString password;
	CString type;
	CString sql;
	CString str;

	int gRow=m_ListCtrl.GetSelectionMark();
	
	if (gRow==-1)
	{
		MessageBox("Please select a user!!!");
		return ;
	}
	
	if(MessageBox("The data selected is being deleted!!!","WARNING!!!",MB_OKCANCEL)==IDOK)
	{
		name=m_ListCtrl.GetItemText(gRow,1);
		
		sql.Format("DELETE * FROM uesr_info WHERE User_name='%s'",name);
		
		m_ListCtrl.DeleteItem(gRow);
		if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
			AfxMessageBox("DB Error");
	}
}

void CUserManagement::OnButton4() 
{
	// TODO: Add your control notification handler code here
	CString name="";
	CString password="";
	CString type="";
	CString sql;
	int i=m_ListCtrl.GetSelectionMark();
	
	name=m_ListCtrl.GetItemText(i,1);
	password=m_ListCtrl.GetItemText(i,2);
	type=m_ListCtrl.GetItemText(i,3);
	
	
	sql.Format("UPDATE uesr_info SET User_password='%s',User_level='%s' WHERE User_name='%s'",password,type,name);
	if(!m_MyDB->ExecSQL((unsigned char *)sql.GetBuffer(0)))
		AfxMessageBox("DB Error");
	
}
