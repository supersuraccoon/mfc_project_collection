// CornSystem.h : main header file for the CORNSYSTEM application
//

#if !defined(AFX_CORNSYSTEM_H__B5E3882E_5A75_489B_81BB_996A8DE446B3__INCLUDED_)
#define AFX_CORNSYSTEM_H__B5E3882E_5A75_489B_81BB_996A8DE446B3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CCornSystemApp:
// See CornSystem.cpp for the implementation of this class
//

class CCornSystemApp : public CWinApp
{
public:
	CCornSystemApp();
	CString DBPath;
	CString strPath;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCornSystemApp)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CCornSystemApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CORNSYSTEM_H__B5E3882E_5A75_489B_81BB_996A8DE446B3__INCLUDED_)
