#if !defined(AFX_ORNSELECTIONDLG_H__0AC054E1_F82C_4284_9704_5C2868A301A6__INCLUDED_)
#define AFX_ORNSELECTIONDLG_H__0AC054E1_F82C_4284_9704_5C2868A301A6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ornSelectionDlg.h : header file
//
#include "AccessDB.h"
/////////////////////////////////////////////////////////////////////////////
// CornSelectionDlg dialog

class CornSelectionDlg : public CDialog
{
// Construction
public:
	double CalDistance2(double,double,double,double,double,double);
	int YieldPrior(double P, double W, double Y,int choose);
	int SelectionTwo(double P, double W, double Y);
	int PeriodPrior(double P, double W, double Y,int choose);
	int SelectionOne(double P, double W, double Y);
	int MakeSelection(double P,double W,double Y);
	double MyLog(double n);
	double CalEntropy(double P1,double P2,double P3);
	void Classification();
	void MakeMove();
	void CalDistance(double x,double y,double z,double &dp1,double &dp2);
	void MakeDivision();
	void CalCenterPoint();
	void GetPWY();
	CornSelectionDlg(CWnd* pParent = NULL);   // standard constructor
	CAccessDB * m_MyDB;
	CString DBpath;

// Dialog Data
	//{{AFX_DATA(CornSelectionDlg)
	enum { IDD = IDD_DIALOG4 };
	CListCtrl	m_List;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CornSelectionDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CornSelectionDlg)
	afx_msg void OnButton1();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	vector<double> Sp1;
	vector<double> Sw1;
	vector<double> Sy1;

	vector<double> Sp2;
	vector<double> Sw2;
	vector<double> Sy2;

	vector<int> S1;
	vector<int> S2;

	double P1[3];
	double P2[3];

	vector<int> P1Move;
	vector<int> P2Move;

	vector<double> Sw1_Level1;
	vector<double> Sw1_Level2;
	vector<double> Sw1_Level3;
	int Sw1_Level1_Num;
	int Sw1_Level2_Num;
	int Sw1_Level3_Num;
	double Sw1_level12;
	double Sw1_level23;

	vector<double> Sw2_Level1;
	vector<double> Sw2_Level2;
	vector<double> Sw2_Level3;
	int Sw2_Level1_Num;
	int Sw2_Level2_Num;
	int Sw2_Level3_Num;
	double Sw2_level12;
	double Sw2_level23;

	vector<double> Sp1_Level1;
	vector<double> Sp1_Level2;
	vector<double> Sp1_Level3;
	int Sp1_Level1_Num;
	int Sp1_Level2_Num;
	int Sp1_Level3_Num;
	double Sp1_level12;
	double Sp1_level23;
	
	vector<double> Sp2_Level1;
	vector<double> Sp2_Level2;
	vector<double> Sp2_Level3;
	int Sp2_Level1_Num;
	int Sp2_Level2_Num;
	int Sp2_Level3_Num;
	double Sp2_level12;
	double Sp2_level23;

	vector<double> Sy1_Level1;
	vector<double> Sy1_Level2;
	vector<double> Sy1_Level3;
	int Sy1_Level1_Num;
	int Sy1_Level2_Num;
	int Sy1_Level3_Num;
	double Sy1_level12;
	double Sy1_level23;
	
	vector<double> Sy2_Level1;
	vector<double> Sy2_Level2;
	vector<double> Sy2_Level3;
	int Sy2_Level1_Num;
	int Sy2_Level2_Num;
	int Sy2_Level3_Num;
	double Sy2_level12;
	double Sy2_level23;


	double SpEn1;
	double SpEn2;

	double SwEn1;
	double SwEn2;

	double SyEn1;
	double SyEn2;

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ORNSELECTIONDLG_H__0AC054E1_F82C_4284_9704_5C2868A301A6__INCLUDED_)
