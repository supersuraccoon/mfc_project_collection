// 25Dlg.h : header file
//

#if !defined(AFX_25DLG_H__EEB78FFF_7B6C_4028_A4CE_6C4D58A48DD7__INCLUDED_)
#define AFX_25DLG_H__EEB78FFF_7B6C_4028_A4CE_6C4D58A48DD7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CMy25Dlg dialog

class CMy25Dlg : public CDialog
{
// Construction
public:
	CMy25Dlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CMy25Dlg)
	enum { IDD = IDD_MY25_DIALOG };
	CListCtrl	m_showInfo;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMy25Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMy25Dlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnExceltest();
	afx_msg void OnInput();
	afx_msg void OnSave();
	afx_msg void OnDelete();
	afx_msg void OnClickShowinfor(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnChoose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CString savePath;
	int delRow;
	int row;
	int columns;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_25DLG_H__EEB78FFF_7B6C_4028_A4CE_6C4D58A48DD7__INCLUDED_)
