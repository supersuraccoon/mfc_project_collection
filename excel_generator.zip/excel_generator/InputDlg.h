#if !defined(AFX_INPUTDLG_H__F8BBA59F_5110_47A8_AB9C_A47637AE9479__INCLUDED_)
#define AFX_INPUTDLG_H__F8BBA59F_5110_47A8_AB9C_A47637AE9479__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// InputDlg.h : header file
//

#include "Student.h"
/////////////////////////////////////////////////////////////////////////////
// CInputDlg dialog

class CInputDlg : public CDialog
{
// Construction
public:
	void SetCtrlList(CString name, CString no, CString sClass, CString telNo,
							CString eng,CString math,CString vc);
		
	CString GetTelNo(void);
	CString GetNo(void);
	CString GetClass(void);
	CString GetName(void);
	CString GetEng(void);
	CString GetMath(void);
	CString GetVC(void);
	CInputDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CInputDlg)
	enum { IDD = IDD_INPUT };
	CEdit	m_vc;
	CEdit	m_math;
	CEdit	m_eng;
	CEdit	m_edClass;
	CEdit	m_edTelNo;
	CEdit	m_edNo;
	CEdit	m_edName;
	CString	m_name;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInputDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CInputDlg)
	afx_msg void OnContinue();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	//Student student;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INPUTDLG_H__F8BBA59F_5110_47A8_AB9C_A47637AE9479__INCLUDED_)
