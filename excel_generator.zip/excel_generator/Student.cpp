// Student.cpp: implementation of the Student class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "25.h"
#include "Student.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Student::Student()
{
	name="";
	no="";
	telNo="";
	sClass="";
}

Student::~Student()
{

}

Student::Student(CString name, CString no, CString sClass, CString telNo,CString eng,
				 CString math,CString vc)
{
	this->name=name;
	this->no=no;
	this->sClass=sClass;
	this->telNo=telNo;
	this->eng=eng;
	this->math=math;
	this->vc=vc;
}

bool Student::IsInputOk()
{
	if(name!=""&&no!=""&&sClass!=""&&telNo!=""&&eng!=""&&math!=""&&vc!="")
		return true;
	else
		return false;
}

CString Student::GetNo()
{
	return no;
}

CString Student::GetName()
{
	return name;
}
CString Student::GetClass()
{
	return sClass;
}
CString Student::GetTelNo()
{
	return telNo;
}

CString Student::GetEng()
{
	return eng;
}
CString Student::GetMath()
{
	return math;
}
CString Student::GetVC()
{
	return vc;
}