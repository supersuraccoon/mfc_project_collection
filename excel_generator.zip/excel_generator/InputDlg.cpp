// InputDlg.cpp : implementation file
//

#include "stdafx.h"
#include "25.h"
#include "InputDlg.h"
#include "25Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CInputDlg dialog


CInputDlg::CInputDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CInputDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CInputDlg)
	m_name = _T("");
	//}}AFX_DATA_INIT
}


void CInputDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CInputDlg)
	DDX_Control(pDX, IDC_VC, m_vc);
	DDX_Control(pDX, IDC_MATH, m_math);
	DDX_Control(pDX, IDC_ENG, m_eng);
	DDX_Control(pDX, IDC_CLASS, m_edClass);
	DDX_Control(pDX, IDC_TELNO, m_edTelNo);
	DDX_Control(pDX, IDC_NO, m_edNo);
	DDX_Control(pDX, IDC_NAME, m_edName);
	DDX_Text(pDX, IDC_NAME, m_name);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CInputDlg, CDialog)
	//{{AFX_MSG_MAP(CInputDlg)
	ON_BN_CLICKED(IDC_CONTINUE, OnContinue)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInputDlg message handlers

void CInputDlg::OnContinue() 
{
	// TODO: Add your control notification handler code here
	//((CMy25Dlg*)AfxGetApp())->m_showInfo.InsertItem(0,"sxc");///////////////

	//CListCtrl m_list;
	//CString tmpName="NULL";
	//CString tmpNo="NULL";
	//CString tmpClass="NULL";
	//CString tmpTelNo="NULL";
	
	Student student(GetName(),GetNo(),GetClass(),GetTelNo(),GetEng(),GetMath(),GetVC());


	if(student.IsInputOk())
		SetCtrlList(student.GetName(),student.GetNo()
			,student.GetClass(),student.GetTelNo(),student.GetEng(),
			student.GetMath(),student.GetVC());
		//m_list=((CMy25Dlg*)GetParent())->m_showInfo;
	else
	{
		int result;
		result=MessageBox("��������û��¼��,�Ƿ����?","����!",MB_YESNO);
		if(result==IDYES)
			SetCtrlList(student.GetName(),student.GetNo()
			,student.GetClass(),student.GetTelNo(),student.GetEng(),
			student.GetMath(),student.GetVC());
		else
			if(result==IDNO)
				return ;
	}

}

CString CInputDlg::GetName()
{
	CString name;
	GetDlgItemText(IDC_NAME,name);

	return name;
}

CString CInputDlg::GetClass()
{
	CString sClass;
	GetDlgItemText(IDC_CLASS,sClass);

	return sClass;
}

CString CInputDlg::GetNo()
{
	CString no;
	GetDlgItemText(IDC_NO,no);

	return no;
}

CString CInputDlg::GetTelNo()
{
	CString telNo;
	GetDlgItemText(IDC_TELNO,telNo);

	return telNo;
}

CString CInputDlg::GetEng()
{
	CString eng;
	GetDlgItemText(IDC_ENG,eng);
	return eng;
}
CString CInputDlg::GetMath()
{
	CString math;
	GetDlgItemText(IDC_MATH,math);
	return math;
}
CString CInputDlg::GetVC()
{
	CString vc;
	GetDlgItemText(IDC_VC,vc);
	return vc;
}

void CInputDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	CDialog::OnCancel();
}

void CInputDlg::SetCtrlList(CString name, CString no, CString sClass, CString telNo,
							CString eng,CString math,CString vc)
{
	    ((CMy25Dlg*)GetParent())->m_showInfo.InsertItem(0xffff,name);//////////
		((CMy25Dlg*)GetParent())->m_showInfo.SetItemText(((CMy25Dlg*)GetParent())->m_showInfo.GetItemCount()-1
			,1,no);
		((CMy25Dlg*)GetParent())->m_showInfo.SetItemText(((CMy25Dlg*)GetParent())->m_showInfo.GetItemCount()-1
			,2,sClass);
		((CMy25Dlg*)GetParent())->m_showInfo.SetItemText(((CMy25Dlg*)GetParent())->m_showInfo.GetItemCount()-1
			,3,telNo);
		((CMy25Dlg*)GetParent())->m_showInfo.SetItemText(((CMy25Dlg*)GetParent())->m_showInfo.GetItemCount()-1
			,4,eng);
		((CMy25Dlg*)GetParent())->m_showInfo.SetItemText(((CMy25Dlg*)GetParent())->m_showInfo.GetItemCount()-1
			,5,math);
		((CMy25Dlg*)GetParent())->m_showInfo.SetItemText(((CMy25Dlg*)GetParent())->m_showInfo.GetItemCount()-1
			,6,vc);
}
