// 25Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "25.h"
#include "25Dlg.h"
#include "comdef.h" 
#include "Excel.h" 
#include "InputDlg.h"
#include "TemplateDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();
	
	// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA
	
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	
	// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
//{{AFX_MSG_MAP(CAboutDlg)
// No message handlers
//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMy25Dlg dialog

CMy25Dlg::CMy25Dlg(CWnd* pParent /*=NULL*/)
: CDialog(CMy25Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMy25Dlg)
	// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMy25Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMy25Dlg)
	DDX_Control(pDX, IDC_SHOWINFOR, m_showInfo);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMy25Dlg, CDialog)
//{{AFX_MSG_MAP(CMy25Dlg)
ON_WM_SYSCOMMAND()
ON_WM_PAINT()
ON_WM_QUERYDRAGICON()
ON_BN_CLICKED(IDC_EXCELTEST, OnExceltest)
	ON_BN_CLICKED(IDC_INPUT, OnInput)
	ON_BN_CLICKED(IDC_SAVE, OnSave)
	ON_BN_CLICKED(IDC_DELETE, OnDelete)
	ON_NOTIFY(NM_CLICK, IDC_SHOWINFOR, OnClickShowinfor)
	ON_BN_CLICKED(IDC_CHOOSE, OnChoose)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMy25Dlg message handlers

BOOL CMy25Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	// Add "About..." menu item to system menu.
	
	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);
	
	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}
	
	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	char *szColumn[]={"����","ѧ��","�༶","��ϵ��ʽ","Ӣ��","��ѧ","VC"};
	columns=7;
	int widths[]={50,100,80,120,50,50,50};
	LV_COLUMN lvc;
	lvc.mask=LVCF_FMT|LVCF_WIDTH|LVCF_TEXT|LVCF_SUBITEM;
	lvc.fmt=LVCFMT_LEFT;
	for(int i=0;i<7;i++) 
	{//�������
		lvc.pszText=szColumn[i];
		lvc.cx=widths[i];
		lvc.iSubItem=i;
		m_showInfo.InsertColumn(i,&lvc);
	}
	m_showInfo.SetExtendedStyle(m_showInfo.GetExtendedStyle()|LVS_EX_GRIDLINES|
		LVS_EX_FULLROWSELECT); 
	
	CFont *font=new CFont;
	//font->CreatePointFont(5,"����"); 
	font->CreateFont(16,0,0,0,FW_DONTCARE,FALSE,FALSE,0,ANSI_CHARSET,OUT_DEFAULT_PRECIS,
		CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH|FF_SWISS,"����");

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMy25Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMy25Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting
		
		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);
		
		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
		
		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMy25Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMy25Dlg::OnExceltest() 
{
	// TODO: Add your control notification handler code here
	const   COleVariant   covOptional((long)DISP_E_PARAMNOTFOUND,VT_ERROR);
	_Application ExcelApp; 
	Workbooks wbsMyBooks; 
	_Workbook wbMyBook; 
	Worksheets wssMysheets; 
	_Worksheet wsMysheet; 
	Range rgMyRge; 
	//����Excel 2000������(����Excel) 
	
	if (!ExcelApp.CreateDispatch("Excel.Application",NULL)) 
	{ 
		AfxMessageBox("����Excel����ʧ��!"); 
		exit(1); 
	} 

	char   filename   [_MAX_PATH];   
	GetModuleFileName(AfxGetInstanceHandle(),filename,_MAX_PATH);

	CString path=filename;
	int find=path.ReverseFind('\\');
	CString newpath=path.Left(find+1);
	newpath+="\\MyTemplate.xlt";

	//strcat(filename,"\\MyTemplate.xlt");

	//����ģ���ļ��������ĵ� 
	wbsMyBooks.AttachDispatch(ExcelApp.GetWorkbooks(),true); 
	wbMyBook.AttachDispatch(wbsMyBooks.Add(_variant_t(newpath))); 
	//�õ�Worksheets 
	wssMysheets.AttachDispatch(wbMyBook.GetWorksheets(),true); 
	//�õ�sheet1 
	wsMysheet.AttachDispatch(wssMysheets.GetItem(_variant_t("sheet1")),true); 
	//�õ�ȫ��Cells����ʱ,rgMyRge��cells�ļ��� 
	rgMyRge.AttachDispatch(wsMysheet.GetCells(),true); 
	//���õ�Ԫ��ֵ 
	row=m_showInfo.GetItemCount();

	rgMyRge.SetItem(_variant_t((long)1),_variant_t((long)1),_variant_t("����")); 
	rgMyRge.SetItem(_variant_t((long)1),_variant_t((long)2),_variant_t("ѧ��"));
	rgMyRge.SetItem(_variant_t((long)1),_variant_t((long)3),_variant_t("�༶"));
	rgMyRge.SetItem(_variant_t((long)1),_variant_t((long)4),_variant_t("��ϵ�绰"));
	rgMyRge.SetItem(_variant_t((long)1),_variant_t((long)5),_variant_t("Ӣ��"));
	rgMyRge.SetItem(_variant_t((long)1),_variant_t((long)6),_variant_t("��ѧ"));
	rgMyRge.SetItem(_variant_t((long)1),_variant_t((long)7),_variant_t("VC"));

	for(int i=2;i<row+2;i++)
		for(int j=0;j<columns;j++)
		{
			rgMyRge.SetItem(_variant_t((long)i),_variant_t((long)(j+1)),
				_variant_t(m_showInfo.GetItemText(i-2,j)));
		}

	rgMyRge.SetHorizontalAlignment(_variant_t((long)2));///////
	//�õ����е��� 
	rgMyRge.AttachDispatch(wsMysheet.GetColumns(),true); 
	//�õ���һ�� 
	rgMyRge.AttachDispatch(rgMyRge.GetItem(_variant_t((long)4),vtMissing).pdispVal,true); 

	//�����п� 
    rgMyRge.SetColumnWidth(_variant_t((long)20)); 
	wbMyBook.SetSaved(true); 
	ExcelApp.SetVisible(true); 
	wbMyBook.SaveAs(COleVariant(savePath),covOptional,covOptional,
	covOptional,covOptional,covOptional,0,
	covOptional,covOptional,covOptional,covOptional,covOptional);
	//wbMyBook.PrintPreview(_variant_t(false)); 
	//�ͷŶ��� 
	rgMyRge.ReleaseDispatch(); 
	wsMysheet.ReleaseDispatch(); 
	wssMysheets.ReleaseDispatch(); 
	wbMyBook.ReleaseDispatch(); 
	wbsMyBooks.ReleaseDispatch(); 
	ExcelApp.ReleaseDispatch(); 
	wbsMyBooks.Close();
	ExcelApp.Quit();
}

void CMy25Dlg::OnInput() 
{
	// TODO: Add your control notification handler code here
	CInputDlg dlg;
	dlg.DoModal();
}



void CMy25Dlg::OnSave() 
{
	// TODO: Add your control notification handler code here
	CFileDialog dlg(FALSE,NULL,NULL,OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT|
		OFN_ALLOWMULTISELECT,"Excel(*.xlt)|*.xlt||",AfxGetMainWnd());

	if(dlg.DoModal()==IDOK)
	{
		savePath=dlg.GetPathName();
		savePath+=".xls";
		OnExceltest();
	}
}

void CMy25Dlg::OnDelete() 
{
	// TODO: Add your control notification handler code here
   m_showInfo.DeleteItem(delRow);

}	

void CMy25Dlg::OnClickShowinfor(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	LPNMITEMACTIVATE temp=(LPNMITEMACTIVATE)pNMHDR;  
	delRow=temp->iItem;

	*pResult = 0;
}

void CMy25Dlg::OnChoose() 
{
	// TODO: Add your control notification handler code here
	CTemplateDlg dlg;
	dlg.DoModal();
}
