// Student.h: interface for the Student class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_STUDENT_H__6E5AF59D_3A92_4006_B546_27D4BB37D438__INCLUDED_)
#define AFX_STUDENT_H__6E5AF59D_3A92_4006_B546_27D4BB37D438__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class Student  
{
public:
	CString GetNo(void);
	CString GetName(void);
	CString GetClass(void);
	CString GetTelNo(void);
	CString GetEng(void);
	CString GetMath(void);
	CString GetVC(void);

	bool IsInputOk(void);
	Student(CString name, CString no, CString sClass, CString telNo,CString eng,
				 CString math,CString vc);
	Student();
	virtual ~Student();

private:
	CString name;
	CString no;
	CString telNo;
	CString sClass;
	CString eng;
	CString math;
	CString vc;
};

#endif // !defined(AFX_STUDENT_H__6E5AF59D_3A92_4006_B546_27D4BB37D438__INCLUDED_)
