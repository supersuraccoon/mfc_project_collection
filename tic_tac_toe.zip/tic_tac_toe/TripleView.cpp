// TripleView.cpp : implementation of the CTripleView class
//

#include "stdafx.h"
#include "Triple.h"

#include "TripleDoc.h"
#include "TripleView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTripleView

IMPLEMENT_DYNCREATE(CTripleView, CView)

BEGIN_MESSAGE_MAP(CTripleView, CView)
	//{{AFX_MSG_MAP(CTripleView)
	ON_WM_LBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTripleView construction/destruction

CTripleView::CTripleView()
{
	// TODO: add construction code here
	move=0;
	bCheckPlayer=FALSE;
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<3;j++)
		{
			m_occupied[i][j]=0;
		}
	}
	m_cs.cx=10;
	m_cs.cy=10;
}

CTripleView::~CTripleView()
{
}

BOOL CTripleView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTripleView drawing

void CTripleView::OnDraw(CDC* pDC)
{
	CTripleDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here

	CRect m_clientRect;
	GetClientRect(&m_clientRect);
	//////////////////////////////////////////////////////////////////
	pDC->MoveTo(0,0);
	pDC->LineTo(286,0);
	pDC->LineTo(286,264);
	pDC->LineTo(0,264);
	pDC->LineTo(0,0);

	//////////////////////////////////////////////////////////////////
	for(int i=0;i<m_clientRect.bottom;)
	{
		pDC->MoveTo(i+m_clientRect.Width()/4,0);
		pDC->LineTo(i+m_clientRect.Width()/4,m_clientRect.Height());
		i+=m_clientRect.Width()/4;
	}
	for(i=0;i<m_clientRect.Width()-100;)
	{
		pDC->MoveTo(0,i+m_clientRect.Height()/4);
		pDC->LineTo(m_clientRect.Width(),i+m_clientRect.Height()/4);
		i+=m_clientRect.Height()/4;
	}
	/////////////////////////////////////////////////////////////////////
	for(i=0;i<3;i++)
	{
		for(int j=0;j<3;j++)
		{
			m_pt[i][j].x=m_clientRect.right/4*(j+1);
			m_pt[i][j].y=m_clientRect.bottom/4*(i+1);
		}
	}
	for(i=0;i<3;i++)
		for(int j=0;j<3;j++)
		{
			{
				m_rect[i][j].left=m_pt[i][j].x-10;
				m_rect[i][j].top=m_pt[i][j].y-10;
				m_rect[i][j].right=m_pt[i][j].x+10;
				m_rect[i][j].bottom=m_pt[i][j].y+10;
			}
		}
		for(i=0;i<3;i++)
			for(int j=0;j<3;j++)
			{
				switch(m_occupied[i][j])
				{
				case 1:
					pDC->SelectStockObject(BLACK_BRUSH);
					pDC->Ellipse(&m_rect[i][j]);
					break;
				case 2:
					pDC->SelectStockObject(WHITE_BRUSH);
					pDC->Ellipse(&m_rect[i][j]);
					break;
				default:
					;
				}
			}
}

/////////////////////////////////////////////////////////////////////////////
// CTripleView diagnostics

#ifdef _DEBUG
void CTripleView::AssertValid() const
{
	CView::AssertValid();
}

void CTripleView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CTripleDoc* CTripleView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTripleDoc)));
	return (CTripleDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTripleView message handlers

BOOL CTripleView::CheckOccupied(int i,int j)
{
	if(m_occupied[i][j])
		return false;
	else 
		return true;
}

BOOL CTripleView::CheckWin()
{
	BOOL bcheckDraw=true;
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<3;j++)
		{
			if(m_occupied[i][j]==0)
				bcheckDraw=false;
			break;
		}
	}
	if(move==9&&bcheckDraw)
		return true;
	 if(m_occupied[0][0]==1&&m_occupied[0][1]==1&&m_occupied[0][2]==1||
		m_occupied[0][0]==2&&m_occupied[0][1]==2&&m_occupied[0][2]==2)
		return true;
	else if(m_occupied[0][0]==1&&m_occupied[1][1]==1&&m_occupied[2][2]==1||
		m_occupied[0][0]==2&&m_occupied[1][1]==2&&m_occupied[2][2]==2)
		return true;
	else if(m_occupied[1][0]==1&&m_occupied[1][1]==1&&m_occupied[1][2]==1||
		m_occupied[1][0]==2&&m_occupied[1][1]==2&&m_occupied[1][2]==2)
		return true;
	else if(m_occupied[0][0]&&1==m_occupied[1][0]==1&&m_occupied[2][0]==1||
		m_occupied[0][0]==2&&m_occupied[1][0]==2&&m_occupied[2][0]==2)
		return true;
	else if(m_occupied[2][0]==1&&m_occupied[2][1]==1&&m_occupied[2][2]==1||
		m_occupied[2][0]==2&&m_occupied[2][1]==2&&m_occupied[2][2]==2)
		return true;
	else if(m_occupied[0][1]==1&&m_occupied[1][1]==1&&m_occupied[2][1]==1||
		m_occupied[0][1]==2&&m_occupied[1][1]==2&&m_occupied[2][1]==2)
		return true;
	else if(m_occupied[0][2]==1&&m_occupied[1][2]==1&&m_occupied[2][2]==1||
		m_occupied[0][2]==2&&m_occupied[1][2]==2&&m_occupied[2][2]==2)
		return true;
	else if(m_occupied[0][2]==1&&m_occupied[1][1]==1&&m_occupied[2][0]==1||
		m_occupied[0][2]==2&&m_occupied[1][1]==2&&m_occupied[2][0]==2)
		return true;
	else 
		return false;
}

void CTripleView::WinnerDeclare(int i)
{
	CString str;
	switch(i)
	{
	case 1:
		if(move==9)
		{
			str="Draw!";
			move=0;
		}
		else
		{
			str="You Win!";
			move=0;
		}
		break;
	case 2:
		str="You Lose!";
		move=0;
		break;
	default:
		;
	}
	MessageBox(str);
	bCheckPlayer=FALSE;
	for(i=0;i<3;i++)
	{
		for(int j=0;j<3;j++)
		{
			m_occupied[i][j]=0;
		}
	}
	Invalidate();

}
int CTripleView::Strategy2(int &i,int &j)
{
	for(int p=0;p<3;p++)
	{
		if(m_occupied[p][0]==2&&m_occupied[p][1]==2&&m_occupied[p][2]==0)
		{
			i=p;
			j=2;
			return 0;
		}
		if(m_occupied[p][0]==2&&m_occupied[p][2]==2&&m_occupied[p][1]==0)
		{
			i=p;
			j=1;
			return 0;
		}
		if(m_occupied[p][1]==2&&m_occupied[p][2]==2&&m_occupied[p][0]==0)
		{
			i=p;
			j=0;
			return 0;
		}
	}
	////////////////////line check
	for(p=0;p<3;p++)
	{
		if(m_occupied[0][p]==2&&m_occupied[1][p]==2&&m_occupied[2][p]==0)
		{
			i=2;
			j=p;
			return 0;
		}
		if(m_occupied[0][p]==2&&m_occupied[2][p]==2&&m_occupied[1][p]==0)
		{
			i=1;
			j=p;
			return 0;
		}
		if(m_occupied[1][p]==2&&m_occupied[2][p]==2&&m_occupied[0][p]==0)
		{
			i=0;
			j=p;
			return 0;
		}
	}
	/////////////////////cross check
	if(m_occupied[0][0]==2&&m_occupied[1][1]==2&&m_occupied[2][2]==0)
	{
		i=2;
		j=2;
		return 0;
	}
	else
		if(m_occupied[0][0]==2&&m_occupied[2][2]==2&&m_occupied[1][1]==0)
	{
		i=1;
		j=1;
		return 0;
	}
	else
		if(m_occupied[1][1]==2&&m_occupied[2][2]==2&&m_occupied[0][0]==0)
	{
		i=0;
		j=0;
		return 0;
	}
	else
		if(m_occupied[0][2]==2&&m_occupied[1][1]==2&&m_occupied[2][0]==0)
	{
		i=2;
		j=0;
		return 0;
	}
	else
		if(m_occupied[1][1]==2&&m_occupied[2][0]==2&&m_occupied[0][2]==0)
	{
		i=0;
		j=2;
		return 0;
	}
	else
		if(m_occupied[0][2]==2&&m_occupied[2][0]==2&&m_occupied[1][1]==0)
	{
		i=1;
		j=1;
		return 0;
	}
}

int CTripleView::Strategy(int &i,int &j)
{
	///////////////////row check
	for(int p=0;p<3;p++)
	{
		if(m_occupied[p][0]==1&&m_occupied[p][1]==1&&m_occupied[p][2]==0)
		{
			i=p;
			j=2;
			return 0;
		}
		if(m_occupied[p][0]==1&&m_occupied[p][2]==1&&m_occupied[p][1]==0)
		{
			i=p;
			j=1;
			return 0;
		}
		if(m_occupied[p][1]==1&&m_occupied[p][2]==1&&m_occupied[p][0]==0)
		{
			i=p;
			j=0;
			return 0;
		}
	}
	////////////////////line check
	for(p=0;p<3;p++)
	{
		if(m_occupied[0][p]==1&&m_occupied[1][p]==1&&m_occupied[2][p]==0)
		{
			i=2;
			j=p;
			return 0;
		}
		if(m_occupied[0][p]==1&&m_occupied[2][p]==1&&m_occupied[1][p]==0)
		{
			i=1;
			j=p;
			return 0;
		}
		if(m_occupied[1][p]==1&&m_occupied[2][p]==1&&m_occupied[0][p]==0)
		{
			i=0;
			j=p;
			return 0;
		}
	}
	/////////////////////cross check
	if(m_occupied[0][0]==1&&m_occupied[1][1]==1&&m_occupied[2][2]==0)
	{
		i=2;
		j=2;
		return 0;
	}
	else
		if(m_occupied[0][0]==1&&m_occupied[2][2]==1&&m_occupied[1][1]==0)
	{
		i=1;
		j=1;
		return 0;
	}
	else
		if(m_occupied[1][1]==1&&m_occupied[2][2]==1&&m_occupied[0][0]==0)
	{
		i=0;
		j=0;
		return 0;
	}
	else
		if(m_occupied[0][2]==1&&m_occupied[1][1]==1&&m_occupied[2][0]==0)
	{
		i=2;
		j=0;
		return 0;
	}
	else
		if(m_occupied[1][1]==1&&m_occupied[2][0]==1&&m_occupied[0][2]==0)
	{
		i=0;
		j=2;
		return 0;
	}
	else
		if(m_occupied[0][2]==1&&m_occupied[2][0]==1&&m_occupied[1][1]==0)
	{
		i=1;
		j=1;
		return 0;
	}
	else
		Strategy2(i,j);
}

void CTripleView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	BOOL bfind=false;
	m_point=point;
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<3;j++)
		{
			if(m_rect[i][j].PtInRect(m_point))
			{
				if(CheckOccupied(i,j))
				{
					PlayerMove(m_rect[i][j]);
					m_occupied[i][j]=1;
					bfind=true;
				}
				else
					break;
				if(CheckWin())
				{
					WinnerDeclare(1);
					CView::OnLButtonDown(nFlags, point);
					return;
				}
			}
		}
	}
	
	if(bfind)
	{
		bfind=false;
		ComputerMove();
		if(CheckWin())
			WinnerDeclare(2);
	}
	
	CView::OnLButtonDown(nFlags, point);
}

void CTripleView::PlayerMove(CRect m_drawRect)
{
	CClientDC dc(this);
	dc.SelectStockObject(BLACK_BRUSH);
	dc.Ellipse(m_drawRect);
	bCheckPlayer=TRUE;
	move+=1;
	
}

void CTripleView::ComputerMove()
{
	int i,j;
	bool check=true;
	CClientDC dc(this);
	dc.SelectStockObject(WHITE_BRUSH);
	while(check)
	{
		i=rand()%3;
		j=rand()%3;
		Strategy(i,j);
		if(CheckOccupied(i,j))
		{
			check=false;
			m_drawRect=m_rect[i][j];
			m_occupied[i][j]=2;
		}
		
	}
	dc.Ellipse(m_drawRect);
	bCheckPlayer=FALSE;
	move+=1;
}