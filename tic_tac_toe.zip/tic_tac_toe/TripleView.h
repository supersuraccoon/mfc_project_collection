// TripleView.h : interface of the CTripleView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TRIPLEVIEW_H__74AFBAE5_1172_4A1D_86DA_1C30D82BB6EA__INCLUDED_)
#define AFX_TRIPLEVIEW_H__74AFBAE5_1172_4A1D_86DA_1C30D82BB6EA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CTripleView : public CView
{
protected: // create from serialization only
	CTripleView();
	DECLARE_DYNCREATE(CTripleView)

// Attributes
public:
	CTripleDoc* GetDocument();

	int move;
	CRect m_drawRect;
	CSize m_cs;
	CPoint m_point;
	CPoint m_pt[3][3];
	CRect m_rect[3][3];
	BOOL bCheckPlayer;
	int m_occupied[3][3];
	BOOL CheckOccupied(int,int);
	void ComputerMove();
	void PlayerMove(CRect);
	BOOL CheckWin();
	void WinnerDeclare(int i);
	int Strategy(int &,int &);
	int Strategy2(int &,int &);

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTripleView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTripleView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CTripleView)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in TripleView.cpp
inline CTripleDoc* CTripleView::GetDocument()
   { return (CTripleDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRIPLEVIEW_H__74AFBAE5_1172_4A1D_86DA_1C30D82BB6EA__INCLUDED_)
