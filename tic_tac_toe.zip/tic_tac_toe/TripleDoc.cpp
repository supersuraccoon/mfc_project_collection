// TripleDoc.cpp : implementation of the CTripleDoc class
//

#include "stdafx.h"
#include "Triple.h"

#include "TripleDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTripleDoc

IMPLEMENT_DYNCREATE(CTripleDoc, CDocument)

BEGIN_MESSAGE_MAP(CTripleDoc, CDocument)
	//{{AFX_MSG_MAP(CTripleDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTripleDoc construction/destruction

CTripleDoc::CTripleDoc()
{
	// TODO: add one-time construction code here

}

CTripleDoc::~CTripleDoc()
{
}

BOOL CTripleDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CTripleDoc serialization

void CTripleDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CTripleDoc diagnostics

#ifdef _DEBUG
void CTripleDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CTripleDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTripleDoc commands
