// TripleDoc.h : interface of the CTripleDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TRIPLEDOC_H__2FF8CBA0_9F81_4D8A_8E99_FBB7F223B33E__INCLUDED_)
#define AFX_TRIPLEDOC_H__2FF8CBA0_9F81_4D8A_8E99_FBB7F223B33E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CTripleDoc : public CDocument
{
protected: // create from serialization only
	CTripleDoc();
	DECLARE_DYNCREATE(CTripleDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTripleDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTripleDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CTripleDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRIPLEDOC_H__2FF8CBA0_9F81_4D8A_8E99_FBB7F223B33E__INCLUDED_)
