// Triple.h : main header file for the TRIPLE application
//

#if !defined(AFX_TRIPLE_H__0FE1B7C6_09A5_4838_A706_2A3B29FE54F7__INCLUDED_)
#define AFX_TRIPLE_H__0FE1B7C6_09A5_4838_A706_2A3B29FE54F7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CTripleApp:
// See Triple.cpp for the implementation of this class
//

class CTripleApp : public CWinApp
{
public:
	CTripleApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTripleApp)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CTripleApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRIPLE_H__0FE1B7C6_09A5_4838_A706_2A3B29FE54F7__INCLUDED_)
