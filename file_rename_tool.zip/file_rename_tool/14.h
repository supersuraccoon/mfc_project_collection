// 14.h : main header file for the 14 application
//

#if !defined(AFX_14_H__EA30EB7E_C7FF_4639_8EBD_F22C3CBA1DB0__INCLUDED_)
#define AFX_14_H__EA30EB7E_C7FF_4639_8EBD_F22C3CBA1DB0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CMy14App:
// See 14.cpp for the implementation of this class
//

class CMy14App : public CWinApp
{
public:
	CMy14App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMy14App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CMy14App)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_14_H__EA30EB7E_C7FF_4639_8EBD_F22C3CBA1DB0__INCLUDED_)
