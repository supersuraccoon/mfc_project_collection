#if !defined(AFX_TYPEDLG_H__15EE7D92_D60C_42F2_83B3_CC508F4822C6__INCLUDED_)
#define AFX_TYPEDLG_H__15EE7D92_D60C_42F2_83B3_CC508F4822C6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TypeDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTypeDlg dialog

class CTypeDlg : public CDialog
{
// Construction
public:
	CTypeDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CTypeDlg)
	enum { IDD = IDD_DIALOG1 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTypeDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTypeDlg)
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TYPEDLG_H__15EE7D92_D60C_42F2_83B3_CC508F4822C6__INCLUDED_)
