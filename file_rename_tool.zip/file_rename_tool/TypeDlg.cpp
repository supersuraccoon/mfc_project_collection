// TypeDlg.cpp : implementation file
//

#include "stdafx.h"
#include "14.h"
#include "TypeDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTypeDlg dialog


CTypeDlg::CTypeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTypeDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTypeDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CTypeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTypeDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTypeDlg, CDialog)
	//{{AFX_MSG_MAP(CTypeDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTypeDlg message handlers



void CTypeDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	CString str;
	GetDlgItemText(IDC_EDIT1,str);
	::SetDlgItemText(AfxGetMainWnd()->m_hWnd,IDC_CHOICE,str);
	
	CDialog::OnCancel();
}
