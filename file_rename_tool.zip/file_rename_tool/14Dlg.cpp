// 14Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "14.h"
#include "14Dlg.h"
#include "TypeDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMy14Dlg dialog

CMy14Dlg::CMy14Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMy14Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMy14Dlg)
	m_name1 = 0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMy14Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMy14Dlg)
	DDX_Control(pDX, IDC_EDIT1, m_name);
	DDX_Control(pDX, IDC_CHOICE, m_choice);
	DDX_Control(pDX, IDC_COMBO, m_comb);
	DDX_Control(pDX, IDC_SHOWLIST, m_list);
	DDX_Text(pDX, IDC_EDIT1, m_name1);
	DDV_MinMaxInt(pDX, m_name1, 0, 999);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMy14Dlg, CDialog)
	//{{AFX_MSG_MAP(CMy14Dlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_OPEN, OnOpen)
	ON_CBN_SELCHANGE(IDC_COMBO, OnSelchangeCombo)
	ON_BN_CLICKED(IDC_CONVERT, OnConvert)
	ON_BN_CLICKED(IDC_DELETE, OnDelete)
	ON_BN_CLICKED(IDC_CLEAR, OnClear)
	ON_LBN_DBLCLK(IDC_SHOWLIST, OnDblclkShowlist)
	ON_BN_CLICKED(IDC_CONVERT2, OnConvert2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMy14Dlg message handlers

BOOL CMy14Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

    

	m_comb.AddString("mp3");
	m_comb.AddString("wma");
	m_comb.AddString("rm");
	m_comb.AddString("rmvb");
	m_comb.AddString("jpg");
	m_comb.AddString("bmp");
	m_comb.AddString("������ʽ...");
	m_list.SetHorizontalExtent(400);//
	
	//ModifyStyle(0,WS_MINIMIZEBOX);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMy14Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMy14Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMy14Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMy14Dlg::OnOpen() 
{
	// TODO: Add your control notification handler code here
	POSITION pt;
	CString path(" ",128);
	CString str(" ",10000);

	CFileDialog dlg(TRUE,NULL,NULL,OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT|
		OFN_ALLOWMULTISELECT,"�����ļ�(*.*)|*.*||",AfxGetMainWnd());

	dlg.m_ofn.lpstrFile=str.GetBuffer(10000);
	dlg.m_ofn.nMaxFile=10000;
    str.ReleaseBuffer();

	dlg.DoModal();

	pt=dlg.GetStartPosition();

	while(pt)
	{
		path=dlg.GetNextPathName(pt);
		m_list.AddString(path);
	}
	
}

void CMy14Dlg::OnSelchangeCombo() 
{
	// TODO: Add your control notification handler code here
	CTypeDlg dlg;
 	int end;
	int choice;
	CString str;
	end=m_comb.GetCount()-1;
	choice=m_comb.GetCurSel();
	if(choice==end)	
	{
	   dlg.DoModal();
	 
	}
	else
	{
		m_comb.GetLBText(choice,str);
		SetDlgItemText(IDC_CHOICE,str);
	}
	
}

void CMy14Dlg::OnConvert() 
{
	// TODO: Add your control notification handler code here
	CString type;
	CString oldpath;
	CString newpath;
	int index=0;

	GetDlgItemText(IDC_CHOICE,type);
	if(!m_list.GetCount())
		return;
	for(;index<m_list.GetCount();index++)
	{
		m_list.GetText(index,oldpath);
		newpath=oldpath.SpanExcluding(".");
		newpath+=".";
		newpath+=type;
	
		rename(oldpath,newpath);	

		if(errno==17)
		{
			MessageBox(newpath);
			return;
		}	
	}	
	MessageBox("ת�����!","��ʾ");
	m_list.ResetContent();
}

void CMy14Dlg::OnDelete() 
{
	// TODO: Add your control notification handler code here
	int num;
	num=m_list.GetSelCount();
	int *p=new int[num];
	
	m_list.GetSelItems(num,p);
    for(int i=0;i<num;i++)   
	{   
		m_list.DeleteString(p[i]-i);
	}   
	delete[]p;
	
}

void CMy14Dlg::OnClear() 
{
	// TODO: Add your control notification handler code here
	m_list.ResetContent();
}

void CMy14Dlg::OnDblclkShowlist() 
{
	// TODO: Add your control notification handler code here
	CString str;
	int index=m_list.GetCurSel();

	m_list.GetText(index,str);
	ShellExecute(NULL,NULL,str,NULL,NULL,SW_SHOWNORMAL);
	
}

void CMy14Dlg::OnConvert2() 
{
	// TODO: Add your control notification handler code here
	m_name.SetReadOnly(false);

	CString type;
	CString name;
	CString oldpath;
	CString newpath;
	int index=0;
	int n=0;
    int input=0;

	GetDlgItemText(IDC_CHOICE,type);
	GetDlgItemText(IDC_EDIT1,name);
    n=atoi(name);
	input=n;

	if(!m_list.GetCount())
		return;
	for(;index<m_list.GetCount();index++)
	{
		n=input;
		int find;
		m_list.GetText(index,oldpath);

		find=oldpath.ReverseFind('\\');
		do
		{	
			newpath=oldpath.Left(find+1);
			
			name.Format("%d",n);
			newpath+=name;
			
			newpath+=".";
			newpath+=type;
			rename(oldpath,newpath);	
			n++;
		}
		while(errno==17);
	}	
	MessageBox("ת�����!","��ʾ");
	m_list.ResetContent();
}

