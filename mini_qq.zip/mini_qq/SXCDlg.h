// SXCDlg.h : header file
//

#if !defined(AFX_SXCDLG_H__5BCA78E1_42E5_4E54_AB6F_BADDD22FE3C7__INCLUDED_)
#define AFX_SXCDLG_H__5BCA78E1_42E5_4E54_AB6F_BADDD22FE3C7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "BtnST.h"
/////////////////////////////////////////////////////////////////////////////
// CSXCDlg dialog

class CSXCDlg : public CDialog
{
// Construction
public:
	CSXCDlg(CWnd* pParent = NULL);	// standard constructor
	int m_nEdgeSnapGap;
	void toTray();

	CButtonST m_btn1;
	CButtonST m_btn2;
	CButtonST m_btn3;

// Dialog Data
	//{{AFX_DATA(CSXCDlg)
	enum { IDD = IDD_SXC_DIALOG };
	CComboBox	m_combo;
	CTabCtrl	m_tabCtrl;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSXCDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSXCDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSelchangeTab1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnWindowPosChanging(WINDOWPOS FAR* lpwndpos);
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnButton2();
	afx_msg void OnClose();
	afx_msg void OnEditPaste();
	//}}AFX_MSG
	LRESULT   OnShowTask(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
private:

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SXCDLG_H__5BCA78E1_42E5_4E54_AB6F_BADDD22FE3C7__INCLUDED_)
