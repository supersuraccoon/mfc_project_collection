// SXCDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SXC.h"
#include "SXCDlg.h"
#include "ChileDlg1.h"
#include "ChileDlg2.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define WM_SHOWTASK (WM_USER+100)

NOTIFYICONDATA nid;
CChileDlg1 m_dlgChile1;
CChileDlg2 m_dlgChile2;

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSXCDlg dialog

CSXCDlg::CSXCDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSXCDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSXCDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSXCDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSXCDlg)
	DDX_Control(pDX, IDC_COMBO1, m_combo);
	DDX_Control(pDX, IDC_TAB1, m_tabCtrl);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSXCDlg, CDialog)
	//{{AFX_MSG_MAP(CSXCDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_NOTIFY(TCN_SELCHANGE, IDC_TAB1, OnSelchangeTab1)
	ON_WM_WINDOWPOSCHANGING()
	ON_WM_ACTIVATE()
	ON_WM_RBUTTONDOWN()
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_WM_CLOSE()
	ON_MESSAGE(WM_SHOWTASK,OnShowTask)
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSXCDlg message handlers

BOOL CSXCDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	CRect rect;
	GetWindowRect(&rect);
	
	int m_xScreen;
	int m_yScreen;
	m_xScreen=GetSystemMetrics(SM_CXSCREEN);
	m_yScreen=GetSystemMetrics(SM_CYSCREEN);
	
	SetWindowPos(&wndTopMost,m_xScreen/2,m_yScreen/5,rect.Width(),rect.Height(),SWP_SHOWWINDOW);
	m_combo.SetCurSel(0);

	TCITEM tcItem;
	tcItem.mask = TCIF_TEXT;
    tcItem.pszText = _T("�ҵĺ���");
	m_tabCtrl.InsertItem(0, &tcItem);
    tcItem.pszText = _T("������");
	m_tabCtrl.InsertItem(1, &tcItem);
	tcItem.pszText = _T("�ҵ��ղ�");
	m_tabCtrl.InsertItem(2, &tcItem);
	tcItem.pszText = _T("ϵͳ����");
	m_tabCtrl.InsertItem(3, &tcItem);

	m_btn1.SubclassDlgItem(IDC_BUTTON2,this);
	m_btn1.SetIcon(IDI_ICON6);
	m_btn1.SetTooltipText("��Ϸ");

	m_btn2.SubclassDlgItem(IDC_BUTTON4,this);
	m_btn2.SetIcon(IDI_ICON3);
	m_btn2.SetTooltipText("����");

	m_btn3.SubclassDlgItem(IDC_BUTTON5,this);
	m_btn3.SetIcon(IDI_ICON4);
	m_btn3.SetTooltipText("����");


	m_dlgChile1.Create(IDD_DIALOG1,GetDlgItem(IDC_TAB1));
	m_dlgChile2.Create(IDD_DIALOG2,GetDlgItem(IDC_TAB1));
	// ���Ӵ�����ʾ��m_Tab��Χ��
	CRect rs;
	m_tabCtrl.GetClientRect(rs);
	rs.top+=4;
	rs.bottom-=4;
	rs.left+=20;
	rs.right-=4;
	m_dlgChile1.MoveWindow(rs);
	m_dlgChile2.MoveWindow(rs);
	// Ĭ����ʾ��һ���Ӵ���
	m_tabCtrl.SetCurSel(0);
	m_dlgChile1.ShowWindow(TRUE);
	m_nEdgeSnapGap=15;

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSXCDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ( nID == SC_MINIMIZE )
	{
		toTray();
	}

	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSXCDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSXCDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSXCDlg::OnSelchangeTab1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	int nCurSel = m_tabCtrl.GetCurSel();
	
	switch(nCurSel)
	{
	case 0: // ��ʾ�Ӵ���1
		m_dlgChile1.ShowWindow(TRUE);
		m_dlgChile2.ShowWindow(FALSE);
		break;
	case 1: // ��ʾ�Ӵ���2
		m_dlgChile1.ShowWindow(FALSE);
		m_dlgChile2.ShowWindow(TRUE);
		break;
}
	*pResult = 0;
}

void CSXCDlg::OnWindowPosChanging(WINDOWPOS FAR* lpwndpos) 
{
	CDialog::OnWindowPosChanging(lpwndpos);
	
	// TODO: Add your message handler code here
	RECT rcScrn;
	SystemParametersInfo (SPI_GETWORKAREA, 0, &rcScrn, 0);
	
	// Snap X axis
	if (abs(lpwndpos->x - rcScrn.left) <= m_nEdgeSnapGap)
		lpwndpos->x = rcScrn.left;
	else if (abs(lpwndpos->x + lpwndpos->cx - rcScrn.right) <= m_nEdgeSnapGap)
		lpwndpos->x = rcScrn.right - lpwndpos->cx;
	
	// Snap Y axis
	if (abs(lpwndpos->y - rcScrn.top) <= m_nEdgeSnapGap)
		lpwndpos->y = rcScrn.top;
	else if (abs(lpwndpos->y + lpwndpos->cy - rcScrn.bottom) <= m_nEdgeSnapGap)
		lpwndpos->y = rcScrn.bottom - lpwndpos->cy;
}

void CSXCDlg::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized) 
{
	CDialog::OnActivate(nState, pWndOther, bMinimized);
	
	// TODO: Add your message handler code here
	if (nState==WA_INACTIVE)
	{
		//toTray();
	}
}

void CSXCDlg::toTray()
{ 
   nid.cbSize=(DWORD)sizeof(NOTIFYICONDATA); 
   nid.hWnd=this->m_hWnd; 
   nid.uID=IDR_MAINFRAME; 
   nid.uFlags=NIF_ICON|NIF_MESSAGE|NIF_TIP ; 
   nid.uCallbackMessage=WM_SHOWTASK;//�Զ������Ϣ���� 
   nid.hIcon=LoadIcon(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDR_MAINFRAME)); 
   strcpy(nid.szTip,"SXC");    //��Ϣ��ʾ��Ϊ���ƻ��������ѡ� 
   Shell_NotifyIcon(NIM_ADD,&nid);    //������������ͼ�� 
   ShowWindow(SW_HIDE);    //���������� 

}

LRESULT CSXCDlg::OnShowTask(WPARAM wParam, LPARAM lParam)
{
	if(wParam!=IDR_MAINFRAME) 
        return 1; 
	
	CMenu menu;
	CPoint point;
	menu.LoadMenu(CG_IDR_POPUP_SXCDLG);
	CMenu *pMenu=menu.GetSubMenu(0);

    switch(lParam) 
    {    
        case WM_RBUTTONUP://�Ҽ�����ʱ������ݲ˵�������ֻ��һ�����رա� 
        { 
			::GetCursorPos(&point);//�õ����λ�� 
			
            pMenu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON,point.x,point.y,this);
			menu.DestroyMenu(); 
        } 
        break; 
        case WM_LBUTTONDBLCLK://˫������Ĵ��� 
		{ 
			Shell_NotifyIcon(NIM_DELETE,&nid); 
			ShowWindow(SW_NORMAL);
		} 
        break; 
		default:
			break;
    } 
    return 0;
}

void CSXCDlg::OnRButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	CDialog::OnRButtonDown(nFlags, point);
}

void CSXCDlg::OnButton2() 
{
	// TODO: Add your control notification handler code here
	ShellExecute(0, _T("open"), "http://www.ntu.edu.cn/", NULL, NULL, SW_SHOWMAXIMIZED); 
}

void CSXCDlg::OnClose() 
{
	// TODO: Add your message handler code here and/or call default

	CDialog::OnClose();
}


BOOL CSXCDlg::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CDialog::PreTranslateMessage(pMsg);
}

void CSXCDlg::OnEditPaste() 
{
	// TODO: Add your command handler code here
	Shell_NotifyIcon(NIM_DELETE, &nid);
	SendMessage(WM_CLOSE);
}
