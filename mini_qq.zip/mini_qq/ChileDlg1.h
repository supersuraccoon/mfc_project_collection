#if !defined(AFX_CHILEDLG1_H__6CB99770_E53D_4D83_A412_91B150C977BE__INCLUDED_)
#define AFX_CHILEDLG1_H__6CB99770_E53D_4D83_A412_91B150C977BE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ChileDlg1.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CChileDlg1 dialog
#define UM_SOCK		(WM_USER+1)

class CChileDlg1 : public CDialog
{
// Construction
public:
	void AddUser(CString name,CString Port);
	void ConnectServer();
	BOOL InitSocket();
	void InitTree();
	CChileDlg1(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CChileDlg1)
	enum { IDD = IDD_DIALOG1 };
	CTreeCtrl	m_tree;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChileDlg1)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CChileDlg1)
	virtual BOOL OnInitDialog();
	afx_msg void OnRclickTree1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnChat();
	afx_msg void OnSock(WPARAM,LPARAM);
	afx_msg void OnGroupchat();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CImageList *m_imagelist; 
	HTREEITEM allUser;
	SOCKET m_socket;
	int port;
	vector<CString> portVec;
	int localPort;
};
	
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHILEDLG1_H__6CB99770_E53D_4D83_A412_91B150C977BE__INCLUDED_)
