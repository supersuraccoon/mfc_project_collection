// ChileDlg2.cpp : implementation file
//

#include "stdafx.h"
#include "SXC.h"
#include "ChileDlg2.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChileDlg2 dialog


CChileDlg2::CChileDlg2(CWnd* pParent /*=NULL*/)
	: CDialog(CChileDlg2::IDD, pParent)
{
	//{{AFX_DATA_INIT(CChileDlg2)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CChileDlg2::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CChileDlg2)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CChileDlg2, CDialog)
	//{{AFX_MSG_MAP(CChileDlg2)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChileDlg2 message handlers
