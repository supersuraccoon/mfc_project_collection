// ChileDlg1.cpp : implementation file
//

#include "stdafx.h"
#include "SXC.h"
#include "ChileDlg1.h"
#include "Chat.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChileDlg1 dialog


CChileDlg1::CChileDlg1(CWnd* pParent /*=NULL*/)
	: CDialog(CChileDlg1::IDD, pParent)
{
	//{{AFX_DATA_INIT(CChileDlg1)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_imagelist=new CImageList; 
}


void CChileDlg1::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CChileDlg1)
	DDX_Control(pDX, IDC_TREE1, m_tree);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CChileDlg1, CDialog)
	//{{AFX_MSG_MAP(CChileDlg1)
	ON_NOTIFY(NM_RCLICK, IDC_TREE1, OnRclickTree1)
	ON_COMMAND(ID_CHAT, OnChat)
	ON_COMMAND(ID_GROUPCHAT, OnGroupchat)
	//}}AFX_MSG_MAP
	ON_MESSAGE(UM_SOCK,OnSock)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChileDlg1 message handlers

void CChileDlg1::InitTree()
{
	DWORD dwStyle = GetWindowLong(m_tree.m_hWnd,GWL_STYLE);
	dwStyle|=TVS_HASBUTTONS|TVS_HASLINES|TVS_LINESATROOT;
	SetWindowLong(m_tree.m_hWnd,GWL_STYLE,dwStyle);	

	HICON icon[4];
	icon[0]=AfxGetApp()->LoadIcon (IDI_ICON1); 
	icon[1]=AfxGetApp()->LoadIcon (IDI_ICON2); 
	icon[2]=AfxGetApp()->LoadIcon (IDI_ICON3); 
	icon[3]=AfxGetApp()->LoadIcon (IDI_ICON4); 

	//����ͼ���б��ؼ�
	m_imagelist->Create(16,16,0,7,7); 
	m_imagelist->SetBkColor (RGB(255,255,255));

	m_imagelist->Add(icon[0]);  //��ͼ������ͼ���б��ؼ�
	m_imagelist->Add(icon[1]);  //��ͼ������ͼ���б��ؼ�
	m_imagelist->Add(icon[2]);  //��ͼ������ͼ���б��ؼ�
	m_imagelist->Add(icon[3]);  //��ͼ������ͼ���б��ؼ�

	m_tree.DeleteAllItems();
	m_tree.SetImageList(m_imagelist,TVSIL_NORMAL);  //Ϊm_mytree����һ��ͼ���б���ʹCtreeCtrl�Ľڵ���ʾ��ͬ��ͼ�� 

	allUser=m_tree.InsertItem("������",0,0);
	/*m_tree.InsertItem("sxc",3,3,temp);
	m_tree.InsertItem("1sxc",3,3,temp);
	m_tree.InsertItem("2sxc",3,3,temp);*/
	m_tree.InsertItem("����",1,1);
	m_tree.InsertItem("������",2,2);

	//m_tree.SetItemData(temp,(DWORD)atoi(ParentID));

}

BOOL CChileDlg1::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	InitTree();
	InitSocket();
	ConnectServer();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CChileDlg1::OnRclickTree1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	CPoint cp;
	CString str;
    GetCursorPos(&cp);
    m_tree.ScreenToClient(&cp);
    HTREEITEM titem = m_tree.HitTest(cp, NULL);
	HTREEITEM parent=m_tree.GetParentItem(titem);
	HTREEITEM child=m_tree.GetChildItem(titem);
    // ���Ϻܹؼ�����֤�Ҽ������λ������Ҷ����֦
	
    if(parent==NULL)
    {
        // �����ڴ˹��˵����Ҷ����֦�ŵ����˵�����û������
		m_tree.SelectItem(titem);
		m_tree.ClientToScreen(&cp);
		str=m_tree.GetItemText(titem);
		if (str=="������")
		{
			CMenu *pMenu = new CMenu();
			VERIFY(pMenu->CreatePopupMenu());
			pMenu->AppendMenu(MF_STRING,ID_GROUPCHAT,"��ʼ��������");
		
			pMenu->TrackPopupMenu(TPM_LEFTALIGN,cp.x,cp.y,this);
			pMenu->DestroyMenu();
		}
    }
	else
	{
		m_tree.SelectItem(titem);
		m_tree.ClientToScreen(&cp);
		str=m_tree.GetItemText(titem);
		port=atoi(str);
		// �����Զ���˵�
		CMenu *pMenu = new CMenu();
		VERIFY(pMenu->CreatePopupMenu());
		pMenu->AppendMenu(MF_STRING,ID_CHAT,"��ʼ����");
		
		pMenu->TrackPopupMenu(TPM_LEFTALIGN,cp.x,cp.y,this);
		pMenu->DestroyMenu();
	}
	
	*pResult = 0;
}

void CChileDlg1::OnChat() 
{
	// TODO: Add your command handler code here
	CChat dlg;
	dlg.m_socket=m_socket;
	dlg.port=port;
	dlg.awaken=FALSE;
	dlg.isGroupChat=FALSE;
	dlg.localPort=localPort;
	dlg.DoModal();
}
BOOL CChileDlg1::InitSocket()
{
	srand( (unsigned)time( NULL ) );
	int n=rand()%1000+6666;
	localPort=n;
	
	m_socket=WSASocket(AF_INET,SOCK_DGRAM,0,NULL,0,0);
	if(INVALID_SOCKET==m_socket)
	{
		MessageBox("�����׽���ʧ�ܣ�");
		return FALSE;
	}
	SOCKADDR_IN addrSock;
	addrSock.sin_addr.S_un.S_addr=htonl(INADDR_ANY);
	addrSock.sin_family=AF_INET;
	
	addrSock.sin_port=htons(n);
	if(SOCKET_ERROR==bind(m_socket,(SOCKADDR*)&addrSock,sizeof(SOCKADDR)))
	{
		MessageBox("��ʧ�ܣ�");
		return FALSE;
	}
	if(SOCKET_ERROR==WSAAsyncSelect(m_socket,m_hWnd,UM_SOCK,FD_READ))
	{
		MessageBox("ע�������ȡ�¼�ʧ�ܣ�");
		return FALSE;
	}

	return TRUE;
}

void CChileDlg1::OnSock(WPARAM wParam,LPARAM lParam)
{
	switch(LOWORD(lParam))
	{
	case FD_READ:
		WSABUF wsabuf;
		wsabuf.buf=new char[200];
		wsabuf.len=200;
		DWORD dwRead;
		DWORD dwFlag=0;
		SOCKADDR_IN addrFrom;
		int len=sizeof(SOCKADDR);
		CString str;
		CString strTemp;
		CString find;

		if(SOCKET_ERROR==WSARecvFrom(m_socket,&wsabuf,1,&dwRead,&dwFlag,
						(SOCKADDR*)&addrFrom,&len,NULL,NULL))
		{
			delete[] wsabuf.buf; 
			return;
		}
		HOSTENT *pHost;
		pHost=gethostbyaddr((char*)&addrFrom.sin_addr.S_un.S_addr,4,AF_INET);
		port=ntohs(addrFrom.sin_port);

		if (wsabuf.buf[dwRead-2]=='1')
		{
			wsabuf.buf[dwRead-2]='\0';
			AddUser(pHost->h_name,wsabuf.buf);
		}
		else
		{
			find.Format("%d",port);
			HTREEITEM temp=m_tree.GetNextItem(allUser,TVGN_CHILD);
			while (temp)
			{
				if (find==m_tree.GetItemText(temp))
				{
					CChat dlg;
					dlg.m_socket=m_socket;
					dlg.port=port;
					if (wsabuf.buf[dwRead-2]=='2')
					{
						dlg.isGroupChat=TRUE;
						dlg.portVec=portVec;
					}
					else
						dlg.isGroupChat=FALSE;
					dlg.awaken=TRUE;
					dlg.localPort=localPort;
					dlg.DoModal();
					break;
				}
				temp=m_tree.GetNextItem(temp,TVGN_NEXT);
			}
		}
		delete[] wsabuf.buf; 
		break;
	}
}

void CChileDlg1::ConnectServer()
{
	CString strSend;
	WSABUF wsabuf;
	DWORD dwSend;
	int len;
	SOCKADDR_IN addrTo;

	addrTo.sin_addr.S_un.S_addr=inet_addr("127.0.0.1");
	addrTo.sin_family=AF_INET;
	addrTo.sin_port=htons(6000);

	strSend="";
	len=strSend.GetLength();
	wsabuf.buf=strSend.GetBuffer(len);
	wsabuf.len=len+1;


	if(SOCKET_ERROR==WSASendTo(m_socket,&wsabuf,1,&dwSend,0,
			(SOCKADDR*)&addrTo,sizeof(SOCKADDR),NULL,NULL))
	{
		MessageBox("���ӷ�����ʧ�ܣ�");
		return;
	}	
}

void CChileDlg1::AddUser(CString name, CString Port)
{
	HTREEITEM temp=m_tree.GetNextItem(allUser,TVGN_CHILD);
	while (temp)
	{
		if (Port==m_tree.GetItemText(temp))
		{
			return;
		}
		temp=m_tree.GetNextItem(temp,TVGN_NEXT);
	}
	m_tree.InsertItem(Port,3,3,allUser);
	portVec.push_back(Port);
	m_tree.Invalidate(TRUE);
}

void CChileDlg1::OnGroupchat() 
{
	// TODO: Add your command handler code here
	CChat dlg;
	dlg.m_socket=m_socket;
	dlg.port=port;
	dlg.isGroupChat=TRUE;
	dlg.awaken=FALSE;
	dlg.localPort=localPort;
	dlg.portVec=portVec;
	dlg.DoModal();
}
