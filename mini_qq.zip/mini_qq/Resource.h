//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SXC.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SXC_DIALOG                  102
#define IDP_SOCKETS_INIT_FAILED         103
#define CG_IDR_POPUP_SXCDLG             104
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     129
#define IDD_DIALOG2                     130
#define IDI_ICON1                       132
#define IDI_ICON3                       135
#define IDI_ICON4                       137
#define IDI_ICON2                       138
#define IDD_DIALOG3                     139
#define IDR_MENU1                       140
#define IDI_ICON5                       146
#define IDI_ICON6                       148
#define IDC_COMBO1                      1001
#define IDC_TAB1                        1002
#define IDC_BUTTON2                     1003
#define IDC_BUTTON4                     1009
#define IDC_BUTTON5                     1010
#define IDC_TREE1                       1012
#define IDC_EDIT1                       1013
#define IDC_EDIT2                       1014
#define IDC_SEND                        1015
#define IDC_BUTTON1                     1017
#define IDC_START                       1018
#define ID_CHAT                         32771
#define ID_GROUPCHAT                    32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        149
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
