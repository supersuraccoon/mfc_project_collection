#if !defined(AFX_CHILEDLG2_H__98E37F7D_C224_4055_8803_D4E86E4FFE76__INCLUDED_)
#define AFX_CHILEDLG2_H__98E37F7D_C224_4055_8803_D4E86E4FFE76__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ChileDlg2.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CChileDlg2 dialog

class CChileDlg2 : public CDialog
{
// Construction
public:
	CChileDlg2(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CChileDlg2)
	enum { IDD = IDD_DIALOG2 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChileDlg2)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CChileDlg2)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHILEDLG2_H__98E37F7D_C224_4055_8803_D4E86E4FFE76__INCLUDED_)
