// Chat.cpp : implementation file
//

#include "stdafx.h"
#include "SXC.h"
#include "Chat.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

HANDLE hThread;
/////////////////////////////////////////////////////////////////////////////
// CChat dialog


CChat::CChat(CWnd* pParent /*=NULL*/)
	: CDialog(CChat::IDD, pParent)
{
	//{{AFX_DATA_INIT(CChat)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	Start=TRUE;
}


void CChat::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CChat)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
	Closed=FALSE;
}


BEGIN_MESSAGE_MAP(CChat, CDialog)
	//{{AFX_MSG_MAP(CChat)
	ON_BN_CLICKED(IDC_SEND, OnSend)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
	ON_MESSAGE(UM_SOCK,OnSock)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChat message handlers

BOOL CChat::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_btn1.SubclassDlgItem(IDC_SEND,this);
	m_btn1.SetIcon(IDI_ICON5);
	m_btn1.SetTooltipText("����");

	if(SOCKET_ERROR==WSAAsyncSelect(m_socket,m_hWnd,UM_SOCK,FD_READ))
	{
		MessageBox("ע�������ȡ�¼�ʧ�ܣ�");
		return FALSE;
	}

	if (!awaken)
	{
		OnSend();
	}
	else
	{
		Start=FALSE;
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CChat::OnSend() 
{
	// TODO: Add your control notification handler code here
	CString strSend;
	CString str;
	CString strTemp;
	WSABUF wsabuf;
	DWORD dwSend;
	int len;
	SOCKADDR_IN addrTo;

	addrTo.sin_addr.S_un.S_addr=inet_addr("127.0.0.1");
	addrTo.sin_family=AF_INET;
	GetDlgItemText(IDC_EDIT2,strSend);
	if(Start==FALSE)
	{
		str.Format("%s--->%s","��˵:",strSend);
		str+="\r\n";
		strTemp+=str;
		GetDlgItemText(IDC_EDIT1,strTemp);
		strTemp+=str;
		SetDlgItemText(IDC_EDIT1,strTemp);
	}
	if (isGroupChat)
	{
		strSend+="2";
	}
	else
		strSend+="0";
		
	len=strSend.GetLength();
	wsabuf.buf=strSend.GetBuffer(len);
	wsabuf.len=len+1;

	if (isGroupChat==FALSE)
	{
		addrTo.sin_port=htons(port);
		
		if(SOCKET_ERROR==WSASendTo(m_socket,&wsabuf,1,&dwSend,0,
			(SOCKADDR*)&addrTo,sizeof(SOCKADDR),NULL,NULL))
		{
			MessageBox("��������ʧ�ܣ�");
			return;
		}	
		SetDlgItemText(IDC_EDIT2,"");
	}
	else
	{
		for(iter=portVec.begin();iter!=portVec.end();iter++)
		{
			port=atoi(*iter);
			if (isGroupChat&&port==localPort)
			{
				continue;
			}
			addrTo.sin_port=htons(port);
			if(SOCKET_ERROR==WSASendTo(m_socket,&wsabuf,1,&dwSend,0,
				(SOCKADDR*)&addrTo,sizeof(SOCKADDR),NULL,NULL))
			{
				MessageBox("��������ʧ�ܣ�");
				return;
			}
		}		
		SetDlgItemText(IDC_EDIT2,"");
	}
	Start=FALSE;
}

void CChat::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	CString strSend;
	CString str;
	CString strTemp;
	WSABUF wsabuf;
	DWORD dwSend;
	int len;
	SOCKADDR_IN addrTo;

	if (!Closed)
	{
		addrTo.sin_addr.S_un.S_addr=inet_addr("127.0.0.1");
		addrTo.sin_family=AF_INET;
		
		strSend="Close";
		len=strSend.GetLength();
		wsabuf.buf=strSend.GetBuffer(len);
		wsabuf.len=len+1;
		
		if (isGroupChat==FALSE)
		{
			addrTo.sin_port=htons(port);
			
			if(SOCKET_ERROR==WSASendTo(m_socket,&wsabuf,1,&dwSend,0,
				(SOCKADDR*)&addrTo,sizeof(SOCKADDR),NULL,NULL))
			{
				MessageBox("��������ʧ�ܣ�");
				return;
			}	
			SetDlgItemText(IDC_EDIT2,"");
		}
		else
		{
			for(iter=portVec.begin();iter!=portVec.end();iter++)
			{
				port=atoi(*iter);
				addrTo.sin_port=htons(port);
				if(SOCKET_ERROR==WSASendTo(m_socket,&wsabuf,1,&dwSend,0,
					(SOCKADDR*)&addrTo,sizeof(SOCKADDR),NULL,NULL))
				{
					MessageBox("��������ʧ�ܣ�");
					return;
				}
			}		
			SetDlgItemText(IDC_EDIT2,"");
		}
	}

	CDialog::OnClose();
}

void CChat::OnSock(WPARAM wParam,LPARAM lParam)
{
	switch(LOWORD(lParam))
	{
	case FD_READ:
		WSABUF wsabuf;
		wsabuf.buf=new char[200];
		wsabuf.len=200;
		DWORD dwRead;
		DWORD dwFlag=0;
		SOCKADDR_IN addrFrom;
		int len=sizeof(SOCKADDR);
		CString str;
		CString strTemp;

		if(SOCKET_ERROR==WSARecvFrom(m_socket,&wsabuf,1,&dwRead,&dwFlag,
						(SOCKADDR*)&addrFrom,&len,NULL,NULL))
		{
			MessageBox("��������ʧ�ܣ�");
			delete[] wsabuf.buf; 
			return;
		}
		HOSTENT *pHost;
		pHost=gethostbyaddr((char*)&addrFrom.sin_addr.S_un.S_addr,4,AF_INET);

		if (strcmp(wsabuf.buf,"Close")==0)
		{
			Closed=TRUE;
			SendMessage(WM_CLOSE);
		}
		wsabuf.buf[dwRead-2]='\0';

		str.Format("%d--->%s",ntohs(addrFrom.sin_port),wsabuf.buf);
		str+="\r\n";
		GetDlgItemText(IDC_EDIT1,strTemp);
		strTemp+=str;
		SetDlgItemText(IDC_EDIT1,strTemp);

		delete[] wsabuf.buf; 
		break;
	}
}
