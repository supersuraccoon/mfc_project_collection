#if !defined(AFX_CHAT_H__A045E4A4_EADD_476F_B9B1_8C98B3BAAF6F__INCLUDED_)
#define AFX_CHAT_H__A045E4A4_EADD_476F_B9B1_8C98B3BAAF6F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Chat.h : header file
//

#include "BtnST.h"
/////////////////////////////////////////////////////////////////////////////
// CChat dialog
#define UM_SOCK		(WM_USER+2)

class CChat : public CDialog
{
// Construction
public:
	CChat(CWnd* pParent = NULL);   // standard constructor
	CButtonST m_btn1;
	SOCKET m_socket;
	int port;
	int localPort;
	BOOL isGroupChat;
	BOOL awaken;
	vector<CString> portVec;
	vector<CString>::iterator iter;
// Dialog Data
	//{{AFX_DATA(CChat)
	enum { IDD = IDD_DIALOG3 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChat)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CChat)
	virtual BOOL OnInitDialog();
	afx_msg void OnSend();
	afx_msg void OnClose();
	afx_msg void OnSock(WPARAM,LPARAM);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	BOOL Start;
	BOOL Closed;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHAT_H__A045E4A4_EADD_476F_B9B1_8C98B3BAAF6F__INCLUDED_)
