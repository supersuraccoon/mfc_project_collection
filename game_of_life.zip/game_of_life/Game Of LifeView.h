// Game Of LifeView.h : interface of the CGameOfLifeView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_GAMEOFLIFEVIEW_H__6B1994F9_29FD_4077_88D0_C2548184CD10__INCLUDED_)
#define AFX_GAMEOFLIFEVIEW_H__6B1994F9_29FD_4077_88D0_C2548184CD10__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define Pos 32
#define life 500

class CGameOfLifeView : public CView
{
protected: // create from serialization only
	CGameOfLifeView();
	DECLARE_DYNCREATE(CGameOfLifeView)

// Attributes
public:
	CGameOfLifeDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGameOfLifeView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	void SetStatus();
	void RefreshPosition(CDC *pDC);
	void NewLife(int i,int j);
	void Alive(int i,int j);
	void Die(int i,int j);
	int CheckAround(int,int);
	void RadomPosition();
	void InitGameFrame(CDC *pDC);
	virtual ~CGameOfLifeView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CGameOfLifeView)
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CRect m_Rect[Pos][Pos];
	CRect m_rectClient;
	int iState[Pos][Pos];
	int iTotalLife;
	int iMostLife;
	int iOldestGeneration;
	int iChange[Pos][Pos];

	bool bGameStart;
};

#ifndef _DEBUG  // debug version in Game Of LifeView.cpp
inline CGameOfLifeDoc* CGameOfLifeView::GetDocument()
   { return (CGameOfLifeDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GAMEOFLIFEVIEW_H__6B1994F9_29FD_4077_88D0_C2548184CD10__INCLUDED_)
