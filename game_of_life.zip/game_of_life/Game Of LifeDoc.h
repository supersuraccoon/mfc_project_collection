// Game Of LifeDoc.h : interface of the CGameOfLifeDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_GAMEOFLIFEDOC_H__DC63D3F4_777C_4667_A20A_A19B29B7E482__INCLUDED_)
#define AFX_GAMEOFLIFEDOC_H__DC63D3F4_777C_4667_A20A_A19B29B7E482__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CGameOfLifeDoc : public CDocument
{
protected: // create from serialization only
	CGameOfLifeDoc();
	DECLARE_DYNCREATE(CGameOfLifeDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGameOfLifeDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CGameOfLifeDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CGameOfLifeDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GAMEOFLIFEDOC_H__DC63D3F4_777C_4667_A20A_A19B29B7E482__INCLUDED_)
