// Game Of LifeView.cpp : implementation of the CGameOfLifeView class
//

#include "stdafx.h"
#include "Game Of Life.h"

#include "Game Of LifeDoc.h"
#include "Game Of LifeView.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGameOfLifeView

IMPLEMENT_DYNCREATE(CGameOfLifeView, CView)

BEGIN_MESSAGE_MAP(CGameOfLifeView, CView)
	//{{AFX_MSG_MAP(CGameOfLifeView)
	ON_WM_TIMER()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGameOfLifeView construction/destruction

CGameOfLifeView::CGameOfLifeView()
{
	// TODO: add construction code here
	bGameStart=TRUE;
	iTotalLife=0;
	iMostLife=0;
	iOldestGeneration=1;

	for(int i=0;i<Pos;i++)
		for(int j=0;j<Pos;j++)
		{
			if (i==0||i==Pos-1||j==0||j==Pos-1)
			{
				iState[i][j]=-1;
				iChange[i][j]=-1;
			}
			else
			{
				iState[i][j]=0;
				iChange[i][j]=0;
			}
		}
}

CGameOfLifeView::~CGameOfLifeView()
{
}

BOOL CGameOfLifeView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	cs.lpszClass=AfxRegisterWndClass(CS_VREDRAW|CS_HREDRAW,::LoadCursor(NULL,IDC_ARROW),   
		(HBRUSH)   ::GetStockObject(BLACK_BRUSH),::LoadIcon(NULL,IDI_APPLICATION));   


	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CGameOfLifeView drawing

void CGameOfLifeView::OnDraw(CDC* pDC)
{
	CGameOfLifeDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
	if (bGameStart)
	{
		InitGameFrame(pDC);
		RadomPosition();
		bGameStart=FALSE;
	}
	
	RefreshPosition(pDC);

	SetTimer(1,100,NULL);
}

/////////////////////////////////////////////////////////////////////////////
// CGameOfLifeView diagnostics

#ifdef _DEBUG
void CGameOfLifeView::AssertValid() const
{
	CView::AssertValid();
}

void CGameOfLifeView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CGameOfLifeDoc* CGameOfLifeView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGameOfLifeDoc)));
	return (CGameOfLifeDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGameOfLifeView message handlers

void CGameOfLifeView::InitGameFrame(CDC *pDC)
{
	CSize m_size;
	GetClientRect(m_rectClient);
	CPoint m_Pt[Pos-2][Pos-2];

	for(int j=0;j<=m_rectClient.Width();j+=m_rectClient.Width()/(Pos-2))
	{
		pDC->MoveTo(j,0);
		pDC->LineTo(j,m_rectClient.Height());
	}
	for(int i=0;i<=m_rectClient.Height();i+=m_rectClient.Height()/(Pos-2))
	{
		pDC->MoveTo(0,i);
		pDC->LineTo(m_rectClient.Width(),i);
	}
	m_size.cx=m_rectClient.Width()/(Pos-2);
	m_size.cy=m_rectClient.Height()/(Pos-2);

	for(i=0;i<(Pos-2);i++)
		for(int j=0;j<(Pos-2);j++)
		{
			m_Pt[i][j].x=j*m_rectClient.Width()/(Pos-2);
			m_Pt[i][j].y=i*m_rectClient.Height()/(Pos-2);
		}
		for(i=0;i<(Pos-2);i++)
			for(int j=0;j<(Pos-2);j++)
			{
				CRect m_rectTemp(m_Pt[i][j],m_size);
				m_Rect[i][j].CopyRect(m_rectTemp);
			}
	
	RefreshPosition(pDC);
}

void CGameOfLifeView::RadomPosition()
{
	srand((unsigned)time(NULL));
	while(iTotalLife<life)
	{
		int i=1+rand()%(Pos-2);
		int j=1+rand()%(Pos-2);
		if(iState[i][j]==0)
		{
			iState[i][j]=1;
			iTotalLife++;
		}
	}
	iMostLife=iTotalLife;
}

void CGameOfLifeView::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	int neighbor=0;
	for(int i=1;i<(Pos-1);i++)
		for(int j=1;j<(Pos-1);j++)
		{
			if (iState[i][j]!=0)
			{
				neighbor=CheckAround(i,j);
				if (neighbor<=1||neighbor>3)
				{
					Die(i,j);
				}
				else
					Alive(i,j);
			}
			else
			{
				neighbor=CheckAround(i,j);
				if (neighbor==3)
				{
					NewLife(i,j);
				}
			}
		}

	for (i=0;i<Pos;i++)
	{
		for (int j=0;j<Pos;j++)
		{
			iState[i][j]=iChange[i][j];
		}
	}
	SetStatus();
	Invalidate(TRUE);
	
	CView::OnTimer(nIDEvent);
}

void CGameOfLifeView::OnDestroy() 
{
	CView::OnDestroy();
	
	// TODO: Add your message handler code here
	KillTimer(1);
}

int CGameOfLifeView::CheckAround(int i,int j)
{
	int neighbor=0;

	if (iState[i-1][j-1]>0)
	{
		neighbor++;
	}

	if (iState[i-1][j]>0)
	{
		neighbor++;
	}

	if (iState[i-1][j+1]>0)
	{
		neighbor++;
	}

	if (iState[i][j-1]>0)
	{
		neighbor++;
	}

	if (iState[i][j+1]>0)
	{
		neighbor++;
	}

	if (iState[i+1][j-1]>0)
	{
		neighbor++;
	}

	if (iState[i+1][j]>0)
	{
		neighbor++;
	}

	if (iState[i+1][j+1]>0)
	{
		neighbor++;
	}

	return neighbor;
}

void CGameOfLifeView::Die(int i, int j)
{
	iChange[i][j]=0;
	iTotalLife--;
}

void CGameOfLifeView::Alive(int i, int j)
{
	iChange[i][j]++;
	if (iChange[i][j]>iOldestGeneration)
	{
		iOldestGeneration=iChange[i][j];
	}
}

void CGameOfLifeView::NewLife(int i, int j)
{
	iChange[i][j]=1;
	iTotalLife++;
	if (iTotalLife>iMostLife)
	{
		iMostLife=iTotalLife;
	}
}

void CGameOfLifeView::RefreshPosition(CDC *pDC)
{
	CRect temp;
	for(int j=0;j<=m_rectClient.Width();j+=m_rectClient.Width()/(Pos-2))
	{
		pDC->MoveTo(j,0);
		pDC->LineTo(j,m_rectClient.Height());
	}
	for(int i=0;i<=m_rectClient.Height();i+=m_rectClient.Height()/(Pos-2))
	{
		pDC->MoveTo(0,i);
		pDC->LineTo(m_rectClient.Width(),i);
	}

	for(i=1;i<(Pos-1);i++)
		for(int j=1;j<(Pos-1);j++)
		{
			CBrush brush;
			if(iState[i][j]!=0)
			{
				temp=m_Rect[i-1][j-1];
				temp.DeflateRect(5,5);
				brush.CreateSolidBrush(RGB(iState[i][j]*100,iState[i][j]*200,iState[i][j]*300));
				pDC->FillRect(temp,&brush);
				/*if (iState[i][j]==1)
				{
					brush.CreateSolidBrush(RGB(111,123,255));
					pDC->FillRect(temp,&brush);
				}
				else
					if (iState[i][j]==2)
					{
						brush.CreateSolidBrush(RGB(111,123,255));
						pDC->FillRect(temp,&brush);
					}
					else
						if (iState[i][j]==3)
						{
							brush.CreateSolidBrush(RGB(111,123,255));
							pDC->FillRect(temp,&brush);
						}*/
			}
		}
}

void CGameOfLifeView::SetStatus()
{
	CString temp;
	temp.Format("%d",iTotalLife);
	((CMainFrame*)AfxGetMainWnd())->m_wndStatusBar.SetPaneText(0,"Total life:"+temp);
	temp.Format("%d",iMostLife);
	((CMainFrame*)AfxGetMainWnd())->m_wndStatusBar.SetPaneText(1,"Most life:"+temp);
	temp.Format("%d",iOldestGeneration);
	((CMainFrame*)AfxGetMainWnd())->m_wndStatusBar.SetPaneText(2,"Oldest Generation:"+temp);
}
