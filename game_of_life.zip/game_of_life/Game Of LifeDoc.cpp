// Game Of LifeDoc.cpp : implementation of the CGameOfLifeDoc class
//

#include "stdafx.h"
#include "Game Of Life.h"

#include "Game Of LifeDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGameOfLifeDoc

IMPLEMENT_DYNCREATE(CGameOfLifeDoc, CDocument)

BEGIN_MESSAGE_MAP(CGameOfLifeDoc, CDocument)
	//{{AFX_MSG_MAP(CGameOfLifeDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGameOfLifeDoc construction/destruction

CGameOfLifeDoc::CGameOfLifeDoc()
{
	// TODO: add one-time construction code here

}

CGameOfLifeDoc::~CGameOfLifeDoc()
{
}

BOOL CGameOfLifeDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CGameOfLifeDoc serialization

void CGameOfLifeDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CGameOfLifeDoc diagnostics

#ifdef _DEBUG
void CGameOfLifeDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CGameOfLifeDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGameOfLifeDoc commands
